# 42.0.8 — Gemini bağlantı düzeltmesi

42.0.7 sürümünde üretim isteğinin bekleme süresi 115 saniyeden 40 saniyeye düşürülmüştü. Uzun makalelerde bu sınır üretimi erken kesebilir. 42.0.8 önceki 115 saniyelik süreyi geri getirir; seçili modeli, kaydedilen anahtarları ve mevcut işleri korur.

- Uzun isteğe uygun olarak iş kilidi 240 saniyeye çıkarıldı. PHP izin veriyorsa ilgili adımın çalışma süresi 150 saniyeye ayarlanır. Tarayıcı bağlantısı kopsa da çalışan adımın tamamlanıp kaydedilmesine izin verilir.
- Zaman aşımı ile DNS/SSL gibi diğer bağlantı hataları ayrılır. Teknik hata mesajı gösterilir; kayıtlı API anahtarı mesajdan çıkarılır.
- Geçici sağlayıcı hatasında aynı dil 8 saniye sonra bir kez yeniden denenir. Tamamlanan diller yeniden üretilmez. Kalıcı bağlantı hatası otomatik olarak tekrarlanmaz.
- Durmuş adım artık ekranda Generating olarak bırakılmaz; hata ayrıntısı adımın yanında görünür.

Doğrulama: gerçek yerel HTTP sunucusundan 45 saniye gecikmeli yanıt başarıyla alındı. Böylece önceki 40 saniyelik kesimin aşıldığı doğrulandı. Teknik hata/anahtar gizleme kontrolleri, 25 WordPress regresyon kontrolü, 69 PHP dosyasında sözdizimi denetimi ve tarayıcıda otomatik yeniden deneme/hata gösterimi kontrolleri geçti. Gerçek Gemini API anahtarıyla ücretli üretim yapılmadı. Canlı hostingin kendi istek zaman aşımı veya dış bağlantı kısıtlaması tema tarafından tamamen kaldırılamaz; kalan bir bağlantı sorunu artık teknik ayrıntısıyla görülebilir.

Kurulum: WordPress'te tam tema ZIP'iyle 42.0.7 sürümünü değiştirin. Blog Studio'da aynı konu için Create / resume article kullanın; yeni iş açmanız veya API anahtarlarını tekrar girmeniz gerekmez.
