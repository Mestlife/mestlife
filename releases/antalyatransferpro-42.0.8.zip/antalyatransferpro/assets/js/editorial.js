/* Server-persisted stages: a reload or a failed response can resume the same job. */
(function(){
 'use strict';
 const cfg=window.AtpEditorial;if(!cfg)return;
 const $=id=>document.getElementById(id),start=$('atp-start');if(!start)return;
 const order=['en','de','ru','tr'],labels={en:'English',de:'Deutsch',ru:'Русский',tr:'Türkçe'};
 let state=cfg.active||null,newJob=false;
 function status(text){$('atp-status').textContent=text;}
 function step(name,cls,text){const li=document.querySelector('#atp-steps [data-lang="'+name+'"]');li.className=cls;li.textContent=(labels[name]||'Pexels & Save draft')+' — '+text;}
 function render(job){
  const completed=job?job.completed:[];order.forEach(lang=>step(lang,completed.includes(lang)?'done':'',completed.includes(lang)?'Saved':'Waiting'));
  step('image',job&&job.post_id?'done':'',job&&job.post_id?'Draft saved':'Waiting');
  const percent=Math.round((completed.length+(job&&job.post_id?1:0))/5*100);$('atp-fill').style.width=percent+'%';$('atp-percent').textContent=percent+'%';
  $('atp-result').replaceChildren();if(job&&job.post_id){const a=document.createElement('a');a.href=job.edit_url;a.textContent='Edit draft #'+job.post_id;$('atp-result').appendChild(a);if(job.photo_error){const p=document.createElement('p');p.textContent='Image warning: '+job.photo_error;$('atp-result').appendChild(p);}}
 }
 async function request(action,params){
  let response;try{response=await fetch(cfg.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action,nonce:cfg.nonce,...params})});}catch(e){throw Error('Connection interrupted. Resume to check the saved job.');}
  let body;try{body=await response.json();}catch(e){throw Error('Server response interrupted (HTTP '+response.status+'). Resume to check saved progress.');}
  if(!body.success){const d=body.data;const error=Error(typeof d==='string'?d:d&&d.message?d.message:'Request failed (HTTP '+response.status+').');error.code=d&&d.code?d.code:'';throw error;}
  return body.data;
 }
 $('atp-new').addEventListener('click',()=>{state=null;newJob=true;render(null);$('atp-keyword').value='';$('atp-keyword').focus();status('Enter a topic to start a new article.');});
 start.addEventListener('click',async()=>{
  const keyword=$('atp-keyword').value.trim();if(keyword.length<3||keyword.length>130){status('Enter a topic of 3–130 characters.');return;}
  start.disabled=true;$('atp-new').disabled=true;$('atp-keyword').disabled=true;
  try{
   state=await request('atp_ai_start',{keyword,new_job:newJob?'1':''});newJob=false;render(state);
   if(!state.post_id){
    for(const lang of order){if(state.completed.includes(lang))continue;step(lang,'live','Generating…');status('Generating '+labels[lang]+'. Uzun bir yazının hazırlanması yaklaşık iki dakika sürebilir. Tamamlanan diller kaydedilir.');try{state=await request('atp_ai_generate',{job_id:state.job_id,lang});}catch(error){if(error.code!=='retryable')throw error;status(labels[lang]+': '+error.message+' Kaydedilen ilerleme korunuyor; 8 saniye sonra bir kez daha denenecek.');await new Promise(resolve=>setTimeout(resolve,8000));state=await request('atp_ai_generate',{job_id:state.job_id,lang});}render(state);}
    step('image','live','Saving draft…');status('Saving the four-language draft.');state=await request('atp_ai_finalize',{job_id:state.job_id});render(state);
   }
   status('Draft saved. Review facts, sources and all languages before publishing.');
  }catch(e){status(e.message+' Completed stages remain saved. Use Create / resume article to continue.');const live=document.querySelector('#atp-steps .live');if(live){live.className='fail';live.textContent=live.textContent.replace('Generating…','Stopped — '+e.message);}}
  finally{start.disabled=false;$('atp-new').disabled=false;$('atp-keyword').disabled=false;}
 });
 const load=$('atp-load-models');if(load)load.addEventListener('click',async()=>{load.disabled=true;const out=$('atp-model-status');out.textContent='Loading…';try{const models=await request('atp_ai_models',{});$('atp-model-list').replaceChildren(...models.map(value=>{const option=document.createElement('option');option.value=value;return option;}));out.textContent=models.length+' models available. Choose an ID and save settings.';}catch(e){out.textContent=e.message;}finally{load.disabled=false;}});
 render(state);if(state)status(state.post_id?'Your saved draft is ready for review.':'Saved progress found. Resume to continue.');
})();
