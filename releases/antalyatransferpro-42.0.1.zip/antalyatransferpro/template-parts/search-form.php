<?php if(!defined('ABSPATH'))exit; /* Shared booking search form. Expects \$ayt (airport row or null). */ ?>
      <form data-min-notice="<?php echo (int)(function_exists('deniz_min_notice_hours')?deniz_min_notice_hours():8); ?>" id="deniz-transfer-form" class="twt-home-search" action="<?php echo esc_url(deniz_url('transfer-search')); ?>" method="get" data-airport-name="<?php echo esc_attr($ayt?twt_entity_name($ayt,'airport').' ('.$ayt->iata.')':deniz_t('antalya_airport').' (AYT)'); ?>" data-airport-lat="<?php echo esc_attr($ayt?$ayt->lat:'36.8987'); ?>" data-airport-lng="<?php echo esc_attr($ayt?$ayt->lng:'30.8005'); ?>" data-airport-id="<?php echo esc_attr($ayt?$ayt->id:0); ?>">
        <input type="hidden" name="from_lat"><input type="hidden" name="from_lng"><input type="hidden" name="to_lat"><input type="hidden" name="to_lng"><input type="hidden" name="airport_id" value="<?php echo esc_attr($ayt?$ayt->id:0); ?>"><input type="hidden" name="region_id"><input type="hidden" name="hotel_id"><input type="hidden" name="direction" value="oneway"><input type="hidden" name="service_mode" value="airport"><input type="hidden" name="currency" value="<?php echo esc_attr(deniz_current_currency()); ?>">

        <div class="twt-home-tabs" role="group" aria-label="<?php echo esc_attr(deniz_t('transfer')); ?>">
          <button type="button" class="active" data-transfer-mode="airport"><?php echo twt_icon('plane'); ?> <span><?php echo esc_html(deniz_t('airport_to_hotel')); ?></span></button>
          <button type="button" data-transfer-mode="hotel"><?php echo twt_icon('hotel'); ?> <span><?php echo esc_html(deniz_t('hotel_to_airport')); ?></span></button>
          <button type="button" data-transfer-mode="return"><?php echo twt_icon('return'); ?> <span><?php echo esc_html(deniz_t('round_trip')); ?></span></button>
        </div>

        <div class="twt-home-locations">
          <label class="twt-home-field"><span data-from-label><?php echo esc_html(deniz_t('from_airport')); ?></span><div><b><?php echo twt_icon('plane'); ?></b><input required data-geocode name="from" autocomplete="off" value="<?php echo esc_attr($ayt?twt_entity_name($ayt,'airport').' ('.$ayt->iata.')':deniz_t('antalya_airport').' (AYT)'); ?>" placeholder="<?php echo esc_attr(deniz_t('from_ph')); ?>" data-lat="<?php echo esc_attr($ayt?$ayt->lat:'36.8987'); ?>" data-lng="<?php echo esc_attr($ayt?$ayt->lng:'30.8005'); ?>" data-airport-id="<?php echo esc_attr($ayt?$ayt->id:0); ?>"></div></label>
          <label class="twt-home-field"><span data-to-label><?php echo esc_html(deniz_t('to_destination')); ?></span><div><b><?php echo twt_icon('pin'); ?></b><input required data-geocode name="to" autocomplete="off" placeholder="<?php echo esc_attr(deniz_t('select_destination')); ?>"></div></label>
        </div>

        <div class="twt-home-meta-row">
          <label class="twt-home-field small"><span><?php echo esc_html(deniz_t('date')); ?></span><div><b><?php echo twt_icon('calendar'); ?></b><input type="date" name="date" required></div></label>
          <label class="twt-home-field small"><span><?php echo esc_html(deniz_t('time')); ?></span><div><b><?php echo twt_icon('clock'); ?></b><?php twt_time_select('time',true); ?></div></label>
          <label class="twt-home-field small"><span><?php echo esc_html(deniz_t('passenger')); ?></span><div><b><?php echo twt_icon('users'); ?></b><select name="passengers"><?php for($i=1;$i<=16;$i++): ?><option value="<?php echo $i; ?>" <?php selected($i,2); ?>><?php echo esc_html($i===1?deniz_t('passenger_single'):sprintf(deniz_t('passenger_count'),$i)); ?></option><?php endfor; ?></select></div></label>
        </div>
        <div class="return-row twt-home-return" hidden>
          <label class="twt-home-field small"><span><?php echo esc_html(deniz_t('return_date')); ?></span><div><input type="date" name="return_date"></div></label>
          <label class="twt-home-field small"><span><?php echo esc_html(deniz_t('return_time')); ?></span><div><?php twt_time_select('return_time'); ?></div></label>
        </div>
        <button class="twt-home-submit" type="submit"><span><?php echo twt_icon('search'); ?></span><?php echo esc_html(atp_experience_text('search_cta')); ?><b>→</b></button>
        <p class="atp-form-error" role="alert" tabindex="-1" hidden></p>
      </form>
