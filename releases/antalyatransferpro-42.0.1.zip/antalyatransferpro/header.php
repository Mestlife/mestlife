<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><?php wp_head(); ?></head><body <?php body_class('twt-theme'); ?>><?php wp_body_open(); ?><a class="screen-reader-text atp-skip" href="#main">Skip to content</a><?php
$lang=deniz_current_lang();$currency=deniz_current_currency();$currencies=deniz_currencies();
$nav_items=[
 [deniz_t('home'),deniz_url()],
 [atp_l('nav_airport'),atp_landing_url('airport')],
 [atp_l('nav_regions'),atp_landing_url('hub')],
 [atp_l('nav_hotels'),deniz_url('hotels')],
 [deniz_t('our_fleet'),deniz_url('vehicles')],
 [deniz_t('contact'),get_page_by_path('contact')?deniz_url('contact'):'#contact'],
];
?>
<header class="twt-shell-header">
 <div class="twt-shell-inner">
  <a class="twt-shell-logo" href="<?php echo esc_url(deniz_url()); ?>" aria-label="<?php echo esc_attr(twt_brand_name()); ?>"><img src="<?php echo esc_url(twt_brand_logo_url()); ?>" alt="<?php echo esc_attr(twt_brand_name().' – '.atp_l('nav_airport')); ?>" width="900" height="102" fetchpriority="high"></a>
  <nav class="twt-shell-nav" aria-label="<?php echo esc_attr(deniz_t('main_navigation')); ?>"><?php foreach($nav_items as [$label,$url]): ?><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></nav>
  <div class="twt-shell-tools">
   <details class="twt-picker" data-header-picker>
    <summary aria-label="<?php echo esc_attr(deniz_t('language')); ?>" aria-expanded="false" aria-controls="twt-language-options">
     <svg class="twt-picker-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 6h14M5 18h14"/></svg>
     <span class="twt-picker-value"><small><?php echo esc_html(deniz_t('language')); ?></small><b><?php echo esc_html(strtoupper($lang)); ?></b></span>
     <svg class="twt-picker-chevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg>
    </summary>
    <div class="twt-picker-menu" id="twt-language-options" aria-label="<?php echo esc_attr(deniz_t('language')); ?>">
     <div class="twt-picker-heading"><?php echo esc_html(deniz_t('language')); ?></div>
     <?php foreach(deniz_languages() as $code=>$info): ?>
      <a href="<?php echo esc_url(deniz_same_page_lang_url($code)); ?>" lang="<?php echo esc_attr($code); ?>" <?php if($lang===$code) echo 'aria-current="true"'; ?>><span class="twt-picker-code"><?php echo esc_html(strtoupper($code)); ?></span><span><?php echo esc_html($info['name']); ?></span><span class="twt-picker-check" aria-hidden="true"><?php echo $lang===$code?'✓':''; ?></span></a>
     <?php endforeach; ?>
    </div>
   </details>
   <details class="twt-picker twt-picker-currency" data-header-picker>
    <summary aria-label="<?php echo esc_attr(deniz_t('currency')); ?>" aria-expanded="false" aria-controls="twt-currency-options">
     <span class="twt-picker-symbol" aria-hidden="true"><?php echo esc_html($currencies[$currency]['symbol']); ?></span>
     <span class="twt-picker-value"><small><?php echo esc_html(deniz_t('currency')); ?></small><b><?php echo esc_html($currency); ?></b></span>
     <svg class="twt-picker-chevron" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg>
    </summary>
    <div class="twt-picker-menu" id="twt-currency-options" aria-label="<?php echo esc_attr(deniz_t('currency')); ?>">
     <div class="twt-picker-heading"><?php echo esc_html(deniz_t('currency')); ?></div>
     <?php foreach($currencies as $code=>$info): ?>
      <a rel="nofollow" href="<?php echo esc_url(deniz_same_page_currency_url($code)); ?>" <?php if($currency===$code) echo 'aria-current="true"'; ?>><span class="twt-picker-code"><?php echo esc_html($info['symbol']); ?></span><span><b><?php echo esc_html($code); ?></b><small><?php echo esc_html(deniz_t('currency_'.strtolower($code))); ?></small></span><span class="twt-picker-check" aria-hidden="true"><?php echo $currency===$code?'✓':''; ?></span></a>
     <?php endforeach; ?>
    </div>
   </details>
   <a class="atp-header-phone" href="<?php echo esc_url(atp_phone_link()); ?>" aria-label="<?php echo esc_attr(atp_contact()['phone_display']); ?>"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z"/></svg><span><?php echo esc_html(atp_contact()['phone_display']); ?></span></a>
   <a class="twt-shell-book" href="<?php echo esc_url(deniz_url().'#transfer-search'); ?>"><?php echo esc_html(deniz_t('book_transfer')); ?> <span aria-hidden="true">→</span></a>
   <button class="app-menu-toggle twt-shell-toggle" type="button" aria-label="<?php echo esc_attr(deniz_t('menu')); ?>" aria-controls="twt-mobile-menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
 </div>
 <div class="app-mobile-drawer twt-shell-drawer" id="twt-mobile-menu"><nav aria-label="<?php echo esc_attr(deniz_t('mobile_navigation')); ?>"><?php foreach($nav_items as [$label,$url]): ?><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($label); ?> <span aria-hidden="true">→</span></a><?php endforeach; ?></nav></div>
</header>
