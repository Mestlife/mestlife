# 41.3.0 – 4 Dilli Yazı Stüdyosu

- Yazılar → **4 Dilli Yazı Ekle**: TR/EN/DE/RU içeriğini tek JSON ile ekler veya günceller.
  - Öne çıkan görsel + sıralı içerik görselleri (`{{image:1}}`, `{{image:2}}` … yer tutucuları, dile göre alt metin).
  - Canlı önizleme: dil sekmeleri, URL, SEO title/meta uzunluğu, kelime sayısı, anahtar kelime yoğunluğu (spam uyarısı), H2/H3, iç link, SSS sayısı.
  - Taslak / incelemede / hemen yayınla / zamanla. Hatalı JSON kaydedilmez, yazdığınız kaybolmaz.
  - Kaynak JSON yazıda saklanır: yazı listesinde "4 dilde düzenle" ile geri açılır.
  - Claude'a verilecek hazır istek şablonu.
- Dil başına slug: `/en/blog/{en-slug}/` vb. Yanlış dildeki slug 301 ile doğruya yönlenir. Hreflang, canonical, dil değiştirici ve sitemap dile özel slug kullanır.
- Klasik EN/DE/RU kutusuna "URL Slug" alanı eklendi.
- Yazıya özel, dile göre SSS (FAQPage şeması ile), öne çıkan görselde dile göre alt metin.
