<?php
if(!defined('ABSPATH'))exit;
$l=atp_landing_current(); if(!$l){ get_template_part('index'); return; }
$key=$l['key']; $lang=$l['lang']; $m=atp_meta($key,$lang); $c=atp_ctx($key,$lang); $is_dest=atp_is_dest($key); $data=atp_ld();
$region=$is_dest?atp_db_region($key):null; $ayt=atp_ayt(); $p=$c['p']; $region_content=($is_dest&&$region&&function_exists('deniz_region_content_get'))?deniz_region_content_get($region->id,$lang):null;
get_header();
?>
<main id="main" class="atp-landing-page">
 <section class="atp-hero">
  <?php $hero_img=($region&&function_exists('atp_region_image'))?atp_region_image($region,'full'):null; $hero_url=($hero_img&&$hero_img['real'])?$hero_img['url']:get_template_directory_uri().'/assets/images/hero-antalyatransfer-clean.jpg'; ?>
  <div class="atp-hero-bg" style="background-image:url('<?php echo esc_url($hero_url); ?>')"<?php if($hero_img&&$hero_img['real']): ?> role="img" aria-label="<?php echo esc_attr($hero_img['alt']); ?>"<?php endif; ?>></div>
  <div class="wrap atp-hero-grid">
   <div class="atp-hero-copy">
    <nav class="atp-breadcrumb" aria-label="Breadcrumb"><a href="<?php echo esc_url(deniz_url()); ?>"><?php echo esc_html(atp_l('home')); ?></a><span aria-hidden="true">/</span><?php if($key!=='hub'): ?><a href="<?php echo esc_url(atp_landing_url('hub')); ?>"><?php echo esc_html(atp_meta('hub')['h1']); ?></a><span aria-hidden="true">/</span><?php endif; ?><span aria-current="page"><?php echo esc_html($m['h1']); ?></span></nav>
    <div class="atp-kicker">TÜRSAB <?php echo esc_html(atp_contact()['tursab']); ?> · <?php echo esc_html(twt_brand_name()); ?></div>
    <h1><?php echo esc_html($m['h1']); ?></h1>
    <?php if($m['sub']): ?><p class="atp-sub"><?php echo esc_html($m['sub']); ?></p><?php endif; ?>
    <p class="atp-lead"><?php echo esc_html($m['intro']); ?></p>
    <?php if($region_content&&!empty($region_content->intro)): $authored_intro=atp_available_service_text(wp_strip_all_tags($region_content->intro),$c,true);if($authored_intro!==''&&$authored_intro!==$m['intro']): ?><p class="atp-region-intro"><?php echo esc_html($authored_intro); ?></p><?php endif;endif; ?>
    <div class="atp-facts">
     <?php if($c['km']): ?><div><small><?php echo esc_html(atp_l('distance')); ?></small><b><?php echo (int)$c['km'].' '.esc_html(atp_l('km')); ?></b></div><?php endif; ?>
     <?php if($c['min']): ?><div><small><?php echo esc_html(atp_l('duration')); ?></small><b>~<?php echo (int)$c['min'].' '.esc_html(atp_l('min')); ?></b></div><?php endif; ?>
     <?php if($is_dest && ($c['shared']??null)!==null): ?><div class="atp-fare-fact atp-fare-shared"><small><?php echo esc_html(deniz_t('shared_transfer')); ?> · <?php echo esc_html(deniz_t('per_person')); ?></small><b><?php echo esc_html(deniz_money($c['shared'])); ?></b></div><?php endif; ?>
     <?php if($is_dest && ($c['private']??null)!==null): ?><div class="atp-fare-fact atp-fare-private"><small><?php echo esc_html(deniz_t('private_transfer')); ?> · <?php echo esc_html(deniz_t('per_vehicle')); ?></small><b><?php echo esc_html(deniz_money($c['private'])); ?></b></div><?php endif; ?>
     <?php if(!$is_dest || (($c['shared']??null)===null && ($c['private']??null)===null)): ?><div><small><?php echo esc_html(atp_l('airport')); ?></small><b><?php echo esc_html($c['air']); ?></b></div><div><small><?php echo esc_html(atp_l('from_price')); ?></small><b><?php echo $c['price']?esc_html(deniz_money($c['price'])):'<a href="#atp-book">'.esc_html(atp_l('check_price')).'</a>'; ?></b></div><?php endif; ?>
    </div>
    <?php if($c['km']): ?><p class="atp-note"><?php echo esc_html(deniz_t('route_estimate_note')); ?></p><?php endif; ?>
    <div class="atp-hero-actions"><a class="atp-btn" href="#atp-book"><?php echo esc_html(atp_l('book_now')); ?> →</a><a class="atp-btn atp-btn-ghost" href="<?php echo esc_url(atp_whatsapp_link($m['h1'])); ?>" target="_blank" rel="noopener nofollow">WhatsApp</a><a class="atp-btn atp-btn-ghost" href="<?php echo esc_url(atp_phone_link()); ?>"><?php echo esc_html(atp_contact()['phone_display']); ?></a></div>
   </div>
   <div class="atp-hero-form twt-home-hero" id="atp-book">
    <h2 class="atp-form-title"><?php echo esc_html(atp_l('cta_h',null,['p'=>$p])); ?></h2>
    <?php if($region&&$ayt&&function_exists('twt_route_search')){ twt_route_search($ayt,$region); } else { include get_template_directory().'/template-parts/search-form.php'; } ?>
   </div>
  </div>
 </section>

 <section class="atp-section">
  <div class="wrap atp-reading">
   <div class="knowledge-answer atp-quick"><div class="knowledge-answer-label"><?php echo esc_html(atp_l('quick')); ?></div>
   <?php if($is_dest): $t=$data['dt'][$lang]; $v=['p'=>$p,'km'=>$c['km'],'min'=>$c['min'],'pricephrase'=>atp_offer_phrase($c,$lang)]; ?>
    <h2><?php echo esc_html(atp_fill($t['qa_q'],$v)); ?></h2><p><?php echo esc_html(atp_offer_quick($c,$lang)); ?></p>
   <?php else: ?>
    <h2><?php echo esc_html($m['h1']); ?></h2><p><?php echo esc_html($m['intro'].' '.atp_offer_phrase($c,$lang)); ?></p>
   <?php endif; ?>
   </div>

   <?php if($is_dest): $t=$data['dt'][$lang]; $v=['p'=>$p,'km'=>$c['km'],'min'=>$c['min']]; ?>
    <h2><?php echo esc_html(atp_fill($t['about_h'],$v)); ?></h2>
    <?php if($region_content&&!empty($region_content->about_content)): ?><div class="twt-authored-content"><?php echo atp_available_service_html($region_content->about_content,$c); ?></div><?php else: ?><p><?php echo esc_html(atp_available_service_text($data['dest'][$key]['about'][$lang]??'',$c)); ?> <?php echo esc_html(atp_available_service_text(atp_fill($t['about2'],$v),$c)); ?></p><?php endif; ?>
    <h2><?php echo esc_html(atp_fill($t['route_h'],$v)); ?></h2>
    <?php if($region_content&&!empty($region_content->route_content)): ?><div class="twt-authored-content"><?php echo atp_available_service_html($region_content->route_content,$c); ?></div><?php else: ?><p><?php echo esc_html(atp_available_service_text(atp_fill(($c['km']&&$c['min'])?$t['route']:$t['route2'],$v),$c)); ?></p><?php endif; ?>
   <?php else: foreach($m['body'] as $para): ?>
    <p><?php echo esc_html($para); ?></p>
   <?php endforeach; endif; ?>
  </div>
 </section>

 <section class="atp-section atp-soft">
  <div class="wrap">
   <h2 class="atp-center"><?php echo esc_html(atp_l('steps_h')); ?></h2>
   <ol class="atp-steps"><?php foreach(atp_l('steps') as $i=>$s): ?><li><span><?php echo '0'.($i+1); ?></span><b><?php echo esc_html($s[0]); ?></b><p><?php echo esc_html($s[1]); ?></p></li><?php endforeach; ?></ol>
  </div>
 </section>

 <?php if($region&&$ayt&&function_exists('deniz_region_price_rows')&&function_exists('twt_public_prices')): ?>
 <section class="atp-section"><div class="wrap atp-reading"><h2><?php echo esc_html(atp_l('prices_h')); ?></h2><?php twt_public_prices(deniz_region_price_rows($region->id,$ayt->id)); ?></div></section>
 <?php endif; ?>

 <?php if($region&&function_exists('twt_hotel_url')): global $wpdb; $tb=deniz_tables(); $hotels=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$tb['hotels']} WHERE active=1 AND region_id=%d ORDER BY name LIMIT 18",$region->id)); if($hotels): ?>
 <section class="atp-section"><div class="wrap"><h2><?php echo esc_html(atp_l('hotels_h',null,['p'=>$p])); ?></h2><div class="hotel-link-grid"><?php foreach($hotels as $h): ?><a href="<?php echo esc_url(twt_hotel_url($h)); ?>"><span><b><?php echo esc_html(twt_entity_name($h,'hotel')); ?></b><small><?php echo esc_html($h->address??''); ?></small></span><em>→</em></a><?php endforeach; ?></div></div></section>
 <?php endif; endif; ?>

 <section class="atp-section atp-why">
  <div class="wrap">
   <h2 class="atp-center"><?php echo esc_html(atp_l('why_h')); ?></h2>
   <ul class="atp-why-grid"><?php foreach(atp_l('why') as $w): ?><li><?php echo esc_html(atp_fill($w,[])); ?></li><?php endforeach; ?></ul>
  </div>
 </section>

 <?php if(!$is_dest): ?>
 <section class="atp-section"><div class="wrap"><h2><?php echo esc_html(atp_l('all_dest_h')); ?></h2><?php atp_dest_table($lang); ?></div></section>
 <?php endif; ?>

 <?php if(function_exists('atp_reviews_section')) atp_reviews_section('landing'); ?>

 <section class="atp-section atp-soft"><div class="wrap atp-reading">
  <?php atp_faq_html(atp_faq_items($lang,$c),$is_dest?atp_l('faq_h',null,['p'=>$p]):atp_l('faq_h_gen')); ?>
 </div></section>

 <section class="atp-section">
  <div class="wrap">
   <?php if($is_dest): ?><h2><?php echo esc_html(atp_l('related_h')); ?></h2><?php atp_link_cards(array_slice(atp_dest_sorted_by($key),0,12),$lang); ?><?php endif; ?>
   <h2><?php echo esc_html(atp_l('services_h')); ?></h2>
   <?php atp_link_cards(array_values(array_filter(atp_service_keys(),fn($k)=>$k!==$key)),$lang); ?>
   <?php if($is_dest): ?><p class="atp-center"><a class="atp-btn atp-btn-line" href="<?php echo esc_url(atp_landing_url('hub')); ?>"><?php echo esc_html(atp_l('see_all')); ?> →</a></p><?php endif; ?>
  </div>
 </section>

 <section class="atp-section atp-soft"><div class="wrap atp-reading"><?php atp_contact_block($lang); ?></div></section>
</main>
<?php get_footer(); ?>
