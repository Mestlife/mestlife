<?php /* Template Name: Vehicle Selection */
if (!defined('ABSPATH')) exit;
$target=deniz_booking_page_url('template-transfer-search.php');
$query=$_GET;
wp_safe_redirect(add_query_arg(array_map('sanitize_text_field',$query),$target));
exit;
