# 41.2.7 – Sitemap Pro

- Yeni `inc/sitemap-pro.php`: tek, birleşik XML sitemap sistemi. GSC'ye yalnızca `/sitemap.xml` gönderilir.
- `/sitemap.xml` artık yönlendirme değil, doğrudan 200 dönen sitemap index.
- Alt sitemap'ler: `sitemap-pages.xml`, `sitemap-archives.xml`, `sitemap-content-N.xml`, `sitemap-hotels-N.xml`; tümünde hreflang (tr/en/de/ru + x-default).
- WP çekirdek sitemap kapatıldı (dil öneki olmayan, yönlendiren URL'ler üretiyordu).
- Eski adresler çalışmaya devam ediyor: wp-sitemap.xml, sitemap_index.xml, landing-sitemap.xml, hotel-sitemap*.xml.
- İstek `init` aşamasında REQUEST_URI'den karşılanır: kalıcı bağlantı yenilemeye bağlı değil, dil/canonical yönlendirmesine takılmaz; çıktı tamponları temizlenir (BOM/boşluk XML'i bozamaz), doğru `application/xml` başlığı.
- İçerik kaydedildiğinde/silindiğinde sitemap önbelleği anında yenilenir (canlı).
- `/tr/airports/` ve `/tr/airports/{slug}/` rewrite kuralları eklendi (önceden 404).
- Hariç tutulanlar: rezervasyon/ödeme sayfaları, şifreli, noindex (Yoast/RankMath), silinmiş SQL kaynaklı içerik, iç içe sayfalar, boş arşivler, tekrar eden URL'ler.
- Tarayıcıda okunabilir görünüm (`sitemap.xsl`).
- Araçlar → Sitemap Pro: URL sayıları, önbellek temizleme, 200 sağlık kontrolü.
- robots.txt tek satır: `Sitemap: https://…/sitemap.xml`.
