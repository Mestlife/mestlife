# 41.4.0 – Güven ve SEO düzeltmeleri

## Özel / paylaşımlı çelişkisi
- "Tüm transferler özeldir, paylaşımlı servis yoktur" diyen metinler (bölge sayfaları, Antalya Transfer sayfası, SSS; TR/EN/DE/RU) iki seçeneği doğru anlatacak şekilde yeniden yazıldı.
- "Özel mi, paylaşımlı mı?" SSS cevabı artık canlı fiyat matrisinden üretiliyor (ana sayfa, otel ve rota sayfaları dahil).
- Ana sayfa araç kartı: varsa özel araç öne çıkar; yalnızca shuttle varsa "Paylaşımlı shuttle" etiketi ve uygun açıklama gösterilir.
- Ana sayfa bölge kartlarındaki sabit "Özel transfer bölgesi" yazısı kaldırıldı; yerine bölgenin kısa tanıtımı geldi.

## Tek URL / bölge (kannibalizasyon)
- /transfers/ayt-to-{bölge}-transfer/ ve bölge (location) sayfaları canonical + hreflang ile /antalya-{bölge}-transfer/ sayfasını gösterir.
- Bu sayfalar sitemap'ten çıkarıldı (Sitemap Pro önbellek sürümü 2.2).
- Ana sayfa kartları ve rota şeridi doğrudan anahtar kelimeli sayfalara linkler.
- Otel bazlı rota sayfaları değişmedi. Kapatmak için: update_option('atp_canonical_consolidation','0').

## Meta ve SSS
- Ana sayfa meta açıklamasındaki "Home ·" ön eki kaldırıldı.
- Fiyat SSS'sinde tekrar eden cümle düzeltildi; cevap canlı "başlangıç" fiyatlarını verir.
- Ana sayfada tekrar eden "sürücümle nerede buluşurum" sorusu kaldırıldı.

## Görseller
- Yeni panel: Antalya Transfer Pro › Bölge Görselleri (her bölgeye Medya Kütüphanesi'nden gerçek fotoğraf).
- Otomatik alt metin (ör. "Antalya Havalimanı – Belek transferi"); bölge kartları artık arka plan yerine <img> kullanır.
- Rota şeridinin sıralaması düzeltildi (önceden hep alfabetik çıkıyordu).

## Google yorumları
- Yeni panel: Antalya Transfer Pro › Google Yorumları (puan, sayı, link, yorum listesi).
- Yorum bölümü ana sayfada ve tüm SEO bölge sayfalarında gösterilir.
- Kendi sayfaya kopyalanan yorumlar Google kurallarına göre yıldızlı sonuç alamayacağı için AggregateRating şeması bilerek eklenmedi.

## Teknik
- WordPress sürüm etiketi gizlendi.
- ?currency= adresleri noindex,follow; para birimi linkleri rel="nofollow".
