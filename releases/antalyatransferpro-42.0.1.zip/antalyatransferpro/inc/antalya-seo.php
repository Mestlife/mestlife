<?php
if (!defined('ABSPATH')) exit;

function deniz_antalya_routes(){
 return [
  ['slug'=>'antalya-airport-to-lara-transfer','name'=>'Antalya Airport to Lara Transfer','area'=>'Lara / Kundu','km'=>15,'min'=>20,'price'=>30],
  ['slug'=>'antalya-airport-to-belek-transfer','name'=>'Antalya Airport to Belek Transfer','area'=>'Belek','km'=>35,'min'=>40,'price'=>40],
  ['slug'=>'antalya-airport-to-kemer-transfer','name'=>'Antalya Airport to Kemer Transfer','area'=>'Kemer','km'=>55,'min'=>60,'price'=>50],
  ['slug'=>'antalya-airport-to-side-transfer','name'=>'Antalya Airport to Side Transfer','area'=>'Side','km'=>65,'min'=>70,'price'=>55],
  ['slug'=>'antalya-airport-to-manavgat-transfer','name'=>'Antalya Airport to Manavgat Transfer','area'=>'Manavgat','km'=>70,'min'=>75,'price'=>60],
  ['slug'=>'antalya-airport-to-alanya-transfer','name'=>'Antalya Airport to Alanya Transfer','area'=>'Alanya','km'=>125,'min'=>120,'price'=>85],
  ['slug'=>'antalya-airport-to-beldibi-transfer','name'=>'Antalya Airport to Beldibi Transfer','area'=>'Beldibi','km'=>42,'min'=>50,'price'=>45],
  ['slug'=>'antalya-airport-to-goynuk-transfer','name'=>'Antalya Airport to Göynük Transfer','area'=>'Göynük','km'=>47,'min'=>55,'price'=>48],
  ['slug'=>'antalya-airport-to-camyuva-transfer','name'=>'Antalya Airport to Çamyuva Transfer','area'=>'Çamyuva','km'=>62,'min'=>70,'price'=>55],
  ['slug'=>'antalya-airport-to-tekirova-transfer','name'=>'Antalya Airport to Tekirova Transfer','area'=>'Tekirova','km'=>73,'min'=>80,'price'=>60],
  ['slug'=>'antalya-airport-to-evrenseki-transfer','name'=>'Antalya Airport to Evrenseki Transfer','area'=>'Evrenseki','km'=>58,'min'=>60,'price'=>50],
  ['slug'=>'antalya-airport-to-kumkoy-transfer','name'=>'Antalya Airport to Kumköy Transfer','area'=>'Kumköy','km'=>62,'min'=>65,'price'=>52],
 ];
}

add_action('after_switch_theme',function(){
 if(get_option('deniz_antalya_seeded')) return;
 $dest=get_page_by_path('antalya',OBJECT,'destination');
 if(!$dest){
  $id=wp_insert_post(['post_type'=>'destination','post_status'=>'publish','post_title'=>'Antalya','post_name'=>'antalya','post_excerpt'=>'Antalya Airport transfer, private transfer and VIP transfer services to Antalya resorts and hotels.','post_content'=>'Antalya is one of Türkiye’s busiest holiday regions. Antalya Transfer Pro (TÜRSAB 18926) provides private airport transfer services from Antalya Airport (AYT) to Lara, Kundu, Belek, Kemer, Side, Manavgat, Alanya and surrounding resort areas. Choose your destination, compare vehicle options and book a fixed-price airport transfer before your flight.']);
  if($id){ update_post_meta($id,'seo_title','Antalya Airport Transfer | Private & VIP Transfer'); update_post_meta($id,'seo_description','Book Antalya Airport transfer to Lara, Belek, Kemer, Side, Manavgat and Alanya. Fixed-price private and VIP transfer with 24/7 support.'); update_post_meta($id,'hero_subtitle','Antalya Airport transfers to hotels, resorts and holiday areas across Antalya.'); }
 }
 foreach(deniz_antalya_routes() as $r){
  if(get_page_by_path($r['slug'],OBJECT,'transfer-route')) continue;
  $id=wp_insert_post(['post_type'=>'transfer-route','post_status'=>'publish','post_title'=>$r['name'],'post_name'=>$r['slug'],'post_excerpt'=>$r['name'].' with fixed-price private vehicles, meet & greet and direct hotel drop-off.','post_content'=>'<h2>'.$r['name'].'</h2><p>Travel directly from Antalya Airport (AYT) to '.$r['area'].' with a pre-booked private transfer. Your driver meets you for your scheduled arrival and takes you directly to your hotel or accommodation without shared shuttle stops.</p><h2>Private transfer from Antalya Airport to '.$r['area'].'</h2><p>This route is suitable for couples, families and groups who want a fixed-price Antalya airport transfer with a vehicle selected for their passenger and luggage requirements. Journey time can change with traffic, season and the exact hotel location.</p>']);
  if($id){
   update_post_meta($id,'airport_code','AYT');
   update_post_meta($id,'seo_title',substr($r['name'].' | Private Transfer',0,60));
   update_post_meta($id,'seo_description',$r['name'].' with fixed pricing, private vehicles and direct hotel drop-off. Check route details and reserve online with Antalya Transfer Pro.');
   update_post_meta($id,'hero_subtitle','Private Antalya Airport transfer to '.$r['area'].' with fixed pricing and direct hotel drop-off.');
  }
 }
 update_option('deniz_antalya_seeded',1);
 flush_rewrite_rules();
});

function deniz_keyword_clusters(){
 return [
  'Antalya airport transfer','Antalya airport private transfer','Antalya VIP transfer','Antalya airport taxi transfer',
  'Antalya Airport to Belek transfer','Antalya Airport to Kemer transfer','Antalya Airport to Side transfer','Antalya Airport to Alanya transfer',
  'Antalya Airport to Lara transfer','Antalya Airport to Kundu transfer','Antalya Airport to Manavgat transfer','Antalya hotel transfer'
 ];
}

add_action('init',function(){ add_rewrite_rule('^llms\.txt$','index.php?deniz_llms=1','top'); });
add_filter('query_vars',function($v){$v[]='deniz_llms';return $v;});
/* llms.txt is served by inc/seo-premium.php (single source, correct language URLs). */

/* Remove fixed seed values from older installs so live route metrics are used. */
add_action('init',function(){ if(get_option('atp_unseed_v1'))return; foreach(deniz_antalya_routes() as $r){ $p=get_page_by_path($r['slug'],OBJECT,'transfer-route'); if(!$p)continue; foreach(['distance_km'=>'km','duration_min'=>'min','from_price'=>'price'] as $mk=>$rk){ if((string)get_post_meta($p->ID,$mk,true)===(string)$r[$rk]) delete_post_meta($p->ID,$mk);} } update_option('atp_unseed_v1',1,false); },50);
add_action('init',function(){ if(get_option('atp_unseed_faq_v1'))return; foreach(deniz_antalya_routes() as $r){ $p=get_page_by_path($r['slug'],OBJECT,'transfer-route'); if(!$p)continue; foreach(['faq_1_q','faq_1_a','faq_2_q','faq_2_a'] as $k) delete_post_meta($p->ID,$k); } update_option('atp_unseed_faq_v1',1,false); },51);
