<?php
/**
 * Antalya Transfer Pro SEO hardening (no SEO plugin required).
 * Deliberately conservative: preserves public routes, pricing, booking and existing language URLs.
 */
if (!defined('ABSPATH')) exit;

function atp_seo_exclude_post($id) {
    $id = (int) $id;
    if (!$id) return false;
    $post = get_post($id);
    if (!$post || $post->post_status !== 'publish' || !empty($post->post_password)) return true;
    if (get_post_meta($id, '_atp_seo_noindex', true) === '1') return true;
    if ($post->post_type === 'page' && in_array($post->post_name, ['sample-page'], true)) return true;
    if ($post->post_type === 'post' && in_array($post->post_name, ['hello-world'], true)) return true;
    if ($post->post_type === 'page') {
        $tpl = get_page_template_slug($id);
        if (in_array($tpl, ['template-transfer-search.php', 'template-passenger-details.php', 'template-booking-confirmation.php'], true)) return true;
    }
    return false;
}

add_filter('wp_robots', function ($robots) {
    $id = get_queried_object_id();
    if (($id && is_singular() && atp_seo_exclude_post($id)) || is_search() || is_404()) {
        unset($robots['index']);
        $robots['noindex'] = true;
        $robots['follow'] = true;
    }
    if (!isset($robots['noindex'])) $robots['max-image-preview'] = 'large';
    return $robots;
}, 80);

// The theme emits its own multilingual SEO meta; never output meta descriptions on noindex demo pages.
add_filter('twt_sitemap_exclude_post', function($excluded, $id) {
    return $excluded || atp_seo_exclude_post($id);
}, 10, 2);

// Internal search/filter parameters don't create indexable copies of hotel directories.
add_filter('wp_robots', function ($robots) {
    foreach (['s', 'hotel_q', 'hotel_city', 'hotel_region'] as $q) {
        if (isset($_GET[$q]) && $_GET[$q] !== '') {
            $robots['noindex'] = true; unset($robots['index']); break;
        }
    }
    return $robots;
}, 90);

// Admin-only diagnostics: operational checklist, no network calls, secrets or write operations.
add_action('admin_menu', function () {
    add_management_page('SEO / GEO Kontrol', 'SEO / GEO Kontrol', 'manage_options', 'atp-seo-check', 'atp_seo_diagnostics');
});
function atp_seo_diagnostics() {
    if (!current_user_can('manage_options')) return;
    $links = ['Sitemap' => home_url('/sitemap.xml'), 'Robots' => home_url('/robots.txt'), 'LLMs' => home_url('/llms.txt'), 'English' => home_url('/en/'), 'German' => home_url('/de/'), 'Russian' => home_url('/ru/')];
    echo '<div class="wrap"><h1>SEO / GEO / AEO Kontrol</h1><p>Bu ekran kaynak yapılandırmasını gösterir, Google sıralaması veya indekslemeyi doğrulamaz.</p>';
    echo '<table class="widefat striped"><tbody>';
    foreach (['Arama motoru görünürlüğü' => get_option('blog_public') ? 'Açık' : 'KAPALI — Ayarlar > Okuma',
        'Tema sürümü' => wp_get_theme()->get('Version'),
        'Özel sitemap sürümü' => defined('TWT_SM_VERSION') ? TWT_SM_VERSION : 'Yok',
        'Aktif SEO eklentisi' => function_exists('twt_seo_plugin_active') && twt_seo_plugin_active() ? 'Var' : 'Yok — tema kendi SEO sistemini kullanır',
        'Dört dil' => implode(', ', array_keys(deniz_languages())),
        'Örnek sayfa' => 'Yayımlanmışsa noindex + sitemap dışı'] as $k => $v) {
        echo '<tr><th>'.esc_html($k).'</th><td>'.esc_html((string)$v).'</td></tr>';
    }
    echo '</tbody></table><h2>Kontrol bağlantıları</h2><ul>';
    foreach ($links as $k => $v) echo '<li><a href="'.esc_url($v).'" target="_blank" rel="noopener">'.esc_html($k).'</a></li>';
    echo '</ul><p>Yayın sonrası GSC URL Denetimi ve canlı schema testleri gereklidir. Gerçek fiyat/mesafe/yorumlar veritabanı üzerinden kontrol edilmelidir.</p></div>';
}
