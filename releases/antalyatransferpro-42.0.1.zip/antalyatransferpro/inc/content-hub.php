<?php
if (!defined('ABSPATH')) exit;

/**
 * Antalya Transfer Pro v15 content hub.
 * Every public entity page is built from operational DB data first.
 * No fabricated distances, prices or hotel counts are output.
 */
function deniz_content_updated_label(){
    return twt_real_updated_label(get_queried_object_id());
}
function deniz_db_city($id){ global $wpdb; $t=deniz_tables(); return $wpdb->get_row($wpdb->prepare("SELECT c.*,co.name country,co.code country_code FROM {$t['cities']} c LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE c.id=%d",$id)); }
function deniz_db_region($id){ global $wpdb; $t=deniz_tables(); return $wpdb->get_row($wpdb->prepare("SELECT r.*,c.name city,c.slug city_slug,co.name country,co.code country_code FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE r.id=%d",$id)); }
function deniz_region_by_slug($slug){ global $wpdb; $t=deniz_tables(); return $wpdb->get_row($wpdb->prepare("SELECT r.*,c.name city,c.slug city_slug,co.name country FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE r.slug=%s OR LOWER(r.name)=LOWER(%s) LIMIT 1",$slug,str_replace('-',' ',$slug))); }
function deniz_airport_full($id){ global $wpdb; $t=deniz_tables(); return $wpdb->get_row($wpdb->prepare("SELECT a.*,c.name city,c.slug city_slug,co.name country FROM {$t['airports']} a LEFT JOIN {$t['cities']} c ON c.id=a.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE a.id=%d",$id)); }
function deniz_region_airports($region_id){ global $wpdb; $t=deniz_tables(); return $wpdb->get_results($wpdb->prepare("SELECT DISTINCT a.* FROM {$t['airports']} a JOIN {$t['prices']} p ON p.airport_id=a.id WHERE p.region_id=%d AND p.active=1 AND a.active=1 ORDER BY a.name",$region_id)); }
function deniz_region_hotels($region_id,$limit=18){ global $wpdb; $t=deniz_tables(); return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE region_id=%d AND active=1 ORDER BY name LIMIT %d",$region_id,$limit)); }
function deniz_region_price_rows($region_id,$airport_id){
 global $wpdb; $t=deniz_tables(); deniz_cleanup_legacy_demo_vehicles();
 $rows=$wpdb->get_results($wpdb->prepare("SELECT p.*,v.id vehicle_row_id,v.slug vehicle_slug,v.name vehicle,v.pax,v.bags,v.image_id,v.service_type,v.pricing_type,v.features,v.opening_price,v.price_per_km FROM {$t['prices']} p JOIN {$t['vehicles']} v ON v.id=p.vehicle_id WHERE p.region_id=%d AND p.airport_id=%d AND p.active=1 AND v.active=1 AND p.one_way>0 ORDER BY v.display_priority,v.sort_order,v.name",$region_id,$airport_id));
 return array_values(array_filter((array)$rows,function($row){
  $v=(object)['id'=>$row->vehicle_id,'slug'=>$row->vehicle_slug,'pax'=>$row->pax,'bags'=>$row->bags,'image_id'=>$row->image_id,'features'=>$row->features,'opening_price'=>$row->opening_price,'price_per_km'=>$row->price_per_km];
  return !deniz_is_legacy_demo_vehicle($v);
 }));
}
function deniz_city_regions($city_id,$limit=30){ global $wpdb; $t=deniz_tables(); return $wpdb->get_results($wpdb->prepare("SELECT r.*,(SELECT COUNT(*) FROM {$t['hotels']} h WHERE h.region_id=r.id AND h.active=1) hotel_count,(SELECT MIN(p.one_way) FROM {$t['prices']} p WHERE p.region_id=r.id AND p.active=1 AND p.one_way>0) from_price FROM {$t['regions']} r WHERE r.city_id=%d AND r.active=1 ORDER BY r.name LIMIT %d",$city_id,$limit)); }
function deniz_city_hotels($city_id,$limit=24){ global $wpdb; $t=deniz_tables(); return $wpdb->get_results($wpdb->prepare("SELECT h.*,r.name region FROM {$t['hotels']} h LEFT JOIN {$t['regions']} r ON r.id=h.region_id WHERE h.city_id=%d AND h.active=1 ORDER BY h.name LIMIT %d",$city_id,$limit)); }
function deniz_route_live_data($post_id=0){
    global $wpdb; $t=deniz_tables(); $post_id=$post_id?:get_queried_object_id(); $c=deniz_route_context($post_id); if(!$c||!$c['a']) return null;
    $region=$c['r']; $hotel=$c['h']; if(!$region && $hotel) $region=deniz_db_region((int)$hotel->region_id);
    $prices=$region?deniz_region_price_rows((int)$region->id,(int)$c['a']->id):[];
    $min=null; foreach($prices as $p){$v=(float)$p->one_way;if($v>0&&($min===null||$v<$min))$min=$v;}
    $distance=trim((string)get_post_meta($post_id,'distance_km',true));
    $duration=trim((string)get_post_meta($post_id,'duration_min',true));
    $target=$hotel?$hotel->name:($region?$region->name:get_the_title($post_id));
    return ['ctx'=>$c,'airport'=>$c['a'],'region'=>$region,'hotel'=>$hotel,'prices'=>$prices,'min'=>$min,'distance'=>$distance,'duration'=>$duration,'target'=>$target];
}
function deniz_quick_answer($title,$text){ echo '<div class="knowledge-answer"><div class="knowledge-answer-label">'.esc_html(deniz_t('quick_answer')).'</div><h2>'.esc_html($title).'</h2><p>'.esc_html($text).'</p></div>'; }
function deniz_page_editorial_note($label=''){ return; /* source/updated box removed for a natural, customer-facing tone */ }
function deniz_page_editorial_note_legacy($label=''){
 echo '<div class="editorial-note"><div><b>'.esc_html(deniz_t('information_source')).'</b><span>'.esc_html($label).' · Antalya Transfer Pro</span></div><div><b>'.esc_html(deniz_t('updated')).'</b><span>'.esc_html(deniz_content_updated_label()).'</span></div><div><b>'.esc_html(deniz_t('prices_heading')).'</b><span>'.esc_html(deniz_t('pricing_source')).'</span></div></div>';
}
function deniz_search_url_for($airport=null,$region=null,$hotel=null){
    $args=[]; if($airport){$args['airport_id']=$airport->id;$args['from']=$airport->name;$args['from_lat']=$airport->lat;$args['from_lng']=$airport->lng;}
    if($region){$args['region_id']=$region->id;$args['to']=$region->name;$args['to_lat']=$region->center_lat;$args['to_lng']=$region->center_lng;}
    if($hotel){$args['hotel_id']=$hotel->id;$args['region_id']=$hotel->region_id;$args['to']=$hotel->name;$args['to_lat']=$hotel->lat;$args['to_lng']=$hotel->lng;}
    return add_query_arg($args,deniz_url('transfer-search'));
}

/** Public airport knowledge pages are generated from Transfer OS airport data. */
function deniz_sync_airport_guides(){
    global $wpdb; $t=deniz_tables(); if(!post_type_exists('airport-guide')) return;
    $airports=$wpdb->get_results("SELECT a.*,c.name city FROM {$t['airports']} a LEFT JOIN {$t['cities']} c ON c.id=a.city_id WHERE a.active=1 ORDER BY a.id");
    foreach($airports as $a){
        $slug=sanitize_title(($a->iata?:$a->name).'-airport-transfer');
        $p=get_page_by_path($slug,OBJECT,'airport-guide');
        $title=$a->name.' Transfer';
        $pid=$p?$p->ID:wp_insert_post(['post_type'=>'airport-guide','post_status'=>'publish','post_title'=>$title,'post_name'=>$slug,'post_excerpt'=>'Airport transfer information, destinations, hotel routes and booking options from '.$a->name.'.']);
        if($pid&&!is_wp_error($pid)){update_post_meta($pid,'dynamic_airport_id',(int)$a->id);}
    }
}
add_action('init','deniz_sync_airport_guides',40);

function deniz_sync_region_guides(){
    global $wpdb; $t=deniz_tables(); if(!post_type_exists('location')) return;
    $regions=$wpdb->get_results("SELECT r.*,c.name city FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id WHERE r.active=1 ORDER BY r.id");
    foreach($regions as $r){
        $p=get_page_by_path($r->slug,OBJECT,'location');
        $pid=$p?$p->ID:wp_insert_post(['post_type'=>'location','post_status'=>'publish','post_title'=>$r->name,'post_name'=>$r->slug,'post_excerpt'=>'Airport transfer guide, hotels and live pricing for '.$r->name.', '.$r->city.'.']);
        if($pid&&!is_wp_error($pid)){update_post_meta($pid,'dynamic_region_id',(int)$r->id);}
    }
}
function deniz_sync_city_guides_live(){
    global $wpdb; $t=deniz_tables(); if(!function_exists('deniz_sync_city_destination')) return;
    foreach($wpdb->get_col("SELECT id FROM {$t['cities']} WHERE active=1 ORDER BY id") as $cid) deniz_sync_city_destination((int)$cid);
}
add_action('init','deniz_sync_region_guides',41);
add_action('init','deniz_sync_city_guides_live',42);
