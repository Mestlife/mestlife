<?php
/**
 * Sitemap Pro – single, Google Search Console friendly XML sitemap system.
 *
 *  /sitemap.xml                 → sitemap index (submit THIS one to GSC)
 *  /sitemap-pages.xml           → home + SEO landing pages (hreflang)
 *  /sitemap-archives.xml        → archive / hub pages (hreflang)
 *  /sitemap-content-{n}.xml     → pages, blog, destinations, locations, transfers, vehicles, airports (hreflang)
 *  /sitemap-hotels-{n}.xml      → hotel directory (hreflang)
 *  /sitemap.xsl                 → human readable view in the browser (Google ignores it)
 *
 * Legacy URLs (wp-sitemap*.xml, sitemap_index.xml, landing-sitemap.xml, hotel-sitemap*.xml)
 * keep working so nothing already submitted to GSC breaks.
 *
 * Requests are answered on `init` straight from REQUEST_URI, so the sitemap works
 * without flushing permalinks and before any language / canonical redirect can run.
 */
if (!defined('ABSPATH')) exit;

const TWT_SM_VERSION      = '2.3';
const TWT_SM_POSTS_PER    = 1000;   // posts per content sitemap (x4 languages = 4.000 URLs, limit is 50.000)
const TWT_SM_HOTELS_PER   = 250;    // must match twt_hotel_sitemap_urls() paging
const TWT_SM_CACHE_TTL    = 1800;

/* WordPress core sitemap produced non-language URLs that redirect → GSC errors. We own sitemaps now. */
add_filter('wp_sitemaps_enabled', '__return_false', 999);

/* ---------- Missing airport-guide routes (/tr/airports/ and /tr/airports/{slug}/) ----------
   Must be added before the language catch-all rule in inc/i18n.php (priority 10). */
add_action('init', function () {
	foreach (array_keys(deniz_languages()) as $lang) {
		add_rewrite_rule('^' . $lang . '/airports/?$', 'index.php?post_type=airport-guide&deniz_lang=' . $lang, 'top');
		add_rewrite_rule('^' . $lang . '/airports/([^/]+)/?$', 'index.php?post_type=airport-guide&name=$matches[1]&deniz_lang=' . $lang, 'top');
	}
}, 9);
add_action('init', function () {
	if (get_option('twt_sitemap_pro_version') !== TWT_SM_VERSION) {
		flush_rewrite_rules(false);
		twt_sm_flush_cache();
		update_option('twt_sitemap_pro_version', TWT_SM_VERSION, false);
	}
}, 100);

/* ---------- Helpers ---------- */
function twt_sm_langs() { return array_keys(deniz_languages()); }
function twt_sm_xdefault() { return apply_filters('twt_sitemap_x_default', 'en'); }
function twt_sm_x($v) { return htmlspecialchars((string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }
function twt_sm_loc($url) { return twt_sm_x(esc_url_raw($url)); }
function twt_sm_date($ts) { return $ts ? gmdate('Y-m-d\TH:i:s+00:00', (int) $ts) : ''; }
function twt_sm_private_templates() { return ['template-transfer-search.php', 'template-passenger-details.php', 'template-booking-confirmation.php']; }
function twt_sm_post_types() {
	$types = ['page', 'post', 'destination', 'location', 'transfer-route', 'vehicle', 'airport-guide'];
	return array_values(array_filter(apply_filters('twt_sitemap_post_types', $types), 'post_type_exists'));
}
function twt_sm_type_paths() { return ['post' => 'blog', 'destination' => 'destinations', 'location' => 'locations', 'transfer-route' => 'transfers', 'vehicle' => 'vehicles', 'airport-guide' => 'airports']; }

function twt_sm_cache($key, callable $build) {
	$k = 'twt_sm_' . TWT_SM_VERSION . '_' . $key;
	$v = get_transient($k);
	if ($v !== false) return $v;
	$v = $build();
	set_transient($k, $v, TWT_SM_CACHE_TTL);
	$keys = get_option('twt_sm_cache_keys', []);
	if (!in_array($k, $keys, true)) { $keys[] = $k; update_option('twt_sm_cache_keys', $keys, false); }
	return $v;
}
function twt_sm_flush_cache() {
	foreach ((array) get_option('twt_sm_cache_keys', []) as $k) delete_transient($k);
	update_option('twt_sm_cache_keys', [], false);
}
/* Live: any content change refreshes the sitemap immediately. */
foreach (['save_post', 'deleted_post', 'trashed_post', 'switch_theme', 'twt_hotels_updated'] as $hook) {
	add_action($hook, function ($id = 0) {
		if ($id && (wp_is_post_revision($id) || wp_is_post_autosave($id))) return;
		twt_sm_flush_cache();
	});
}

/** URL group with hreflang alternates for a path that exists in every language. */
function twt_sm_group(callable $url_for_lang, $lastmod = 0) {
	$alts = [];
	foreach (twt_sm_langs() as $l) $alts[$l] = $url_for_lang($l);
	return ['alts' => $alts, 'lastmod' => (int) $lastmod];
}

/* ---------- Data sources ---------- */
function twt_sm_landing_mtime() {
	$f = get_template_directory() . '/inc/seo-landings.json';
	return file_exists($f) ? (int) filemtime($f) : 0;
}
function twt_sm_last_content_change() {
	global $wpdb;
	$types = twt_sm_post_types();
	if (!$types) return 0;
	$in = implode(',', array_map(fn($t) => $wpdb->prepare('%s', $t), $types));
	$d  = $wpdb->get_var("SELECT MAX(post_modified_gmt) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in)");
	return $d ? (int) strtotime($d . ' UTC') : 0;
}

function twt_sm_pages_groups() {
	return twt_sm_cache('pages', function () {
		$mod  = max(twt_sm_landing_mtime(), 0);
		$out  = [twt_sm_group(fn($l) => deniz_url('', $l), max($mod, twt_sm_last_content_change()))];
		if (function_exists('atp_page_keys')) {
			foreach (atp_page_keys() as $key) $out[] = twt_sm_group(fn($l) => atp_landing_url($key, $l), $mod);
		}
		return $out;
	});
}

function twt_sm_landing_paths() {
	$set = [];
	foreach (twt_sm_pages_groups() as $g) foreach ($g['alts'] as $u) $set[untrailingslashit($u)] = true;
	return $set;
}

function twt_sm_content_ids() {
	return twt_sm_cache('content_ids', function () {
		$exclude = [(int) get_option('page_on_front'), (int) get_option('page_for_posts')];
		if (function_exists('twt_stale_vehicle_ids')) $exclude = array_merge($exclude, twt_stale_vehicle_ids());
		if (function_exists('twt_stale_content_ids')) $exclude = array_merge($exclude, twt_stale_content_ids());
		$ids = get_posts([
			'post_type' => twt_sm_post_types(), 'post_status' => 'publish', 'has_password' => false,
			'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
			'post__not_in' => array_values(array_filter(array_unique(array_map('intval', $exclude)))),
			'suppress_filters' => true, 'no_found_rows' => true,
			'meta_query' => [['relation' => 'OR',
				['key' => '_wp_page_template', 'compare' => 'NOT EXISTS'],
				['key' => '_wp_page_template', 'value' => twt_sm_private_templates(), 'compare' => 'NOT IN'],
			]],
		]);
		$ids = array_values(array_filter(array_map('intval', $ids), function ($id) {
			if (get_post_type($id) === 'page' && wp_get_post_parent_id($id)) return false;
            if (function_exists('atp_seo_exclude_post') && atp_seo_exclude_post($id)) return false; // nested pages are not routed per language
			if (get_post_meta($id, '_yoast_wpseo_meta-robots-noindex', true) === '1') return false;
			$rm = get_post_meta($id, 'rank_math_robots', true);
			if (is_array($rm) && in_array('noindex', $rm, true)) return false;
			return !apply_filters('twt_sitemap_exclude_post', false, $id);
		}));
		return $ids;
	});
}
function twt_sm_content_pages() { return max(1, (int) ceil(count(twt_sm_content_ids()) / TWT_SM_POSTS_PER)); }

function twt_sm_post_path($id) {
	$type = get_post_type($id);
	$map  = twt_sm_type_paths();
	$slug = get_post_field('post_name', $id);
	if (isset($map[$type])) return $map[$type] . '/' . $slug;
	return get_page_uri($id);
}

function twt_sm_content_groups($page) {
	return twt_sm_cache('content_' . $page, function () use ($page) {
		$ids     = array_slice(twt_sm_content_ids(), ($page - 1) * TWT_SM_POSTS_PER, TWT_SM_POSTS_PER);
		$landing = twt_sm_landing_paths();
		$out     = [];
		foreach ($ids as $id) {
			$path = twt_sm_post_path($id);
			if ($path === '' || $path === null) continue;
			$is_post = get_post_type($id) === 'post' && function_exists('twt_post_lang_slug');
			$g = twt_sm_group(fn($l) => $is_post ? deniz_url('blog/' . twt_post_lang_slug($id, $l), $l) : deniz_url($path, $l),
				function_exists('twt_real_updated_timestamp') ? twt_real_updated_timestamp($id) : get_post_modified_time('U', true, $id));
			if (isset($landing[untrailingslashit(reset($g['alts']))])) continue; // already in sitemap-pages.xml
			$out[] = $g;
		}
		return $out;
	});
}

function twt_sm_archive_groups() {
	return twt_sm_cache('archives', function () {
		global $wpdb;
		$out = [];
		foreach (twt_sm_type_paths() as $type => $path) {
			if (!post_type_exists($type)) continue;
			$last = $wpdb->get_var($wpdb->prepare("SELECT MAX(post_modified_gmt) FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish'", $type));
			if (!$last) continue; // empty archive → don't list (would be thin / 404)
			$out[] = twt_sm_group(fn($l) => deniz_url($path, $l), strtotime($last . ' UTC'));
		}
		if (twt_sm_hotel_pages() > 0) $out[] = twt_sm_group(fn($l) => deniz_url('hotels', $l), 0);
		return $out;
	});
}

function twt_sm_hotel_pages() {
	if (!function_exists('twt_hotel_sitemap_pages')) return 0;
	static $n = null;
	if ($n === null) { try { $n = (int) twt_hotel_sitemap_pages(); } catch (\Throwable $e) { $n = 0; } }
	return $n;
}
function twt_sm_hotel_groups($page) {
	return twt_sm_cache('hotels_' . $page, function () use ($page) {
		$items = twt_hotel_sitemap_urls($page); // ordered: hotel1-tr, hotel1-en, ... (one row per language)
		$langs = twt_sm_langs();
		$out   = [];
		foreach (array_chunk($items, count($langs)) as $chunk) {
			$alts = [];
			foreach ($chunk as $i => $it) $alts[$langs[$i] ?? 'x' . $i] = $it['loc'];
			$out[] = ['alts' => $alts, 'lastmod' => 0];
		}
		return $out;
	});
}

/* ---------- XML rendering ---------- */
function twt_sm_head() {
	return '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<?xml-stylesheet type="text/xsl" href="' . twt_sm_x(home_url('/sitemap.xsl')) . '"?>' . "\n";
}
function twt_sm_urlset(array $groups) {
	$xd  = twt_sm_xdefault();
	$xml = twt_sm_head() . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
	$seen = [];
	foreach ($groups as $g) {
		$alts = $g['alts'];
		foreach ($alts as $lang => $loc) {
			if (isset($seen[$loc])) continue;
			$seen[$loc] = true;
			$xml .= '<url><loc>' . twt_sm_loc($loc) . '</loc>';
			if (!empty($g['lastmod'])) $xml .= '<lastmod>' . twt_sm_date($g['lastmod']) . '</lastmod>';
			if (count($alts) > 1) {
				foreach ($alts as $al => $au) $xml .= '<xhtml:link rel="alternate" hreflang="' . twt_sm_x($al) . '" href="' . twt_sm_loc($au) . '"/>';
				if (isset($alts[$xd])) $xml .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . twt_sm_loc($alts[$xd]) . '"/>';
			}
			$xml .= "</url>\n";
		}
	}
	return $xml . '</urlset>';
}
function twt_sm_max_lastmod(array $groups) {
	$m = 0;
	foreach ($groups as $g) $m = max($m, (int) $g['lastmod']);
	return $m;
}
function twt_sm_index() {
	$items = [['loc' => home_url('/sitemap-pages.xml'), 'mod' => twt_sm_max_lastmod(twt_sm_pages_groups())]];
	if (twt_sm_archive_groups()) $items[] = ['loc' => home_url('/sitemap-archives.xml'), 'mod' => twt_sm_max_lastmod(twt_sm_archive_groups())];
	if (twt_sm_content_ids()) for ($i = 1, $n = twt_sm_content_pages(); $i <= $n; $i++) $items[] = ['loc' => home_url('/sitemap-content-' . $i . '.xml'), 'mod' => twt_sm_max_lastmod(twt_sm_content_groups($i))];
	for ($i = 1, $n = twt_sm_hotel_pages(); $i <= $n; $i++) $items[] = ['loc' => home_url('/sitemap-hotels-' . $i . '.xml'), 'mod' => 0];
	$xml = twt_sm_head() . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ($items as $it) {
		$xml .= '<sitemap><loc>' . twt_sm_loc($it['loc']) . '</loc>' . ($it['mod'] ? '<lastmod>' . twt_sm_date($it['mod']) . '</lastmod>' : '') . "</sitemap>\n";
	}
	return $xml . '</sitemapindex>';
}

function twt_sm_send($body, $type = 'application/xml', $code = 200) {
	while (ob_get_level() > 0) @ob_end_clean(); // kills BOM / stray whitespace from plugins that breaks XML
	if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
	if (!headers_sent()) {
		status_header($code);
		foreach (['X-Pingback', 'Link', 'Set-Cookie', 'Content-Type'] as $h) header_remove($h);
		header('Content-Type: ' . $type . '; charset=UTF-8');
		header('X-Robots-Tag: noindex, follow');
		header('X-Content-Type-Options: nosniff');
		header('Cache-Control: no-cache, must-revalidate, max-age=0');
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
	}
	if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') echo $body;
	exit;
}
function twt_sm_redirect($path) {
	while (ob_get_level() > 0) @ob_end_clean();
	wp_safe_redirect(home_url($path), 301, 'Sitemap Pro');
	exit;
}
function twt_sm_404() { twt_sm_send('<?xml version="1.0" encoding="UTF-8"?><error>Sitemap not found</error>', 'application/xml', 404); }

/* ---------- Router ---------- */
add_action('init', function () {
	if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) return;
	if (!function_exists('deniz_current_request_relative_path')) return;
	$p = strtolower(deniz_current_request_relative_path());
	if (!preg_match('~^/[a-z0-9_\-]*sitemap[a-z0-9_\-]*\.(xml|xsl)/?$~', $p)) return;
	if (substr($p, -1) === '/') twt_sm_redirect(rtrim($p, '/'));
	if (!get_option('blog_public')) twt_sm_404(); // "Discourage search engines" is on

	try {
		if (in_array($p, ['/sitemap.xml', '/sitemap_index.xml', '/wp-sitemap.xml', '/hotel-sitemap.xml'], true)) twt_sm_send(twt_sm_index());
		if ($p === '/sitemap.xsl') twt_sm_send(twt_sm_xsl(), 'text/xsl');
		if (in_array($p, ['/sitemap-pages.xml', '/landing-sitemap.xml'], true)) twt_sm_send(twt_sm_urlset(twt_sm_pages_groups()));
		if ($p === '/sitemap-archives.xml') { $g = twt_sm_archive_groups(); $g ? twt_sm_send(twt_sm_urlset($g)) : twt_sm_404(); }
		if (preg_match('~^/sitemap-content-([1-9][0-9]*)\.xml$~', $p, $m)) { $n = (int) $m[1]; ($n <= twt_sm_content_pages() && twt_sm_content_ids()) ? twt_sm_send(twt_sm_urlset(twt_sm_content_groups($n))) : twt_sm_404(); }
		if (preg_match('~^/(?:sitemap-hotels|hotel-sitemap)-([1-9][0-9]*)\.xml$~', $p, $m)) { $n = (int) $m[1]; $n <= twt_sm_hotel_pages() ? twt_sm_send(twt_sm_urlset(twt_sm_hotel_groups($n))) : twt_sm_404(); }
		if (strpos($p, '/wp-sitemap') === 0) twt_sm_redirect('/sitemap.xml'); // old core children
	} catch (\Throwable $e) {
		error_log('[Sitemap Pro] ' . $e->getMessage());
		twt_sm_send('<?xml version="1.0" encoding="UTF-8"?><error>Temporary error</error>', 'application/xml', 503);
	}
	twt_sm_404();
}, PHP_INT_MAX);

/* Never let canonical redirect touch sitemap URLs. */
add_filter('redirect_canonical', function ($r, $req) { return preg_match('~sitemap[^/]*\.(xml|xsl)~i', (string) $req) ? false : $r; }, 1, 2);

/* ---------- Browser stylesheet ---------- */
function twt_sm_xsl() {
	$brand = function_exists('twt_brand_name') ? twt_brand_name() : get_bloginfo('name');
	$b = twt_sm_x($brand);
	return <<<XSL
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:s="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html lang="tr"><head><meta charset="UTF-8"/><meta name="robots" content="noindex,follow"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>XML Sitemap – {$b}</title>
<style>
body{margin:0;font:14px/1.5 Inter,system-ui,-apple-system,"Segoe UI",sans-serif;color:#061c3e;background:#f6f8fb}
header{background:#061c3d;color:#fff;padding:28px 0}.w{width:min(1200px,calc(100% - 32px));margin:auto}
h1{margin:0 0 6px;font-size:24px}header p{margin:0;opacity:.75}
.card{background:#fff;border:1px solid #e5edf2;border-radius:16px;margin:24px auto;overflow:auto}
table{width:100%;border-collapse:collapse}th,td{padding:10px 14px;text-align:left;border-bottom:1px solid #eef2f6;vertical-align:top}
th{background:#f8fafb;font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:#667684}
a{color:#0b5d8b;text-decoration:none;word-break:break-all}a:hover{text-decoration:underline}
.n{color:#667684;width:48px}.tag{display:inline-block;background:#e9f5fb;color:#0b5d8b;border-radius:6px;padding:1px 7px;margin:2px 4px 2px 0;font-size:12px;font-weight:700}
.badge{display:inline-block;background:#34c9a0;color:#061c3e;border-radius:999px;padding:2px 10px;font-weight:800;margin-left:8px;font-size:13px}
</style></head><body>
<header><div class="w"><h1>XML Sitemap <xsl:choose><xsl:when test="s:sitemapindex"><span class="badge"><xsl:value-of select="count(s:sitemapindex/s:sitemap)"/> sitemap</span></xsl:when><xsl:otherwise><span class="badge"><xsl:value-of select="count(s:urlset/s:url)"/> URL</span></xsl:otherwise></xsl:choose></h1>
<p>{$b} · Bu dosya arama motorları içindir. Google Search Console'a <b>/sitemap.xml</b> adresini gönderin.</p></div></header>
<div class="w"><div class="card">
<xsl:choose>
<xsl:when test="s:sitemapindex">
<table><tr><th class="n">#</th><th>Sitemap</th><th>Son güncelleme</th></tr>
<xsl:for-each select="s:sitemapindex/s:sitemap"><tr><td class="n"><xsl:value-of select="position()"/></td><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td><td><xsl:value-of select="substring(s:lastmod,1,16)"/></td></tr></xsl:for-each>
</table>
</xsl:when>
<xsl:otherwise>
<table><tr><th class="n">#</th><th>URL</th><th>Diller</th><th>Son güncelleme</th></tr>
<xsl:for-each select="s:urlset/s:url"><tr><td class="n"><xsl:value-of select="position()"/></td><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td>
<td><xsl:for-each select="xhtml:link"><span class="tag"><xsl:value-of select="@hreflang"/></span></xsl:for-each></td>
<td><xsl:value-of select="substring(s:lastmod,1,16)"/></td></tr></xsl:for-each>
</table>
</xsl:otherwise>
</xsl:choose>
</div></div></body></html>
</xsl:template>
</xsl:stylesheet>
XSL;
}

/* ---------- Admin: Araçlar → Sitemap Pro (links, URL counts, health check, cache clear) ---------- */
add_action('admin_menu', function () {
	add_management_page('Sitemap Pro', 'Sitemap Pro', 'manage_options', 'twt-sitemap-pro', 'twt_sm_admin_page');
});
add_action('admin_post_twt_sm_flush', function () {
	if (!current_user_can('manage_options')) wp_die('Yetki yok');
	check_admin_referer('twt_sm_flush');
	twt_sm_flush_cache();
	flush_rewrite_rules(false);
	wp_safe_redirect(admin_url('tools.php?page=twt-sitemap-pro&flushed=1'));
	exit;
});
function twt_sm_admin_page() {
	if (!current_user_can('manage_options')) return;
	$count = function ($groups) { $n = 0; foreach ($groups as $g) $n += count($g['alts']); return $n; };
	$rows = [['sitemap-pages.xml', $count(twt_sm_pages_groups())], ['sitemap-archives.xml', $count(twt_sm_archive_groups())]];
	for ($i = 1, $n = twt_sm_content_pages(); $i <= $n && twt_sm_content_ids(); $i++) $rows[] = ['sitemap-content-' . $i . '.xml', $count(twt_sm_content_groups($i))];
	for ($i = 1, $n = twt_sm_hotel_pages(); $i <= $n; $i++) $rows[] = ['sitemap-hotels-' . $i . '.xml', $count(twt_sm_hotel_groups($i))];
	$total = array_sum(array_column($rows, 1));
	echo '<div class="wrap"><h1>Sitemap Pro</h1>';
	if (isset($_GET['flushed'])) echo '<div class="notice notice-success"><p>Önbellek ve kalıcı bağlantılar yenilendi.</p></div>';
	if (!get_option('blog_public')) echo '<div class="notice notice-error"><p><b>Ayarlar → Okuma → "Arama motorlarının siteyi dizine eklemesini engelle"</b> açık. Sitemap kapalı (404). Bu kutuyu kaldırın.</p></div>';
	if (function_exists('twt_seo_plugin_active') && twt_seo_plugin_active()) echo '<div class="notice notice-warning"><p>Bir SEO eklentisi aktif. Eklentinin kendi XML sitemap özelliğini kapatın; GSC\'de yalnızca <code>/sitemap.xml</code> gönderilsin.</p></div>';
	echo '<p>Google Search Console → Site Haritaları bölümüne <b>yalnızca</b> şunu gönderin: <code>sitemap.xml</code></p>';
	echo '<p><a class="button button-primary" target="_blank" href="' . esc_url(home_url('/sitemap.xml')) . '">sitemap.xml aç</a> ';
	echo '<a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=twt_sm_flush'), 'twt_sm_flush')) . '">Önbelleği temizle &amp; yenile</a></p>';
	echo '<table class="widefat striped" style="max-width:720px"><thead><tr><th>Sitemap</th><th>URL sayısı</th></tr></thead><tbody>';
	foreach ($rows as $r) echo '<tr><td><a target="_blank" href="' . esc_url(home_url('/' . $r[0])) . '">' . esc_html($r[0]) . '</a></td><td>' . (int) $r[1] . '</td></tr>';
	echo '<tr><th>Toplam</th><th>' . (int) $total . '</th></tr></tbody></table>';

	if (isset($_GET['check'])) {
		echo '<h2>Sağlık kontrolü (ilk 40 URL)</h2><table class="widefat striped" style="max-width:1000px"><thead><tr><th>URL</th><th>HTTP</th></tr></thead><tbody>';
		$urls = [];
		foreach (array_merge(twt_sm_pages_groups(), twt_sm_archive_groups(), twt_sm_content_ids() ? twt_sm_content_groups(1) : []) as $g) $urls[] = reset($g['alts']);
		$bad = 0;
		foreach (array_slice($urls, 0, 40) as $u) {
			$res  = wp_remote_head($u, ['timeout' => 8, 'redirection' => 0]);
			$code = is_wp_error($res) ? $res->get_error_message() : wp_remote_retrieve_response_code($res);
			$ok   = (int) $code === 200;
			if (!$ok) $bad++;
			echo '<tr><td><a target="_blank" href="' . esc_url($u) . '">' . esc_html($u) . '</a></td><td style="font-weight:700;color:' . ($ok ? '#1a7f37' : '#b32d2e') . '">' . esc_html($code) . '</td></tr>';
		}
		echo '</tbody></table><p>' . ($bad ? '<b style="color:#b32d2e">' . (int) $bad . ' URL 200 dönmüyor.</b> Önbelleği temizleyip tekrar deneyin; devam ederse bu URL\'lerin içeriklerini kontrol edin.' : '<b style="color:#1a7f37">Kontrol edilen tüm URL\'ler 200 OK.</b>') . '</p>';
	} else {
		echo '<p><a class="button" href="' . esc_url(admin_url('tools.php?page=twt-sitemap-pro&check=1')) . '">Sağlık kontrolü çalıştır</a> <span class="description">Sitemap\'teki URL\'lerin 200 döndüğünü kontrol eder.</span></p>';
	}
	echo '</div>';
}
