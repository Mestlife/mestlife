<?php
/**
 * Blog Stüdyosu – 4 dilli (TR/EN/DE/RU) blog yazısı ekleme / güncelleme.
 *
 *  - Yazılar → "4 Dilli Yazı Ekle": JSON yapıştır, öne çıkan görsel + içerik görselleri seç, kaydet.
 *  - Her dilin kendi slug'ı: /tr/blog/{tr-slug}/, /en/blog/{en-slug}/, /de/blog/{de-slug}/, /ru/blog/{ru-slug}/
 *    (yanlış dildeki slug ile gelen istek doğru adrese 301 ile yönlenir; hreflang, canonical, sitemap otomatik).
 *  - Yazıya özel, dile göre SSS (FAQPage şeması ile).
 *  - Öne çıkan görselin alt metni dile göre değişir.
 */
if (!defined('ABSPATH')) exit;

function twt_bs_langs() { return array_keys(deniz_languages()); }
function twt_bs_strip_fences($s) { return trim(preg_replace('~^\s*```(?:json)?\s*|\s*```\s*$~i', '', (string) $s)); }

/* =========================================================================
 * 1) Dile göre slug
 * ========================================================================= */
function twt_post_lang_slug($post, $lang) {
	$post = get_post($post);
	if (!$post) return '';
	if ($lang === 'tr') return $post->post_name;
	$s = get_post_meta($post->ID, 'deniz_' . $lang . '_slug', true);
	return $s !== '' ? $s : $post->post_name;
}
function twt_post_lang_url($post, $lang) { return deniz_url('blog/' . twt_post_lang_slug($post, $lang), $lang); }

/* Front-end blog links use the current language's slug. */
add_filter('post_link', function ($url, $post) {
	if (is_admin() || $post->post_type !== 'post') return $url;
	return twt_post_lang_url($post, deniz_current_lang());
}, 30, 2);

function twt_bs_find_post($slug, $lang) {
	global $wpdb;
	$st = "('publish','future','draft','pending','private')";
	if ($lang !== 'tr') {
		$id = $wpdb->get_var($wpdb->prepare("SELECT pm.post_id FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key=%s AND pm.meta_value=%s AND p.post_type='post' AND p.post_status IN $st ORDER BY p.post_status='publish' DESC LIMIT 1", 'deniz_' . $lang . '_slug', $slug));
		if ($id) return (int) $id;
	}
	$id = $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_name=%s AND post_type='post' AND post_status IN $st ORDER BY post_status='publish' DESC LIMIT 1", $slug));
	if ($id) return (int) $id;
	$keys = "'" . implode("','", array_map(fn($l) => 'deniz_' . $l . '_slug', twt_bs_langs())) . "'";
	$id = $wpdb->get_var($wpdb->prepare("SELECT pm.post_id FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key IN ($keys) AND pm.meta_value=%s AND p.post_type='post' AND p.post_status IN $st LIMIT 1", $slug));
	return (int) $id;
}

/* /{lang}/blog/{slug}/ → resolve the post by that language's slug. */
add_filter('request', function ($qv) {
	if (is_admin() || empty($qv['name']) || empty($qv['deniz_lang']) || !empty($qv['post_type']) || !empty($qv['pagename'])) return $qv;
	$slug = sanitize_title(urldecode($qv['name']));
	$id   = twt_bs_find_post($slug, sanitize_key($qv['deniz_lang']));
	if ($id) {
		unset($qv['name']);
		$qv['p'] = $id;
		$GLOBALS['twt_bs_requested_slug'] = $slug;
	}
	return $qv;
});

/* Wrong-language slug → 301 to the right one (no duplicate URLs). */
add_action('template_redirect', function () {
	if (!is_singular('post') || is_preview() || empty($GLOBALS['twt_bs_requested_slug'])) return;
	$lang     = deniz_current_lang();
	$expected = twt_post_lang_slug(get_queried_object_id(), $lang);
	if ($expected && $expected !== $GLOBALS['twt_bs_requested_slug']) {
		wp_safe_redirect(twt_post_lang_url(get_queried_object_id(), $lang), 301, 'Blog Studio');
		exit;
	}
}, 2);

function twt_bs_unique_lang_slug($slug, $lang, $post_id) {
	global $wpdb;
	$slug = sanitize_title($slug);
	if ($slug === '') return '';
	if ($lang === 'tr') return wp_unique_post_slug($slug, $post_id, 'publish', 'post', 0);
	$base = $slug; $i = 2;
	while ($wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value=%s AND post_id<>%d LIMIT 1", 'deniz_' . $lang . '_slug', $slug, $post_id))) {
		$slug = $base . '-' . $i++;
	}
	return $slug;
}
/* Slugs typed into the classic EN/DE/RU box are normalised too. */
add_action('save_post', function ($id) {
	if (wp_is_post_revision($id) || get_post_type($id) !== 'post') return;
	foreach (twt_bs_langs() as $l) {
		if ($l === 'tr') continue;
		$v = get_post_meta($id, 'deniz_' . $l . '_slug', true);
		if ($v === '') continue;
		$clean = twt_bs_unique_lang_slug($v, $l, $id);
		if ($clean !== $v) update_post_meta($id, 'deniz_' . $l . '_slug', $clean);
	}
}, 30);

/* =========================================================================
 * 2) Yazıya özel SSS + dile göre görsel alt metni
 * ========================================================================= */
function twt_post_faq($post_id, $lang = null) {
	$lang = $lang ?: deniz_current_lang();
	$raw  = get_post_meta($post_id, 'deniz_' . $lang . '_faq', true);
	$out  = [];
	if ($raw) foreach ((array) json_decode($raw, true) as $f) if (!empty($f['q']) && !empty($f['a'])) $out[] = ['q' => $f['q'], 'a' => $f['a']];
	if (!$out) {
		$p = $lang === 'tr' ? '' : 'deniz_' . $lang . '_';
		for ($i = 1; $i <= 2; $i++) {
			$q = get_post_meta($post_id, $p . 'faq_' . $i . '_q', true);
			$a = get_post_meta($post_id, $p . 'faq_' . $i . '_a', true);
			if ($q && $a) $out[] = ['q' => $q, 'a' => $a];
		}
	}
	return $out;
}
add_filter('wp_get_attachment_image_attributes', function ($attr, $att) {
	if (is_admin() || !is_singular('post')) return $attr;
	$pid = get_queried_object_id();
	if ((int) get_post_thumbnail_id($pid) !== (int) $att->ID) return $attr;
	$alt = get_post_meta($pid, 'deniz_' . deniz_current_lang() . '_image_alt', true);
	if ($alt) $attr['alt'] = $alt;
	return $attr;
}, 10, 2);

/* =========================================================================
 * 3) JSON → yazı
 * ========================================================================= */
function twt_bs_template() {
	$lang = function ($l) {
		return [
			'title' => '', 'slug' => '', 'excerpt' => '', 'seo_title' => '', 'seo_description' => '',
			'focus_keyword' => '', 'hero_subtitle' => '', 'featured_image_alt' => '', 'image_alts' => ['', ''],
			'content' => '<h2>…</h2><p>…</p>{{image:1}}<h2>…</h2><p>…</p>',
			'faq' => [['q' => '', 'a' => ''], ['q' => '', 'a' => '']],
		];
	};
	$t = ['category' => 'Antalya Rehberi', 'tags' => ['antalya transfer', 'antalya havalimanı transfer']];
	foreach (twt_bs_langs() as $l) $t[$l] = $lang($l);
	return $t;
}

function twt_bs_render_images($html, array $image_ids, array $alts, $fallback_alt) {
	return preg_replace_callback('~<p>\s*\{\{\s*image\s*:\s*(\d+)\s*\}\}\s*</p>|\{\{\s*image\s*:\s*(\d+)\s*\}\}~i', function ($m) use ($image_ids, $alts, $fallback_alt) {
		$n  = (int) ($m[1] !== '' ? $m[1] : $m[2]);
		$id = $image_ids[$n - 1] ?? 0;
		if (!$id) return '';
		$alt = trim((string) ($alts[$n - 1] ?? '')) ?: $fallback_alt;
		$img = wp_get_attachment_image($id, 'large', false, ['alt' => $alt, 'loading' => 'lazy', 'class' => 'twt-blog-image']);
		return $img ? "\n<figure class=\"wp-block-image size-large twt-blog-figure\">" . $img . "</figure>\n" : '';
	}, $html);
}

/** @return array{0:array,1:array} [errors, warnings] */
function twt_bs_validate(array $d) {
	$err = []; $warn = [];
	foreach (twt_bs_langs() as $l) {
		$L = strtoupper($l);
		if (empty($d[$l]) || !is_array($d[$l])) { $err[] = "$L bölümü yok."; continue; }
		foreach (['title', 'slug', 'content'] as $k) if (trim((string) ($d[$l][$k] ?? '')) === '') $err[] = "$L: \"$k\" boş.";
		$words = twt_bs_word_count(wp_strip_all_tags((string) ($d[$l]['content'] ?? '')));
		if ($words && $words < 600) $warn[] = "$L: içerik kısa ($words kelime).";
		$st = mb_strlen((string) ($d[$l]['seo_title'] ?? ''));
		$sd = mb_strlen((string) ($d[$l]['seo_description'] ?? ''));
		if ($st > 65) $warn[] = "$L: SEO title uzun ($st karakter).";
		if ($sd > 165) $warn[] = "$L: meta description uzun ($sd karakter).";
		if (!$st) $warn[] = "$L: SEO title boş.";
		if (!$sd) $warn[] = "$L: meta description boş.";
	}
	return [$err, $warn];
}
function twt_bs_word_count($text) {
	$text = trim(preg_replace('~\s+~u', ' ', html_entity_decode((string) $text, ENT_QUOTES, 'UTF-8')));
	return $text === '' ? 0 : count(preg_split('~\s+~u', $text));
}

function twt_bs_save(array $d, array $opt) {
	[$err] = twt_bs_validate($d);
	if ($err) return new WP_Error('invalid', implode(' ', $err));

	$post_id   = (int) ($opt['post_id'] ?? 0);
	$images    = array_values(array_filter(array_map('intval', (array) ($opt['images'] ?? []))));
	$featured  = (int) ($opt['featured'] ?? 0);
	$status    = in_array($opt['status'] ?? 'draft', ['draft', 'publish', 'future', 'pending'], true) ? $opt['status'] : 'draft';
	$tr        = $d['tr'];
	$content   = function ($l) use ($d, $images) {
		$x = $d[$l];
		return wp_kses_post(twt_bs_render_images((string) $x['content'], $images, (array) ($x['image_alts'] ?? []), (string) (($x['featured_image_alt'] ?? '') ?: $x['title'])));
	};

	$postarr = [
		'post_type' => 'post', 'post_status' => $status,
		'post_title' => sanitize_text_field($tr['title']), 'post_excerpt' => sanitize_textarea_field($tr['excerpt'] ?? ''),
		'post_content' => $content('tr'), 'post_name' => sanitize_title($tr['slug']),
	];
	if ($status === 'future' && !empty($opt['date']) && ($ts = strtotime($opt['date']))) {
		$postarr['post_date']     = gmdate('Y-m-d H:i:s', $ts); // datetime-local = site saati
		$postarr['post_date_gmt'] = get_gmt_from_date($postarr['post_date']);
		$postarr['edit_date']     = true;
	} elseif ($status === 'future') {
		$postarr['post_status'] = 'draft';
	}
	if ($post_id) { $postarr['ID'] = $post_id; $res = wp_update_post(wp_slash($postarr), true); }
	else $res = wp_insert_post(wp_slash($postarr), true);
	if (is_wp_error($res)) return $res;
	$post_id = (int) $res;

	// Category & tags
	if (!empty($d['category'])) {
		$cat = term_exists($d['category'], 'category') ?: wp_insert_term(sanitize_text_field($d['category']), 'category');
		if (!is_wp_error($cat)) wp_set_post_categories($post_id, [(int) (is_array($cat) ? $cat['term_id'] : $cat)]);
	}
	if (!empty($d['tags']) && is_array($d['tags'])) wp_set_post_tags($post_id, array_map('sanitize_text_field', $d['tags']));

	// TR meta
	$m = function ($k, $v) use ($post_id) { update_post_meta($post_id, $k, wp_slash($v)); };
	$m('seo_title', sanitize_text_field($tr['seo_title'] ?? ''));
	$m('seo_description', sanitize_textarea_field($tr['seo_description'] ?? ''));
	$m('hero_subtitle', sanitize_text_field($tr['hero_subtitle'] ?? ''));

	foreach (twt_bs_langs() as $l) {
		$x = $d[$l];
		$p = 'deniz_' . $l . '_';
		$faq = [];
		foreach ((array) ($x['faq'] ?? []) as $f) if (!empty($f['q']) && !empty($f['a'])) $faq[] = ['q' => sanitize_text_field($f['q']), 'a' => wp_kses_post($f['a'])];
		$m($p . 'faq', wp_json_encode($faq, JSON_UNESCAPED_UNICODE));
		$m($p . 'focus_keyword', sanitize_text_field($x['focus_keyword'] ?? ''));
		$m($p . 'image_alt', sanitize_text_field($x['featured_image_alt'] ?? ''));
		if ($l === 'tr') {
			$m('deniz_tr_slug', get_post_field('post_name', $post_id));
			for ($i = 1; $i <= 2; $i++) { $m('faq_' . $i . '_q', $faq[$i - 1]['q'] ?? ''); $m('faq_' . $i . '_a', $faq[$i - 1]['a'] ?? ''); }
			continue;
		}
		$m($p . 'title', sanitize_text_field($x['title']));
		$m($p . 'slug', twt_bs_unique_lang_slug($x['slug'], $l, $post_id));
		$m($p . 'excerpt', sanitize_textarea_field($x['excerpt'] ?? ''));
		$m($p . 'content', $content($l));
		$m($p . 'seo_title', sanitize_text_field($x['seo_title'] ?? ''));
		$m($p . 'seo_description', sanitize_textarea_field($x['seo_description'] ?? ''));
		$m($p . 'hero_subtitle', sanitize_text_field($x['hero_subtitle'] ?? ''));
		for ($i = 1; $i <= 2; $i++) { $m($p . 'faq_' . $i . '_q', $faq[$i - 1]['q'] ?? ''); $m($p . 'faq_' . $i . '_a', $faq[$i - 1]['a'] ?? ''); }
	}

	if ($featured) {
		set_post_thumbnail($post_id, $featured);
		if (!get_post_meta($featured, '_wp_attachment_image_alt', true) && !empty($tr['featured_image_alt'])) update_post_meta($featured, '_wp_attachment_image_alt', sanitize_text_field($tr['featured_image_alt']));
	}
	foreach ($images as $i => $img) {
		if (!get_post_meta($img, '_wp_attachment_image_alt', true) && !empty($tr['image_alts'][$i])) update_post_meta($img, '_wp_attachment_image_alt', sanitize_text_field($tr['image_alts'][$i]));
	}

	// Kaynak JSON saklanır → sonradan stüdyoda açıp güncellenebilir.
	$m('twt_bs_source', wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
	$m('twt_bs_images', implode(',', $images));
	clean_post_cache($post_id);
	if (function_exists('twt_sm_flush_cache')) twt_sm_flush_cache();
	return $post_id;
}

/* =========================================================================
 * 4) Yönetim ekranı
 * ========================================================================= */
add_action('admin_menu', function () {
	add_posts_page('4 Dilli Yazı Stüdyosu', '4 Dilli Yazı Ekle', 'edit_posts', 'twt-blog-studio', 'twt_bs_page');
});
add_filter('post_row_actions', function ($a, $post) {
	if ($post->post_type === 'post' && current_user_can('edit_post', $post->ID)) $a['twt_bs'] = '<a href="' . esc_url(admin_url('edit.php?page=twt-blog-studio&post=' . $post->ID)) . '">4 dilde düzenle</a>';
	return $a;
}, 10, 2);
add_action('admin_enqueue_scripts', function ($hook) { if ($hook === 'posts_page_twt-blog-studio') wp_enqueue_media(); });

add_action('admin_post_twt_bs_save', function () {
	if (!current_user_can('edit_posts')) wp_die('Yetki yok');
	check_admin_referer('twt_bs_save');
	$raw  = twt_bs_strip_fences(wp_unslash($_POST['twt_bs_json'] ?? ''));
	$data = json_decode($raw, true);
	$opt  = [
		'post_id'  => absint($_POST['twt_bs_post'] ?? 0),
		'featured' => absint($_POST['twt_bs_featured'] ?? 0),
		'images'   => array_filter(array_map('absint', explode(',', (string) ($_POST['twt_bs_images'] ?? '')))),
		'status'   => sanitize_key($_POST['twt_bs_status'] ?? 'draft'),
		'date'     => sanitize_text_field($_POST['twt_bs_date'] ?? ''),
	];
	if ($opt['post_id'] && !current_user_can('edit_post', $opt['post_id'])) wp_die('Yetki yok');
	if ($opt['status'] === 'publish' && !current_user_can('publish_posts')) $opt['status'] = 'pending';
	$res = is_array($data) ? twt_bs_save($data, $opt) : new WP_Error('json', 'JSON okunamadı: ' . json_last_error_msg());
	if (is_wp_error($res)) {
		set_transient('twt_bs_draft_' . get_current_user_id(), ['json' => $raw, 'opt' => $opt, 'error' => $res->get_error_message()], HOUR_IN_SECONDS);
		wp_safe_redirect(admin_url('edit.php?page=twt-blog-studio&restore=1'));
		exit;
	}
	wp_safe_redirect(admin_url('edit.php?page=twt-blog-studio&saved=' . $res));
	exit;
});

function twt_bs_page() {
	if (!current_user_can('edit_posts')) return;
	$json = ''; $opt = ['post_id' => 0, 'featured' => 0, 'images' => [], 'status' => 'draft', 'date' => '']; $error = '';
	if (isset($_GET['restore']) && ($t = get_transient('twt_bs_draft_' . get_current_user_id()))) {
		$json = $t['json']; $opt = array_merge($opt, $t['opt']); $error = $t['error'];
		delete_transient('twt_bs_draft_' . get_current_user_id());
	} elseif (!empty($_GET['post']) && current_user_can('edit_post', absint($_GET['post']))) {
		$pid = absint($_GET['post']);
		$src = get_post_meta($pid, 'twt_bs_source', true);
		$json = $src ? wp_json_encode(json_decode($src, true), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
		$opt['post_id'] = $pid;
		$opt['featured'] = (int) get_post_thumbnail_id($pid);
		$opt['images'] = array_filter(array_map('intval', explode(',', (string) get_post_meta($pid, 'twt_bs_images', true))));
		$opt['status'] = get_post_status($pid) === 'publish' ? 'publish' : 'draft';
		if (!$src) $error = 'Bu yazı stüdyo ile oluşturulmamış; mevcut içerik JSON\'a çevrilemez. Yeni JSON yapıştırırsanız bu yazının üzerine yazılır.';
	}
	$saved = absint($_GET['saved'] ?? 0);
	$tpl = wp_json_encode(twt_bs_template(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	$thumb = function ($id) { return $id ? wp_get_attachment_image_url($id, 'thumbnail') : ''; };
	$imgs = array_map(fn($id) => ['id' => $id, 'url' => $thumb($id)], $opt['images']);
	$recent = get_posts(['post_type' => 'post', 'post_status' => ['publish', 'draft', 'future', 'pending'], 'posts_per_page' => 50, 'orderby' => 'modified']);
	$home = home_url('/');
	?>
	<div class="wrap twt-bs">
	<h1>4 Dilli Yazı Stüdyosu <span class="twt-bs-pill">TR · EN · DE · RU</span></h1>
	<p class="description">JSON'u yapıştırın, görselleri seçin, kaydedin. Her dil kendi slug'ı, SEO başlığı, meta açıklaması ve SSS'si ile yayınlanır; hreflang ve sitemap otomatik güncellenir.</p>

	<?php if ($saved && get_post($saved)): ?>
		<div class="notice notice-success"><p><b>Kaydedildi (<?php echo esc_html(get_post_status($saved)); ?>).</b>
		<?php foreach (twt_bs_langs() as $l) echo ' <a target="_blank" href="' . esc_url(twt_post_lang_url($saved, $l)) . '">' . esc_html(strtoupper($l)) . '</a> ·'; ?>
		<a href="<?php echo esc_url(get_edit_post_link($saved)); ?>">WordPress editöründe aç</a> ·
		<a href="<?php echo esc_url(admin_url('edit.php?page=twt-blog-studio&post=' . $saved)); ?>">Stüdyoda düzenle</a></p></div>
	<?php endif; if ($error): ?>
		<div class="notice notice-error"><p><?php echo esc_html($error); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="twt-bs-form">
	<?php wp_nonce_field('twt_bs_save'); ?>
	<input type="hidden" name="action" value="twt_bs_save">
	<input type="hidden" name="twt_bs_featured" id="twt-bs-featured" value="<?php echo (int) $opt['featured']; ?>">
	<input type="hidden" name="twt_bs_images" id="twt-bs-images" value="<?php echo esc_attr(implode(',', $opt['images'])); ?>">

	<div class="twt-bs-grid">
	 <div class="twt-bs-main">
	  <div class="twt-bs-card">
	   <div class="twt-bs-bar"><b>1 · JSON</b>
	    <span><button type="button" class="button" id="twt-bs-tpl">Boş şablonu yükle</button> <button type="button" class="button" id="twt-bs-fmt">Biçimlendir</button> <button type="button" class="button button-secondary" id="twt-bs-check">Kontrol et</button></span></div>
	   <textarea name="twt_bs_json" id="twt-bs-json" spellcheck="false" placeholder='{"category":"…","tr":{…},"en":{…},"de":{…},"ru":{…}}'><?php echo esc_textarea($json); ?></textarea>
	   <p class="description">```json çitleriyle yapıştırırsanız otomatik temizlenir. İçerikte görsel yeri için <code>{{image:1}}</code>, <code>{{image:2}}</code> … kullanın.</p>
	  </div>
	  <div class="twt-bs-card"><b>Önizleme ve SEO kontrolü</b><div id="twt-bs-preview"><p class="description">JSON yapıştırıp "Kontrol et"e basın.</p></div></div>
	 </div>

	 <div class="twt-bs-side">
	  <div class="twt-bs-card"><b>2 · Öne çıkan görsel</b>
	   <div id="twt-bs-feat-prev" class="twt-bs-thumbs"><?php if ($opt['featured']) echo '<img src="' . esc_url($thumb($opt['featured'])) . '">'; ?></div>
	   <button type="button" class="button" id="twt-bs-feat-btn">Görsel seç</button> <button type="button" class="button-link" id="twt-bs-feat-clear">Kaldır</button>
	  </div>
	  <div class="twt-bs-card"><b>3 · İçerik görselleri</b>
	   <p class="description">Seçim sırası numarayı belirler: 1. görsel = <code>{{image:1}}</code>.</p>
	   <div id="twt-bs-img-prev" class="twt-bs-thumbs"></div>
	   <button type="button" class="button" id="twt-bs-img-btn">Görselleri seç</button> <button type="button" class="button-link" id="twt-bs-img-clear">Temizle</button>
	  </div>
	  <div class="twt-bs-card"><b>4 · Kaydet</b>
	   <p><label>Hedef yazı<br><select name="twt_bs_post" style="width:100%">
	    <option value="0">+ Yeni yazı oluştur</option>
	    <?php foreach ($recent as $p) echo '<option value="' . (int) $p->ID . '"' . selected($opt['post_id'], $p->ID, false) . '>#' . (int) $p->ID . ' · ' . esc_html(wp_trim_words($p->post_title, 8)) . ' (' . esc_html($p->post_status) . ')</option>'; ?>
	   </select></label></p>
	   <p><label>Durum<br><select name="twt_bs_status" id="twt-bs-status" style="width:100%">
	    <?php foreach (['draft' => 'Taslak', 'pending' => 'İncelemede', 'publish' => 'Hemen yayınla', 'future' => 'Zamanla'] as $k => $v) echo '<option value="' . esc_attr($k) . '"' . selected($opt['status'], $k, false) . '>' . esc_html($v) . '</option>'; ?>
	   </select></label></p>
	   <p id="twt-bs-date-wrap" style="display:none"><label>Yayın tarihi<br><input type="datetime-local" name="twt_bs_date" value="<?php echo esc_attr($opt['date']); ?>" style="width:100%"></label></p>
	   <button type="submit" class="button button-primary button-hero" id="twt-bs-submit" style="width:100%">Kaydet</button>
	   <p class="description">Kaydetmeden önce otomatik kontrol yapılır; zorunlu alan eksikse kaydedilmez.</p>
	  </div>
	  <details class="twt-bs-card"><summary><b>Claude'a verilecek istek şablonu</b></summary>
	   <textarea readonly class="twt-bs-prompt" onclick="this.select()">Antalya Transfer Pro blogu için [KONU] hakkında, her dilde yaklaşık 2000 kelimelik bir yazı yaz. Ana anahtar kelimeler: TR "[...]", EN "[...]", DE "[...]", RU "[...]".
Yalnızca aşağıdaki JSON şablonunda, geçerli JSON olarak ver. content alanı HTML olsun (h2, h3, p, ul, ol, table, a, strong), h1 kullanma. Her dilin kendi slug'ı olsun (küçük harf, Latin karakter, tire). seo_title ≤ 60, seo_description ≤ 155 karakter. Her dilde 5-6 SSS. Görsel yerleri için {{image:1}} ve {{image:2}} koy, image_alts doldur. İç linkler sitedeki dil sayfalarına gitsin (/tr/…, /en/…, /de/…, /ru/…).

<?php echo esc_textarea($tpl); ?></textarea>
	  </details>
	 </div>
	</div>
	</form>
	</div>
	<style>
	.twt-bs-pill{font-size:12px;background:#061c3d;color:#34c9a0;border-radius:999px;padding:3px 10px;vertical-align:middle;margin-left:6px}
	.twt-bs-grid{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:20px;margin-top:16px}@media(max-width:1100px){.twt-bs-grid{grid-template-columns:1fr}}
	.twt-bs-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px;margin-bottom:16px}
	.twt-bs-bar{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}
	#twt-bs-json{width:100%;min-height:520px;font:12px/1.5 Menlo,Consolas,monospace;border-radius:8px;background:#0b1220;color:#d6e2ff;padding:12px}
	.twt-bs-prompt{width:100%;min-height:260px;font:12px/1.5 Menlo,Consolas,monospace;margin-top:10px}
	.twt-bs-thumbs{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}.twt-bs-thumbs figure{margin:0;position:relative}.twt-bs-thumbs img{width:86px;height:66px;object-fit:cover;border-radius:6px;border:1px solid #dcdcde}
	.twt-bs-thumbs figcaption{position:absolute;top:4px;left:4px;background:#061c3d;color:#fff;font-size:11px;border-radius:4px;padding:0 5px}
	.twt-bs-tabs{display:flex;gap:6px;margin:12px 0}.twt-bs-tabs button{border:1px solid #dcdcde;background:#f6f7f7;border-radius:6px;padding:5px 12px;cursor:pointer;font-weight:600}.twt-bs-tabs button.on{background:#061c3d;color:#fff;border-color:#061c3d}
	.twt-bs-kv{display:grid;grid-template-columns:150px 1fr;gap:6px 12px;font-size:13px}.twt-bs-kv dt{color:#646970}.twt-bs-kv dd{margin:0;word-break:break-word}
	.twt-ok{color:#1a7f37;font-weight:600}.twt-warn{color:#996800;font-weight:600}.twt-bad{color:#b32d2e;font-weight:600}
	.twt-bs-msgs li{margin:2px 0}.twt-bs-body{max-height:420px;overflow:auto;border:1px solid #eee;border-radius:8px;padding:12px;margin-top:10px;background:#fbfbfb}
	</style>
	<script>
	(function($){
	 var TPL=<?php echo wp_json_encode($tpl); ?>, HOME=<?php echo wp_json_encode($home); ?>, LANGS=['tr','en','de','ru'];
	 var imgs=<?php echo wp_json_encode($imgs); ?>;
	 var $j=$('#twt-bs-json');
	 function strip(s){return s.replace(/^\s*```(?:json)?\s*/i,'').replace(/\s*```\s*$/,'').trim();}
	 function parse(){try{return {d:JSON.parse(strip($j.val()))};}catch(e){return {e:e.message};}}
	 function txt(h){var d=document.createElement('div');d.innerHTML=h||'';return (d.textContent||'').replace(/\s+/g,' ').trim();}
	 function words(h){var t=txt(h);return t?t.split(' ').length:0;}
	 function esc(s){return $('<div>').text(s==null?'':String(s)).html();}
	 function len(v,max,min){var n=(v||'').length;var c=!n?'twt-bad':(n>max?'twt-warn':(n<min?'twt-warn':'twt-ok'));return '<span class="'+c+'">'+n+' / '+max+'</span>';}
	 function density(h,kw){if(!kw)return '<span class="twt-warn">anahtar kelime yok</span>';var t=txt(h).toLowerCase(),k=kw.toLowerCase(),n=t.split(k).length-1,w=words(h)||1,p=(n*k.split(' ').length/w*100);var c=p<0.5?'twt-warn':(p>2.5?'twt-bad':'twt-ok');return '<span class="'+c+'">'+n+' kez · %'+p.toFixed(2)+'</span>'+(p>2.5?' <span class="twt-bad">(fazla – spam riski)</span>':'');}
	 function check(){
	  var r=parse(),$p=$('#twt-bs-preview');
	  if(r.e){$p.html('<p class="twt-bad">JSON hatası: '+esc(r.e)+'</p>');return false;}
	  var d=r.d,errs=[],warns=[],slugs={};
	  LANGS.forEach(function(l){var x=d[l];var L=l.toUpperCase();if(!x){errs.push(L+' bölümü yok');return;}
	   ['title','slug','content'].forEach(function(k){if(!(x[k]||'').trim())errs.push(L+': '+k+' boş');});
	   if(x.slug&&!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(x.slug))warns.push(L+': slug Latin küçük harf ve tire olmalı ("'+x.slug+'")');
	   if(x.slug){if(slugs[x.slug])warns.push(L+': slug '+slugs[x.slug]+' ile aynı');slugs[x.slug]=L;}
	   var w=words(x.content);if(w&&w<600)warns.push(L+': içerik kısa ('+w+' kelime)');
	   var need=((x.content||'').match(/\{\{\s*image\s*:\s*(\d+)\s*\}\}/gi)||[]).map(function(m){return +m.replace(/\D/g,'');});
	   need.forEach(function(n){if(n>imgs.length)warns.push(L+': {{image:'+n+'}} için görsel seçilmedi');});
	   if(/<h1[\s>]/i.test(x.content||''))warns.push(L+': içerikte H1 var; başlık zaten H1');
	  });
	  var tabs='<div class="twt-bs-tabs">'+LANGS.map(function(l,i){return '<button type="button" data-l="'+l+'" class="'+(i?'':'on')+'">'+l.toUpperCase()+'</button>';}).join('')+'</div>';
	  var panes=LANGS.map(function(l,i){var x=d[l]||{};var url=HOME+l+'/blog/'+(x.slug||'…')+'/';
	   return '<div class="twt-bs-pane" data-l="'+l+'" style="'+(i?'display:none':'')+'"><dl class="twt-bs-kv">'+
	    '<dt>Başlık</dt><dd><b>'+esc(x.title)+'</b></dd><dt>URL</dt><dd><code>'+esc(url)+'</code></dd>'+
	    '<dt>SEO title</dt><dd>'+esc(x.seo_title)+' '+len(x.seo_title,60,30)+'</dd>'+
	    '<dt>Meta description</dt><dd>'+esc(x.seo_description)+' '+len(x.seo_description,155,110)+'</dd>'+
	    '<dt>Kelime sayısı</dt><dd>'+words(x.content)+'</dd><dt>Anahtar kelime</dt><dd>'+esc(x.focus_keyword)+' → '+density(x.content,x.focus_keyword)+'</dd>'+
	    '<dt>H2 / H3</dt><dd>'+((x.content||'').match(/<h2/gi)||[]).length+' / '+((x.content||'').match(/<h3/gi)||[]).length+'</dd>'+
	    '<dt>İç link</dt><dd>'+((x.content||'').match(/<a\s/gi)||[]).length+'</dd><dt>SSS</dt><dd>'+((x.faq||[]).filter(function(f){return f.q&&f.a;}).length)+' soru</dd>'+
	    '</dl><div class="twt-bs-body">'+(x.content||'').replace(/\{\{\s*image\s*:\s*(\d+)\s*\}\}/gi,'<p style="background:#e9f5fb;padding:10px;border-radius:6px">🖼 Görsel $1</p>')+'</div></div>';}).join('');
	  var msgs=(errs.length?'<ul class="twt-bs-msgs">'+errs.map(function(e){return '<li class="twt-bad">✕ '+esc(e)+'</li>';}).join('')+'</ul>':'<p class="twt-ok">✓ Zorunlu alanlar tamam.</p>')+
	   (warns.length?'<ul class="twt-bs-msgs">'+warns.map(function(e){return '<li class="twt-warn">! '+esc(e)+'</li>';}).join('')+'</ul>':'');
	  $p.html(msgs+tabs+panes);
	  return !errs.length;
	 }
	 $(document).on('click','.twt-bs-tabs button',function(){var l=$(this).data('l');$('.twt-bs-tabs button').removeClass('on');$(this).addClass('on');$('.twt-bs-pane').hide().filter('[data-l="'+l+'"]').show();});
	 $('#twt-bs-check').on('click',check);
	 $('#twt-bs-tpl').on('click',function(){if(!$j.val().trim()||confirm('Mevcut JSON silinsin mi?'))$j.val(TPL);});
	 $('#twt-bs-fmt').on('click',function(){var r=parse();if(r.d)$j.val(JSON.stringify(r.d,null,2));else alert('JSON hatası: '+r.e);});
	 $('#twt-bs-form').on('submit',function(e){if(!check()){e.preventDefault();$('html,body').animate({scrollTop:$('#twt-bs-preview').offset().top-60});}});
	 function stat(){$('#twt-bs-date-wrap').toggle($('#twt-bs-status').val()==='future');}$('#twt-bs-status').on('change',stat);stat();
	 function drawImgs(){$('#twt-bs-images').val(imgs.map(function(i){return i.id;}).join(','));$('#twt-bs-img-prev').html(imgs.map(function(i,n){return '<figure><img src="'+i.url+'"><figcaption>'+(n+1)+'</figcaption></figure>';}).join(''));}
	 drawImgs();
	 var fFrame,iFrame;
	 $('#twt-bs-feat-btn').on('click',function(){fFrame=fFrame||wp.media({title:'Öne çıkan görsel',library:{type:'image'},multiple:false});fFrame.off('select').on('select',function(){var a=fFrame.state().get('selection').first().toJSON();$('#twt-bs-featured').val(a.id);$('#twt-bs-feat-prev').html('<img src="'+((a.sizes&&a.sizes.thumbnail)?a.sizes.thumbnail.url:a.url)+'">');});fFrame.open();});
	 $('#twt-bs-feat-clear').on('click',function(){$('#twt-bs-featured').val(0);$('#twt-bs-feat-prev').empty();});
	 $('#twt-bs-img-btn').on('click',function(){iFrame=iFrame||wp.media({title:'İçerik görselleri (sırayla seçin)',library:{type:'image'},multiple:'add'});iFrame.off('select').on('select',function(){iFrame.state().get('selection').each(function(m){var a=m.toJSON();if(!imgs.some(function(i){return i.id===a.id;}))imgs.push({id:a.id,url:(a.sizes&&a.sizes.thumbnail)?a.sizes.thumbnail.url:a.url});});drawImgs();check();});iFrame.open();});
	 $('#twt-bs-img-clear').on('click',function(){imgs=[];drawImgs();});
	 if($j.val().trim())check();
	})(jQuery);
	</script>
	<?php
}
