<?php
if (!defined('ABSPATH')) exit;

/* One catalogue shared by templates, AJAX UI and the existing translation centre.
 * Extensions may register new four-language strings through twt_ui_strings.
 * Proper hotel/vehicle/place names are preserved unless a translated name exists.
 */
function twt_ui_strings(){
 static $strings=null;
 if($strings===null){
  $data=json_decode(file_get_contents(__DIR__.'/ui-strings.json'),true);
  $strings=apply_filters('twt_ui_strings',is_array($data)?$data:[]);
 }
 return $strings;
}
function twt_ui_default($key,$lang){
 $all=twt_ui_strings();
 return $all[$key][$lang] ?? $all[$key]['en'] ?? null;
}
function twt_ui_payload(){
 $out=[];foreach(twt_ui_strings() as $key=>$row) $out[$key]=deniz_t($key);
 return $out;
}
function twt_entity_name($entity,$type='region'){
 if(!$entity) return '';
 $lang=deniz_current_lang();$name=(string)($entity->name??'');
 foreach(['name_'.$lang,$lang.'_name'] as $column) if(!empty($entity->$column)){$name=(string)$entity->$column;break;}
 if(!empty($entity->translations)){
  $translations=is_string($entity->translations)?json_decode($entity->translations,true):(array)$entity->translations;
  if(!empty($translations[$lang]['name']))$name=(string)$translations[$lang]['name'];
  elseif(!empty($translations[$lang]) && is_string($translations[$lang]))$name=$translations[$lang];
 }
 if($type==='airport' && strtoupper((string)($entity->iata??''))==='AYT') $name=deniz_t('antalya_airport');
 elseif($type==='airport' && $name===(string)($entity->name??'')){
  $base=trim(preg_replace('/\s*\([A-Z]{3}\)\s*$/u','',$name));
  $base=trim(preg_replace('/\b(?:International\s+)?Airport\b|\bHavalimanı\b|\bFlughafen\b|\bАэропорт\b/iu','',$base));
  if($base!=='' && $base!==$name) $name=sprintf(deniz_t('airport_name'),$base);
 }
 $key='entity_'.sanitize_key($type).'_'.absint($entity->id??0).'_name';
 return deniz_translation_override($key,$lang,$name);
}
function twt_dynamic_translation_keys(){
 static $cached=null;if($cached!==null)return $cached;
 global $wpdb;$tables=deniz_tables();$keys=[];
 foreach(['airports'=>'airport','regions'=>'region','vehicles'=>'vehicle','extras'=>'extra'] as $table=>$type){
  foreach((array)$wpdb->get_results("SELECT id,name FROM {$tables[$table]} WHERE active=1 ORDER BY name") as $row){
   $keys['entity_'.$type.'_'.(int)$row->id.'_name']=$row->name;
   if($type==='vehicle')$keys['entity_vehicle_'.(int)$row->id.'_features']=$row->name.' · Features (separate with |)';
  }
 }
 return $cached=$keys;
}
function twt_hero_heading($title){
 $service=deniz_t('hero_title_service');$offset=strpos($title,$service);
 if($offset===false) return esc_html($title);
 return esc_html(substr($title,0,$offset)).'<span>'.esc_html($service).'</span>'.esc_html(substr($title,$offset+strlen($service)));
}
function twt_entity_features($entity){
 if(function_exists('twt_localized_vehicle_features'))return twt_localized_vehicle_features($entity);
 $raw=deniz_translation_override('entity_vehicle_'.absint($entity->id??0).'_features',deniz_current_lang(),(string)($entity->features??''));
 $items=preg_split('/[\r\n|]+/',$raw);$lookup=[];
 foreach(twt_ui_strings() as $key=>$row)foreach($row as $value)$lookup[strtolower(trim($value))]=$key;
 return array_values(array_filter(array_map(function($item)use($lookup){$item=trim($item);$key=$lookup[strtolower($item)]??null;return $key?deniz_t($key):$item;},$items)));
}

function twt_place_label($name){
 return in_array(strtolower(trim((string)$name)),['turkey','türkiye','turkiye'],true)?deniz_t('turkey'):(string)$name;
}
function twt_icon($name){
 $paths=[
  'plane'=>'<path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="m22 2-11 11"/>',
  'hotel'=>'<path d="M6 21V3h12v18M3 21h18M9 7h1m4 0h1M9 11h1m4 0h1M10 21v-6h4v6"/>',
  'return'=>'<path d="M4 7h16l-4-4M20 17H4l4 4M20 7l-4 4M4 17l4-4"/>',
  'pin'=>'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  'calendar'=>'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
  'clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  'users'=>'<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M17 4a3 3 0 0 1 0 6m4 11v-3a6 6 0 0 0-3-5"/>',
  'search'=>'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  'tag'=>'<path d="M20 13 11 22 2 13V2h11l7 7v4Z"/><circle cx="7" cy="7" r="1"/>',
  'support'=>'<path d="M3 14v-3a9 9 0 0 1 18 0v3M18 19a6 6 0 0 1-6 3"/><rect x="2" y="11" width="4" height="8" rx="2"/><rect x="18" y="11" width="4" height="8" rx="2"/>',
  'card'=>'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 9h20M6 15h4"/>',
 ];
 return '<svg class="twt-ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$name]??$paths['pin']).'</svg>';
}
