<?php
if (!defined('ABSPATH')) exit;
/* Antalya Transfer Pro — brand, contact and licence data (single source of truth). */
function twt_brand_name(){ return 'Antalya Transfer Pro'; }
function twt_brand_domain(){ return 'antalyatransferpro.com'; }
function twt_brand_logo_url(){ return get_template_directory_uri().'/assets/images/antalyatransferpro-logo.webp'; }
function twt_brand_logo_white_url(){ return get_template_directory_uri().'/assets/images/antalyatransferpro-logo-white.png'; }
function atp_img($file){ return get_template_directory_uri().'/assets/images/'.$file; }
function atp_contact(){
 return [
  'phone_display'=>'+90 542 792 07 92',
  'phone'=>'+905427920792',
  'whatsapp'=>'905427920792',
  'email'=>(function_exists('deniz_support_email')?deniz_support_email():get_option('admin_email')),
  'street'=>'Altıntaş Mah. Kardeş Kentler Cad. Selvi İş Merkezi No:85 İç Kapı No:1',
  'locality'=>'Aksu',
  'region'=>'Antalya',
  'country'=>'TR',
  'country_name'=>'Türkiye',
  'address'=>'Altıntaş Mah. Kardeş Kentler Cad. Selvi İş Merkezi No:85 İç Kapı No:1, Aksu / Antalya, Türkiye',
  'tursab'=>'18926',
  'tursab_url'=>'https://www.tursab.org.tr/tr/ddsv',
  'map'=>'https://www.google.com/maps/search/?api=1&query='.rawurlencode('Selvi İş Merkezi Kardeş Kentler Caddesi No:85 Altıntaş Aksu Antalya'),
 ];
}
function atp_phone_link(){ return 'tel:'.atp_contact()['phone']; }
function atp_whatsapp_link($text=''){ $u='https://wa.me/'.atp_contact()['whatsapp']; return $text!==''?add_query_arg('text',rawurlencode($text),$u):$u; }

/* One-time brand migration: site title, tagline and booking settings defaults. */
add_action('init', function(){
 if(get_option('atp_brand_v1_done')) return;
 update_option('blogname', twt_brand_name());
 update_option('blogdescription', 'Antalya Airport Transfer · TÜRSAB 18926');
 $opts=get_option('deniz_transfer_settings',[]); if(!is_array($opts)) $opts=[];
 $c=atp_contact();
 $opts['company_name']=twt_brand_name();
 if(empty($opts['support_phone'])) $opts['support_phone']=$c['phone_display'];
 if(empty($opts['whatsapp_number'])) $opts['whatsapp_number']=$c['whatsapp'];
 if(empty($opts['company_address'])) $opts['company_address']=$c['address'];
 update_option('deniz_transfer_settings',$opts,false);
 update_option('atp_brand_v1_done',1,false);
}, 2);

/* Antalya Transfer Pro favicon / app icon set. Theme icons are authoritative so
 * browser tabs, bookmarks and mobile home-screen shortcuts use the same brand mark. */
add_action('init',function(){ remove_action('wp_head','wp_site_icon',99); },1);
add_action('wp_head',function(){
 $v=wp_get_theme()->get('Version');
 $u=static fn($file)=>add_query_arg('ver',$v,atp_img($file));
 echo '<link rel="icon" href="'.esc_url($u('favicon.ico')).'" sizes="any">'."\n";
 echo '<link rel="icon" type="image/png" sizes="16x16" href="'.esc_url($u('favicon-16.png')).'">'."\n";
 echo '<link rel="icon" type="image/png" sizes="32x32" href="'.esc_url($u('favicon-32.png')).'">'."\n";
 echo '<link rel="icon" type="image/png" sizes="48x48" href="'.esc_url($u('favicon-48.png')).'">'."\n";
 echo '<link rel="icon" type="image/png" sizes="192x192" href="'.esc_url($u('icon-192.png')).'">'."\n";
 echo '<link rel="apple-touch-icon" sizes="180x180" href="'.esc_url($u('apple-touch-icon.png')).'">'."\n";
},2);
add_action('wp_head',function(){
 echo '<meta name="theme-color" content="#06285A">'."\n";
 if(is_admin())return;
 echo '<meta name="geo.region" content="TR-07">'."\n".'<meta name="geo.placename" content="Antalya">'."\n";
},4);
add_action('admin_head',function(){ echo '<link rel="icon" href="'.esc_url(add_query_arg('ver',wp_get_theme()->get('Version'),atp_img('favicon.ico'))).'">'; });

/* Login screen branding. */
add_action('login_enqueue_scripts',function(){echo '<style>#login h1 a{background:url('.esc_url(twt_brand_logo_url()).') center/contain no-repeat;width:280px;height:60px}body.login{background:#f3f7fb}.wp-core-ui .button-primary{background:#06285A;border-color:#06285A}</style>';});
add_filter('login_headerurl',fn()=>home_url('/'));
add_filter('login_headertext',fn()=>twt_brand_name());

/* Floating WhatsApp + call button on public pages (not inside the booking checkout). */
add_action('wp_footer',function(){
 if(is_admin()||(function_exists('twt_seo_private_page')&&twt_seo_private_page()))return;
 $lang=function_exists('deniz_current_lang')?deniz_current_lang():'en';
 $msg=['tr'=>'Merhaba, Antalya transfer rezervasyonu hakkında bilgi almak istiyorum.','en'=>'Hello, I would like information about an Antalya transfer booking.','de'=>'Hallo, ich hätte gern Informationen zu einem Transfer in Antalya.','ru'=>'Здравствуйте, хочу узнать о трансфере в Анталье.'][$lang]??'Hello';
 echo '<div class="atp-float" role="complementary" aria-label="WhatsApp"><a class="atp-float-wa" href="'.esc_url(atp_whatsapp_link($msg)).'" target="_blank" rel="noopener nofollow" aria-label="WhatsApp"><svg viewBox="0 0 32 32" width="26" height="26" aria-hidden="true"><path fill="currentColor" d="M16 3a13 13 0 0 0-11.2 19.6L3 29l6.6-1.7A13 13 0 1 0 16 3zm0 23.7c-2 0-4-.6-5.7-1.6l-.4-.2-3.9 1 1-3.8-.3-.4A10.7 10.7 0 1 1 16 26.7zm5.9-8c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2l-1 1.2c-.2.2-.4.2-.7.1a8.8 8.8 0 0 1-4.4-3.8c-.3-.6.3-.5.9-1.7.1-.2 0-.4 0-.5l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.1 1.1-1.1 2.7s1.2 3.2 1.3 3.4c.2.2 2.3 3.5 5.6 4.9 2.1.9 2.9.9 4 .8.6-.1 1.9-.8 2.2-1.5.3-.8.3-1.4.2-1.5l-.6-.3z"/></svg></a><a class="atp-float-call" href="'.esc_url(atp_phone_link()).'" aria-label="'.esc_attr(atp_contact()['phone_display']).'"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z"/></svg></a></div>';
},50);

/* First run: static front page + posts page so /{lang}/blog/ never renders the homepage template. */
add_action('init',function(){
 if(get_option('atp_reading_v1')) return;
 if(get_option('show_on_front')!=='page'||!(int)get_option('page_on_front')){
  $home=get_page_by_path('home'); $hid=$home?$home->ID:wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Home','post_name'=>'home']);
  if($hid&&!is_wp_error($hid)){ update_option('show_on_front','page'); update_option('page_on_front',(int)$hid); }
 }
 if(!(int)get_option('page_for_posts')){
  $blog=get_page_by_path('blog'); $bid=$blog?$blog->ID:wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Blog','post_name'=>'blog']);
  if($bid&&!is_wp_error($bid)) update_option('page_for_posts',(int)$bid);
 }
 update_option('atp_reading_v1',1,false); flush_rewrite_rules(false);
},40);
