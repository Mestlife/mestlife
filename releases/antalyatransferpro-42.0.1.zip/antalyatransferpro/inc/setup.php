<?php
add_action('after_setup_theme', function(){
  add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('html5',['search-form','gallery','caption','style','script']);
  add_theme_support('custom-logo');
  register_nav_menus(['primary_tr'=>'Primary Menu · TR','primary_en'=>'Primary Menu · EN','primary_de'=>'Primary Menu · DE','primary_ru'=>'Primary Menu · RU','footer'=>'Footer Menu']);
});
add_action('wp_enqueue_scripts', function(){
  $ver=wp_get_theme()->get('Version');
  wp_enqueue_style('deniz-style', get_stylesheet_uri(), [], $ver);
  wp_enqueue_style('twt-home',get_template_directory_uri().'/assets/css/homepage.css',['deniz-style'],$ver);
  wp_enqueue_style('twt-pages',get_template_directory_uri().'/assets/css/pages.css',['twt-home'],$ver);
  if(is_page_template(['template-transfer-search.php','template-passenger-details.php'])){wp_enqueue_style('twt-mobile-checkout',get_template_directory_uri().'/assets/css/mobile-checkout.css',['twt-pages'],$ver);wp_enqueue_script('twt-mobile-checkout',get_template_directory_uri().'/assets/js/mobile-checkout.js',[],$ver,true);}
  wp_enqueue_style('twt-location-menu',get_template_directory_uri().'/assets/css/location-menu.css',['twt-pages'],$ver);
  wp_enqueue_script('twt-header-menus',get_template_directory_uri().'/assets/js/header-menus.js',[],$ver,true);
  wp_enqueue_script('deniz-main', get_template_directory_uri().'/assets/js/main.js', [], $ver, true);
});
add_filter('document_title_separator', fn()=> '•');

add_action('wp_enqueue_scripts',function(){
 wp_enqueue_script('deniz-transfer-search',get_template_directory_uri().'/assets/js/transfer-search.js',[],wp_get_theme()->get('Version'),true);
 if(is_front_page()) wp_enqueue_script('deniz-hero-route-ticker',get_template_directory_uri().'/assets/js/hero-route-ticker.js',[],wp_get_theme()->get('Version'),true);
 wp_localize_script('deniz-transfer-search','DenizTransfer',['photon'=>deniz_setting('photon_url','https://photon.komoot.io/api/'),'nominatim'=>deniz_setting('nominatim_url','https://nominatim.openstreetmap.org/search'),'ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('deniz_transfer'),'lang'=>deniz_current_lang(),'currency'=>deniz_current_currency(),'strings'=>twt_ui_payload()]);
 if(is_page_template('template-transfer-search.php')){ wp_enqueue_script('deniz-vehicle-results',get_template_directory_uri().'/assets/js/vehicle-results.js',[],wp_get_theme()->get('Version'),true); wp_localize_script('deniz-vehicle-results','DenizBooking',['passengerUrl'=>deniz_booking_page_url('template-passenger-details.php')]); }
 if(is_page_template('template-passenger-details.php')) wp_enqueue_script('deniz-booking',get_template_directory_uri().'/assets/js/booking.js',[],wp_get_theme()->get('Version'),true);
},20);

add_action('wp_enqueue_scripts',function(){if(is_page_template('template-passenger-details.php'))wp_enqueue_script('twt-address-verify',get_template_directory_uri().'/assets/js/address-verify.js',[],wp_get_theme()->get('Version'),true);});

add_filter('body_class',function($classes){if(is_page_template(['template-transfer-search.php','template-passenger-details.php']))$classes[]='twt-booking-app';return $classes;});

/**
 * dbDelta() needs one column per line and "PRIMARY KEY  (col)". The original single-line
 * CREATE TABLE statements made WordPress re-run failing ALTER queries on every request.
 */
function atp_dbdelta($sql){
 require_once ABSPATH.'wp-admin/includes/upgrade.php';
 $out=[];
 foreach((array)$sql as $q){
  if(preg_match('/^\s*CREATE TABLE\s+(\S+)\s*\((.*)\)\s*([^()]*)$/is',$q,$m)){
   $parts=[];$depth=0;$buf='';$quote=false;
   foreach(str_split($m[2]) as $ch){
    if($ch==="'")$quote=!$quote;
    if(!$quote){ if($ch==='(')$depth++; elseif($ch===')')$depth--; elseif($ch===','&&$depth===0){$parts[]=trim($buf);$buf='';continue;} }
    $buf.=$ch;
   }
   if(trim($buf)!=='')$parts[]=trim($buf);
   foreach($parts as $i=>$p){
    $p=preg_replace('/^PRIMARY KEY\s*\(/i','PRIMARY KEY  (',$p);
    $p=preg_replace('/^(UNIQUE KEY|UNIQUE INDEX|KEY|INDEX)\s+([`\w]+)\s*\(/i','$1 $2 (',$p);
    $parts[$i]=$p;
   }
   $q="CREATE TABLE {$m[1]} (\n".implode(",\n",$parts)."\n) ".trim($m[3]);
  }
  $out=array_merge($out,dbDelta($q));
 }
 return $out;
}

/* Brand layer loads after every other theme stylesheet. */
add_action('wp_enqueue_scripts',function(){ wp_enqueue_style('atp-brand',get_template_directory_uri().'/assets/css/brand.css',[],wp_get_theme()->get('Version')); },99);
