<?php
if (!defined('ABSPATH')) exit;
function deniz_register_cpt($type,$single,$plural,$icon,$slug=null){
 register_post_type($type,[
  'labels'=>['name'=>$plural,'singular_name'=>$single,'add_new_item'=>'Yeni '.$single,'edit_item'=>$single.' Düzenle'],
  'public'=>true,'has_archive'=>true,'rewrite'=>['slug'=>$slug?:$type],'menu_icon'=>$icon,'show_in_rest'=>true,
  // Legacy SEO/public content types stay available on the front-end, but all management
  // is handled from Deniz Transfer OS. Do not expose separate WordPress sidebar menus.
  'show_in_menu'=>false,
  'supports'=>['title','editor','excerpt','thumbnail','custom-fields','revisions']
 ]);
}
add_action('init',function(){
 deniz_register_cpt('destination','Destinasyon','Destinasyonlar','dashicons-location-alt','destinations');
 deniz_register_cpt('location','Lokasyon','Lokasyonlar','dashicons-admin-site-alt3','locations');
 deniz_register_cpt('transfer-route','Transfer Rotası','Transfer Rotaları','dashicons-randomize','transfers');
 deniz_register_cpt('vehicle','Araç Sınıfı','Araçlar','dashicons-car','vehicles');
 deniz_register_cpt('transfer-zone','Fiyat Bölgesi','Fiyat Bölgeleri','dashicons-location','transfer-zones');
 deniz_register_cpt('airport-guide','Havalimanı Rehberi','Havalimanı Rehberleri','dashicons-airplane','airports');
});

// Belt-and-suspenders: hide legacy CPT menus even if another component re-registers them.
function deniz_hide_legacy_cpt_menus(){
 $legacy=['destination','location','transfer-route','vehicle','transfer-zone','airport-guide'];
 foreach($legacy as $pt){ remove_menu_page('edit.php?post_type='.$pt); }
}
add_action('admin_menu','deniz_hide_legacy_cpt_menus',999);
