<?php
if(!defined('ABSPATH'))exit;
function twt_time_select($name,$required=false){
 echo '<span class="twt-time-parts" data-time-select><select data-time-hour aria-label="'.esc_attr(deniz_t('time_hour')).'"'.($required?' required':'').'><option value="">--</option>';
 for($h=0;$h<24;$h++){ $v=sprintf('%02d',$h);echo '<option value="'.$v.'">'.$v.'</option>'; }
 echo '</select><span aria-hidden="true">:</span><select data-time-minute aria-label="'.esc_attr(deniz_t('time_minute')).'"'.($required?' required':'').'><option value="">--</option>';
 for($m=0;$m<60;$m+=5){$v=sprintf('%02d',$m);echo '<option value="'.$v.'">'.$v.'</option>';}
 echo '</select><input type="hidden" name="'.esc_attr($name).'" value=""></span>';
}
add_action('wp_enqueue_scripts',function(){wp_enqueue_script('twt-time-select',get_template_directory_uri().'/assets/js/time-select.js',[],wp_get_theme()->get('Version'),true);wp_enqueue_style('twt-time-select',get_template_directory_uri().'/assets/css/time-select.css',['twt-home'],wp_get_theme()->get('Version'));},20);
