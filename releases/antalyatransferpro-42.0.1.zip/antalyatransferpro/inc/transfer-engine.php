<?php
if (!defined('ABSPATH')) exit;

function deniz_setting($key,$default=''){
 $opts=get_option('deniz_transfer_settings',[]);
 return isset($opts[$key]) && $opts[$key]!=='' ? $opts[$key] : $default;
}

function deniz_point_in_polygon($lat,$lng,$polygon){
 if(!is_array($polygon)||count($polygon)<3) return false;
 $inside=false; $j=count($polygon)-1;
 for($i=0,$n=count($polygon);$i<$n;$j=$i++){
  $yi=(float)$polygon[$i]['lat']; $xi=(float)$polygon[$i]['lng'];
  $yj=(float)$polygon[$j]['lat']; $xj=(float)$polygon[$j]['lng'];
  $intersect=(($yi>$lat)!==($yj>$lat)) && ($lng < ($xj-$xi)*($lat-$yi)/(($yj-$yi) ?: 1e-12)+$xi);
  if($intersect)$inside=!$inside;
 }
 return $inside;
}

function deniz_find_zone($lat,$lng){
 $zones=get_posts(['post_type'=>'transfer-zone','post_status'=>'publish','numberposts'=>-1,'orderby'=>'menu_order title','order'=>'ASC']);
 foreach($zones as $z){
  $poly=json_decode(get_post_meta($z->ID,'zone_polygon',true),true);
  if(deniz_point_in_polygon((float)$lat,(float)$lng,$poly)) return $z;
 }
 return null;
}

function deniz_vehicle_list(){
 return get_posts(['post_type'=>'vehicle','post_status'=>'publish','numberposts'=>-1,'orderby'=>'menu_order title','order'=>'ASC']);
}

function deniz_zone_price($zone_id,$vehicle_id,$direction='oneway'){
 $matrix=get_post_meta($zone_id,'zone_prices',true); if(!is_array($matrix))$matrix=[];
 $key=(string)$vehicle_id;
 if(isset($matrix[$key][$direction]) && $matrix[$key][$direction] !== '') return (float)$matrix[$key][$direction];
 return null;
}

add_action('wp_ajax_deniz_quote','deniz_ajax_quote');
add_action('wp_ajax_nopriv_deniz_quote','deniz_ajax_quote');
function deniz_ajax_quote(){
 check_ajax_referer('deniz_transfer','nonce'); global $wpdb; $t=deniz_tables();
 $from_lat=(float)($_POST['from_lat']??0); $from_lng=(float)($_POST['from_lng']??0);
 $to_lat=(float)($_POST['to_lat']??0); $to_lng=(float)($_POST['to_lng']??0);
 $direction=sanitize_key($_POST['direction']??'oneway');
 $request_pax=max(1,absint($_POST['passengers']??1)); $request_bags=max(0,absint($_POST['bags']??0)); $request_date=sanitize_text_field($_POST['date']??''); $request_time=sanitize_text_field($_POST['time']??'');
 if(!deniz_pickup_is_valid($request_date,$request_time)) wp_send_json_error(['message'=>sprintf(deniz_t('notice_hours'),deniz_min_notice_hours())]);
 $airport_id=absint($_POST['airport_id']??0); $region_id=absint($_POST['region_id']??0);
 $mode=sanitize_key($_POST['service_mode']??'airport');
 if(!in_array($mode,['airport','hotel','return'],true)||!in_array($direction,['oneway','return'],true))wp_send_json_error(['message'=>deniz_t('route_validation_error')]);
 if($direction==='return'&&deniz_pickup_timestamp(sanitize_text_field($_POST['return_date']??''),sanitize_text_field($_POST['return_time']??''))<=deniz_pickup_timestamp($request_date,$request_time))wp_send_json_error(['message'=>deniz_t('return_after_outbound')]);
 $alat=$mode==='hotel'?$to_lat:$from_lat;$alng=$mode==='hotel'?$to_lng:$from_lng;
 $rlat=$mode==='hotel'?$from_lat:$to_lat;$rlng=$mode==='hotel'?$from_lng:$to_lng;
 $airport=$airport_id?$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d AND active=1",$airport_id)):deniz_db_airport_near($alat,$alng,10);
 if(!$airport)wp_send_json_error(['message'=>deniz_t('airport_unmatched')]);
 $hotel_id=absint($_POST['hotel_id']??0);
 if($hotel_id){$hotel=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE id=%d AND active=1",$hotel_id));if(!$hotel||($region_id&&(int)$hotel->region_id!==$region_id))wp_send_json_error(['message'=>deniz_t('route_validation_error')]);$region_id=(int)$hotel->region_id;}
 // Resolve only the hotel/destination endpoint, never the airport endpoint.
 $region=$region_id?$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d AND active=1",$region_id)):deniz_db_region_for_point($rlat,$rlng);
 if(!$region)wp_send_json_error(['message'=>deniz_t('zone_missing')]);
 if(!twt_validate_route($airport->id,$region->id,$hotel_id,$mode,$from_lat,$from_lng,$to_lat,$to_lng))wp_send_json_error(['message'=>deniz_t('route_validation_error')]);
 $vehicles=[]; deniz_cleanup_legacy_demo_vehicles(); $dbv=deniz_active_fleet_rows();
 foreach($dbv as $v){
   if((int)$v->pax < $request_pax) continue;
   if($request_bags>0 && (int)$v->bags < $request_bags) continue;
   if($request_date&&$request_time&&!twt_vehicle_available($v,$request_date,$request_time))continue;
   if($direction==='return'&&!twt_vehicle_available($v,sanitize_text_field($_POST['return_date']??''),sanitize_text_field($_POST['return_time']??'')))continue;
   $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['prices']} WHERE airport_id=%d AND region_id=%d AND vehicle_id=%d AND active=1",$airport->id,$region->id,$v->id));
   if(!$p) continue;
   $unit_base=$direction==='return'?(float)$p->return_price:(float)$p->one_way;
   if($unit_base<=0) continue;
   // Per-person services are displayed at the matrix unit fare (e.g. €30/person),
   // while the server-calculated booking total still uses passenger count.
   $base=$v->pricing_type==='per_person'?$unit_base*$request_pax:$unit_base;
   $vehicles[]=['id'=>$v->id,'name'=>twt_entity_name($v,'vehicle'),'service_type'=>$v->service_type,'pricing_type'=>$v->pricing_type,'price'=>deniz_convert_price($base),'display_price'=>deniz_convert_price($unit_base),'base_price'=>$base,'unit_base_price'=>$unit_base,'currency'=>deniz_current_currency(),'symbol'=>deniz_currencies()[deniz_current_currency()]['symbol'],'pax'=>(int)$v->pax,'bags'=>(int)$v->bags,'image'=>$v->image_id?wp_get_attachment_image_url($v->image_id,'large'):'','features'=>twt_entity_features($v)];
 }
 $extras=$wpdb->get_results("SELECT id,name,pricing_type,price,max_qty FROM {$t['extras']} WHERE active=1 ORDER BY name");
 foreach($extras as $e){$e->converted_price=deniz_convert_price((float)$e->price);$e->symbol=deniz_currencies()[deniz_current_currency()]['symbol'];}
 wp_send_json_success(['airport'=>['id'=>$airport->id,'name'=>twt_entity_name($airport,'airport'),'iata'=>$airport->iata],'zone'=>['id'=>$region->id,'name'=>twt_entity_name($region,'region')],'vehicles'=>$vehicles,'fleet_count'=>count($dbv),'extras'=>$extras]);
}

add_action('wp_ajax_deniz_location_search','deniz_ajax_location_search');
add_action('wp_ajax_nopriv_deniz_location_search','deniz_ajax_location_search');
function deniz_ajax_location_search(){
 // Read-only public location catalogue; cached pages must not fail on an expired nonce.
 global $wpdb; $t=deniz_tables();
 $q=mb_substr(trim(sanitize_text_field(wp_unslash($_GET['q']??''))),0,80); if(mb_strlen($q)<2) wp_send_json_success([]);
 $like='%'.$wpdb->esc_like($q).'%'; $items=[];
 // 1) Local airports.
 foreach($wpdb->get_results($wpdb->prepare("SELECT a.id,a.name,a.iata,a.lat,a.lng,c.name city,co.name country FROM {$t['airports']} a LEFT JOIN {$t['cities']} c ON c.id=a.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE a.active=1 AND (a.name LIKE %s OR a.iata LIKE %s OR c.name LIKE %s) ORDER BY a.name LIMIT 6",$like,$like,$like)) as $a){
   $items[]=['source'=>'local','type'=>'airport','group'=>deniz_t('airports'),'id'=>(int)$a->id,'label'=>twt_entity_name($a,'airport').($a->iata?' ('.$a->iata.')':'').' · '.trim($a->city.', '.twt_place_label($a->country),', '),'lat'=>(float)$a->lat,'lng'=>(float)$a->lng,'airport_id'=>(int)$a->id];
 }
 // 2) Approved/imported local hotels are always first.
 foreach($wpdb->get_results($wpdb->prepare("SELECT h.id,h.name,h.lat,h.lng,h.region_id,r.name region,c.name city,co.name country FROM {$t['hotels']} h LEFT JOIN {$t['regions']} r ON r.id=h.region_id LEFT JOIN {$t['cities']} c ON c.id=h.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE h.active=1 AND (h.name LIKE %s OR r.name LIKE %s OR c.name LIKE %s) ORDER BY h.name LIMIT 16",$like,$like,$like)) as $h){
   $items[]=['source'=>'local','type'=>'hotel','group'=>deniz_t('saved_hotels'),'id'=>(int)$h->id,'label'=>$h->name.' · '.implode(', ',array_filter([$h->region,$h->city,twt_place_label($h->country)])),'lat'=>(float)$h->lat,'lng'=>(float)$h->lng,'region_id'=>(int)$h->region_id,'hotel_id'=>(int)$h->id];
 }
 // 4) Local transfer regions are useful but should not crowd hotel results.
 foreach($wpdb->get_results($wpdb->prepare("SELECT r.id,r.name,r.center_lat lat,r.center_lng lng,c.name city,co.name country FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE r.active=1 AND (r.name LIKE %s OR c.name LIKE %s) ORDER BY r.name LIMIT 6",$like,$like)) as $r){
   $items[]=['source'=>'local','type'=>'region','group'=>deniz_t('transfer_areas'),'id'=>(int)$r->id,'label'=>twt_entity_name($r,'region').' · '.implode(', ',array_filter([$r->city,twt_place_label($r->country)])),'lat'=>(float)$r->lat,'lng'=>(float)$r->lng,'region_id'=>(int)$r->id];
 }
 // Local results return immediately; remote providers are fallback only.
 if($items)wp_send_json_success(array_slice($items,0,26));
 if(mb_strlen($q)<3)wp_send_json_success([]);
 // 3) Turkey-wide hotel/resort search from OSM services. Cached to protect public endpoints.
 $cache_key='twt_hotels_v23_'.deniz_current_lang().'_'.md5(mb_strtolower($q)); $remote=get_transient($cache_key);
 if($remote===false){
   $remote=[]; $ua='AntalyaTransferPro/12.0 (+'.home_url('/').')';
   $hotel_types=['hotel','resort','guest_house','hostel','motel','apartment','chalet'];
   $nom=deniz_setting('nominatim_url','https://nominatim.openstreetmap.org/search');
   $nurl=add_query_arg(['format'=>'jsonv2','addressdetails'=>1,'namedetails'=>1,'extratags'=>1,'countrycodes'=>'tr','limit'=>14,'q'=>$q],$nom);
   $nr=wp_remote_get($nurl,['headers'=>['User-Agent'=>$ua,'Accept-Language'=>deniz_current_lang().',en;q=0.8'],'timeout'=>3,'limit_response_size'=>131072]);
   if(!is_wp_error($nr) && wp_remote_retrieve_response_code($nr)===200){
     $data=json_decode(wp_remote_retrieve_body($nr),true);
     if(is_array($data)) foreach($data as $x){
       $type=strtolower((string)($x['type']??'')); $class=strtolower((string)($x['class']??''));
       if($class!=='tourism' && !in_array($type,$hotel_types,true)) continue;
       $name=$x['namedetails']['name:'.deniz_current_lang()]??$x['namedetails']['name']??$x['name']??explode(',',(string)($x['display_name']??''))[0];
       if(!$name) continue; $addr=$x['address']??[];
       $city=$addr['city']??$addr['town']??$addr['municipality']??$addr['county']??''; $district=$addr['suburb']??$addr['district']??'';
       $remote[]=['source'=>'nominatim','type'=>'hotel','group'=>deniz_t('hotels_turkey'),'label'=>implode(' · ',array_filter([$name,implode(', ',array_filter([$district,$city,deniz_t('turkey')]))])),'lat'=>(float)$x['lat'],'lng'=>(float)$x['lon']];
     }
   }
   $ph=deniz_setting('photon_url','https://photon.komoot.io/api/');
   $purl=add_query_arg(['limit'=>16,'lang'=>in_array(deniz_current_lang(),['en','de'],true)?deniz_current_lang():'en','bbox'=>'25.5,35.5,45.0,42.5','q'=>$q],$ph);
   $pr=wp_remote_get($purl,['headers'=>['User-Agent'=>$ua],'timeout'=>3,'limit_response_size'=>131072]);
   if(!is_wp_error($pr) && wp_remote_retrieve_response_code($pr)===200){
     $data=json_decode(wp_remote_retrieve_body($pr),true);
     foreach(($data['features']??[]) as $f){ $pp=$f['properties']??[]; $cc=strtoupper((string)($pp['countrycode']??$pp['country_code']??'')); if($cc && $cc!=='TR') continue;
       $val=strtolower((string)($pp['osm_value']??$pp['type']??'')); $key=strtolower((string)($pp['osm_key']??''));
       if($key==='tourism' && $val && !in_array($val,$hotel_types,true)) continue;
       if($key && $key!=='tourism' && !in_array($val,$hotel_types,true)) continue;
       $name=$pp['name']??''; if(!$name) continue; $coords=$f['geometry']['coordinates']??[]; if(count($coords)<2) continue;
       $city=$pp['city']??$pp['district']??$pp['county']??'';
       $remote[]=['source'=>'photon','type'=>'hotel','group'=>deniz_t('hotels_turkey'),'label'=>$name.' · '.implode(', ',array_filter([$city,deniz_t('turkey')])),'lat'=>(float)$coords[1],'lng'=>(float)$coords[0]];
     }
   }
   // de-duplicate remote by rounded coordinates + normalized name.
   $ded=[];$clean=[]; foreach($remote as $x){$k=md5(remove_accents(mb_strtolower($x['label'])).'|'.round($x['lat'],4).'|'.round($x['lng'],4));if(isset($ded[$k]))continue;$ded[$k]=1;$clean[]=$x;} $remote=array_slice($clean,0,18);
   set_transient($cache_key,$remote,12*HOUR_IN_SECONDS);
 }
 foreach($remote as $x)$items[]=$x;
 // Unique and cap, preserving local hotel / airport priority then Turkey hotels.
 $seen=[];$out=[];foreach($items as $x){$k=mb_strtolower(trim($x['label']));if(!$k||isset($seen[$k]))continue;$seen[$k]=1;$out[]=$x;if(count($out)>=26)break;}
 wp_send_json_success($out);
}

add_action('admin_menu',function(){
 add_theme_page('Transfer Ayarları','Transfer Ayarları','manage_options','deniz-transfer-settings','deniz_transfer_settings_page');
});
add_action('admin_init',function(){ register_setting('deniz_transfer_settings_group','deniz_transfer_settings',['sanitize_callback'=>'deniz_sanitize_settings']); });
function deniz_sanitize_settings($in){
 $out=get_option('deniz_transfer_settings',[]); foreach(['photon_url','nominatim_url','osrm_url','overpass_url','airport_name','airport_lat','airport_lng','airport_radius','currency','rate_try','rate_usd','rate_gbp','company_name','support_email','support_phone','whatsapp_number','min_notice_hours','free_cancel_hours','intl_wait_start','domestic_wait_start','total_wait_minutes','cash_payment_text','company_address'] as $k) if(array_key_exists($k,(array)$in)) $out[$k]=$k==='support_email'?sanitize_email($in[$k]):sanitize_text_field($in[$k]); return $out;
}
function deniz_transfer_settings_page(){ $o=get_option('deniz_transfer_settings',[]); ?>
<div class="wrap"><h1>Antalya Transfer Pro Transfer Motoru</h1><p>Harita, geocoding ve ana havalimanı ayarları. Kamu servislerini yoğun trafikte kendi sunucunuzla değiştirmeniz önerilir.</p><form method="post" action="options.php"><?php settings_fields('deniz_transfer_settings_group'); ?>
<table class="form-table"><tbody>
<?php $f=['airport_name'=>['Ana Havalimanı','Antalya Airport (AYT)'],'airport_lat'=>['Havalimanı Latitude','36.8987'],'airport_lng'=>['Havalimanı Longitude','30.8005'],'airport_radius'=>['Havalimanı Eşleşme Yarıçapı (km)','8'],'currency'=>['Baz Para Birimi','EUR'],'rate_try'=>['1 EUR = TRY','52'],'rate_usd'=>['1 EUR = USD','1.17'],'rate_gbp'=>['1 EUR = GBP','0.87'],'photon_url'=>['Photon Endpoint','https://photon.komoot.io/api/'],'nominatim_url'=>['Nominatim Endpoint','https://nominatim.openstreetmap.org/search'],'osrm_url'=>['OSRM Endpoint','https://router.project-osrm.org/route/v1/driving/'],'overpass_url'=>['Overpass Endpoint','https://overpass-api.de/api/interpreter']]; foreach($f as $k=>$v): ?>
<tr><th><?php echo esc_html($v[0]); ?></th><td><input class="regular-text" name="deniz_transfer_settings[<?php echo esc_attr($k); ?>]" value="<?php echo esc_attr($o[$k]??$v[1]); ?>"></td></tr>
<?php endforeach; ?></tbody></table><?php submit_button(); ?></form></div><?php }
