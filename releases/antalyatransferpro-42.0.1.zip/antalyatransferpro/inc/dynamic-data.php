<?php
if (!defined('ABSPATH')) exit;

function deniz_tables(){ global $wpdb; return [
 'countries'=>$wpdb->prefix.'deniz_countries','cities'=>$wpdb->prefix.'deniz_cities','regions'=>$wpdb->prefix.'deniz_regions',
 'airports'=>$wpdb->prefix.'deniz_airports','hotels'=>$wpdb->prefix.'deniz_hotels','vehicles'=>$wpdb->prefix.'deniz_vehicles',
 'extras'=>$wpdb->prefix.'deniz_extras','prices'=>$wpdb->prefix.'deniz_prices',
 'bookings'=>$wpdb->prefix.'deniz_bookings','booking_extras'=>$wpdb->prefix.'deniz_booking_extras','region_content'=>$wpdb->prefix.'deniz_region_content'
]; }

/** Hard migration for legacy wp_deniz_vehicles schemas. */
function deniz_force_vehicle_schema(){
 if(get_option('deniz_vehicle_schema_version')==='19.1')return true;
 global $wpdb; $t=deniz_tables(); $table=$t['vehicles'];
 $exists=$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$table));
 if($exists!==$table){ return new WP_Error('vehicle_table_missing','Vehicle table does not exist yet.'); }
 $required=[
  'image_id'=>"bigint unsigned NULL AFTER slug",
  'service_type'=>"varchar(20) NOT NULL DEFAULT 'private' AFTER image_id",
  'pricing_type'=>"varchar(20) NOT NULL DEFAULT 'per_vehicle' AFTER service_type",
  'vehicle_type'=>"varchar(30) NOT NULL DEFAULT 'standard' AFTER pricing_type",
  'pax'=>"int NOT NULL DEFAULT 4 AFTER vehicle_type",
  'adults'=>"int NOT NULL DEFAULT 4 AFTER pax",
  'children'=>"int NOT NULL DEFAULT 4 AFTER adults",
  'bags'=>"int NOT NULL DEFAULT 3 AFTER children",
  'features'=>"text NULL AFTER bags",
  'opening_price'=>"decimal(12,2) NOT NULL DEFAULT 0 AFTER features",
  'price_per_km'=>"decimal(12,2) NOT NULL DEFAULT 0 AFTER opening_price",
  'display_priority'=>"int NOT NULL DEFAULT 10 AFTER price_per_km",
  'shuttle_wait_minutes'=>"int NOT NULL DEFAULT 0 AFTER display_priority",
  'shuttle_max_stops'=>"int NOT NULL DEFAULT 0 AFTER shuttle_wait_minutes",
  'shuttle_luggage_per_person'=>"int NOT NULL DEFAULT 1 AFTER shuttle_max_stops",
  'shuttle_meeting_point'=>"text NULL AFTER shuttle_luggage_per_person",
  'shuttle_pickup_note'=>"text NULL AFTER shuttle_meeting_point",
  'shuttle_notice'=>"text NULL AFTER shuttle_pickup_note",
  'unavailable_dates'=>"longtext NULL AFTER shuttle_notice",
  'unavailable_slots'=>"longtext NULL AFTER unavailable_dates",
  'active'=>"tinyint(1) NOT NULL DEFAULT 1 AFTER unavailable_slots",
  'sort_order'=>"int NOT NULL DEFAULT 0 AFTER active"
 ];
 $cols=array_flip((array)$wpdb->get_col("SHOW COLUMNS FROM `$table`",0));
 foreach($required as $name=>$definition){
  if(isset($cols[$name])) continue;
  $res=$wpdb->query("ALTER TABLE `$table` ADD COLUMN `$name` $definition");
  if($res===false) return new WP_Error('vehicle_schema_alter_failed',$wpdb->last_error ?: ('Could not add '.$name));
  $cols[$name]=true;
 }
 update_option('deniz_vehicle_schema_version','19.1',false);
 return true;
}

function deniz_install_tables(){
 global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=deniz_tables(); $cc=$wpdb->get_charset_collate();
 $sql=[];
 $sql[]="CREATE TABLE {$t['countries']} (id bigint unsigned NOT NULL AUTO_INCREMENT,name varchar(120) NOT NULL,code varchar(8) NOT NULL,active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),UNIQUE KEY code(code)) $cc;";
 $sql[]="CREATE TABLE {$t['cities']} (id bigint unsigned NOT NULL AUTO_INCREMENT,country_id bigint unsigned NOT NULL,name varchar(120) NOT NULL,slug varchar(140) NOT NULL,lat decimal(10,7) NULL,lng decimal(10,7) NULL,active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),KEY country_id(country_id),UNIQUE KEY slug(slug)) $cc;";
 $sql[]="CREATE TABLE {$t['regions']} (id bigint unsigned NOT NULL AUTO_INCREMENT,city_id bigint unsigned NOT NULL,name varchar(160) NOT NULL,slug varchar(180) NOT NULL,polygon longtext NULL,center_lat decimal(10,7) NULL,center_lng decimal(10,7) NULL,osm_type varchar(20) NULL,osm_id bigint NULL,seo_title varchar(190) NULL,seo_description text NULL,active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),KEY city_id(city_id),UNIQUE KEY slug(slug)) $cc;";
 $sql[]="CREATE TABLE {$t['airports']} (id bigint unsigned NOT NULL AUTO_INCREMENT,city_id bigint unsigned NOT NULL,name varchar(180) NOT NULL,iata varchar(8) NULL,lat decimal(10,7) NOT NULL,lng decimal(10,7) NOT NULL,polygon longtext NULL,osm_type varchar(20) NULL,osm_id bigint NULL,active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),KEY city_id(city_id),KEY iata(iata)) $cc;";
 $sql[]="CREATE TABLE {$t['hotels']} (id bigint unsigned NOT NULL AUTO_INCREMENT,city_id bigint unsigned NOT NULL,region_id bigint unsigned NOT NULL,name varchar(220) NOT NULL,slug varchar(240) NOT NULL,lat decimal(10,7) NOT NULL,lng decimal(10,7) NOT NULL,address text NULL,phone varchar(80) NULL,website varchar(255) NULL,osm_type varchar(20) NULL,osm_id bigint NULL,stars decimal(2,1) NULL,seo_title varchar(190) NULL,seo_description text NULL,source varchar(30) NOT NULL DEFAULT 'manual',active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),KEY region_id(region_id),KEY city_id(city_id),KEY slug(slug),UNIQUE KEY osm_unique(osm_type,osm_id)) $cc;";
 $sql[]="CREATE TABLE {$t['vehicles']} (id bigint unsigned NOT NULL AUTO_INCREMENT,name varchar(160) NOT NULL,slug varchar(180) NOT NULL,image_id bigint unsigned NULL,service_type varchar(20) NOT NULL DEFAULT 'private',pricing_type varchar(20) NOT NULL DEFAULT 'per_vehicle',vehicle_type varchar(30) NOT NULL DEFAULT 'standard',pax int NOT NULL DEFAULT 4,adults int NOT NULL DEFAULT 4,children int NOT NULL DEFAULT 4,bags int NOT NULL DEFAULT 3,features text NULL,opening_price decimal(12,2) NOT NULL DEFAULT 0,price_per_km decimal(12,2) NOT NULL DEFAULT 0,display_priority int NOT NULL DEFAULT 10,shuttle_wait_minutes int NOT NULL DEFAULT 0,shuttle_max_stops int NOT NULL DEFAULT 0,shuttle_luggage_per_person int NOT NULL DEFAULT 1,shuttle_meeting_point text NULL,shuttle_pickup_note text NULL,shuttle_notice text NULL,unavailable_dates longtext NULL,unavailable_slots longtext NULL,active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,PRIMARY KEY(id),UNIQUE KEY slug(slug),KEY service_type(service_type),KEY display_priority(display_priority)) $cc;";
 $sql[]="CREATE TABLE {$t['extras']} (id bigint unsigned NOT NULL AUTO_INCREMENT,name varchar(160) NOT NULL,slug varchar(180) NOT NULL,pricing_type varchar(20) NOT NULL DEFAULT 'per_booking',price decimal(12,2) NOT NULL DEFAULT 0,max_qty int NOT NULL DEFAULT 1,active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),UNIQUE KEY slug(slug)) $cc;";
 $sql[]="CREATE TABLE {$t['prices']} (id bigint unsigned NOT NULL AUTO_INCREMENT,airport_id bigint unsigned NOT NULL,region_id bigint unsigned NOT NULL,vehicle_id bigint unsigned NOT NULL,one_way decimal(12,2) NULL,return_price decimal(12,2) NULL,currency varchar(6) NOT NULL DEFAULT 'EUR',active tinyint(1) NOT NULL DEFAULT 1,PRIMARY KEY(id),UNIQUE KEY route_vehicle(airport_id,region_id,vehicle_id),KEY region_id(region_id),KEY airport_id(airport_id)) $cc;";
 $sql[]="CREATE TABLE {$t['bookings']} (id bigint unsigned NOT NULL AUTO_INCREMENT,booking_ref varchar(32) NOT NULL,status varchar(30) NOT NULL DEFAULT 'new',created_at datetime NOT NULL,airport_id bigint unsigned NOT NULL,region_id bigint unsigned NOT NULL,hotel_id bigint unsigned NULL,vehicle_id bigint unsigned NOT NULL,direction varchar(20) NOT NULL DEFAULT 'oneway',pickup_label text NOT NULL,dropoff_label text NOT NULL,pickup_lat decimal(10,7) NULL,pickup_lng decimal(10,7) NULL,dropoff_lat decimal(10,7) NULL,dropoff_lng decimal(10,7) NULL,pickup_date date NOT NULL,pickup_time varchar(12) NOT NULL,return_date date NULL,return_time varchar(12) NULL,passengers int NOT NULL DEFAULT 1,bags int NOT NULL DEFAULT 0,first_name varchar(100) NOT NULL,last_name varchar(100) NOT NULL,email varchar(190) NOT NULL,phone varchar(80) NOT NULL,flight_number varchar(60) NULL,notes text NULL,payment_method varchar(30) NOT NULL DEFAULT 'cash_to_driver',payment_status varchar(30) NOT NULL DEFAULT 'pending',currency varchar(6) NOT NULL DEFAULT 'EUR',base_amount decimal(12,2) NOT NULL DEFAULT 0,extras_amount decimal(12,2) NOT NULL DEFAULT 0,total_amount decimal(12,2) NOT NULL DEFAULT 0,PRIMARY KEY(id),UNIQUE KEY booking_ref(booking_ref),KEY created_at(created_at),KEY status(status),KEY airport_id(airport_id),KEY region_id(region_id)) $cc;";
 $sql[]="CREATE TABLE {$t['booking_extras']} (id bigint unsigned NOT NULL AUTO_INCREMENT,booking_id bigint unsigned NOT NULL,extra_id bigint unsigned NOT NULL,qty int NOT NULL DEFAULT 1,unit_price decimal(12,2) NOT NULL DEFAULT 0,total_price decimal(12,2) NOT NULL DEFAULT 0,PRIMARY KEY(id),KEY booking_id(booking_id),KEY extra_id(extra_id)) $cc;";
 $sql[]="CREATE TABLE {$t['region_content']} (id bigint unsigned NOT NULL AUTO_INCREMENT,region_id bigint unsigned NOT NULL,lang varchar(6) NOT NULL DEFAULT 'tr',hero_title varchar(220) NULL,intro text NULL,about_title varchar(220) NULL,about_content longtext NULL,route_title varchar(220) NULL,route_content longtext NULL,seo_title varchar(190) NULL,seo_description text NULL,faq_json longtext NULL,updated_at datetime NULL,PRIMARY KEY(id),UNIQUE KEY region_lang(region_id,lang),KEY region_id(region_id)) $cc;";
 foreach($sql as $q) atp_dbdelta($q);
 deniz_seed_base_data();
 deniz_cleanup_legacy_demo_vehicles();
 update_option('deniz_db_version','20.0');
}
add_action('after_switch_theme','deniz_install_tables');
add_action('init',function(){ if(get_option('deniz_db_version')!=='20.0') deniz_install_tables(); if(function_exists('deniz_force_vehicle_schema')) deniz_force_vehicle_schema(); deniz_cleanup_legacy_demo_vehicles(); },5);

function deniz_seed_base_data(){ global $wpdb; $t=deniz_tables();
 $country=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['countries']} WHERE code=%s",'TR'));
 if(!$country){ $wpdb->insert($t['countries'],['name'=>'Turkey','code'=>'TR','active'=>1]); $country=$wpdb->insert_id; }
 $city=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['cities']} WHERE slug=%s",'antalya'));
 if(!$city){$wpdb->insert($t['cities'],['country_id'=>$country,'name'=>'Antalya','slug'=>'antalya','lat'=>36.8969,'lng'=>30.7133]);$city=$wpdb->insert_id;}
 $airport=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['airports']} WHERE iata=%s",'AYT'));
 if(!$airport){$wpdb->insert($t['airports'],['city_id'=>$city,'name'=>'Antalya Airport','iata'=>'AYT','lat'=>36.8987,'lng'=>30.8005]);}
 // Vehicles are never seeded. Fleet is created only from Deniz Transfer OS -> Vehicles.
 if(!(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['extras']}")){
  $wpdb->insert($t['extras'],['name'=>'Baby Seat','slug'=>'baby-seat','pricing_type'=>'per_item','price'=>5,'max_qty'=>3]);
  $wpdb->insert($t['extras'],['name'=>'Booster Seat','slug'=>'booster-seat','pricing_type'=>'per_item','price'=>4,'max_qty'=>3]);
 }
}

/**
 * One-time v14 cleanup for vehicle rows that older theme versions inserted as demo data.
 * If a legacy demo vehicle has bookings, keep the row for history but make it inactive.
 * Otherwise remove its route prices and the vehicle itself. User-created vehicles are untouched.
 */
function deniz_is_legacy_demo_vehicle($v){
 if(!$v) return false;
 $slug=(string)($v->slug??'');
 if(!in_array($slug,['economy-sedan','mercedes-vito','vip-vito','mercedes-sprinter'],true)) return false;
 $features=(string)($v->features??'');
 // v5-v8 demo rows stored literal "\\n" text instead of real line breaks.
 $features=str_replace(["\\r\\n","\\n","\\r","\r\n","\r"],"\n",$features);
 $features=trim($features);
 $legacy_features=($features==="Private vehicle\nMeet & greet\nFlight monitoring" || $features==='');
 $image_empty=empty($v->image_id);
 $price_empty=((float)($v->opening_price??0)===0.0 && (float)($v->price_per_km??0)===0.0);
 $seed_caps=[
  'economy-sedan'=>[4,3],
  'mercedes-vito'=>[7,7],
  'vip-vito'=>[6,6],
  'mercedes-sprinter'=>[13,12],
 ];
 $caps_ok=isset($seed_caps[$slug]) && (int)($v->pax??0)===$seed_caps[$slug][0] && (int)($v->bags??0)===$seed_caps[$slug][1];
 if(!($image_empty && $price_empty && $legacy_features && $caps_ok))return false;
 // A configured route fare identifies a real operational vehicle, even without a photo.
 if(!empty($v->id)){global $wpdb;$t=deniz_tables();if($wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['prices']} WHERE vehicle_id=%d AND active=1 AND one_way>0 LIMIT 1",(int)$v->id)))return false;}
 return true;
}
function deniz_cleanup_legacy_demo_vehicles($force=false){
 global $wpdb; $t=deniz_tables();
 if(!$force && get_option('deniz_v14_demo_vehicle_cleanup_done')) return;
 $legacy_slugs=['economy-sedan','mercedes-vito','vip-vito','mercedes-sprinter'];
 foreach($legacy_slugs as $slug){
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['vehicles']} WHERE slug=%s ORDER BY id ASC",$slug));
  if(!$rows) continue;
  foreach($rows as $v){
   if(!deniz_is_legacy_demo_vehicle($v)) continue;
   $booking_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE vehicle_id=%d",$v->id));
   if($booking_count>0){
    $wpdb->update($t['vehicles'],['active'=>0,'display_priority'=>9999],['id'=>$v->id]);
    $wpdb->update($t['prices'],['active'=>0],['vehicle_id'=>$v->id]);
   }else{
    $wpdb->delete($t['prices'],['vehicle_id'=>$v->id]);
    $wpdb->delete($t['vehicles'],['id'=>$v->id]);
   }
  }
 }
 $wpdb->query("DELETE p FROM {$t['prices']} p LEFT JOIN {$t['vehicles']} v ON v.id=p.vehicle_id WHERE v.id IS NULL");
 update_option('deniz_v14_demo_vehicle_cleanup_done',1,false);
 update_option('deniz_last_demo_vehicle_cleanup',current_time('mysql'),false);
}
function deniz_active_fleet_rows(){
 global $wpdb; $t=deniz_tables();
 $rows=$wpdb->get_results("SELECT * FROM {$t['vehicles']} WHERE active=1 ORDER BY display_priority,sort_order,name");
 return array_values(array_filter((array)$rows, function($v){ return !deniz_is_legacy_demo_vehicle($v); }));
}

function deniz_db_region_for_point($lat,$lng,$city_id=0){ global $wpdb; $t=deniz_tables();
 $where=$city_id?$wpdb->prepare('WHERE active=1 AND city_id=%d',$city_id):'WHERE active=1';
 $rows=$wpdb->get_results("SELECT * FROM {$t['regions']} $where ORDER BY id ASC");
 $match=null;foreach($rows as $r){$poly=json_decode($r->polygon,true);if(deniz_point_in_polygon((float)$lat,(float)$lng,$poly)){if($match)return null;$match=$r;}}return $match;
}
function deniz_db_airport_near($lat,$lng,$radius=7){ global $wpdb; $t=deniz_tables(); $rows=$wpdb->get_results("SELECT * FROM {$t['airports']} WHERE active=1");
 $best=null;$bestd=99999; foreach($rows as $a){$d=deniz_haversine($lat,$lng,$a->lat,$a->lng); if($d<$bestd && $d<=$radius){$best=$a;$bestd=$d;}} return $best;
}
function deniz_haversine($a,$b,$c,$d){$r=6371;$p=pi()/180;$x=sin(($c-$a)*$p/2)**2+cos($a*$p)*cos($c*$p)*sin(($d-$b)*$p/2)**2;return 2*$r*asin(min(1,sqrt($x)));}

function deniz_sync_route_post($airport_id,$region_id){global $wpdb;$t=deniz_tables();$a=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d AND active=1",$airport_id));$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d AND active=1",$region_id));if(!$a||!$r)return;$priced=$wpdb->get_var($wpdb->prepare("SELECT p.id FROM {$t['prices']} p JOIN {$t['vehicles']} v ON v.id=p.vehicle_id AND v.active=1 WHERE p.airport_id=%d AND p.region_id=%d AND p.active=1 AND p.one_way>0 LIMIT 1",$airport_id,$region_id));if(!$priced)return;
 $existing=get_posts(['post_type'=>'transfer-route','post_status'=>'any','posts_per_page'=>1,'meta_query'=>[['key'=>'dynamic_airport_id','value'=>$airport_id],['key'=>'dynamic_region_id','value'=>$region_id],['relation'=>'OR',['key'=>'dynamic_hotel_id','compare'=>'NOT EXISTS'],['key'=>'dynamic_hotel_id','value'=>0]]]]);$slug=sanitize_title(($a->iata?:$a->name).'-to-'.$r->name.'-transfer');$post=$existing[0]??get_page_by_path($slug,OBJECT,'transfer-route');$pid=$post?$post->ID:wp_insert_post(['post_type'=>'transfer-route','post_status'=>'publish','post_title'=>$a->name.' to '.$r->name.' Transfer','post_name'=>$slug]);
 if($pid&&!is_wp_error($pid)){update_post_meta($pid,'dynamic_airport_id',$airport_id);update_post_meta($pid,'dynamic_region_id',$region_id);update_post_meta($pid,'twt_auto_generated',1);foreach(['seo_title','seo_description','hero_subtitle'] as $key){$value=get_post_meta($pid,$key,true);if(strpos($value,'Private '.$a->name.' transfer to ')===0||strpos($value,'Book '.$a->name.' to '.$r->name.' transfer')===0)delete_post_meta($pid,$key);}if(function_exists('twt_route_metrics'))twt_route_metrics($a,$r);}
}

function deniz_dynamic_regions($city_slug='antalya'){ global $wpdb;$t=deniz_tables();return $wpdb->get_results($wpdb->prepare("SELECT r.* FROM {$t['regions']} r JOIN {$t['cities']} c ON c.id=r.city_id WHERE c.slug=%s AND r.active=1 ORDER BY r.name",$city_slug)); }
function deniz_dynamic_airport($iata='AYT'){ global $wpdb;$t=deniz_tables();return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE iata=%s AND active=1 LIMIT 1",$iata)); }
function deniz_region_from_price($region_id,$airport_id=0){ global $wpdb;$t=deniz_tables(); if(!$airport_id){$a=deniz_dynamic_airport('AYT');$airport_id=$a?$a->id:0;} if(!$airport_id)return null; return $wpdb->get_var($wpdb->prepare("SELECT MIN(p.one_way) FROM {$t['prices']} p JOIN {$t['vehicles']} v ON v.id=p.vehicle_id AND v.active=1 WHERE p.airport_id=%d AND p.region_id=%d AND p.active=1 AND p.one_way>0",$airport_id,$region_id)); }
function deniz_region_route_url($region,$airport=null){ global $wpdb;$t=deniz_tables(); if(!$airport && !empty($region->city_id))$airport=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE city_id=%d AND active=1 ORDER BY id LIMIT 1",(int)$region->city_id)); if(!$airport)$airport=deniz_dynamic_airport('AYT');if(!$airport)return get_post_type_archive_link('transfer-route');$slug=sanitize_title(($airport->iata?:$airport->name).'-to-'.$region->name.'-transfer');$p=get_page_by_path($slug,OBJECT,'transfer-route');return $p?get_permalink($p):get_post_type_archive_link('transfer-route');}
function deniz_dynamic_vehicles(){ return deniz_active_fleet_rows(); }


function deniz_normalize_hotel_name($name){
 $name=remove_accents(mb_strtolower((string)$name));
 $name=preg_replace('/\\b(hotel|resort|spa|antalya|turkey|türkiye)\\b/u',' ',$name);
 return trim(preg_replace('/[^a-z0-9]+/u',' ', $name));
}
function deniz_sync_hotel_route_post($airport_id,$hotel_id){
 global $wpdb;$t=deniz_tables();
 $a=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d",$airport_id));
 $h=$wpdb->get_row($wpdb->prepare("SELECT h.*,r.name region_name FROM {$t['hotels']} h LEFT JOIN {$t['regions']} r ON r.id=h.region_id WHERE h.id=%d",$hotel_id));
 if(!$a||!$h)return 0;
 $title=$a->name.' to '.$h->name.' Transfer';
 $slug=sanitize_title(($a->iata?:$a->name).'-to-'.$h->name.'-transfer');
 $exists=get_page_by_path($slug,OBJECT,'transfer-route');
 $desc='Book a private '.$a->name.' to '.$h->name.' transfer in '.($h->region_name?:'Antalya').'. Fixed prices, flight monitoring, meet & greet and direct hotel drop-off.';
 $pid=$exists?$exists->ID:wp_insert_post(['post_type'=>'transfer-route','post_status'=>'publish','post_title'=>$title,'post_name'=>$slug,'post_content'=>$desc]);
 if($pid&&!is_wp_error($pid)){
  update_post_meta($pid,'dynamic_airport_id',$airport_id); update_post_meta($pid,'dynamic_region_id',$h->region_id); update_post_meta($pid,'dynamic_hotel_id',$hotel_id);
  update_post_meta($pid,'seo_title',mb_substr($title.' | Antalya Transfer Pro',0,60)); update_post_meta($pid,'seo_description',mb_substr($desc,0,155));
  if(!$h->seo_title||!$h->seo_description)$wpdb->update($t['hotels'],['seo_title'=>mb_substr($title.' | Antalya Transfer Pro',0,60),'seo_description'=>mb_substr($desc,0,155)],['id'=>$hotel_id]);
  return (int)$pid;
 } return 0;
}
function deniz_sync_all_hotel_routes($hotel_id){
 global $wpdb;$t=deniz_tables(); $h=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE id=%d",$hotel_id)); if(!$h)return;
 foreach($wpdb->get_results($wpdb->prepare("SELECT DISTINCT p.airport_id FROM {$t['prices']} p WHERE p.region_id=%d AND p.active=1",$h->region_id)) as $a) deniz_sync_hotel_route_post($a->airport_id,$hotel_id);
}


function deniz_sync_city_destination($city_id){
 global $wpdb;$t=deniz_tables();
 $city=$wpdb->get_row($wpdb->prepare("SELECT c.*,co.name country FROM {$t['cities']} c LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE c.id=%d",$city_id));
 if(!$city)return 0;
 $slug=$city->slug?:sanitize_title($city->name);
 $existing=get_page_by_path($slug,OBJECT,'destination');
 $title=$city->name;
 $desc='Private airport transfers to '.$city->name.' hotels and resort areas. Search the exact destination, compare available vehicles and book with clear route pricing.';
 $pid=$existing?$existing->ID:wp_insert_post(['post_type'=>'destination','post_status'=>'publish','post_title'=>$title,'post_name'=>$slug,'post_excerpt'=>$desc,'post_content'=>'<p>'.$desc.'</p>']);
 if($pid&&!is_wp_error($pid)){
   update_post_meta($pid,'dynamic_city_id',(int)$city->id);
   update_post_meta($pid,'seo_title',mb_substr($city->name.' Airport Transfer | Antalya Transfer Pro',0,60));
   update_post_meta($pid,'seo_description',mb_substr('Book '.$city->name.' airport transfer to hotels and resort areas. Private vehicles, direct pickup, destination-based pricing and 24/7 booking support.',0,155));
   update_post_meta($pid,'hero_subtitle','Airport transfers to '.$city->name.' hotels, resorts and transfer regions.');
   return (int)$pid;
 }
 return 0;
}
add_action('init',function(){
 if(get_option('deniz_city_destination_sync_v9'))return;
 global $wpdb;$t=deniz_tables();
 foreach($wpdb->get_col("SELECT id FROM {$t['cities']} WHERE active=1") as $cid)deniz_sync_city_destination((int)$cid);
 update_option('deniz_city_destination_sync_v9',1,false);
},25);
