<?php
if (!defined('ABSPATH')) exit;
function deniz_booking_ref(){return 'DNZ-'.strtoupper(wp_generate_password(8,false,false));}
function deniz_booking_page_url($template){$pages=get_pages(['meta_key'=>'_wp_page_template','meta_value'=>$template,'number'=>1]);return $pages?deniz_url($pages[0]->post_name):deniz_url();}
function deniz_ensure_booking_pages(){foreach([['Transfer Search','template-transfer-search.php','transfer-search'],['Passenger Details','template-passenger-details.php','passenger-details'],['Booking Confirmation','template-booking-confirmation.php','booking-confirmation']] as $p){$exists=get_page_by_path($p[2]);if(!$exists){$id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$p[0],'post_name'=>$p[2]]);if($id)update_post_meta($id,'_wp_page_template',$p[1]);}}}
add_action('after_switch_theme','deniz_ensure_booking_pages');
add_action('init',function(){if(get_option('deniz_db_version')==='6.0'&&!get_page_by_path('passenger-details'))deniz_ensure_booking_pages();},20);
add_action('wp_ajax_deniz_create_booking','deniz_create_booking');add_action('wp_ajax_nopriv_deniz_create_booking','deniz_create_booking');
function deniz_create_booking(){
 check_ajax_referer('deniz_booking','nonce'); global $wpdb;$t=deniz_tables();foreach($_POST as $key=>$value)if($key!=='extras'&&!is_scalar($value))wp_send_json_error(['message'=>deniz_t('complete_required')]);if(isset($_POST['extras'])&&!is_array($_POST['extras']))wp_send_json_error(['message'=>deniz_t('complete_required')]);
 $request_key=is_scalar($_POST['request_key']??null)?sanitize_text_field($_POST['request_key']):'';
 if(!preg_match('/^[a-zA-Z0-9-]{24,80}$/',$request_key))wp_send_json_error(['message'=>deniz_t('refresh_booking')]);
 $ref='ATP-'.strtoupper(substr(hash_hmac('sha256',$request_key,wp_salt('nonce')),0,20));
 $existing=$wpdb->get_row($wpdb->prepare("SELECT id,booking_ref FROM {$t['bookings']} WHERE booking_ref=%s",$ref));if($existing)wp_send_json_success(['ref'=>$ref,'redirect'=>twt_voucher_url($existing)]);
 if(($_POST['journey_reviewed']??'')!=='1')wp_send_json_error(['message'=>atp_experience_text('review_error')]);
 $vehicle=absint($_POST['vehicle_id']??0);$airport=absint($_POST['airport_id']??0);$region=absint($_POST['region_id']??0);$direction=sanitize_key($_POST['direction']??'oneway');
 $pickup_date=sanitize_text_field($_POST['date']??'');$pickup_time=sanitize_text_field($_POST['time']??'');$passengers=max(1,absint($_POST['passengers']??1));$bags=max(0,absint($_POST['bags']??0));$currency=strtoupper(sanitize_text_field($_POST['currency']??'EUR'));if(!isset(deniz_currencies()[$currency]))$currency='EUR';
 if(function_exists('deniz_pickup_is_valid')&&!deniz_pickup_is_valid($pickup_date,$pickup_time)) wp_send_json_error(['message'=>sprintf(deniz_t('notice_hours'),deniz_min_notice_hours())]);
 $v=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['vehicles']} WHERE id=%d AND active=1",$vehicle));
 if(!$v||function_exists('deniz_is_legacy_demo_vehicle')&&deniz_is_legacy_demo_vehicle($v)) wp_send_json_error(['message'=>deniz_t('vehicle_unavailable')]);
 if((int)$v->pax<$passengers) wp_send_json_error(['message'=>deniz_t('capacity_passengers')]);
 if($bags>0&&(int)$v->bags<$bags) wp_send_json_error(['message'=>deniz_t('capacity_bags')]);
 if(!twt_vehicle_available($v,$pickup_date,$pickup_time)) wp_send_json_error(['message'=>deniz_t('vehicle_date_unavailable')]);
 $price=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['prices']} WHERE airport_id=%d AND region_id=%d AND vehicle_id=%d AND active=1",$airport,$region,$vehicle));
 if(!$price)wp_send_json_error(['message'=>deniz_t('route_price_missing')]);
 $base=$direction==='return'?(float)$price->return_price:(float)$price->one_way;if($v->pricing_type==='per_person')$base*=$passengers;if($base<=0)wp_send_json_error(['message'=>deniz_t('journey_fare_missing')]);
 if($direction==='return'){
  $rd=sanitize_text_field($_POST['return_date']??'');$rt=sanitize_text_field($_POST['return_time']??'');
  if(!$rd||!$rt)wp_send_json_error(['message'=>deniz_t('enter_return')]);
  if(!twt_vehicle_available($v,$rd,$rt))wp_send_json_error(['message'=>deniz_t('vehicle_date_unavailable')]);
  if(deniz_pickup_timestamp($rd,$rt)<=deniz_pickup_timestamp($pickup_date,$pickup_time))wp_send_json_error(['message'=>deniz_t('return_after_outbound')]);
 }
 $hotel_id=absint($_POST['hotel_id']??0);$selected_hotel=$hotel_id?$wpdb->get_row($wpdb->prepare("SELECT id FROM {$t['hotels']} WHERE id=%d AND region_id=%d AND active=1",$hotel_id,$region)):null;
 $hotel_address=isset($_POST['hotel_address'])&&is_scalar($_POST['hotel_address'])?trim(sanitize_text_field(wp_unslash($_POST['hotel_address']))):'';
 if(!$selected_hotel&&$hotel_address==='')wp_send_json_error(['message'=>deniz_t('hotel_address_required')]);
 if(strlen($hotel_address)>2000)wp_send_json_error(['message'=>deniz_t('hotel_address_required')]);
 $mode=sanitize_key($_POST['service_mode']??'airport');if(!in_array($mode,['airport','hotel','return'],true)||!in_array($direction,['oneway','return'],true))wp_send_json_error(['message'=>deniz_t('route_validation_error')]);
 $fl=(float)($_POST['from_lat']??0);$fg=(float)($_POST['from_lng']??0);$tl=(float)($_POST['to_lat']??0);$tg=(float)($_POST['to_lng']??0);
 if($hotel_address!==''){$selected_hotel=null;$hotel_id=0;$lat=sanitize_text_field($_POST['address_lat']??'');$lng=sanitize_text_field($_POST['address_lng']??'');$signature=sanitize_text_field($_POST['address_signature']??'');if(!hash_equals(twt_address_signature($hotel_address,$lat,$lng,$region),$signature))wp_send_json_error(['message'=>deniz_t('select_verified_address')]);if($mode==='hotel'){$fl=(float)$lat;$fg=(float)$lng;}else{$tl=(float)$lat;$tg=(float)$lng;}}
 if(!twt_validate_route($airport,$region,$hotel_address!==''?0:$hotel_id,$mode,$fl,$fg,$tl,$tg))wp_send_json_error(['message'=>deniz_t('route_validation_error')]);
 $pickup_label=sanitize_text_field(wp_unslash($_POST['from']??''));$dropoff_label=sanitize_text_field(wp_unslash($_POST['to']??''));
 if($hotel_address!==''){if(sanitize_key($_POST['service_mode']??'airport')==='hotel')$pickup_label.=' · '.$hotel_address;else $dropoff_label.=' · '.$hotel_address;}
 $extras=$_POST['extras']??[];$extra_total=0;$extra_rows=[];foreach($extras as $eid=>$qty){if(!is_scalar($qty))wp_send_json_error(['message'=>deniz_t('complete_required')]);$qty=max(0,absint($qty));if(!$qty)continue;$e=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['extras']} WHERE id=%d AND active=1",absint($eid)));if(!$e)continue;$qty=min($qty,(int)$e->max_qty);if($qty<1)continue;$line=$e->pricing_type==='per_item'?(float)$e->price*$qty:(float)$e->price;$extra_total+=$line;$extra_rows[]=[$e,$qty,$line];}
 $revision=twt_price_revision($v,$price,$currency,$wpdb->get_results("SELECT * FROM {$t['extras']} WHERE active=1 ORDER BY name"));if(!hash_equals($revision,sanitize_text_field($_POST['price_revision']??'')))wp_send_json_error(['code'=>'price_changed','message'=>deniz_t('price_changed')]);
 $base_converted=deniz_convert_price($base,$currency);$extra_total_converted=deniz_convert_price($extra_total,$currency);
 $data=['booking_ref'=>$ref,'status'=>'new','created_at'=>current_time('mysql'),'airport_id'=>$airport,'region_id'=>$region,'hotel_id'=>$selected_hotel?$hotel_id:null,'vehicle_id'=>$vehicle,'direction'=>$direction,'pickup_label'=>$pickup_label,'dropoff_label'=>$dropoff_label,'pickup_lat'=>$fl,'pickup_lng'=>$fg,'dropoff_lat'=>$tl,'dropoff_lng'=>$tg,'pickup_date'=>$pickup_date,'pickup_time'=>$pickup_time,'return_date'=>sanitize_text_field($_POST['return_date']??'')?:null,'return_time'=>sanitize_text_field($_POST['return_time']??'')?:null,'passengers'=>$passengers,'bags'=>$bags,'first_name'=>sanitize_text_field($_POST['first_name']??''),'last_name'=>sanitize_text_field($_POST['last_name']??''),'email'=>sanitize_email($_POST['email']??''),'phone'=>sanitize_text_field($_POST['phone']??''),'flight_number'=>sanitize_text_field($_POST['flight_number']??''),'notes'=>sanitize_textarea_field($_POST['notes']??''),'payment_method'=>'cash_to_driver','payment_status'=>'cash_due','currency'=>$currency,'base_amount'=>$base_converted,'extras_amount'=>$extra_total_converted,'total_amount'=>$base_converted+$extra_total_converted];
 foreach(['first_name','last_name','email','phone','pickup_date','pickup_time','pickup_label','dropoff_label'] as $k)if(empty($data[$k]))wp_send_json_error(['message'=>deniz_t('complete_required')]);if(!is_email($data['email']))wp_send_json_error(['message'=>deniz_t('valid_email')]);
 $lock='twt_'.substr(hash('sha256',$request_key),0,50);$locked=(int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,5)',$lock));if(!$locked)wp_send_json_error(['message'=>deniz_t('booking_processing')]);
 $result=null;$error=false;$bid=0;
 try{
 $existing=$wpdb->get_row($wpdb->prepare("SELECT id,booking_ref FROM {$t['bookings']} WHERE booking_ref=%s",$ref));if($existing)$result=$existing;
 else{
 if($wpdb->query('START TRANSACTION')===false)throw new RuntimeException('transaction');
 if(!$wpdb->insert($t['bookings'],$data))throw new RuntimeException('booking');$bid=(int)$wpdb->insert_id;
 foreach($extra_rows as [$e,$qty,$line]){if(!$wpdb->insert($t['booking_extras'],['booking_id'=>$bid,'extra_id'=>$e->id,'qty'=>$qty,'unit_price'=>deniz_convert_price((float)$e->price,$currency),'total_price'=>deniz_convert_price($line,$currency)]))throw new RuntimeException('extra');}
 $return_flight=($direction==='return' && isset($_POST['return_flight_number']) && is_scalar($_POST['return_flight_number'])) ? sanitize_text_field(wp_unslash($_POST['return_flight_number'])) : '';if(strlen($return_flight)>60)$return_flight=substr($return_flight,0,60);
 $snapshot=['return_flight_number'=>$return_flight,'lang'=>deniz_current_lang(),'rate'=>deniz_currencies()[$currency]['rate'],'base_eur'=>$base,'image_id'=>(int)$v->image_id,'vehicle'=>twt_entity_name($v,'vehicle'),'airport'=>twt_entity_name($wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d",$airport)),'airport'),'region'=>twt_entity_name($wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d",$region)),'region'),'extras'=>[]];foreach($extra_rows as [$e,$qty,$line])$snapshot['extras'][(int)$e->id]=twt_entity_name($e,'extra');if(!add_option('twt_booking_snapshot_'.$bid,$snapshot,'',false))throw new RuntimeException('snapshot');
 if($wpdb->query('COMMIT')===false)throw new RuntimeException('commit');$result=(object)['id'=>$bid,'booking_ref'=>$ref];
 }
 }catch(Throwable $e){$wpdb->query('ROLLBACK');if($bid){delete_option('twt_booking_snapshot_'.$bid);$wpdb->delete($t['booking_extras'],['booking_id'=>$bid]);$wpdb->delete($t['bookings'],['id'=>$bid]);}$error=true;}finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
 if($error||!$result)wp_send_json_error(['message'=>deniz_t('booking_save_error')]);
 deniz_send_booking_emails($result->id);wp_send_json_success(['ref'=>$ref,'redirect'=>twt_voucher_url($result)]);
}
