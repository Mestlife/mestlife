<?php
if(!defined('ABSPATH'))exit;
function twt_seo_plugin_active(){return defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION')||defined('AIOSEO_VERSION');}
function twt_seo_private_page(){return is_page_template('template-transfer-search.php')||is_page_template('template-passenger-details.php')||is_page_template('template-booking-confirmation.php');}

/** Live transfer SEO from active operational data. */
function twt_live_transfer_seo_context($post_id=0){
 $post_id=$post_id?:get_queried_object_id();$type=get_post_type($post_id);if(!in_array($type,['transfer-route','location'],true))return null;
 $airport=null;$region=null;$hotel=null;
 if($type==='transfer-route'){$c=deniz_route_context($post_id);if(!$c||empty($c['a']))return null;$airport=$c['a'];$region=$c['r']??null;$hotel=$c['h']??null;if(!$region&&$hotel)$region=deniz_db_region((int)$hotel->region_id);}
 else{$region=deniz_db_region((int)get_post_meta($post_id,'dynamic_region_id',true));if(!$region)$region=deniz_region_by_slug(get_post_field('post_name',$post_id));if(!$region)return null;$airports=deniz_region_airports((int)$region->id);$airport=$airports[0]??null;}
 if(!$airport||!$region)return null;$rows=deniz_region_price_rows((int)$region->id,(int)$airport->id);$shared=null;$private=null;
 foreach((array)$rows as $row){$fare=(float)($row->one_way??0);if($fare<=0)continue;$bucket=atp_is_shared_service($row)?'shared':'private';if($$bucket===null||$fare<$$bucket)$$bucket=$fare;}
 return ['airport'=>$airport,'region'=>$region,'hotel'=>$hotel,'shared'=>$shared,'private'=>$private,'target'=>$hotel?twt_entity_name($hotel,'hotel'):twt_entity_name($region,'region'),'lang'=>deniz_current_lang()];
}
function twt_live_seo_money($value){return '€'.rtrim(rtrim(number_format((float)$value,2,'.',''),'0'),'.');}
function twt_live_transfer_h1($ctx){$a=twt_entity_name($ctx['airport'],'airport');$p=$ctx['target'];$lang=$ctx['lang']??'en';$copy=['tr'=>'%s → %s Transfer','en'=>'%s to %s Transfer','de'=>'Transfer von %s nach %s','ru'=>'Трансфер из %s в %s'];return sprintf($copy[$lang]??$copy['en'],$a,$p);}
function twt_live_transfer_title($ctx){
 $a=twt_entity_name($ctx['airport'],'airport');$p=$ctx['target'];$s=$ctx['shared'];$v=$ctx['private'];$lang=$ctx['lang']??'en';
 if($s!==null&&$v!==null){$copy=['tr'=>'%s → %s Transfer | Shuttle %s, Özel %s','en'=>'%s to %s Transfer | Shuttle %s, Private %s','de'=>'%s nach %s Transfer | Shuttle %s, Privat %s','ru'=>'%s – %s | Шаттл %s, Индив. %s'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($s),twt_live_seo_money($v)),68);}
 if($s!==null){$copy=['tr'=>'%s → %s Shuttle Transfer %s’dan','en'=>'%s to %s Shuttle from %s/person','de'=>'%s nach %s Shuttle ab %s/Person','ru'=>'%s – %s Шаттл от %s/чел.'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($s)),68);}
 if($v!==null){$copy=['tr'=>'%s → %s Özel Transfer %s’dan','en'=>'%s to %s Private Transfer from %s','de'=>'%s nach %s Privattransfer ab %s','ru'=>'%s – %s Индив. трансфер от %s'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($v)),68);}
 return deniz_seo_trim(twt_live_transfer_h1($ctx),68);
}
function twt_live_transfer_meta($ctx){
 $a=twt_entity_name($ctx['airport'],'airport');$p=$ctx['target'];$s=$ctx['shared'];$v=$ctx['private'];$lang=$ctx['lang']??'en';
 if($s!==null&&$v!==null){$copy=['tr'=>'%s ile %s arası transfer: paylaşımlı shuttle kişi başı %s’dan, özel transfer araç başı %s’dan. Güncel fiyatı görüp rezervasyon yapın.','en'=>'%s to %s transfer: shared shuttle from %s per person and private transfer from %s per vehicle. See live prices and book online.','de'=>'Transfer %s–%s: Sammelshuttle ab %s pro Person, Privattransfer ab %s pro Fahrzeug. Aktuelle Preise ansehen und buchen.','ru'=>'Трансфер %s – %s: шаттл от %s с человека, индивидуальный трансфер от %s за автомобиль. Актуальные цены при бронировании.'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($s),twt_live_seo_money($v)),160);}
 if($s!==null){$copy=['tr'=>'%s ile %s arası paylaşımlı shuttle kişi başı %s’dan. Aktif fiyatı, araç bilgilerini ve müsaitliği rezervasyon öncesi görün.','en'=>'Shared shuttle from %s to %s from %s per person. Check the live fare, service details and availability before booking.','de'=>'Sammelshuttle von %s nach %s ab %s pro Person. Aktuellen Preis, Details und Verfügbarkeit vor der Buchung prüfen.','ru'=>'Групповой шаттл из %s в %s от %s с человека. Проверьте актуальную цену и доступность перед бронированием.'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($s)),160);}
 if($v!==null){$copy=['tr'=>'%s ile %s arası özel transfer araç başı %s’dan. Sabit rota fiyatını, araç seçeneklerini ve müsaitliği rezervasyon öncesi görün.','en'=>'Private transfer from %s to %s from %s per vehicle. Check the live route fare, vehicle choices and availability before booking.','de'=>'Privattransfer von %s nach %s ab %s pro Fahrzeug. Aktuellen Routenpreis, Fahrzeuge und Verfügbarkeit vor der Buchung prüfen.','ru'=>'Индивидуальный трансфер из %s в %s от %s за автомобиль. Проверьте актуальную цену, автомобили и доступность.'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p,twt_live_seo_money($v)),160);}
 $copy=['tr'=>'%s ile %s arasında havalimanı transferi. Güncel araçları, fiyatları ve müsaitliği rezervasyon sırasında kontrol edin.','en'=>'Airport transfer from %s to %s. Check current vehicles, fares and availability during booking.','de'=>'Flughafentransfer von %s nach %s. Aktuelle Fahrzeuge, Preise und Verfügbarkeit bei der Buchung prüfen.','ru'=>'Трансфер из %s в %s. Актуальные автомобили, цены и доступность отображаются при бронировании.'];return deniz_seo_trim(sprintf($copy[$lang]??$copy['en'],$a,$p),160);
}
function deniz_auto_seo_title(){
 if(function_exists('atp_landing_current')&&($l=atp_landing_current()))return atp_meta($l['key'])['title'];
 if(function_exists('twt_is_hotels_page')&&twt_is_hotels_page()&&!is_404())return deniz_seo_trim(twt_hotels_title().' | Antalya Transfer Pro',70);
 if(is_singular(['transfer-route','location'])&&($ctx=twt_live_transfer_seo_context()))return twt_live_transfer_title($ctx);
 if(is_singular()){$custom=deniz_translated_meta(get_queried_object_id(),'seo_title');if($custom)return deniz_seo_trim($custom,70);}
 $title='';if(is_page_template('template-how-it-works.php'))$title=deniz_t('guide_steps');if(is_front_page())$title=deniz_t('seo_home_title');elseif(is_post_type_archive('transfer-route'))$title=deniz_t('seo_routes_title');elseif(is_post_type_archive('location'))$title=deniz_t('seo_regions_title');elseif(is_post_type_archive('destination'))$title=deniz_t('hub_dest_title');elseif(is_post_type_archive('vehicle'))$title=deniz_t('hub_fleet_title');
 elseif(is_singular('vehicle')){$v=twt_fleet_entity();if($v)$title=sprintf(deniz_t('hub_vehicle_seo'),twt_entity_name($v,'vehicle'));}
 elseif(is_singular('transfer-route')){$c=deniz_route_context();if($c&&$c['a'])$title=twt_entity_name($c['a'],'airport').' → '.($c['h']?twt_entity_name($c['h'],'hotel'):twt_entity_name($c['r'],'region'));}
 if(!$title&&is_singular())$title=twt_public_title(get_queried_object_id());if(!$title)$title=deniz_legacy_seo_title();
 $brand=twt_brand_name();if(strpos($title,$brand)!==false)return $title;return mb_strlen($title.' | '.$brand)<=65?$title.' | '.$brand:$title;
}
function deniz_auto_meta_description(){
 if(function_exists('atp_landing_current')&&($l=atp_landing_current()))return atp_meta($l['key'])['desc'];
 if(function_exists('twt_is_hotels_page')&&twt_is_hotels_page()&&!is_404())return deniz_seo_trim(twt_hotels_description(),160);
 if(is_singular(['transfer-route','location'])&&($ctx=twt_live_transfer_seo_context()))return twt_live_transfer_meta($ctx);
 if(is_singular()){$custom=deniz_translated_meta(get_queried_object_id(),'seo_description');if($custom)return deniz_seo_trim($custom,160);}
 if(is_singular('transfer-route')){$c=deniz_route_context();if($c&&$c['a'])return deniz_seo_trim(sprintf(deniz_t('seo_route_desc'),twt_entity_name($c['a'],'airport'),$c['h']?twt_entity_name($c['h'],'hotel'):twt_entity_name($c['r'],'region')),160);}
 if(is_post_type_archive('destination')||is_post_type_archive('location'))return deniz_seo_trim(deniz_t('hub_dest_intro'),160);
 if(is_post_type_archive('vehicle'))return deniz_seo_trim(deniz_t('hub_fleet_intro'),160);
 if(is_singular('vehicle')){$v=twt_fleet_entity();if($v)return deniz_seo_trim(sprintf(deniz_t('hub_vehicle_intro'),twt_entity_name($v,'vehicle'),(int)$v->pax,(int)$v->bags,deniz_t($v->pricing_type==='per_person'?'shared_transfer':'private_transfer')),160);}
 if(is_singular('destination')){global $wpdb;$t=deniz_tables();$id=get_queried_object_id();$city=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['cities']} WHERE active=1 AND (id=%d OR slug=%s) LIMIT 1",(int)get_post_meta($id,'dynamic_city_id',true),get_post_field('post_name',$id)));if($city)return deniz_seo_trim(sprintf(deniz_t('hub_city_intro'),twt_entity_name($city,'city')),160);}
 if(is_singular('location')){$region=deniz_db_region((int)get_post_meta(get_queried_object_id(),'dynamic_region_id',true));if(!$region)$region=deniz_region_by_slug(get_post_field('post_name',get_queried_object_id()));if($region)return deniz_seo_trim(sprintf(deniz_t('hub_region_intro'),twt_entity_name($region,'region')),160);}
 if(is_singular('post'))return deniz_seo_trim(deniz_translated_meta(get_queried_object_id(),'excerpt',get_the_excerpt()),160);
 $is_home=is_front_page()||(function_exists('deniz_is_language_home_request')&&deniz_is_language_home_request());$name=(!$is_home&&is_singular())?twt_public_title(get_queried_object_id()).' – ':'';return deniz_seo_trim($name.deniz_t('seo_desc'),160);
}
// Keep live route/region SEO dynamic even when a supported SEO plugin is active.
foreach(['wpseo_title','rank_math/frontend/title','aioseo_title'] as $filter)add_filter($filter,function($value){if(is_singular(['transfer-route','location'])&&($ctx=twt_live_transfer_seo_context()))return twt_live_transfer_title($ctx);return $value;},120);
foreach(['wpseo_metadesc','rank_math/frontend/description','aioseo_description'] as $filter)add_filter($filter,function($value){if(is_singular(['transfer-route','location'])&&($ctx=twt_live_transfer_seo_context()))return twt_live_transfer_meta($ctx);return $value;},120);
add_action('wp_head',function(){if(twt_seo_plugin_active()||twt_seo_private_page()||is_404())return;$url=deniz_lang_url(deniz_current_lang());foreach(deniz_languages() as $code=>$info)if($code!==deniz_current_lang())echo '<meta property="og:locale:alternate" content="'.esc_attr(['en'=>'en_GB','tr'=>'tr_TR','de'=>'de_DE','ru'=>'ru_RU'][$code]).'">'."\n";$tags=['og:type'=>is_singular('post')?'article':'website','og:site_name'=>twt_brand_name(),'og:title'=>deniz_auto_seo_title(),'og:description'=>deniz_auto_meta_description(),'og:url'=>$url,'og:locale'=>(['en'=>'en_GB','tr'=>'tr_TR','de'=>'de_DE','ru'=>'ru_RU'][deniz_current_lang()]??'en_GB')];$image=is_singular()?get_the_post_thumbnail_url(get_queried_object_id(),'full'):'';if(!$image){$logo=get_theme_mod('custom_logo');$image=$logo?wp_get_attachment_image_url($logo,'full'):'';}if(!$image)$image=atp_img('og-default.jpg');$tags['og:image']=$image;if(strpos($image,'og-default.jpg')!==false){$tags['og:image:width']='1200';$tags['og:image:height']='630';}$tags['og:image:alt']=twt_brand_name();foreach($tags as $k=>$v)echo '<meta property="'.esc_attr($k).'" content="'.esc_attr($v).'">'."\n";echo '<meta name="twitter:card" content="'.($image?'summary_large_image':'summary').'">'."\n";},8);
/* Core sitemap excludes private transaction pages. Public content keeps native paging. */
add_filter('wp_sitemaps_posts_query_args',function($args,$type){if($type==='page'){$private=get_posts(['post_type'=>'page','post_status'=>'publish','fields'=>'ids','posts_per_page'=>-1,'meta_query'=>[['key'=>'_wp_page_template','value'=>['template-transfer-search.php','template-passenger-details.php','template-booking-confirmation.php'],'compare'=>'IN']]]);$args['post__not_in']=array_unique(array_merge($args['post__not_in']??[],$private));}return $args;},10,2);
add_filter('wp_robots',function($r){if(twt_seo_private_page()||is_search()){$r['noindex']=true;unset($r['index']);}else{$r['max-image-preview']='large';}return $r;},30);
/* Human-readable source discovery; no fabricated rankings or AI promises. */
add_action('template_redirect',function(){if(trim(deniz_current_request_relative_path(),'/')==='llms.txt'||get_query_var('deniz_llms')){status_header(200);header('Content-Type: text/plain; charset=utf-8');header('X-Robots-Tag: noindex');echo atp_llms_txt();exit;}},1);
/* robots.txt is generated in inc/seo-landings.php */
/* Language sitemap complements WordPress' paged public-content sitemap. */
add_action('wp_sitemaps_init',function(){
 if(twt_seo_plugin_active())return;
 $provider=new class extends WP_Sitemaps_Provider{
  public function __construct(){$this->name='twt-languages';$this->object_type='twt-languages';}
  public function get_url_list($page_num,$subtype=''){
   $types=['page','post','destination','location','transfer-route','vehicle','airport-guide'];$query=['post_type'=>$types,'post_status'=>'publish','posts_per_page'=>250,'paged'=>max(1,(int)$page_num),'orderby'=>'ID','order'=>'ASC','meta_query'=>[['relation'=>'OR',['key'=>'_wp_page_template','compare'=>'NOT EXISTS'],['key'=>'_wp_page_template','value'=>['template-transfer-search.php','template-passenger-details.php','template-booking-confirmation.php'],'compare'=>'NOT IN']]]];$query['post__not_in']=array_merge(twt_stale_vehicle_ids(),twt_stale_content_ids());$posts=get_posts($query);$out=[];$map=['post'=>'blog','destination'=>'destinations','location'=>'locations','transfer-route'=>'transfers','vehicle'=>'vehicles','airport-guide'=>'airports'];
   foreach($posts as $post){$path=isset($map[$post->post_type])?$map[$post->post_type].'/'.$post->post_name:get_page_uri($post);if((int)get_option('page_on_front')===$post->ID)$path='';foreach(deniz_languages() as $lang=>$info)$out[]=['loc'=>deniz_url($path,$lang),'lastmod'=>gmdate(DATE_W3C,twt_real_updated_timestamp($post->ID))];}
   if((int)$page_num===1)foreach(deniz_languages() as $lang=>$info){$out[]=['loc'=>deniz_url('',$lang)];foreach(['destinations','locations','transfers','vehicles','blog'] as $path)$out[]=['loc'=>deniz_url($path,$lang)];}return $out;
  }
  public function get_max_num_pages($subtype=''){global $wpdb;$types=['page','post','destination','location','transfer-route','vehicle','airport-guide'];$n=0;foreach($types as $type){$counts=wp_count_posts($type);$n+=(int)($counts->publish??0);}return max(1,(int)ceil($n/250));}
 };
 wp_register_sitemap_provider('twt-languages',$provider);
});
