<?php
if (!defined('ABSPATH')) exit;
/**
 * Antalya Transfer Pro — keyword landing pages (TR / EN / DE / RU), FAQ engine,
 * landing sitemap, robots.txt and llms.txt.
 * Content lives in inc/seo-landings.json so copy can be edited without touching PHP.
 */

function atp_ld(){
 static $d=null; if($d!==null) return $d;
 $raw=@file_get_contents(get_template_directory().'/inc/seo-landings.json');
 $d=$raw?json_decode($raw,true):[]; if(!is_array($d)) $d=[];
 return $d;
}
function atp_lang(){ $l=function_exists('deniz_current_lang')?deniz_current_lang():'tr'; return in_array($l,['tr','en','de','ru'],true)?$l:'en'; }
function atp_l($key,$lang=null,$vars=[]){ $lang=$lang?:atp_lang(); $L=atp_ld()['labels'][$lang]??[]; $v=$L[$key]??(atp_ld()['labels']['en'][$key]??$key); return is_string($v)?atp_fill($v,$vars):$v; }
function atp_fill($s,$vars){
 $base=['brand'=>twt_brand_name(),'tursab'=>atp_contact()['tursab'],'phone'=>atp_contact()['phone_display']];
 foreach(array_merge($base,$vars) as $k=>$v) $s=str_replace('{'.$k.'}',(string)$v,$s);
 return $s;
}
function atp_service_keys(){ return array_keys(atp_ld()['services']??[]); }
function atp_dest_keys(){ return array_keys(atp_ld()['dest']??[]); }
function atp_page_keys(){ return array_merge(atp_service_keys(),atp_dest_keys()); }
function atp_is_dest($key){ return isset(atp_ld()['dest'][$key]); }
function atp_slug($key,$lang){
 $d=atp_ld();
 if(isset($d['services'][$key])) return $d['services'][$key]['slug'][$lang]??$d['services'][$key]['slug']['en'];
 if($key==='cirali') return 'antalya-cirali-olympos-transfer';
 return 'antalya-'.$key.'-transfer';
}
function atp_landing_url($key,$lang=null){ $lang=$lang?:atp_lang(); return deniz_url(atp_slug($key,$lang),$lang); }
function atp_place($key,$lang=null){ $lang=$lang?:atp_lang(); $x=atp_ld()['dest'][$key]??null; if(!$x) return 'Antalya'; return $lang==='ru'?$x['name_ru']:$x['name']; }
function atp_air_name($code,$lang,$form=''){ $a=atp_ld()['air'][$code]??atp_ld()['air']['AYT']; return $a[$lang.($form?'_'.$form:'')]??$a[$lang]??$a['en']; }

/* ---------- Routing ---------- */
add_filter('query_vars',function($v){$v[]='atp_landing';$v[]='atp_sitemap';return $v;});
add_action('init',function(){
 foreach(['tr','en','de','ru'] as $lang){
  foreach(atp_page_keys() as $key){
   add_rewrite_rule('^'.$lang.'/'.preg_quote(atp_slug($key,$lang),'/').'/?$','index.php?atp_landing='.$key.'&deniz_lang='.$lang,'top');
  }
 }
 add_rewrite_rule('^landing-sitemap\.xml$','index.php?atp_sitemap=landing','top');
 if(get_option('atp_landing_rules')!=='3'){ flush_rewrite_rules(false); update_option('atp_landing_rules','3',false); }
},5);

function atp_landing_current(){
 static $cache=null; if($cache!==null) return $cache?:null;
 if(!did_action('parse_request')) return null;
 $key=sanitize_key((string)get_query_var('atp_landing'));
 $cache=($key&&in_array($key,atp_page_keys(),true))?['key'=>$key,'lang'=>atp_lang()]:false;
 return $cache?:null;
}
add_action('parse_query',function($q){
 if(!$q->is_main_query()||is_admin()||!$q->get('atp_landing'))return;
 $q->is_home=false;$q->is_page=false;$q->is_singular=false;$q->is_archive=false;$q->is_404=false;$q->is_posts_page=false;
});
add_filter('posts_pre_query',function($posts,$q){ return ($q->is_main_query()&&$q->get('atp_landing'))?[]:$posts; },10,2);
add_filter('pre_handle_404',function($pre){ return atp_landing_current()?true:$pre; });
add_filter('redirect_canonical',function($r){ return atp_landing_current()?false:$r; });
add_action('template_redirect',function(){ if(atp_landing_current()) status_header(200); },0);
add_filter('template_include',function($t){ return atp_landing_current()?get_template_directory().'/template-seo-landing.php':$t; },100);
add_filter('body_class',function($c){ if($l=atp_landing_current()){$c[]='atp-landing';$c[]='atp-landing-'.$l['key'];} return $c; });
add_action('wp_enqueue_scripts',function(){
 if(!atp_landing_current())return; $v=wp_get_theme()->get('Version');
 wp_enqueue_style('twt-route-page',get_template_directory_uri().'/assets/css/route-page.css',['twt-pages'],$v);
 wp_enqueue_style('twt-hubs',get_template_directory_uri().'/assets/css/premium-hubs.css',['twt-route-page'],$v);
},20);

/* ---------- Data helpers ---------- */
function atp_ret_text($min,$lang){ $r=atp_ld()['ret'][$lang]??atp_ld()['ret']['en']; if(!$min) return $r[3]; return $min<=45?$r[0]:($min<=90?$r[1]:$r[2]); }
/**
 * Live road distance / drive time for a landing page.
 * Priority: manual override (admin) > route matrix metrics (airport + region from the price DB) > OSRM road routing on the page coordinates.
 * OSRM results are cached for 30 days by the existing twt_fetch_road worker; nothing is hard-coded.
 */
function atp_airport_obj($code){ static $c=[]; if(!array_key_exists($code,$c)) $c[$code]=function_exists('deniz_dynamic_airport')?deniz_dynamic_airport($code):null; return $c[$code]; }
function atp_airport_coords($code){ $a=atp_airport_obj($code); if($a&&$a->lat&&$a->lng) return [(float)$a->lat,(float)$a->lng]; return $code==='GZP'?[36.2992,32.3006]:[36.8987,30.8005]; }
function atp_metrics_overrides(){ $o=get_option('atp_metrics_override',[]); return is_array($o)?$o:[]; }
function atp_metrics_target($key){
 $d=atp_ld();
 if(isset($d['dest'][$key])) return ['air'=>'AYT','dest'=>$key];
 $s=$d['services'][$key]??[]; if(!empty($s['airport'])&&!empty($s['place'])) return ['air'=>$s['airport'],'dest'=>$s['place']];
 return null;
}
function atp_metrics_for($air,$dest,$schedule=true,$use_override=true){
 $o=atp_metrics_overrides(); $ok=$air.':'.$dest;
 if($use_override&&!empty($o[$ok]['km'])&&!empty($o[$ok]['min'])) return ['km'=>(int)round($o[$ok]['km']),'min'=>(int)$o[$ok]['min'],'source'=>'manual'];
 $x=atp_ld()['dest'][$dest]??null; if(!$x) return null;
 $airport=atp_airport_obj($air); $region=atp_db_region($dest);
 if($airport&&$region&&function_exists('twt_route_metrics')){
  $m=$schedule?twt_route_metrics($airport,$region):(function_exists('twt_road_args')&&($a=twt_road_args($airport,$region,null))?(get_transient('twt_road_'.$a[4])?:[]):[]);
  if(!empty($m['distance'])&&!empty($m['duration'])) return ['km'=>(int)round($m['distance']),'min'=>(int)$m['duration'],'source'=>'route'];
 }
 [$alat,$alng]=atp_airport_coords($air); $rk='atp_'.md5($air.'|'.$dest.'|'.$x['lat'].'|'.$x['lng']);
 $m=get_transient('twt_road_'.$rk);
 if($m===false){ if($schedule&&function_exists('twt_fetch_road_worker')){ $args=[$alat,$alng,(float)$x['lat'],(float)$x['lng'],$rk]; if(!wp_next_scheduled('twt_fetch_road',$args)) wp_schedule_single_event(time()+5,'twt_fetch_road',$args);} return null; }
 if(!empty($m['distance'])&&!empty($m['duration'])) return ['km'=>(int)round($m['distance']),'min'=>(int)$m['duration'],'source'=>'osrm'];
 return null;
}
function atp_metrics($key){ static $c=[]; if(array_key_exists($key,$c)) return $c[$key]; $t=atp_metrics_target($key); return $c[$key]=$t?atp_metrics_for($t['air'],$t['dest']):null; }
/** Fetch every missing metric synchronously (admin button / daily cron). */
function atp_metrics_warm($limit=100){
 if(!function_exists('twt_fetch_road_worker')) return 0; $n=0;
 foreach(atp_dest_keys() as $k){ foreach(['AYT','GZP'] as $air){
  if($air==='GZP'&&!in_array($k,atp_ld()['services']['gazipasa']['times']??[],true)) continue;
  if(atp_metrics_for($air,$k,false,false)) continue; if($n>=$limit) return $n;
  $x=atp_ld()['dest'][$k]; $airport=atp_airport_obj($air); $region=atp_db_region($k);
  if($airport&&$region&&function_exists('twt_road_args')&&($a=twt_road_args($airport,$region,null))){ delete_transient('twt_road_'.$a[4]); twt_fetch_road_worker(...$a); }
  else { [$alat,$alng]=atp_airport_coords($air); $rk='atp_'.md5($air.'|'.$k.'|'.$x['lat'].'|'.$x['lng']); delete_transient('twt_road_'.$rk); twt_fetch_road_worker($alat,$alng,(float)$x['lat'],(float)$x['lng'],$rk); }
  $n++; usleep(300000);
 }}
 return $n;
}
add_action('atp_metrics_cron',function(){ atp_metrics_warm(15); });
add_action('init',function(){ if(!wp_next_scheduled('atp_metrics_cron')) wp_schedule_event(time()+60,'hourly','atp_metrics_cron'); });

function atp_db_region($key){
 if(!function_exists('deniz_region_by_slug')||!atp_is_dest($key)) return null;
 static $c=[]; if(array_key_exists($key,$c)) return $c[$key];
 $x=atp_ld()['dest'][$key]; $r=null;
 foreach(array_unique([$key,sanitize_title($x['name']),sanitize_title(remove_accents($x['name']))]) as $slug){ $r=deniz_region_by_slug($slug); if($r) break; }
 // Imported composite regions (e.g. Lara Beach / Kundu) may not equal the landing slug.
 if(!$r){global $wpdb;$tables=deniz_tables();$token=sanitize_title($key);$matches=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$tables['regions']} WHERE active=1 AND slug REGEXP %s LIMIT 2",'(^|-)'.preg_quote($token,'/').'(-|$)'));if(count($matches)===1)$r=deniz_db_region((int)$matches[0]->id);}
 return $c[$key]=$r?:null;
}
/**
 * Manual destination -> pricing region mapping used by SEO landing fare blocks.
 * The destination's own geographic region remains untouched; this only controls
 * which live Price Matrix region supplies the displayed fare.
 */
function atp_price_region_map(){
 $map=get_option('atp_destination_price_regions',[]);
 if(!is_array($map)) return [];
 $clean=[]; foreach($map as $key=>$region_id){ $key=sanitize_key($key); $region_id=absint($region_id); if($key&&$region_id) $clean[$key]=$region_id; }
 return $clean;
}
function atp_price_region($key){
 if(!atp_is_dest($key)) return null;
 $map=atp_price_region_map();
 if(!empty($map[$key])&&function_exists('deniz_db_region')){
  $r=deniz_db_region((int)$map[$key]);
  if($r&&!isset($r->active)||($r&&isset($r->active)&&(int)$r->active===1)) return $r;
 }
 return atp_db_region($key);
}
function atp_pricing_regions(){
 if(!function_exists('deniz_tables')) return [];
 global $wpdb; $t=deniz_tables();
 return (array)$wpdb->get_results("SELECT r.*,c.name city_name FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id WHERE r.active=1 ORDER BY COALESCE(c.name,''),r.name");
}
function atp_ayt(){ static $a=false; if($a===false) $a=function_exists('deniz_dynamic_airport')?deniz_dynamic_airport('AYT'):null; return $a; }
/** Lowest one-way shared (per person) and private (per vehicle) fare for one region + airport. */
function atp_fares_for_region_id($region_id,$airport_id){
 $out=['shared'=>null,'private'=>null];
 if(!$region_id||!$airport_id||!function_exists('deniz_region_price_rows'))return $out;
 foreach((array)deniz_region_price_rows((int)$region_id,(int)$airport_id) as $row){
  $fare=(float)($row->one_way??0); if($fare<=0)continue;
  $bucket=atp_is_shared_service($row)?'shared':'private';
  if($out[$bucket]===null||$fare<$out[$bucket])$out[$bucket]=$fare;
 }
 return $out;
}
function atp_fares($key){
 $r=atp_price_region($key); $a=atp_ayt();
 return ($r&&$a)?atp_fares_for_region_id((int)$r->id,(int)$a->id):['shared'=>null,'private'=>null];
}
/** Site-wide "from" fares for one airport (homepage, hub and service pages). */
function atp_global_fares($air='AYT'){
 static $c=[]; if(isset($c[$air]))return $c[$air];
 $out=['shared'=>null,'private'=>null];
 $a=atp_airport_obj($air);
 if(!$a||!function_exists('deniz_tables'))return $c[$air]=$out;
 global $wpdb; $t=deniz_tables();
 $rows=$wpdb->get_results($wpdb->prepare("SELECT v.pricing_type,v.service_type,MIN(p.one_way) fare FROM {$t['prices']} p JOIN {$t['vehicles']} v ON v.id=p.vehicle_id WHERE p.airport_id=%d AND p.active=1 AND v.active=1 AND p.one_way>0 GROUP BY v.pricing_type,v.service_type",(int)$a->id));
 foreach((array)$rows as $r){ $b=atp_is_shared_service($r)?'shared':'private'; $f=(float)$r->fare; if($f>0&&($out[$b]===null||$f<$out[$b]))$out[$b]=$f; }
 return $c[$air]=$out;
}
function atp_min_fare($fares){ $v=array_values(array_filter([$fares['shared']??null,$fares['private']??null],fn($x)=>$x!==null&&$x>0)); return $v?min($v):null; }
function atp_from_price($key){
 $f=atp_fares($key); $vals=array_values(array_filter([$f['shared'],$f['private']],fn($v)=>$v!==null&&$v>0));
 return $vals?min($vals):null;
}
function atp_offer_phrase($ctx,$lang){
 $shared=$ctx['shared']??null; $private=$ctx['private']??null;
 $money=fn($v)=>function_exists('deniz_money')?deniz_money($v):'€'.number_format((float)$v,0);
 $copy=[
  'tr'=>['both'=>'Paylaşımlı shuttle kişi başı %s’dan, özel transfer araç başı %s’dan başlar.','shared'=>'Paylaşımlı shuttle kişi başı %s’dan başlar.','private'=>'Özel transfer araç başı %s’dan başlar.','none'=>'Güncel fiyat rezervasyondan önce gösterilir.'],
  'en'=>['both'=>'Shared shuttle starts from %s per person; private transfer starts from %s per vehicle.','shared'=>'Shared shuttle starts from %s per person.','private'=>'Private transfer starts from %s per vehicle.','none'=>'Your current fare is shown before booking.'],
  'de'=>['both'=>'Sammelshuttle ab %s pro Person; Privattransfer ab %s pro Fahrzeug.','shared'=>'Sammelshuttle ab %s pro Person.','private'=>'Privattransfer ab %s pro Fahrzeug.','none'=>'Der aktuelle Preis wird vor der Buchung angezeigt.'],
  'ru'=>['both'=>'Групповой шаттл — от %s с человека; индивидуальный трансфер — от %s за автомобиль.','shared'=>'Групповой шаттл — от %s с человека.','private'=>'Индивидуальный трансфер — от %s за автомобиль.','none'=>'Актуальная цена показывается до бронирования.']
 ];
 $x=$copy[$lang]??$copy['en'];
 if($shared!==null&&$private!==null)return sprintf($x['both'],$money($shared),$money($private));
 if($shared!==null)return sprintf($x['shared'],$money($shared));
 if($private!==null)return sprintf($x['private'],$money($private));
 return $x['none'];
}
function atp_offer_intro($ctx,$lang){
 $p=$ctx['p']??'';$offer=atp_offer_phrase($ctx,$lang);$s=$ctx['shared']??null;$v=$ctx['private']??null;
 if($s!==null&&$v!==null)$copy=[
  'tr'=>'Antalya Havalimanı’ndan %s bölgesine paylaşımlı shuttle ve özel transfer seçenekleri. %s Shuttle paylaşımlıdır; özel transfer ise yalnızca sizin grubunuza ayrılır.',
  'en'=>'Shared shuttle and private transfer options from Antalya Airport to %s. %s The shuttle is shared with other passengers; a private transfer is reserved only for your party.',
  'de'=>'Sammelshuttle und Privattransfer vom Flughafen Antalya nach %s. %s Der Shuttle wird mit anderen Fahrgästen geteilt; der Privattransfer ist nur für Ihre Gruppe reserviert.',
  'ru'=>'Групповой шаттл и индивидуальный трансфер из аэропорта Антальи в %s. %s Шаттл является совместной поездкой; индивидуальный трансфер предоставляется только вашей группе.'
 ];
 elseif($s!==null)$copy=[
  'tr'=>'Antalya Havalimanı’ndan %s bölgesine paylaşımlı shuttle transferi. %s Ücret kişi başıdır ve araçta aynı yönde seyahat eden diğer yolcular bulunabilir.',
  'en'=>'Shared shuttle transfer from Antalya Airport to %s. %s The fare is per passenger and other travelers heading in the same direction may share the vehicle.',
  'de'=>'Sammelshuttle vom Flughafen Antalya nach %s. %s Der Preis gilt pro Person; weitere Fahrgäste mit ähnlicher Route können mitfahren.',
  'ru'=>'Групповой шаттл из аэропорта Антальи в %s. %s Цена указана за пассажира; в автомобиле могут ехать другие пассажиры по тому же направлению.'
 ];
 elseif($v!==null)$copy=[
  'tr'=>'Antalya Havalimanı’ndan %s bölgesine sabit fiyatlı özel transfer. %s Araç yalnızca sizin grubunuza ayrılır ve doğrudan adresinize gider.',
  'en'=>'Fixed-price private transfer from Antalya Airport to %s. %s The vehicle is reserved only for your party and drives directly to your address.',
  'de'=>'Privattransfer zum Festpreis vom Flughafen Antalya nach %s. %s Das Fahrzeug ist ausschließlich für Ihre Gruppe reserviert und fährt direkt zu Ihrer Adresse.',
  'ru'=>'Индивидуальный трансфер по фиксированной цене из аэропорта Антальи в %s. %s Автомобиль предоставляется только вашей группе и едет напрямую по адресу.'
 ];
 else $copy=[
  'tr'=>'Antalya Havalimanı’ndan %s bölgesine transfer seçeneklerini görüntüleyin. %s',
  'en'=>'View current transfer options from Antalya Airport to %s. %s',
  'de'=>'Aktuelle Transferoptionen vom Flughafen Antalya nach %s ansehen. %s',
  'ru'=>'Смотрите актуальные варианты трансфера из аэропорта Антальи в %s. %s'
 ];
 return sprintf($copy[$lang]??$copy['en'],$p,$offer);
}
function atp_offer_quick($ctx,$lang){
 $p=$ctx['p']??'';$km=$ctx['km']??null;$min=$ctx['min']??null;$offer=atp_offer_phrase($ctx,$lang);$s=$ctx['shared']??null;$v=$ctx['private']??null;
 $travel='';
 if($km&&$min){
  $travel=[
   'tr'=>sprintf('Antalya Havalimanı ile %s arası yaklaşık %d km ve yolculuk yaklaşık %d dakika sürer.',$p,$km,$min),
   'en'=>sprintf('Antalya Airport to %s is about %d km and the drive usually takes around %d minutes.',$p,$km,$min),
   'de'=>sprintf('Vom Flughafen Antalya nach %s sind es etwa %d km; die Fahrt dauert normalerweise rund %d Minuten.',$p,$km,$min),
   'ru'=>sprintf('Расстояние от аэропорта Антальи до %s — около %d км, поездка обычно занимает примерно %d минут.',$p,$km,$min),
  ][$lang]??'';
 }
 if($s!==null&&$v!==null)$tail=['tr'=>' Shuttle kişi başı fiyatlanır ve diğer yolcularla paylaşılır; özel transfer yalnızca sizin grubunuza ayrılır ve araç başı fiyatlanır.','en'=>' The shuttle is shared and priced per passenger; the private transfer is reserved only for your party and priced per vehicle.','de'=>' Der Shuttle wird geteilt und pro Person berechnet; der Privattransfer ist nur für Ihre Gruppe und wird pro Fahrzeug berechnet.','ru'=>' Шаттл общий и оплачивается за пассажира; индивидуальный трансфер только для вашей группы и оплачивается за автомобиль.'][$lang]??'';
 elseif($s!==null)$tail=['tr'=>' Shuttle paylaşımlıdır ve kişi başı fiyatlanır.','en'=>' The shuttle is shared and priced per passenger.','de'=>' Der Shuttle wird geteilt und pro Person berechnet.','ru'=>' Шаттл общий и оплачивается за пассажира.'][$lang]??'';
 elseif($v!==null)$tail=['tr'=>' Özel transfer yalnızca sizin grubunuza ayrılır ve araç başı fiyatlanır.','en'=>' The private transfer is reserved only for your party and priced per vehicle.','de'=>' Der Privattransfer ist nur für Ihre Gruppe reserviert und wird pro Fahrzeug berechnet.','ru'=>' Индивидуальный трансфер предоставляется только вашей группе и оплачивается за автомобиль.'][$lang]??'';
 else $tail='';
 return trim($travel.' '.$offer.$tail);
}
function atp_ctx($key,$lang=null){
 $lang=$lang?:atp_lang(); $d=atp_ld(); $m=atp_metrics($key);
 $base=['key'=>$key,'km'=>$m['km']??null,'min'=>$m['min']??null,'msource'=>$m['source']??null];
 if(atp_is_dest($key)){ $x=$d['dest'][$key]; $fares=atp_fares($key); return $base+['p'=>atp_place($key,$lang),'air'=>'AYT','price'=>atp_from_price($key),'shared'=>$fares['shared'],'private'=>$fares['private'],'lat'=>$x['lat'],'lng'=>$x['lng']]; }
 $s=$d['services'][$key]??[];
 if(!empty($s['airport'])){ [$la,$ln]=atp_airport_coords($s['airport']); $gf=atp_global_fares($s['airport']); return $base+['p'=>atp_place($s['place']??'alanya',$lang),'air'=>$s['airport'],'price'=>atp_min_fare($gf),'shared'=>$gf['shared'],'private'=>$gf['private'],'lat'=>$la,'lng'=>$ln]; }
 [$la,$ln]=atp_airport_coords('AYT'); $gf=atp_global_fares('AYT');
 return $base+['p'=>$lang==='ru'?'Анталья':'Antalya','air'=>'AYT','price'=>atp_min_fare($gf),'shared'=>$gf['shared'],'private'=>$gf['private'],'lat'=>$la,'lng'=>$ln];
}
function atp_fit($s,$max){ $s=trim($s); if(mb_strlen($s)<=$max) return $s; $t=preg_replace('/\s*TÜRSAB 18926\.?$/u','',$s); if(mb_strlen($t)<=$max) return $t; $t=mb_substr($t,0,$max-1); $p=mb_strrpos($t,' '); return rtrim(mb_substr($t,0,$p?:$max-1),' ,.;:–-').'…'; }
function atp_times_text($key,$lang){
 $s=atp_ld()['services'][$key]??[]; $air=$s['airport']??'AYT'; $parts=[];
 foreach(($s['times']??[]) as $dk){ $m=atp_metrics_for($air,$dk); if($m) $parts[]=atp_place($dk,$lang).' ~'.$m['min'].' '.atp_l('min',$lang).' ('.$m['km'].' '.atp_l('km',$lang).')'; }
 $t=atp_ld()['times'][$lang]??atp_ld()['times']['en'];
 return $parts?str_replace('{list}',implode(', ',$parts),$t[0]):$t[1];
}

function atp_price_phrase($price,$lang){ $p=atp_ld()['price'][$lang]??atp_ld()['price']['en']; return $price?str_replace('{price}',function_exists('deniz_money')?deniz_money($price):'€'.$price,$p[0]):$p[1]; }

/** Destination SEO is generated from live operational data, never from manual title/meta fields. */
function atp_airport_seo_label($air,$lang){
 $map=[
  'AYT'=>['tr'=>'Antalya','en'=>'Antalya','de'=>'Antalya','ru'=>'Анталья'],
  'GZP'=>['tr'=>'Gazipaşa','en'=>'Gazipaşa','de'=>'Gazipaşa','ru'=>'Газипаша']
 ];
 return $map[$air][$lang]??($map[$air]['en']??preg_replace('/\s+Airport.*$/iu','',atp_air_name($air,$lang)));
}
function atp_dynamic_destination_h1($ctx,$lang){
 $a=atp_airport_seo_label($ctx['air']??'AYT',$lang);$p=$ctx['p']??'';
 return $lang==='ru'?sprintf('%s – %s Трансфер',$a,$p):trim($a.' '.$p.' Transfer');
}
function atp_dynamic_destination_title($ctx,$lang){
 $a=atp_airport_seo_label($ctx['air']??'AYT',$lang);$p=$ctx['p']??'';
 $has_shuttle=array_key_exists('shared',$ctx)&&$ctx['shared']!==null;
 $has_private=array_key_exists('private',$ctx)&&$ctx['private']!==null;

 // Strong commercial titles without repeating the word “Transfer”.
 // Service suffix is driven by live availability, never hardcoded per destination.
 if($lang==='tr'){
  $base=sprintf('%s Havalimanı %s Transfer',$a,$p);
  $suffix=$has_shuttle&&$has_private?'Shuttle & Özel':($has_private?'Özel Transfer':($has_shuttle?'Shuttle':'Havalimanı Transferi'));
 } elseif($lang==='de'){
  $base=sprintf('%s Flughafen %s Transfer',$a,$p);
  $suffix=$has_shuttle&&$has_private?'Shuttle & Privat':($has_private?'Privattransfer':($has_shuttle?'Shuttle':'Flughafentransfer'));
 } elseif($lang==='ru'){
  $base=sprintf('%s Аэропорт – %s Трансфер',$a,$p);
  $suffix=$has_shuttle&&$has_private?'Шаттл и индивидуальный':($has_private?'Индивидуальный':($has_shuttle?'Шаттл':'Из аэропорта'));
 } else {
  $base=sprintf('%s Airport to %s Transfer',$a,$p);
  $suffix=$has_shuttle&&$has_private?'Private & Shuttle':($has_private?'Private':($has_shuttle?'Shared Shuttle':'Airport Transfer'));
 }
 $title=$base.' | '.$suffix;

 // Long destination names: keep the commercial route keyword, shorten only the suffix.
 if(mb_strlen($title)>65){
  $fallback=[
   'tr'=>sprintf('%s %s Transfer | Havalimanı',$a,$p),
   'en'=>sprintf('%s to %s Transfer | Airport',$a,$p),
   'de'=>sprintf('%s %s Transfer | Flughafen',$a,$p),
   'ru'=>sprintf('%s – %s Трансфер | Аэропорт',$a,$p)
  ];
  $title=$fallback[$lang]??$fallback['en'];
 }
 return deniz_seo_trim($title,65);
}
function atp_dynamic_destination_meta($ctx,$lang){
 $a=atp_airport_seo_label($ctx['air']??'AYT',$lang);$p=$ctx['p']??'';$km=$ctx['km']??null;$min=$ctx['min']??null;$s=$ctx['shared']??null;$v=$ctx['private']??null;
 $money=fn($x)=>function_exists('deniz_money')?deniz_money($x):('€'.number_format((float)$x,0));
 $route='';
 if($km&&$min){
  $route=[
   'tr'=>sprintf('%s Havalimanı’ndan %s’e transfer. %d km, yaklaşık %d dakika.',$a,$p,(int)$km,(int)$min),
   'en'=>sprintf('%s Airport to %s transfer. %d km, around %d minutes.',$a,$p,(int)$km,(int)$min),
   'de'=>sprintf('Transfer vom Flughafen %s nach %s. %d km, ca. %d Minuten.',$a,$p,(int)$km,(int)$min),
   'ru'=>sprintf('Трансфер из аэропорта %s в %s: %d км, около %d минут.',$a,$p,(int)$km,(int)$min)
  ][$lang]??'';
 } else {
  $route=[
   'tr'=>sprintf('%s Havalimanı’ndan %s’e transfer.',$a,$p),
   'en'=>sprintf('%s Airport to %s transfer.',$a,$p),
   'de'=>sprintf('Transfer vom Flughafen %s nach %s.',$a,$p),
   'ru'=>sprintf('Трансфер из аэропорта %s в %s.',$a,$p)
  ][$lang]??'';
 }
 if($s!==null&&$v!==null){
  $fare=[
   'tr'=>sprintf(' Shuttle %s’dan, özel transfer %s’dan. Sabit fiyat ve 7/24 destek.',$money($s),$money($v)),
   'en'=>sprintf(' Shuttle from %s per person, private transfer from %s per vehicle. Fixed fares and 24/7 support.',$money($s),$money($v)),
   'de'=>sprintf(' Shuttle ab %s pro Person, Privattransfer ab %s pro Fahrzeug. Feste Preise und 24/7 Support.',$money($s),$money($v)),
   'ru'=>sprintf(' Шаттл от %s с человека, индивидуальный трансфер от %s за автомобиль. Фиксированные цены, поддержка 24/7.',$money($s),$money($v))
  ][$lang]??'';
 } elseif($s!==null){
  $fare=[
   'tr'=>sprintf(' Paylaşımlı shuttle kişi başı %s’dan. Güncel araç ve transfer seçeneklerini görüntüleyin.',$money($s)),
   'en'=>sprintf(' Shared shuttle from %s per person. View current vehicles and transfer options.',$money($s)),
   'de'=>sprintf(' Sammelshuttle ab %s pro Person. Aktuelle Fahrzeuge und Transferoptionen ansehen.',$money($s)),
   'ru'=>sprintf(' Групповой шаттл от %s с человека. Смотрите актуальные автомобили и варианты трансфера.',$money($s))
  ][$lang]??'';
 } elseif($v!==null){
  $fare=[
   'tr'=>sprintf(' Özel transfer araç başı %s’dan. Sabit fiyat, uçuş takibi ve 7/24 destek.',$money($v)),
   'en'=>sprintf(' Private transfer from %s per vehicle. Fixed fares, flight tracking and 24/7 support.',$money($v)),
   'de'=>sprintf(' Privattransfer ab %s pro Fahrzeug. Feste Preise, Flugverfolgung und 24/7 Support.',$money($v)),
   'ru'=>sprintf(' Индивидуальный трансфер от %s за автомобиль. Фиксированная цена, отслеживание рейса и поддержка 24/7.',$money($v))
  ][$lang]??'';
 } else {
  $fare=[
   'tr'=>' Mesafe, tahmini yolculuk süresi, araç seçenekleri ve güncel transfer fiyatlarını görüntüleyin.',
   'en'=>' View distance, estimated journey time, vehicle options and current transfer prices.',
   'de'=>' Entfernung, geschätzte Fahrzeit, Fahrzeugoptionen und aktuelle Transferpreise ansehen.',
   'ru'=>' Смотрите расстояние, примерное время в пути, варианты автомобилей и актуальные цены.'
  ][$lang]??'';
 }
 return atp_fit(trim($route.$fare),160);
}
function atp_meta($key,$lang=null){
 $lang=$lang?:atp_lang(); $d=atp_ld(); static $cache=[]; if(isset($cache[$key.$lang])) return $cache[$key.$lang];
 if(isset($d['services'][$key])){ $s=$d['services'][$key][$lang];
  $body=[]; foreach($s[4] as $x) $body[]=$x==='{times}'?atp_times_text($key,$lang):atp_fill($x,[]);
  return $cache[$key.$lang]=['title'=>atp_fit(atp_fill($s[0],[]),70),'h1'=>atp_fill($s[1],[]),'desc'=>atp_fit(atp_fill($s[2],[]),160),'intro'=>atp_fill($s[3],[]),'body'=>$body,'sub'=>''];
 }
 $c=atp_ctx($key,$lang); $t=$d['dt'][$lang]; $has=$c['km']&&$c['min'];
 $v=['p'=>$c['p'],'km'=>$c['km'],'min'=>$c['min'],'pricephrase'=>atp_offer_phrase($c,$lang)];
 $title=atp_dynamic_destination_title($c,$lang);
 $h1=atp_dynamic_destination_h1($c,$lang);
 $desc=atp_dynamic_destination_meta($c,$lang);
 return $cache[$key.$lang]=['title'=>$title,'h1'=>$h1,'desc'=>$desc,'intro'=>atp_offer_intro($c,$lang),'sub'=>atp_fill($has?$t['sub']:$t['sub2'],$v),'body'=>[]];
}

/* ---------- FAQ engine (used on every public page) ---------- */
function atp_faq_intent($type,$question,$lang){
 $type=(string)$type;$q=mb_strtolower(wp_strip_all_tags((string)$question));
 $known=['distance','duration','price','booking_notice','luggage','meeting','payment','service_type'];
 if(in_array($type,$known,true))return $type;
 if(in_array($type,['km','d'],true))return 'distance';
 if($type==='min')return 'duration';
 if(in_array($type,['g1','g1b'],true))return 'meeting';
 // Backward compatibility for old FAQ JSON. Specific intents are checked before price.
 $tests=[
  'booking_notice'=>['tr'=>['ne kadar önceden'],'en'=>['how early should i book','how far in advance should i book'],'de'=>['wie früh sollte ich buchen'],'ru'=>['за сколько времени нужно бронировать']],
  'luggage'=>['tr'=>['ne kadar bagaj'],'en'=>['how much luggage'],'de'=>['wie viel gepäck'],'ru'=>['сколько багажа']],
  'payment'=>['tr'=>['nasıl öderim'],'en'=>['how do i pay','how can i pay'],'de'=>['wie bezahle ich'],'ru'=>['как оплатить']],
  'service_type'=>['tr'=>['özel mi, paylaşımlı mı'],'en'=>['private or shared'],'de'=>['privat oder ein sammeltransfer'],'ru'=>['индивидуальный или групповой']],
  'price'=>['tr'=>['transferi ne kadar?','transfer fiyatı ne kadar?'],'en'=>['how much is a transfer'],'de'=>['was kostet ein transfer'],'ru'=>['сколько стоит трансфер']]
 ];
 foreach($tests as $intent=>$langs)foreach(($langs[$lang]??[]) as $needle)if(mb_strpos($q,$needle)!==false)return $intent;
 return 'general';
}
function atp_faq_dynamic_answer($intent,$lang,$ctx,$vars,$fallback){
 $p=$ctx['p']??'';$air=$ctx['air']??'AYT';$airport=atp_air_name($air,$lang);$airport_gen=atp_air_name($air,$lang,'gen');
 switch($intent){
  case 'distance':
   if(empty($ctx['km']))return $fallback;
   $x=['tr'=>'%s, %s’na yaklaşık %d km uzaklıktadır.','en'=>'%s is approximately %d km from %s.','de'=>'%s liegt etwa %d km vom %s entfernt.','ru'=>'Расстояние от %s до %s составляет примерно %d км.'];
   return $lang==='tr'?sprintf($x['tr'],$p,$airport,(int)$ctx['km']):($lang==='ru'?sprintf($x['ru'],$airport_gen,$p,(int)$ctx['km']):sprintf($x[$lang]??$x['en'],$p,(int)$ctx['km'],$airport));
  case 'duration':
   if(empty($ctx['min']))return $fallback;
   $x=['tr'=>'%s’ndan %s’e transfer yaklaşık %d dakika sürer.','en'=>'The transfer from %s to %s takes around %d minutes.','de'=>'Der Transfer vom %s nach %s dauert ungefähr %d Minuten.','ru'=>'Трансфер из %s в %s занимает около %d минут.'];
   return sprintf($x[$lang]??$x['en'],$lang==='ru'?$airport_gen:$airport,$p,(int)$ctx['min']);
  case 'price':
   $offer=atp_offer_phrase($ctx,$lang);$s=$ctx['shared']??null;$v=$ctx['private']??null;
   if($s!==null&&$v!==null)$tail=['tr'=>' Shuttle fiyatı kişi başıdır; özel transfer fiyatı araç başıdır. Kesin toplam rezervasyon öncesinde gösterilir.','en'=>' Shuttle fares are per passenger; private transfer fares are per vehicle. Your exact total is shown before booking.','de'=>' Shuttlepreise gelten pro Person; Privattransferpreise pro Fahrzeug. Der genaue Gesamtpreis wird vor der Buchung angezeigt.','ru'=>' Цена шаттла указана за пассажира, индивидуального трансфера — за автомобиль. Итоговая сумма показывается до бронирования.'];
   elseif($s!==null)$tail=['tr'=>' Shuttle fiyatı kişi başıdır ve kesin toplam seçilen yolcu sayısına göre rezervasyon öncesinde gösterilir.','en'=>' The shuttle fare is per passenger and the exact total for your passenger count is shown before booking.','de'=>' Der Shuttlepreis gilt pro Person; der genaue Gesamtpreis für Ihre Personenzahl wird vor der Buchung angezeigt.','ru'=>' Цена шаттла указана за пассажира; итоговая сумма для выбранного числа пассажиров показывается до бронирования.'];
   elseif($v!==null)$tail=['tr'=>' Özel transfer fiyatı araç başıdır ve kesin toplam rezervasyon öncesinde gösterilir.','en'=>' The private-transfer fare is per vehicle and the exact total is shown before booking.','de'=>' Der Privattransferpreis gilt pro Fahrzeug; der genaue Gesamtpreis wird vor der Buchung angezeigt.','ru'=>' Цена индивидуального трансфера указана за автомобиль; итоговая сумма показывается до бронирования.'];
   else return $offer; // atp_offer_phrase() already says the fare is shown before booking
   return trim($offer.($tail[$lang]??$tail['en']));
  case 'booking_notice':
   $n=(int)($vars['notice']??8);$x=['tr'=>'Transferinizi en az %d saat önceden rezerve etmenizi öneririz.','en'=>'We recommend booking your transfer at least %d hours before pickup.','de'=>'Wir empfehlen, Ihren Transfer mindestens %d Stunden vor der Abholung zu buchen.','ru'=>'Рекомендуем бронировать трансфер минимум за %d часов до подачи автомобиля.'];return sprintf($x[$lang]??$x['en'],$n);
  case 'luggage':
   $x=['tr'=>'Bagaj kapasitesi seçtiğiniz araca göre değişir. Her araç kartında yolcu ve bagaj kapasitesi gösterilir; ekstra veya büyük bagajınızı rezervasyonda belirtin.','en'=>'Luggage capacity depends on the vehicle you choose. Each vehicle card shows passenger and luggage capacity; add oversized or extra luggage in your booking details.','de'=>'Die Gepäckkapazität hängt vom gewählten Fahrzeug ab. Auf jeder Fahrzeugkarte stehen Personen- und Gepäckkapazität; zusätzliches oder sperriges Gepäck bitte bei der Buchung angeben.','ru'=>'Допустимый багаж зависит от выбранного автомобиля. Вместимость по пассажирам и багажу указана в карточке автомобиля; дополнительный или крупный багаж укажите при бронировании.'];return $x[$lang]??$x['en'];
  case 'meeting':
   if($air==='AYT'){$x=['tr'=>'Sürücünüz Antalya Havalimanı’nda terminalinizin varış çıkışında isim tabelasıyla sizi karşılar ve bagajınızla araca kadar yardımcı olur.','en'=>'Your driver meets you at the arrivals exit of your Antalya Airport terminal with a name sign and helps you to the vehicle.','de'=>'Ihr Fahrer erwartet Sie am Ausgang der Ankunftshalle Ihres Terminals am Flughafen Antalya mit einem Namensschild und begleitet Sie zum Fahrzeug.','ru'=>'Водитель встретит вас у выхода из зоны прилёта вашего терминала аэропорта Антальи с табличкой с именем и поможет пройти к автомобилю.'];return $x[$lang]??$x['en'];}
   $x=['tr'=>'Sürücünüz %s varış çıkışında isim tabelasıyla sizi karşılar ve araca kadar yardımcı olur.','en'=>'Your driver meets you at the arrivals exit of %s with a name sign and helps you to the vehicle.','de'=>'Ihr Fahrer erwartet Sie am Ankunftsausgang des %s mit einem Namensschild und begleitet Sie zum Fahrzeug.','ru'=>'Водитель встретит вас у выхода из зоны прилёта %s с табличкой с именем и поможет пройти к автомобилю.'];return sprintf($x[$lang]??$x['en'],$airport);
  case 'payment':
   $x=['tr'=>'Rezervasyonda onaylanan toplam tutarı transfer günü sürücünüze nakit ödeyebilirsiniz.','en'=>'You can pay the confirmed booking total in cash directly to your driver on the transfer day.','de'=>'Den bestätigten Gesamtbetrag können Sie am Transfertag direkt beim Fahrer bar bezahlen.','ru'=>'Подтверждённую итоговую сумму можно оплатить наличными водителю в день трансфера.'];return $x[$lang]??$x['en'];
  case 'service_type':
   $s=$ctx['shared']??null;$v=$ctx['private']??null;
   if($s!==null&&$v!==null){$x=['tr'=>'Bu rotada hem paylaşımlı shuttle hem özel transfer seçeneği bulunur. Shuttle diğer yolcularla paylaşılır ve kişi başı; özel transfer yalnızca sizin grubunuza ayrılır ve araç başı fiyatlanır.','en'=>'This route offers both shared shuttle and private transfer options. The shuttle is shared and priced per passenger; a private transfer is reserved for your party and priced per vehicle.','de'=>'Auf dieser Strecke gibt es Sammelshuttle und Privattransfer. Der Shuttle wird geteilt und pro Person berechnet; der Privattransfer ist nur für Ihre Gruppe und wird pro Fahrzeug berechnet.','ru'=>'На маршруте доступны групповой шаттл и индивидуальный трансфер. Шаттл общий и оплачивается за пассажира; индивидуальный трансфер только для вашей группы и оплачивается за автомобиль.'];return $x[$lang]??$x['en'];}
   if($s!==null){$x=['tr'=>'Bu rotada paylaşımlı shuttle hizmeti bulunur ve ücret kişi başı hesaplanır.','en'=>'A shared shuttle service is available on this route and is priced per passenger.','de'=>'Auf dieser Strecke ist ein Sammelshuttle verfügbar; der Preis gilt pro Person.','ru'=>'На этом маршруте доступен групповой шаттл с оплатой за пассажира.'];return $x[$lang]??$x['en'];}
   if($v!==null){$x=['tr'=>'Bu rotada özel transfer hizmeti bulunur. Araç yalnızca sizin grubunuza ayrılır ve fiyat araç başıdır.','en'=>'A private transfer is available on this route. The vehicle is reserved for your party and the fare is per vehicle.','de'=>'Auf dieser Strecke ist ein Privattransfer verfügbar. Das Fahrzeug ist nur für Ihre Gruppe reserviert; der Preis gilt pro Fahrzeug.','ru'=>'На маршруте доступен индивидуальный трансфер. Автомобиль только для вашей группы, цена указана за автомобиль.'];return $x[$lang]??$x['en'];}
   return $fallback;
 }
 return $fallback;
}
function atp_faq_items($lang,$ctx){
 $pool=atp_ld()['faq'][$lang]??atp_ld()['faq']['en']; $air=$ctx['air']??'AYT';
 $vars=['p'=>$ctx['p'],'km'=>$ctx['km']??'','min'=>$ctx['min']??'','airport'=>atp_air_name($air,$lang),'airport_gen'=>atp_air_name($air,$lang,'gen'),'airport_pre'=>atp_air_name($air,$lang,'pre'),
  'pricephrase'=>atp_offer_phrase($ctx,$lang),'ret'=>atp_ret_text($ctx['min']??null,$lang),
  'cancel'=>function_exists('deniz_cancel_hours')?deniz_cancel_hours():24,'notice'=>function_exists('deniz_min_notice_hours')?deniz_min_notice_hours():8];
 $out=[];
 foreach($pool as $row){ [$type,$q,$a]=$row;$intent=atp_faq_intent($type,$q,$lang);
  if(($ctx['shared']??null)===null&&($intent==='service_type'||atp_mentions_shared_service($q)))continue;
  if($intent==='distance'&&empty($ctx['km'])) continue;
  if($intent==='duration'&&empty($ctx['min'])) continue;
  if($type==='g1'&&$air!=='AYT') continue;
  if($type==='g1b'&&$air==='AYT') continue;
  $fq=atp_fill($q,$vars);$fallback=atp_fill($a,$vars);$fa=atp_faq_dynamic_answer($intent,$lang,$ctx,$vars,$fallback);
  $fa=atp_available_service_text($fa,$ctx);if(trim($fa)==='')continue;
  $out[]=['q'=>$fq,'a'=>$fa,'intent'=>$intent];
 }
 return $out;
}
function atp_faq_context(){
 $lang=atp_lang(); $gf=atp_global_fares('AYT'); $generic=['p'=>$lang==='ru'?'Анталья':'Antalya','air'=>'AYT','price'=>atp_min_fare($gf),'shared'=>$gf['shared'],'private'=>$gf['private']];
 if($l=atp_landing_current()) return atp_ctx($l['key'],$lang);
 if(function_exists('twt_is_hotels_page')&&twt_is_hotels_page()&&function_exists('twt_hotel_entity')&&($h=twt_hotel_entity())){ $r=function_exists('deniz_db_region')?deniz_db_region($h->region_id):null; $a=atp_ayt(); $m=($a&&$r&&function_exists('twt_route_metrics'))?twt_route_metrics($a,$r,$h):[]; $pr=($a&&function_exists('deniz_region_from_price'))?deniz_region_from_price((int)$h->region_id,(int)$a->id):null; $hf=($a&&$r)?atp_fares_for_region_id((int)$r->id,(int)$a->id):['shared'=>null,'private'=>null]; return ['p'=>twt_entity_name($h,'hotel'),'air'=>'AYT','km'=>!empty($m['distance'])?(int)round($m['distance']):null,'min'=>!empty($m['duration'])?(int)$m['duration']:null,'price'=>$pr?(float)$pr:null,'shared'=>$hf['shared'],'private'=>$hf['private']]; }
 if(is_singular('transfer-route')&&function_exists('deniz_route_context')){ $c=deniz_route_context(); if($c&&($c['h']||$c['r'])){ $rid=$c['h']?(int)$c['h']->region_id:(int)$c['r']->id; $ay=atp_ayt(); $aid=$c['a']?(int)$c['a']->id:($ay?(int)$ay->id:0); $rf=atp_fares_for_region_id($rid,$aid); return ['p'=>$c['h']?twt_entity_name($c['h'],'hotel'):twt_entity_name($c['r'],'region'),'air'=>'AYT','shared'=>$rf['shared'],'private'=>$rf['private']]; } }
 if(is_singular('location')&&function_exists('deniz_region_by_slug')){ $r=deniz_region_by_slug(get_post_field('post_name',get_queried_object_id())); if($r){ $ay=atp_ayt(); $rf=atp_fares_for_region_id((int)$r->id,$ay?(int)$ay->id:0); return ['p'=>twt_entity_name($r,'region'),'air'=>'AYT','shared'=>$rf['shared'],'private'=>$rf['private']]; } }
 return $generic;
}
/** Merge page-specific FAQs with the contextual pool; always ≥13 unique questions. */
function atp_faq_merge($custom=[]){
 $items=[];$seen=[];
 foreach(array_merge((array)$custom,atp_faq_items(atp_lang(),atp_faq_context())) as $f){
  if(empty($f['q'])||empty($f['a'])) continue; $k=mb_strtolower(trim(wp_strip_all_tags($f['q'])));
  if(isset($seen[$k])) continue; $seen[$k]=1; $items[]=$f;
 }
 return $items;
}
function atp_faq_schema($items){
 if(!empty($GLOBALS['atp_faq_schema_done'])||(function_exists('twt_seo_plugin_active')&&twt_seo_plugin_active())) return;
 $GLOBALS['atp_faq_schema_done']=1; $m=[];
 foreach($items as $f)$m[]=['@type'=>'Question','name'=>wp_strip_all_tags($f['q']),'acceptedAnswer'=>['@type'=>'Answer','text'=>wp_strip_all_tags($f['a'])]];
 deniz_schema_json(['@context'=>'https://schema.org','@type'=>'FAQPage','inLanguage'=>atp_lang(),'mainEntity'=>$m]);
}
function atp_faq_html($items,$heading,$id='faq'){
 echo '<div class="faq knowledge-faq atp-faq" id="'.esc_attr($id).'"><h2>'.esc_html($heading).'</h2>';
 foreach($items as $i=>$f) echo '<details'.($i===0?' open':'').'><summary>'.esc_html(wp_strip_all_tags($f['q'])).'</summary><p>'.wp_kses_post($f['a']).'</p></details>';
 echo '</div>';
 atp_faq_schema($items);
}
/** Stand-alone FAQ section for generic templates (pages, posts, archives). */
function atp_faq_section($custom=[]){
 if(function_exists('twt_seo_private_page')&&twt_seo_private_page()) return;
 echo '<section class="section atp-faq-section"><div class="wrap atp-reading">';
 atp_faq_html(atp_faq_merge($custom),atp_l('faq_h_gen'));
 echo '</div></section>';
}

/* ---------- Head: title, description, canonical, schema ---------- */
add_filter('pre_get_document_title',function($t){ $l=atp_landing_current(); return $l?atp_meta($l['key'])['title']:$t; },120);
foreach(['wpseo_title','rank_math/frontend/title','aioseo_title'] as $f) add_filter($f,function($v){$l=atp_landing_current();return $l?atp_meta($l['key'])['title']:$v;},120);
foreach(['wpseo_metadesc','rank_math/frontend/description','aioseo_description'] as $f) add_filter($f,function($v){$l=atp_landing_current();return $l?atp_meta($l['key'])['desc']:$v;},120);
foreach(['wpseo_canonical','rank_math/frontend/canonical','aioseo_canonical_url'] as $f) add_filter($f,function($v){$l=atp_landing_current();return $l?atp_landing_url($l['key']):$v;},120);
add_action('wp_head',function(){
 $l=atp_landing_current(); if(!$l||(function_exists('twt_seo_plugin_active')&&twt_seo_plugin_active())) return;
 echo '<link rel="canonical" href="'.esc_url(atp_landing_url($l['key'])).'">'."\n";
},3);
add_action('wp_head',function(){
 $l=atp_landing_current(); if(!$l||twt_seo_plugin_active()) return; $key=$l['key']; $lang=$l['lang'];
 $m=atp_meta($key,$lang); $c=atp_ctx($key,$lang); $url=atp_landing_url($key,$lang); $org=home_url('/#organization');
 $crumbs=[['@type'=>'ListItem','position'=>1,'name'=>atp_l('home'),'item'=>deniz_url('',$lang)]];
 if($key!=='hub') $crumbs[]=['@type'=>'ListItem','position'=>2,'name'=>atp_meta('hub',$lang)['h1'],'item'=>atp_landing_url('hub',$lang)];
 $crumbs[]=['@type'=>'ListItem','position'=>count($crumbs)+1,'name'=>$m['h1'],'item'=>$url];
 deniz_schema_json(['@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>$crumbs]);
 deniz_schema_json(['@context'=>'https://schema.org','@type'=>'WebPage','@id'=>$url.'#webpage','url'=>$url,'name'=>$m['title'],'description'=>$m['desc'],'inLanguage'=>$lang,'isPartOf'=>['@id'=>home_url('/#website')],'about'=>['@id'=>$org],'primaryImageOfPage'=>atp_img('og-default.jpg'),'dateModified'=>gmdate('c',filemtime(get_template_directory().'/inc/seo-landings.json')),'speakable'=>['@type'=>'SpeakableSpecification','cssSelector'=>['.atp-hero h1','.atp-quick p']]]);
 $air=$c['air']==='GZP'?['@type'=>'Airport','name'=>'Gazipaşa-Alanya Airport','iataCode'=>'GZP','geo'=>['@type'=>'GeoCoordinates','latitude'=>36.2992,'longitude'=>32.3006]]:['@type'=>'Airport','name'=>'Antalya Airport','iataCode'=>'AYT','geo'=>['@type'=>'GeoCoordinates','latitude'=>36.8987,'longitude'=>30.8005]];
 $category='Airport transfer';if(atp_is_dest($key)){if(($c['shared']??null)!==null&&($c['private']??null)!==null)$category='Airport transfer: shared shuttle and private transfer';elseif(($c['shared']??null)!==null)$category='Shared airport shuttle';elseif(($c['private']??null)!==null)$category='Private airport transfer';}
 $service=['@context'=>'https://schema.org','@type'=>'Service','@id'=>$url.'#service','name'=>$m['h1'],'description'=>$m['desc'],'serviceType'=>'Airport transfer','category'=>$category,'provider'=>['@id'=>$org],'url'=>$url,'inLanguage'=>$lang,'availableChannel'=>['@type'=>'ServiceChannel','serviceUrl'=>$url,'servicePhone'=>['@type'=>'ContactPoint','telephone'=>atp_contact()['phone'],'contactType'=>'reservations']],'areaServed'=>[$air]];
 if(atp_is_dest($key)) $service['areaServed'][]=['@type'=>'Place','name'=>$c['p'].', Antalya, Türkiye','geo'=>['@type'=>'GeoCoordinates','latitude'=>$c['lat'],'longitude'=>$c['lng']]];
 else $service['areaServed'][]=['@type'=>'AdministrativeArea','name'=>'Antalya, Türkiye'];
 if(atp_is_dest($key)){
  $offers=[];
  if(($c['shared']??null)!==null)$offers[]=['@type'=>'Offer','name'=>'Shared shuttle','price'=>deniz_convert_price($c['shared']),'priceCurrency'=>deniz_current_currency(),'url'=>$url,'priceSpecification'=>['@type'=>'UnitPriceSpecification','price'=>deniz_convert_price($c['shared']),'priceCurrency'=>deniz_current_currency(),'referenceQuantity'=>['@type'=>'QuantitativeValue','value'=>1,'unitText'=>'person']]];
  if(($c['private']??null)!==null)$offers[]=['@type'=>'Offer','name'=>'Private transfer','price'=>deniz_convert_price($c['private']),'priceCurrency'=>deniz_current_currency(),'url'=>$url,'priceSpecification'=>['@type'=>'UnitPriceSpecification','price'=>deniz_convert_price($c['private']),'priceCurrency'=>deniz_current_currency(),'referenceQuantity'=>['@type'=>'QuantitativeValue','value'=>1,'unitText'=>'vehicle']]];
  if($offers)$service['offers']=$offers;
 }
 deniz_schema_json($service);
 if(atp_is_dest($key)) deniz_schema_json(['@context'=>'https://schema.org','@type'=>['TouristDestination','Place'],'name'=>$c['p'],'description'=>atp_ld()['dest'][$key]['about'][$lang]??'','geo'=>['@type'=>'GeoCoordinates','latitude'=>$c['lat'],'longitude'=>$c['lng']],'containedInPlace'=>['@type'=>'AdministrativeArea','name'=>'Antalya, Türkiye'],'hasMap'=>'https://www.google.com/maps/search/?api=1&query='.$c['lat'].','.$c['lng']]);
 if($key==='hub'||$key==='airport'){ $items=[];$i=1; foreach(atp_dest_keys() as $dk) $items[]=['@type'=>'ListItem','position'=>$i++,'name'=>atp_meta($dk,$lang)['h1'],'url'=>atp_landing_url($dk,$lang)]; deniz_schema_json(['@context'=>'https://schema.org','@type'=>'ItemList','name'=>atp_l('all_dest_h',$lang),'itemListElement'=>$items]); }
},25);

/* ---------- Rendering helpers used by template-seo-landing.php ---------- */
function atp_dest_sorted_by($key){
 $all=atp_ld()['dest']; if(!isset($all[$key])) return array_keys($all);
 $o=$all[$key]; $keys=array_keys($all); $keys=array_values(array_filter($keys,fn($k)=>$k!==$key));
 usort($keys,function($a,$b)use($all,$o){ $da=($all[$a]['lat']-$o['lat'])**2+($all[$a]['lng']-$o['lng'])**2; $db=($all[$b]['lat']-$o['lat'])**2+($all[$b]['lng']-$o['lng'])**2; return $da<=>$db; });
 return $keys;
}
function atp_dest_table($lang){
 echo '<div class="atp-table-wrap"><table class="atp-table"><thead><tr><th>'.esc_html(atp_l('t_dest',$lang)).'</th><th>'.esc_html(atp_l('t_km',$lang)).'</th><th>'.esc_html(atp_l('t_min',$lang)).'</th><th>'.esc_html(atp_l('from_price',$lang)).'</th></tr></thead><tbody>';
 $rows=[]; foreach(atp_dest_keys() as $k){ $m=atp_metrics($k); $x=atp_ld()['dest'][$k]; [$la,$ln]=atp_airport_coords('AYT'); $rows[]=['k'=>$k,'m'=>$m,'sort'=>$m?$m['km']:1000+sqrt(($x['lat']-$la)**2+($x['lng']-$ln)**2)]; }
 usort($rows,fn($a,$b)=>$a['sort']<=>$b['sort']);
 foreach($rows as $r){ $k=$r['k'];$m=$r['m'];$p=atp_from_price($k);
  echo '<tr><th scope="row"><a href="'.esc_url(atp_landing_url($k,$lang)).'">'.esc_html(atp_meta($k,$lang)['h1']).'</a></th><td>'.($m?(int)$m['km'].' '.esc_html(atp_l('km',$lang)):'—').'</td><td>'.($m?'~'.(int)$m['min'].' '.esc_html(atp_l('min',$lang)):'—').'</td><td>'.($p?esc_html(deniz_money($p)):'<a class="atp-link" href="'.esc_url(atp_landing_url($k,$lang)).'">'.esc_html(atp_l('check_price',$lang)).' →</a>').'</td></tr>'; }
 echo '</tbody></table></div>';
}

function atp_link_cards($keys,$lang){
 echo '<div class="atp-cards">';
 foreach($keys as $k){ $m=atp_meta($k,$lang); $x=atp_is_dest($k)?atp_metrics($k):null;
  echo '<a class="atp-card" href="'.esc_url(atp_landing_url($k,$lang)).'"><b>'.esc_html($m['h1']).'</b>'.($x?'<small>'.(int)$x['km'].' '.esc_html(atp_l('km',$lang)).' · ~'.(int)$x['min'].' '.esc_html(atp_l('min',$lang)).'</small>':'<small>'.esc_html(wp_trim_words($m['intro'],12)).'</small>').'<span aria-hidden="true">→</span></a>'; }
 echo '</div>';
}
function atp_contact_block($lang){
 $c=atp_contact();
 echo '<div class="atp-contact" itemscope itemtype="https://schema.org/TravelAgency"><meta itemprop="name" content="'.esc_attr(twt_brand_name()).'"><h2>'.esc_html(atp_l('contact_h',$lang)).'</h2><p>'.esc_html(atp_l('contact_text',$lang)).'</p><ul>';
 echo '<li><b>'.esc_html(atp_l('phone',$lang)).'</b> <a itemprop="telephone" href="'.esc_url(atp_phone_link()).'">'.esc_html($c['phone_display']).'</a></li>';
 echo '<li><b>WhatsApp</b> <a href="'.esc_url(atp_whatsapp_link()).'" target="_blank" rel="noopener nofollow">'.esc_html($c['phone_display']).'</a></li>';
 echo '<li><b>'.esc_html(atp_l('address',$lang)).'</b> <span itemprop="address">'.esc_html($c['address']).'</span> · <a href="'.esc_url($c['map']).'" target="_blank" rel="noopener">'.esc_html(atp_l('map',$lang)).'</a></li>';
 echo '<li><b>'.esc_html(atp_l('licence',$lang)).'</b> '.esc_html($c['tursab']).' · <a href="'.esc_url($c['tursab_url']).'" target="_blank" rel="noopener">'.esc_html(atp_l('verify',$lang)).'</a></li>';
 echo '</ul></div>';
}

/* ---------- Landing sitemap (with hreflang alternates), robots.txt, llms.txt ---------- */
add_action('template_redirect',function(){
 $s=get_query_var('atp_sitemap'); if(!$s) return;
 if($s==='redirect'){ wp_safe_redirect(home_url('/sitemap.xml'),301); exit; }
 status_header(200); header('Content-Type: application/xml; charset=UTF-8'); header('X-Robots-Tag: noindex, follow');
 $mod=gmdate('c',filemtime(get_template_directory().'/inc/seo-landings.json'));
 echo '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">'."\n";
 $langs=['tr','en','de','ru'];
 $pages=array_merge([''],atp_page_keys());
 foreach($pages as $key){ foreach($langs as $lang){
  $loc=$key===''?deniz_url('',$lang):atp_landing_url($key,$lang);
  echo '<url><loc>'.esc_url($loc).'</loc><lastmod>'.$mod.'</lastmod><changefreq>weekly</changefreq><priority>'.($key===''?'1.0':(in_array($key,['hub','airport','hotel'],true)?'0.9':'0.8')).'</priority>';
  foreach($langs as $alt){ $h=$key===''?deniz_url('',$alt):atp_landing_url($key,$alt); echo '<xhtml:link rel="alternate" hreflang="'.$alt.'" href="'.esc_url($h).'"/>'; }
  echo '<xhtml:link rel="alternate" hreflang="x-default" href="'.esc_url($key===''?deniz_url('','en'):atp_landing_url($key,'en')).'"/></url>'."\n";
 }}
 echo '</urlset>'; exit;
},0);
add_filter('robots_txt',function($text,$public){
 if(!$public) return $text;
 $h=home_url('/');
 $r="User-agent: *\nUser-agent: GPTBot\nUser-agent: OAI-SearchBot\nUser-agent: ChatGPT-User\nUser-agent: PerplexityBot\nUser-agent: ClaudeBot\nUser-agent: Google-Extended\nAllow: /\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nDisallow: /wp-login.php\nDisallow: /?s=\nDisallow: /*?s=\nDisallow: /search/\nDisallow: /*/transfer-search/\nDisallow: /transfer-search/\nDisallow: /*/passenger-details/\nDisallow: /passenger-details/\nDisallow: /*/booking-confirmation/\nDisallow: /booking-confirmation/\nDisallow: /*?*hotel_q=\nDisallow: /*?*ref=\nDisallow: /*?*twt_knowledge=\n\n";
 $r.='Sitemap: '.$h."sitemap.xml\n# LLM summary: ".$h."llms.txt\n";
 return $r;
},99,2);
function atp_llms_txt(){
 $c=atp_contact(); $o="# ".twt_brand_name()."\n\n> ".twt_brand_name()." (".twt_brand_domain().") is a TÜRSAB-licensed travel agency (licence no. {$c['tursab']}) in Aksu, Antalya, Türkiye, providing private, VIP, group and (on selected routes) shared shuttle airport transfers from Antalya Airport (AYT) and Gazipaşa-Alanya Airport (GZP) to hotels across the Antalya region. Languages: Turkish, English, German, Russian.\n\n";
 $o.="## Contact\n- Phone / WhatsApp: {$c['phone_display']}\n- Address: {$c['address']}\n- TÜRSAB licence: {$c['tursab']} ({$c['tursab_url']})\n\n## Key facts\n- Shared shuttle is available on routes where it is configured and is priced per person; private transfer is priced per vehicle. Both fare types are shown clearly before booking\n- Meet & greet with name sign in the arrivals hall, flight tracking\n- Payment in cash to the driver; free cancellation up to ".(function_exists('deniz_cancel_hours')?deniz_cancel_hours():24)." hours before pickup\n- 24/7 service\n\n";
 foreach(['en'=>'English','tr'=>'Türkçe','de'=>'Deutsch','ru'=>'Русский'] as $lang=>$name){
  $o.="## Transfer pages ($name)\n- ".atp_meta('hub',$lang)['h1'].': '.atp_landing_url('hub',$lang)."\n";
  foreach(atp_page_keys() as $k){ if($k==='hub')continue; $o.='- '.atp_meta($k,$lang)['h1'].': '.atp_landing_url($k,$lang)."\n"; }
  $o.="\n";
 }
 $o.="## Other sources\n- Hotels: ".deniz_url('hotels','en')."\n- Fleet: ".deniz_url('vehicles','en')."\n- Sitemap: ".home_url('/sitemap.xml')."\n";
 return $o;
}

add_filter('wp_robots',function($r){ if(is_404()){ $r['noindex']=true; unset($r['index']); } return $r; },50);


/* ---------- Admin: SEO landing overview, live distances and overrides ---------- */
add_action('admin_menu',function(){ add_submenu_page('deniz-os','SEO Sayfaları','SEO Sayfaları','manage_options','atp-seo-landings','atp_admin_landings'); },30);
function atp_admin_landings(){
 if(!current_user_can('manage_options')) return;
 if(isset($_POST['atp_save_price_regions'])&&check_admin_referer('atp_price_regions')){
  $map=[];
  foreach(atp_dest_keys() as $key){
   $region_id=absint($_POST['price_region'][$key]??0);
   if($region_id) $map[$key]=$region_id;
  }
  update_option('atp_destination_price_regions',$map,false);
  echo '<div class="notice notice-success"><p>Destination fiyat bölgesi eşleştirmeleri kaydedildi.</p></div>';
 }
 if(isset($_POST['atp_save_metrics'])&&check_admin_referer('atp_metrics')){
  $o=[]; foreach((array)($_POST['ov']??[]) as $k=>$v){ $k=sanitize_text_field($k); $km=(float)($v['km']??0); $min=(int)($v['min']??0); if($km>0&&$min>0) $o[$k]=['km'=>$km,'min'=>$min]; }
  update_option('atp_metrics_override',$o,false); echo '<div class="notice notice-success"><p>Kaydedildi.</p></div>';
 }
 if(isset($_POST['atp_refresh'])&&check_admin_referer('atp_metrics')){ @set_time_limit(180); $n=atp_metrics_warm(60); echo '<div class="notice notice-success"><p>'.(int)$n.' rota yeniden hesaplandı (OSRM yol verisi).</p></div>'; }
 $o=atp_metrics_overrides(); $src=['manual'=>'Manuel','route'=>'Rota matrisi','osrm'=>'OSRM yol hesabı'];
 echo '<div class="wrap"><h1>SEO Sayfaları · Mesafe &amp; Süre</h1><p>Mesafe ve süreler otomatik hesaplanır: önce fiyat matrisindeki havalimanı + bölge rotası, yoksa sayfa koordinatları üzerinden OSRM yol rotası (30 gün önbellek). Gerekirse manuel değer girebilirsiniz; boş bırakılırsa otomatik değer kullanılır. Değer yoksa sayfada rakam gösterilmez.</p>';
 echo '<form method="post">'; wp_nonce_field('atp_metrics');
 echo '<p><button class="button button-secondary" name="atp_refresh" value="1">Eksik mesafeleri şimdi hesapla</button></p><table class="widefat striped"><thead><tr><th>Sayfa</th><th>Rota</th><th>Otomatik</th><th>Kaynak</th><th>Manuel km</th><th>Manuel dk</th><th>Fiyat (matris)</th><th>Diller</th></tr></thead><tbody>';
 $pairs=[]; foreach(atp_dest_keys() as $k) $pairs[]=['AYT',$k,$k]; foreach((atp_ld()['services']['gazipasa']['times']??[]) as $k) $pairs[]=['GZP',$k,'gazipasa'];
 foreach($pairs as [$air,$k,$page]){ $id=$air.':'.$k; $saved=$o[$id]??null; $auto=atp_metrics_for($air,$k,false,false); $p=$air==='AYT'?atp_from_price($k):null; $links=''; foreach(['tr','en','de','ru'] as $l) $links.='<a href="'.esc_url(atp_landing_url($page,$l)).'" target="_blank">'.strtoupper($l).'</a> ';
  echo '<tr><td><b>'.esc_html(atp_meta($page,'tr')['h1']).'</b></td><td>'.esc_html($air.' → '.atp_place($k,'tr')).'</td><td>'.($auto?esc_html($auto['km'].' km · '.$auto['min'].' dk'):'<em>hesaplanıyor / yok</em>').'</td><td>'.esc_html($saved?'Manuel':($auto?$src[$auto['source']]:'—')).'</td><td><input type="number" step="0.1" min="0" name="ov['.esc_attr($id).'][km]" value="'.esc_attr($saved['km']??'').'" style="width:80px"></td><td><input type="number" min="0" name="ov['.esc_attr($id).'][min]" value="'.esc_attr($saved['min']??'').'" style="width:80px"></td><td>'.($p?esc_html(deniz_money($p)):'—').'</td><td>'.$links.'</td></tr>'; }
 echo '</tbody></table><p><button class="button button-primary" name="atp_save_metrics" value="1">Manuel değerleri kaydet</button></p></form>';

 // Destination -> Price Matrix region mapping. Kept separate from distance/route data on purpose.
 $price_map=atp_price_region_map(); $regions=atp_pricing_regions();
 echo '<hr style="margin:28px 0"><h2>Destination → Fiyat Bölgesi Eşleştirmesi</h2>';
 echo '<p>Her SEO destination sayfasının fiyatı, <strong>Fiyat Matrisi</strong> içindeki hangi bölgeden alacağını seçin. <strong>Otomatik eşleştirme</strong> seçiliyse sistem destination adı/slug ile bölgeyi bulmaya devam eder. Bu ayar yalnızca fiyat kaynağını değiştirir; destination adı, SEO içeriği ve mesafe/süre verisini değiştirmez.</p>';
 echo '<form method="post">'; wp_nonce_field('atp_price_regions');
 echo '<table class="widefat striped"><thead><tr><th style="width:34%">Destination</th><th style="width:20%">Otomatik bölge</th><th style="width:30%">Fiyat alınacak bölge</th><th>Canlı başlangıç fiyatı</th></tr></thead><tbody>';
 foreach(atp_dest_keys() as $key){
  $auto=atp_db_region($key); $selected=absint($price_map[$key]??0); $fare=atp_from_price($key);
  echo '<tr><td><strong>'.esc_html(atp_place($key,'tr')).'</strong><br><code>'.esc_html($key).'</code></td>';
  echo '<td>'.($auto?esc_html($auto->name):'<span style="color:#b32d2e">Eşleşme yok</span>').'</td>';
  echo '<td><select name="price_region['.esc_attr($key).']" style="min-width:280px;max-width:100%">';
  echo '<option value="0">— Otomatik eşleştirme —</option>';
  foreach($regions as $region){
   $label=trim(($region->city_name??'')?($region->city_name.' → '.$region->name):$region->name);
   echo '<option value="'.(int)$region->id.'" '.selected($selected,(int)$region->id,false).'>'.esc_html($label).'</option>';
  }
  echo '</select></td><td>'.($fare?esc_html(deniz_money($fare)):'—').'</td></tr>';
 }
 echo '</tbody></table><p><button class="button button-primary" name="atp_save_price_regions" value="1">Fiyat bölgesi eşleştirmelerini kaydet</button></p></form>';

 echo '<h2>Teknik SEO</h2><ul><li><a href="'.esc_url(home_url('/sitemap.xml')).'" target="_blank">sitemap.xml</a> (GSC\'ye bunu gönderin) · <a href="'.esc_url(admin_url('tools.php?page=twt-sitemap-pro')).'">Sitemap Pro</a></li><li><a href="'.esc_url(home_url('/robots.txt')).'" target="_blank">robots.txt</a></li><li><a href="'.esc_url(home_url('/llms.txt')).'" target="_blank">llms.txt</a></li></ul></div>';
}
add_action('after_switch_theme',function(){ wp_schedule_single_event(time()+30,'atp_metrics_cron'); });

function atp_dest_for_region($region){
 if(!$region) return null; $cands=[sanitize_title($region->slug??''),sanitize_title(remove_accents($region->name??''))];
 foreach(atp_ld()['dest'] as $k=>$x){ foreach($cands as $c){ if($c&&($c===$k||$c===sanitize_title(remove_accents($x['name']))||strpos($c,$k)===0)) return $k; } }
 return null;
}
