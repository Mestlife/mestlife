<?php
if (!defined('ABSPATH')) exit;

/** v19 professional operating rules */
function deniz_pro_setting($key,$default=''){
 $opts=get_option('deniz_transfer_settings',[]);
 return isset($opts[$key]) && $opts[$key]!=='' ? $opts[$key] : $default;
}
function deniz_min_notice_hours(){ return max(0,(int)deniz_pro_setting('min_notice_hours',8)); }
function deniz_cancel_hours(){ return max(0,(int)deniz_pro_setting('free_cancel_hours',24)); }
function deniz_support_email(){ return sanitize_email(deniz_pro_setting('support_email',get_option('admin_email'))); }
function deniz_support_phone(){ return sanitize_text_field(deniz_pro_setting('support_phone','')); }
function deniz_whatsapp_number(){ return preg_replace('/[^0-9+]/','',deniz_pro_setting('whatsapp_number','')); }
function deniz_company_name(){ return sanitize_text_field(deniz_pro_setting('company_name',get_bloginfo('name')?:'Antalya Transfer Pro')); }

function deniz_pickup_timestamp($date,$time){
 if(!$date||!$time) return 0;
 $dt=DateTimeImmutable::createFromFormat('!Y-m-d H:i',$date.' '.$time,wp_timezone());$errors=DateTimeImmutable::getLastErrors();if(!$dt||($errors&&($errors['warning_count']||$errors['error_count']))||$dt->format('Y-m-d H:i')!==$date.' '.$time)return 0;return $dt->getTimestamp();
}
function deniz_pickup_is_valid($date,$time){
 $ts=deniz_pickup_timestamp($date,$time); if(!$ts)return false;
 return $ts >= time() + deniz_min_notice_hours()*HOUR_IN_SECONDS;
}
function deniz_vehicle_date_blocked($vehicle,$date){
 if(!$vehicle||!$date)return false;
 $rows=preg_split('/\r\n|\r|\n/',(string)($vehicle->unavailable_dates??''));
 $rows=array_filter(array_map('trim',$rows));
 return in_array($date,$rows,true);
}

/* Booking/search pages should never compete with landing pages in search. */
add_filter('wp_robots',function($robots){
 if(is_page_template('template-transfer-search.php')||is_page_template('template-passenger-details.php')||is_page_template('template-booking-confirmation.php')){
  $robots['noindex']=true; $robots['nofollow']=false;
 }
 return $robots;
});

/* Ensure a real How It Works page exists. */
function deniz_ensure_pro_pages(){
 $p=get_page_by_path('how-it-works');
 if(!$p){
  $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'How It Works','post_name'=>'how-it-works']);
  if($id&&!is_wp_error($id)) update_post_meta($id,'_wp_page_template','template-how-it-works.php');
 } elseif(get_post_meta($p->ID,'_wp_page_template',true)!=='template-how-it-works.php'){
  update_post_meta($p->ID,'_wp_page_template','template-how-it-works.php');
 }
}
add_action('after_switch_theme','deniz_ensure_pro_pages',30);
add_action('init','deniz_ensure_pro_pages',40);

/* Professional admin settings inside Transfer OS. */
add_action('admin_menu',function(){
 add_submenu_page('deniz-os','Sistem Ayarları','Sistem Ayarları','manage_options','deniz-pro-settings','deniz_pro_settings_page');
},40);
function deniz_pro_settings_page(){
 if(isset($_POST['deniz_save_pro_settings']) && check_admin_referer('deniz_pro_settings')){
  $old=get_option('deniz_transfer_settings',[]);
  $fields=['company_name','support_email','support_phone','whatsapp_number','min_notice_hours','free_cancel_hours','intl_wait_start','domestic_wait_start','total_wait_minutes','cash_payment_text','company_address'];
  foreach($fields as $f){$v=wp_unslash($_POST[$f]??'');$old[$f]=in_array($f,['support_email'])?sanitize_email($v):sanitize_text_field($v);}
  update_option('deniz_transfer_settings',$old,false);
  echo '<div class="notice notice-success"><p>Ayarlar kaydedildi.</p></div>';
 }
 deniz_admin_shell_start('Sistem Ayarları','Rezervasyon kuralları, müşteri iletişimi ve operasyon metinlerini tek yerden yönetin.');
 echo '<form method="post" class="dos-panel">';wp_nonce_field('deniz_pro_settings');
 $fields=[
  ['company_name','Firma adı',deniz_company_name(),'text'],['support_email','Destek e-posta',deniz_support_email(),'email'],['support_phone','Destek telefonu',deniz_support_phone(),'text'],['whatsapp_number','WhatsApp numarası',deniz_whatsapp_number(),'text'],
  ['min_notice_hours','Minimum rezervasyon süresi (saat)',deniz_min_notice_hours(),'number'],['free_cancel_hours','Ücretsiz iptal süresi (saat)',deniz_cancel_hours(),'number'],['intl_wait_start','Dış hat bekleme başlangıcı (dk)',deniz_pro_setting('intl_wait_start',30),'number'],['domestic_wait_start','İç hat bekleme başlangıcı (dk)',deniz_pro_setting('domestic_wait_start',15),'number'],['total_wait_minutes','Toplam ücretsiz bekleme (dk)',deniz_pro_setting('total_wait_minutes',45),'number'],['company_address','Firma adresi',deniz_pro_setting('company_address','Antalya, Türkiye'),'text'],['cash_payment_text','Nakit ödeme açıklaması',deniz_pro_setting('cash_payment_text','Pay the confirmed total directly to your driver on transfer day.'),'text']
 ];
 echo '<div class="dos-2">'; foreach($fields as $i=>$f){echo '<label>'.esc_html($f[1]).'<input type="'.esc_attr($f[3]).'" name="'.esc_attr($f[0]).'" value="'.esc_attr($f[2]).'"></label>'; if($i===3||$i===7)echo '</div><div class="dos-2">';} echo '</div><button class="dos-btn" name="deniz_save_pro_settings">Ayarları Kaydet</button></form>';deniz_admin_shell_end();
}


add_action('admin_menu',function(){
 add_submenu_page('deniz-os','Sistem Kontrolü','Sistem Kontrolü','manage_options','deniz-system-health','deniz_system_health_page');
},41);
function deniz_system_health_page(){
 global $wpdb;$t=deniz_tables();
 $checks=[];
 $checks[]=['Aktif havalimanı',(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['airports']} WHERE active=1")>0,'En az bir aktif havalimanı gerekli.'];
 $checks[]=['Aktif bölge',(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['regions']} WHERE active=1")>0,'En az bir polygon bölgesi gerekli.'];
 $checks[]=['Aktif araç',count(deniz_active_fleet_rows())>0,'Araçlar panelinden en az bir aktif araç ekleyin.'];
 $checks[]=['Aktif fiyat',(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['prices']} WHERE active=1 AND one_way>0")>0,'Fiyat Matrisinden rota fiyatı girin.'];
 $checks[]=['Otel verisi',(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['hotels']} WHERE active=1")>0,'Hotel Manager ile otel ekleyin veya import edin.'];
 $checks[]=['Booking sayfaları',get_page_by_path('transfer-search')&&get_page_by_path('passenger-details')&&get_page_by_path('booking-confirmation'),'Rezervasyon sayfaları otomatik oluşturulmalıdır.'];
 $checks[]=['Destek e-posta',is_email(deniz_support_email()),'Müşteri ve operasyon e-postaları için geçerli adres girin.'];
 $checks[]=['PHP cURL',function_exists('curl_init'),'OSM/Photon/Nominatim çağrıları için cURL önerilir.'];
 deniz_admin_shell_start('Sistem Kontrolü','Rezervasyon motorunun yayın için temel gereksinimlerini tek ekranda kontrol edin.');
 echo '<div class="dos-panel"><table class="dos-table"><thead><tr><th>Kontrol</th><th>Durum</th><th>Not</th></tr></thead><tbody>';foreach($checks as $c)echo '<tr><td><b>'.esc_html($c[0]).'</b></td><td><span class="dos-badge">'.($c[1]?'HAZIR':'EKSİK').'</span></td><td>'.esc_html($c[1]?'Hazır':$c[2]).'</td></tr>';echo '</tbody></table></div>';deniz_admin_shell_end();
}

/* Email receipt helper */
/* Booking admin update + export */
add_action('admin_init',function(){
 if(!current_user_can('manage_options'))return;
 if(isset($_POST['deniz_booking_status_save']) && check_admin_referer('deniz_booking_status')){
  global $wpdb;$t=deniz_tables(); $id=absint($_POST['booking_id']??0); $status=sanitize_key($_POST['status']??'new');
  $allowed=['new','confirmed','assigned','completed','cancelled']; if(in_array($status,$allowed,true)&&$id)$wpdb->update($t['bookings'],['status'=>$status],['id'=>$id]);
  wp_safe_redirect(admin_url('admin.php?page=deniz-bookings&updated=1'));exit;
 }
 if(isset($_GET['deniz_export_bookings']) && wp_verify_nonce($_GET['_wpnonce']??'','deniz_export_bookings')){
  global $wpdb;$t=deniz_tables();$rows=$wpdb->get_results("SELECT b.*,v.name vehicle,r.name region,h.name hotel FROM {$t['bookings']} b LEFT JOIN {$t['vehicles']} v ON v.id=b.vehicle_id LEFT JOIN {$t['regions']} r ON r.id=b.region_id LEFT JOIN {$t['hotels']} h ON h.id=b.hotel_id ORDER BY b.id DESC",ARRAY_A);
  nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=deniz-bookings-'.gmdate('Y-m-d').'.csv');$o=fopen('php://output','w');fputcsv($o,['Reference','Status','Pickup date','Pickup time','Passenger','Phone','Email','Pickup','Destination','Region','Hotel','Vehicle','Passengers','Bags','Flight','Total','Currency','Extras','Payment']);foreach($rows as $r){$ex=$wpdb->get_results($wpdb->prepare("SELECT be.qty,be.total_price,e.name FROM {$t['booking_extras']} be LEFT JOIN {$t['extras']} e ON e.id=be.extra_id WHERE be.booking_id=%d",$r['id']));$extra_text=implode(' | ',array_map(function($x){return $x->name.' × '.$x->qty.' · '.$x->total_price;},$ex));$csv_row=[$r['booking_ref'],$r['status'],$r['pickup_date'],$r['pickup_time'],trim($r['first_name'].' '.$r['last_name']),$r['phone'],$r['email'],$r['pickup_label'],$r['dropoff_label'],$r['region'],$r['hotel'],$r['vehicle'],$r['passengers'],$r['bags'],$r['flight_number'],$r['total_amount'],$r['currency'],$extra_text,$r['payment_method']];fputcsv($o,array_map(function($v){return preg_match('/^[=+@\-\t\r]/',(string)$v)?"'".$v:$v;},$csv_row));}fclose($o);exit;
 }
});
