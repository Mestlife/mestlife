<?php
if (!defined('ABSPATH')) exit;

function deniz_languages(){
  return [
    'tr'=>['name'=>'Türkçe','short'=>'TR','locale'=>'tr_TR'],
    'en'=>['name'=>'English','short'=>'EN','locale'=>'en_US'],
    'de'=>['name'=>'Deutsch','short'=>'DE','locale'=>'de_DE'],
    'ru'=>['name'=>'Русский','short'=>'RU','locale'=>'ru_RU'],
  ];
}
function deniz_current_lang(){
  static $lang=null; if($lang!==null) return $lang;
  $langs=deniz_languages();
  $candidate=get_query_var('deniz_lang');
  if(!$candidate && isset($_POST['lang'])) $candidate=sanitize_key($_POST['lang']);
  if(!$candidate && isset($_GET['lang'])) $candidate=sanitize_key($_GET['lang']);
  if(!$candidate && isset($_COOKIE['deniz_lang'])) $candidate=sanitize_key($_COOKIE['deniz_lang']);
  $lang=isset($langs[$candidate])?$candidate:'tr';
  return $lang;
}
function deniz_t($key,$fallback=''){
  static $strings=[
   'tr'=>[
    'home'=>'Anasayfa','destinations'=>'Destinasyonlar','locations'=>'Bölgeler','vehicles'=>'Araçlarımız','blog'=>'Blog','book'=>'Rezervasyon Yap','airport_transfer'=>'Havalimanı Transferi','hotel_transfer'=>'Otel Transferi','intercity'=>'Şehirlerarası','hourly'=>'Saatlik Kiralama','from'=>'Nereden?','to'=>'Nereye?','from_ph'=>'Havalimanı, otel veya adres','to_ph'=>'Otel, şehir veya bölge','date'=>'Tarih','time'=>'Saat','passenger'=>'Yolcu','passengers'=>'Yolcu','search'=>'Transfer Ara','free_cancel'=>'Ücretsiz İptal','fixed_price'=>'Sabit Fiyat','support'=>'7/24 Destek','pro_driver'=>'Profesyonel Sürücü','popular_areas'=>'En Popüler Bölgeler','popular_dest'=>'Popüler Destinasyonlar','door_to_door'=>'Tatil bölgelerine özel, kapıdan kapıya transfer.','view_all'=>'Tümünü Gör','services'=>'Transfer Hizmetlerimiz','solutions'=>'Her İhtiyaca Uygun Transfer Çözümleri','safe_desc'=>'Konforlu, özel araç ve profesyonel sürücü ile güvenli ulaşım.','popular_routes'=>'Popüler Transfer Rotaları','top_routes'=>'En Çok Tercih Edilen Rotalar','all_routes'=>'Tüm Rotalar','our_vehicles'=>'Araçlarımız','fleet'=>'Konforlu ve Modern Araç Filomuz','all_vehicles'=>'Tüm Araçlar','why'=>'Neden Bizi Tercih Etmelisiniz?','travel_blog'=>'Seyahat Rehberi ve İpuçları','all_posts'=>'Tüm Yazılar','transfer_details'=>'Transfer Detayları','vehicle_selection'=>'Araç Seçimi','passenger_details'=>'Yolcu Bilgileri','payment'=>'Ödeme','confirmation'=>'Onay','transfer_info'=>'Transfer Bilgileri','available_vehicles'=>'Uygun Araçlarımız','calculating'=>'Fiyatlar hesaplanıyor…','total_price'=>'Toplam fiyat','select_vehicle'=>'Bu Aracı Seç','bags'=>'Bagaj','zone_found'=>'fiyat bölgesi bulundu.','zone_missing'=>'Bu konum için henüz fiyat bölgesi tanımlanmamış.','price_missing'=>'Bölge bulundu fakat bu bölge için araç fiyatı girilmemiş.','service_error'=>'Fiyat servisine ulaşılamadı.','approx'=>'yaklaşık','minutes'=>'dk','start_holiday'=>'Tatiliniz Havaalanında Başlar','hero_desc'=>'Antalya Transfer Pro ile havalimanından otelinize konforlu, güvenli ve zamanında özel transfer.','transfer'=>'Transfer','overview'=>'Genel Bakış','transfer_regions'=>'Transfer Bölgeleri','transfer_prices'=>'Transfer Fiyatları','travel_guide'=>'Gezi Rehberi','faq'=>'Sık Sorulan Sorular','airport_distance'=>'Havalimanına uzaklık','avg_duration'=>'Ortalama süre','transfer_service'=>'Transfer hizmeti','starting_price'=>'Başlangıç fiyatı','destination_guide'=>'Destinasyon Rehberi','travel_info'=>'Transfer ve Seyahat Bilgileri','local_guide'=>'Yerel Rehber','quick_booking'=>'Hızlı Rezervasyon','book_desc'=>'Sabit fiyatlı özel transferinizi dakikalar içinde ayırın.','trust_points'=>'Güven Unsurları','flight_tracking'=>'Uçuş takibi','all_dest_desc'=>'Türkiye’nin öne çıkan tatil bölgeleri, havalimanları ve özel transfer seçenekleri.','all_loc_desc'=>'Havalimanı transfer fiyatlarının tanımlandığı tatil bölgeleri ve lokasyonlar.','all_route_desc'=>'Havalimanları ile oteller ve tatil bölgeleri arasındaki özel transfer rotaları.','all_vehicle_desc'=>'Yolcu ve bagaj ihtiyacınıza uygun özel transfer araç seçenekleri.','blog_desc'=>'Destinasyonlar, havalimanları, oteller ve transfer planlaması için seyahat odaklı içerikler.'
   ],
   'en'=>[
    'home'=>'Home','destinations'=>'Destinations','locations'=>'Locations','vehicles'=>'Vehicles','blog'=>'Blog','book'=>'Book Now','airport_transfer'=>'Airport Transfer','hotel_transfer'=>'Hotel Transfer','intercity'=>'Intercity Transfer','hourly'=>'Hourly Chauffeur','from'=>'Pickup','to'=>'Drop-off','from_ph'=>'Airport, hotel or address','to_ph'=>'Hotel, city or area','date'=>'Date','time'=>'Time','passenger'=>'Passenger','passengers'=>'Passengers','search'=>'Search Transfer','free_cancel'=>'Free Cancellation','fixed_price'=>'Fixed Price','support'=>'24/7 Support','pro_driver'=>'Professional Driver','popular_areas'=>'Most Popular Areas','popular_dest'=>'Popular Destinations','door_to_door'=>'Private door-to-door transfers to Turkey’s most popular holiday areas.','view_all'=>'View All','services'=>'Transfer Services','solutions'=>'Transfer Solutions for Every Journey','safe_desc'=>'Comfortable private vehicles and professional drivers for a reliable journey.','popular_routes'=>'Popular Transfer Routes','top_routes'=>'Most Booked Routes','all_routes'=>'All Routes','our_vehicles'=>'Our Vehicles','fleet'=>'Comfortable & Modern Fleet','all_vehicles'=>'All Vehicles','why'=>'Why Choose Antalya Transfer Pro?','travel_blog'=>'Travel Guides & Tips','all_posts'=>'All Articles','transfer_details'=>'Transfer Details','vehicle_selection'=>'Vehicle Selection','passenger_details'=>'Passenger Details','payment'=>'Payment','confirmation'=>'Confirmation','transfer_info'=>'Transfer Information','available_vehicles'=>'Available Vehicles','calculating'=>'Calculating prices…','total_price'=>'Total price','select_vehicle'=>'Select Vehicle','bags'=>'Bags','zone_found'=>'pricing zone found.','zone_missing'=>'No pricing zone has been defined for this location yet.','price_missing'=>'The zone was found, but vehicle prices have not been entered.','service_error'=>'The pricing service could not be reached.','approx'=>'approx.','minutes'=>'min','start_holiday'=>'Your Holiday Starts at the Airport','hero_desc'=>'Private airport transfers to your hotel with comfort, reliability and on-time service.','transfer'=>'Transfer','overview'=>'Overview','transfer_regions'=>'Transfer Areas','transfer_prices'=>'Transfer Prices','travel_guide'=>'Travel Guide','faq'=>'Frequently Asked Questions','airport_distance'=>'Distance from airport','avg_duration'=>'Average duration','transfer_service'=>'Transfer service','starting_price'=>'Starting price','destination_guide'=>'Destination Guide','travel_info'=>'Transfer & Travel Information','local_guide'=>'Local Guide','quick_booking'=>'Quick Booking','book_desc'=>'Book your fixed-price private transfer in minutes.','trust_points'=>'Why travellers book with us','flight_tracking'=>'Flight tracking','all_dest_desc'=>'Holiday destinations, airports and private transfer options across Turkey.','all_loc_desc'=>'Resort areas and locations connected to airport transfer pricing zones.','all_route_desc'=>'Private transfer routes between airports, hotels and holiday areas.','all_vehicle_desc'=>'Private transfer vehicles for different passenger and luggage requirements.','blog_desc'=>'Travel-focused guides for destinations, airports, hotels and transfer planning.'
   ],
   'de'=>[
    'home'=>'Startseite','destinations'=>'Reiseziele','locations'=>'Regionen','vehicles'=>'Fahrzeuge','blog'=>'Blog','book'=>'Jetzt buchen','airport_transfer'=>'Flughafentransfer','hotel_transfer'=>'Hoteltransfer','intercity'=>'Städtetransfer','hourly'=>'Stundenweise Fahrt','from'=>'Abholung','to'=>'Ziel','from_ph'=>'Flughafen, Hotel oder Adresse','to_ph'=>'Hotel, Stadt oder Region','date'=>'Datum','time'=>'Uhrzeit','passenger'=>'Fahrgast','passengers'=>'Fahrgäste','search'=>'Transfer suchen','free_cancel'=>'Kostenlose Stornierung','fixed_price'=>'Festpreis','support'=>'24/7 Support','pro_driver'=>'Professioneller Fahrer','popular_areas'=>'Beliebte Regionen','popular_dest'=>'Beliebte Reiseziele','door_to_door'=>'Private Tür-zu-Tür-Transfers in die beliebtesten Urlaubsregionen.','view_all'=>'Alle anzeigen','services'=>'Transferleistungen','solutions'=>'Transferlösungen für jede Reise','safe_desc'=>'Komfortable Privatfahrzeuge und professionelle Fahrer für eine sichere Fahrt.','popular_routes'=>'Beliebte Transferrouten','top_routes'=>'Meistgebuchte Routen','all_routes'=>'Alle Routen','our_vehicles'=>'Unsere Fahrzeuge','fleet'=>'Komfortable & moderne Fahrzeugflotte','all_vehicles'=>'Alle Fahrzeuge','why'=>'Warum Antalya Transfer Pro?','travel_blog'=>'Reiseführer & Tipps','all_posts'=>'Alle Beiträge','transfer_details'=>'Transferdetails','vehicle_selection'=>'Fahrzeugauswahl','passenger_details'=>'Fahrgastdaten','payment'=>'Zahlung','confirmation'=>'Bestätigung','transfer_info'=>'Transferinformationen','available_vehicles'=>'Verfügbare Fahrzeuge','calculating'=>'Preise werden berechnet…','total_price'=>'Gesamtpreis','select_vehicle'=>'Fahrzeug wählen','bags'=>'Gepäck','zone_found'=>'Preiszone gefunden.','zone_missing'=>'Für diesen Ort ist noch keine Preiszone definiert.','price_missing'=>'Die Zone wurde gefunden, aber es wurden keine Fahrzeugpreise hinterlegt.','service_error'=>'Der Preisdienst ist nicht erreichbar.','approx'=>'ca.','minutes'=>'Min.','start_holiday'=>'Ihr Urlaub beginnt am Flughafen','hero_desc'=>'Komfortable, zuverlässige und pünktliche private Flughafentransfers zu Ihrem Hotel.','transfer'=>'Transfer','overview'=>'Übersicht','transfer_regions'=>'Transferregionen','transfer_prices'=>'Transferpreise','travel_guide'=>'Reiseführer','faq'=>'Häufig gestellte Fragen','airport_distance'=>'Entfernung zum Flughafen','avg_duration'=>'Durchschnittliche Dauer','transfer_service'=>'Transferservice','starting_price'=>'Preis ab','destination_guide'=>'Reiseziel-Guide','travel_info'=>'Transfer- & Reiseinformationen','local_guide'=>'Lokaler Reiseführer','quick_booking'=>'Schnellbuchung','book_desc'=>'Buchen Sie Ihren privaten Festpreis-Transfer in wenigen Minuten.','trust_points'=>'Ihre Vorteile','flight_tracking'=>'Flugverfolgung','all_dest_desc'=>'Urlaubsziele, Flughäfen und private Transfermöglichkeiten in der Türkei.','all_loc_desc'=>'Urlaubsregionen und Orte mit hinterlegten Flughafentransfer-Preiszonen.','all_route_desc'=>'Private Transferrouten zwischen Flughäfen, Hotels und Urlaubsregionen.','all_vehicle_desc'=>'Private Transferfahrzeuge für unterschiedliche Personen- und Gepäckanforderungen.','blog_desc'=>'Reiseinformationen zu Reisezielen, Flughäfen, Hotels und Transfers.'
   ],
   'ru'=>[
    'home'=>'Главная','destinations'=>'Направления','locations'=>'Регионы','vehicles'=>'Автомобили','blog'=>'Блог','book'=>'Забронировать','airport_transfer'=>'Трансфер из аэропорта','hotel_transfer'=>'Трансфер в отель','intercity'=>'Междугородний трансфер','hourly'=>'Почасовая аренда','from'=>'Откуда','to'=>'Куда','from_ph'=>'Аэропорт, отель или адрес','to_ph'=>'Отель, город или район','date'=>'Дата','time'=>'Время','passenger'=>'Пассажир','passengers'=>'Пассажиры','search'=>'Найти трансфер','free_cancel'=>'Бесплатная отмена','fixed_price'=>'Фиксированная цена','support'=>'Поддержка 24/7','pro_driver'=>'Профессиональный водитель','popular_areas'=>'Популярные районы','popular_dest'=>'Популярные направления','door_to_door'=>'Индивидуальные трансферы от двери до двери в популярные курортные районы.','view_all'=>'Смотреть все','services'=>'Услуги трансфера','solutions'=>'Трансферы для любой поездки','safe_desc'=>'Комфортные частные автомобили и профессиональные водители.','popular_routes'=>'Популярные маршруты','top_routes'=>'Самые популярные маршруты','all_routes'=>'Все маршруты','our_vehicles'=>'Наши автомобили','fleet'=>'Комфортный современный автопарк','all_vehicles'=>'Все автомобили','why'=>'Почему Antalya Transfer Pro?','travel_blog'=>'Путеводитель и советы','all_posts'=>'Все статьи','transfer_details'=>'Детали трансфера','vehicle_selection'=>'Выбор автомобиля','passenger_details'=>'Данные пассажира','payment'=>'Оплата','confirmation'=>'Подтверждение','transfer_info'=>'Информация о трансфере','available_vehicles'=>'Доступные автомобили','calculating'=>'Рассчитываем стоимость…','total_price'=>'Итоговая цена','select_vehicle'=>'Выбрать автомобиль','bags'=>'Багаж','zone_found'=>'тарифная зона найдена.','zone_missing'=>'Для этого места пока не настроена тарифная зона.','price_missing'=>'Зона найдена, но цены для автомобилей не указаны.','service_error'=>'Не удалось связаться с сервисом расчёта цены.','approx'=>'примерно','minutes'=>'мин','start_holiday'=>'Ваш отдых начинается в аэропорту','hero_desc'=>'Комфортный, надёжный и своевременный частный трансфер из аэропорта в отель.','transfer'=>'Трансфер','overview'=>'Обзор','transfer_regions'=>'Регионы трансфера','transfer_prices'=>'Цены на трансфер','travel_guide'=>'Путеводитель','faq'=>'Часто задаваемые вопросы','airport_distance'=>'Расстояние до аэропорта','avg_duration'=>'Среднее время','transfer_service'=>'Трансфер 24/7','starting_price'=>'Цена от','destination_guide'=>'Путеводитель по направлению','travel_info'=>'Информация о трансфере и поездке','local_guide'=>'Местный гид','quick_booking'=>'Быстрое бронирование','book_desc'=>'Забронируйте частный трансфер по фиксированной цене за несколько минут.','trust_points'=>'Преимущества','flight_tracking'=>'Отслеживание рейса','all_dest_desc'=>'Курортные направления, аэропорты и варианты частного трансфера по Турции.','all_loc_desc'=>'Курортные районы и локации с тарифными зонами аэропорт-трансфера.','all_route_desc'=>'Маршруты частного трансфера между аэропортами, отелями и курортами.','all_vehicle_desc'=>'Автомобили для частного трансфера с разной вместимостью пассажиров и багажа.','blog_desc'=>'Полезные материалы о направлениях, аэропортах, отелях и планировании трансфера.'
   ]
  ];
  $lang=deniz_current_lang();
  $ui=function_exists('twt_ui_default')?twt_ui_default($key,$lang):null;
  $base=$ui ?? $strings[$lang][$key] ?? $strings['tr'][$key] ?? ($fallback ?: $key);
  if(function_exists('deniz_translation_override')) return deniz_translation_override($key,$lang,$base);
  return $base;
}

add_filter('query_vars',function($vars){$vars[]='deniz_lang'; return $vars;});
add_action('init',function(){
 foreach(array_keys(deniz_languages()) as $lang){
  add_rewrite_rule('^'.$lang.'/?$','index.php?deniz_lang='.$lang,'top');
  add_rewrite_rule('^'.$lang.'/transfer-search/?$','index.php?pagename=transfer-search&deniz_lang='.$lang,'top');
  add_rewrite_rule('^'.$lang.'/blog/?$','index.php?post_type=post&deniz_lang='.$lang,'top');
  add_rewrite_rule('^'.$lang.'/blog/([^/]+)/?$','index.php?name=$matches[1]&deniz_lang='.$lang,'top');
  add_rewrite_rule('^'.$lang.'/(?!(?:blog|destinations|locations|transfers|vehicles|transfer-search)(?:/|$))([^/]+)/?$','index.php?pagename=$matches[1]&deniz_lang='.$lang,'top');
  $map=['destinations'=>'destination','locations'=>'location','transfers'=>'transfer-route','vehicles'=>'vehicle'];
  foreach($map as $slug=>$pt){
   add_rewrite_rule('^'.$lang.'/'.$slug.'/?$','index.php?post_type='.$pt.'&deniz_lang='.$lang,'top');
   add_rewrite_rule('^'.$lang.'/'.$slug.'/([^/]+)/?$','index.php?post_type='.$pt.'&name=$matches[1]&deniz_lang='.$lang,'top');
  }
 }
},20);

function deniz_url($path='',$lang=null){
 $lang=$lang?:deniz_current_lang(); $path=ltrim($path,'/');
 return home_url('/'.$lang.'/'.($path?$path.'/':''));
}

function deniz_current_request_relative_path(){
 $request_uri=$_SERVER['REQUEST_URI']??'/';
 $parts=wp_parse_url($request_uri);
 $request_path='/'.ltrim((string)($parts['path']??'/'),'/');
 $home_path=(string)(wp_parse_url(home_url('/'),PHP_URL_PATH)?:'/');
 $home_path='/'.trim($home_path,'/');
 if($home_path!=='/'){
  if($request_path===$home_path) $request_path='/';
  elseif(strpos($request_path,$home_path.'/')===0) $request_path=substr($request_path,strlen($home_path));
 }
 return '/'.ltrim($request_path,'/');
}
function deniz_same_page_lang_url($lang){
 if(is_singular('post')&&in_array($lang,array_keys(deniz_languages()),true)) return deniz_base_lang_url($lang);
 if(function_exists('atp_landing_current')&&atp_landing_current()&&in_array($lang,array_keys(deniz_languages()),true)) return atp_landing_url(atp_landing_current()['key'],$lang);
 $langs=array_keys(deniz_languages());
 $lang=in_array($lang,$langs,true)?$lang:'tr';
 $relative=deniz_current_request_relative_path();
 if(is_front_page() || deniz_is_language_home_request()) $relative='/';
 $segments=array_values(array_filter(explode('/',trim($relative,'/')),fn($x)=>$x!==''));
 if($segments && in_array($segments[0],$langs,true)) $segments[0]=$lang;
 else array_unshift($segments,$lang);
 $relative_path='/'.implode('/',$segments).'/';
 $url=home_url($relative_path);
 $parts=wp_parse_url($_SERVER['REQUEST_URI']??'/');
 $query=[];
 if(!empty($parts['query'])) parse_str($parts['query'],$query);
 unset($query['lang']);
 if(is_front_page() || deniz_is_language_home_request()) foreach(['p','page_id','pagename','name','post_type','paged'] as $key) unset($query[$key]);
 if($query) $url=add_query_arg($query,$url);
 return $url;
}

function deniz_base_lang_url($lang){
 if(function_exists('atp_landing_current')&&atp_landing_current()) return atp_landing_url(atp_landing_current()['key'],$lang);
 if(function_exists('atp_route_landing_key')&&($atp_k=atp_route_landing_key())) return atp_landing_url($atp_k,$lang); /* one URL per region */
 if(function_exists('twt_is_hotels_page')&&twt_is_hotels_page()&&!is_404())return twt_hotels_canonical($lang);
 if(is_front_page() || deniz_is_language_home_request()) return deniz_url('',$lang);
 if(is_singular()){
  $pt=get_post_type(); $slug=get_post_field('post_name',get_queried_object_id());
  if($pt==='post') return deniz_url('blog/'.(function_exists('twt_post_lang_slug')?twt_post_lang_slug(get_queried_object_id(),$lang):$slug),$lang);
  $maps=['destination'=>'destinations','location'=>'locations','transfer-route'=>'transfers','vehicle'=>'vehicles','airport-guide'=>'airports'];
  if(isset($maps[$pt])) return deniz_url($maps[$pt].'/'.$slug,$lang);
  if($pt==='page')return deniz_url(get_page_uri(get_queried_object_id()),$lang);
  if($pt==='airport-guide')return deniz_url('airports/'.$slug,$lang);
 }
 if(is_post_type_archive()){
  $maps=['destination'=>'destinations','location'=>'locations','transfer-route'=>'transfers','vehicle'=>'vehicles','airport-guide'=>'airports']; $pt=get_query_var('post_type');
  if(isset($maps[$pt])) return deniz_url($maps[$pt],$lang);
 }
 if(is_home()) return deniz_url('blog',$lang);
 return deniz_url('',$lang);
}

add_filter('post_type_link',function($url,$post){
 if(is_admin()) return $url; $map=['destination'=>'destinations','location'=>'locations','transfer-route'=>'transfers','vehicle'=>'vehicles','airport-guide'=>'airports'];
 if(isset($map[$post->post_type])) return deniz_url($map[$post->post_type].'/'.$post->post_name);
 return $url;
},20,2);
add_filter('post_link',function($url,$post){ if(is_admin()) return $url; return $post->post_type==='post'?deniz_url('blog/'.$post->post_name):$url;},20,2);
add_filter('post_type_archive_link',function($url,$pt){$map=['destination'=>'destinations','location'=>'locations','transfer-route'=>'transfers','vehicle'=>'vehicles','airport-guide'=>'airports'];return isset($map[$pt])?deniz_url($map[$pt]):$url;},20,2);
add_action('after_switch_theme',function(){flush_rewrite_rules();});

add_action('template_redirect',function(){
 if(isset($_GET['lang']) && isset(deniz_languages()[sanitize_key($_GET['lang'])])){
  setcookie('deniz_lang',sanitize_key($_GET['lang']),time()+31536000,COOKIEPATH?:'/');
 }
});
add_filter('language_attributes',function($output){return preg_replace('/lang="[^"]+"/','lang="'.esc_attr(deniz_current_lang()).'"',$output);});

function deniz_translated_meta($post_id,$key,$default=''){
 $lang=deniz_current_lang();
 if($lang==='tr') return get_post_meta($post_id,$key,true) ?: $default;
 $v=get_post_meta($post_id,'deniz_'.$lang.'_'.$key,true);
 return $v!==''?$v:(get_post_meta($post_id,$key,true) ?: $default);
}
function deniz_translated_title($post_id){
 $lang=deniz_current_lang(); if($lang==='tr') return get_the_title($post_id);
 return get_post_meta($post_id,'deniz_'.$lang.'_title',true) ?: get_the_title($post_id);
}
function deniz_translated_content($post_id){
 $lang=deniz_current_lang(); if($lang==='tr') return get_post_field('post_content',$post_id);
 return get_post_meta($post_id,'deniz_'.$lang.'_content',true) ?: get_post_field('post_content',$post_id);
}
function deniz_translated_excerpt($post_id){
 $lang=deniz_current_lang(); if($lang==='tr') return get_post_field('post_excerpt',$post_id);
 return get_post_meta($post_id,'deniz_'.$lang.'_excerpt',true) ?: get_post_field('post_excerpt',$post_id);
}
add_filter('the_title',function($title,$id){ if(is_admin()||!$id||deniz_current_lang()==='tr') return $title; return get_post_meta($id,'deniz_'.deniz_current_lang().'_title',true) ?: $title;},20,2);
add_filter('the_content',function($content){ if(is_admin()||deniz_current_lang()==='tr'||!is_singular()) return $content; $v=get_post_meta(get_the_ID(),'deniz_'.deniz_current_lang().'_content',true); return $v!==''?wpautop($v):$content;},20);
add_filter('get_the_excerpt',function($excerpt,$post){ if(is_admin()||deniz_current_lang()==='tr') return $excerpt; $v=get_post_meta($post->ID,'deniz_'.deniz_current_lang().'_excerpt',true); return $v!==''?$v:$excerpt;},20,2);

add_action('add_meta_boxes',function(){
 foreach(['page','destination','location','transfer-route','vehicle','airport-guide','post'] as $pt) add_meta_box('deniz_languages','Antalya Transfer Pro · EN / DE / RU İçerikleri','deniz_languages_meta_box',$pt,'normal','default');
});
function deniz_languages_meta_box($post){
 wp_nonce_field('deniz_i18n_save','deniz_i18n_nonce');
 foreach(['en'=>'English','de'=>'Deutsch','ru'=>'Русский'] as $lang=>$label){
  echo '<details style="margin:10px 0;border:1px solid #dcdcde;padding:12px;background:#fff"><summary><strong>'.esc_html($label).'</strong></summary>';
  $fields=['slug'=>'URL Slug (bu dile özel, ör. antalya-airport-transfer-guide)','title'=>'Başlık','excerpt'=>'Kısa Açıklama / Excerpt','seo_title'=>'SEO Title','seo_description'=>'Meta Description','hero_subtitle'=>'Hero Subtitle','faq_1_q'=>'FAQ 1 Question','faq_1_a'=>'FAQ 1 Answer','faq_2_q'=>'FAQ 2 Question','faq_2_a'=>'FAQ 2 Answer','content'=>'Ana İçerik'];
  foreach($fields as $key=>$name){$v=get_post_meta($post->ID,'deniz_'.$lang.'_'.$key,true);echo '<p><label><strong>'.esc_html($name).'</strong></label><br><textarea name="deniz_i18n['.$lang.']['.$key.']" style="width:100%;min-height:'.($key==='content'?'180':'48').'px">'.esc_textarea($v).'</textarea></p>';}
  echo '</details>';
 }
}
add_action('save_post',function($id){
 if(!isset($_POST['deniz_i18n_nonce'])||!wp_verify_nonce($_POST['deniz_i18n_nonce'],'deniz_i18n_save')||!current_user_can('edit_post',$id)) return;
 foreach((array)($_POST['deniz_i18n']??[]) as $lang=>$fields){ if(!isset(deniz_languages()[$lang])||$lang==='tr') continue; foreach((array)$fields as $key=>$value){$value=$key==='content'?wp_kses_post($value):sanitize_textarea_field($value);update_post_meta($id,'deniz_'.$lang.'_'.sanitize_key($key),$value);} }
});

add_action('wp_head',function(){
 if(twt_seo_plugin_active()||twt_seo_private_page()||is_404()||is_search())return;
 if(isset($_GET['hotel_q'])||isset($_GET['hotel_city'])||isset($_GET['hotel_region']))return;
 foreach(deniz_languages() as $lang=>$data) echo '<link rel="alternate" hreflang="'.$lang.'" href="'.esc_url(deniz_lang_url($lang)).'">'."\n";
 echo '<link rel="alternate" hreflang="x-default" href="'.esc_url(deniz_lang_url('en')).'">'."\n";
},2);

remove_action('wp_head','rel_canonical');
add_action('wp_head',function(){ if(!twt_seo_plugin_active()&&!twt_seo_private_page()&&!(function_exists('atp_landing_current')&&atp_landing_current())&&(is_front_page()||is_home()||is_singular()||is_post_type_archive())) echo '<link rel="canonical" href="'.esc_url(deniz_lang_url(deniz_current_lang())).'">'."\n"; },3);

/* Language roots always represent the homepage, never a post or posts index. */
function deniz_is_language_home_request(){
 $path=trim(deniz_current_request_relative_path(),'/');
 return $path==='' || isset(deniz_languages()[$path]);
}
add_action('pre_get_posts',function($query){
 if(is_admin() || !$query->is_main_query() || !deniz_is_language_home_request()) return;
 $front=(int)get_option('page_on_front');
 if(get_option('show_on_front')==='page' && $front){
  $query->set('p',0); $query->set('page_id',$front); $query->set('pagename',''); $query->set('name','');
  $query->set('post_type','page'); $query->is_page=true; $query->is_singular=true;
  $query->is_home=false; $query->is_posts_page=false;
 }
},20);
add_filter('template_include',function($template){
 if(!is_admin() && deniz_is_language_home_request()) return get_template_directory().'/front-page.php';
 return $template;
},99);
add_filter('redirect_canonical',function($redirect){return deniz_is_language_home_request()?false:$redirect;});
/* Existing installs need fresh rules once, even when the theme folder is unchanged. */
add_action('init',function(){
 if(get_option('twt_home_rewrite_version')==='22.0') return;
 flush_rewrite_rules(false); update_option('twt_home_rewrite_version','22.0',false);
},99);

function deniz_lang_url($lang){if(function_exists('twt_is_hotels_page')&&twt_is_hotels_page()&&!is_404())return twt_hotels_canonical($lang);$url=deniz_base_lang_url($lang);$paged=max(1,(int)get_query_var('paged'));if($paged>1&&(is_home()||is_post_type_archive()))$url=trailingslashit($url).'page/'.$paged.'/';if(is_singular()&&isset($_GET['hotels_page'])&&absint($_GET['hotels_page'])>1)$url=add_query_arg('hotels_page',absint($_GET['hotels_page']),$url);if(is_singular('destination')&&isset($_GET['regions_page'])&&absint($_GET['regions_page'])>1)$url=add_query_arg('regions_page',absint($_GET['regions_page']),$url);return $url;}
add_action('init',function(){foreach(array_keys(deniz_languages()) as $lang){foreach(['destinations'=>'destination','locations'=>'location','transfers'=>'transfer-route','vehicles'=>'vehicle','airports'=>'airport-guide','blog'=>'post'] as $slug=>$type)add_rewrite_rule('^'.$lang.'/'.$slug.'/page/([0-9]+)/?$','index.php?post_type='.$type.'&paged=$matches[1]&deniz_lang='.$lang,'top');}});
add_action('init',function(){if(get_option('twt_routes_version')!=='27'){flush_rewrite_rules(false);update_option('twt_routes_version','27',false);}},99);
