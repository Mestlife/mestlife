<?php
if(!defined('ABSPATH'))exit;
function twt_road_args($airport,$region,$hotel=null){
 if(!$airport||(!$region&&!$hotel))return null;
 $lat=$hotel?$hotel->lat:$region->center_lat;$lng=$hotel?$hotel->lng:$region->center_lng;
 $coords=[$airport->lat,$airport->lng,$lat,$lng];foreach($coords as $i=>$v)if(!is_numeric($v)||!is_finite((float)$v)||abs((float)$v)>($i%2?180:90))return null;
 if((float)$lat===0.0&&(float)$lng===0.0)return null;
 $coords=array_map(function($v){return sprintf('%.7F',(float)$v);},$coords);
 $coords[]=md5(implode('|',$coords));return $coords;
}
function twt_route_metrics($airport,$region,$hotel=null){
 $args=twt_road_args($airport,$region,$hotel);if(!$args)return [];
 $metrics=get_transient('twt_road_'.$args[4]);if($metrics!==false)return $metrics;
 if(!wp_next_scheduled('twt_fetch_road',$args))wp_schedule_single_event(time()+10,'twt_fetch_road',$args);return [];
}
function twt_fetch_road_worker($alat,$alng,$lat,$lng,$key){
 if(get_transient('twt_road_'.$key)!==false)return;
 // One global outgoing request at a time. Atomic option prevents concurrent visitors.
 $lock='twt_road_worker_lock';$expires=(int)get_option($lock,0);if($expires&&$expires<time())delete_option($lock);
 if(!add_option($lock,time()+12,'','no'))return;
 try{
 $base=apply_filters('twt_osrm_base_url','https://router.project-osrm.org');
 $url=rtrim($base,'/').'/route/v1/driving/'.sprintf('%.7F,%.7F;%.7F,%.7F',(float)$alng,(float)$alat,(float)$lng,(float)$lat).'?overview=false&steps=false';
 $response=wp_remote_get($url,['timeout'=>4,'redirection'=>1,'limit_response_size'=>65536]);$data=!is_wp_error($response)?json_decode(wp_remote_retrieve_body($response),true):null;$route=$data['routes'][0]??null;
 if(($data['code']??'')==='Ok'&&$route&&is_numeric($route['distance']??null)&&is_numeric($route['duration']??null)&&$route['distance']>0&&$route['duration']>0){$metrics=['distance'=>round($route['distance']/1000,1),'duration'=>(int)ceil($route['duration']/60),'source'=>'OSRM','updated'=>current_time('mysql')];set_transient('twt_road_'.$key,$metrics,30*DAY_IN_SECONDS);}else set_transient('twt_road_'.$key,[],HOUR_IN_SECONDS);
 }finally{delete_option($lock);}
}
add_action('twt_fetch_road','twt_fetch_road_worker',10,5);
function twt_route_metrics_ajax(){
 $id=absint($_GET['route_id']??0);if(get_post_type($id)!=='transfer-route'||get_post_status($id)!=='publish')wp_send_json_error([],404);
 $c=deniz_route_context($id);$region=$c['r']??null;if(!$region&&!empty($c['h']))$region=deniz_db_region($c['h']->region_id);
 if(empty($c['a'])||!$region||empty($c['a']->active)||empty($region->active))wp_send_json_error([],404);
 $args=twt_road_args($c['a'],$region,$c['h']);if(!$args)wp_send_json_success(['state'=>'unavailable']);
 $metrics=get_transient('twt_road_'.$args[4]);if($metrics===false){twt_fetch_road_worker(...$args);$metrics=get_transient('twt_road_'.$args[4]);}
 $distance=get_post_meta($id,'distance_km',true);$duration=get_post_meta($id,'duration_min',true);
 wp_send_json_success(['state'=>$metrics===false?'pending':($metrics?'ready':'unavailable'),'distance'=>is_numeric($distance)&&$distance>0?(float)$distance:($metrics['distance']??null),'duration'=>is_numeric($duration)&&$duration>0?(float)$duration:($metrics['duration']??null)]);
}
add_action('wp_ajax_twt_route_metrics','twt_route_metrics_ajax');add_action('wp_ajax_nopriv_twt_route_metrics','twt_route_metrics_ajax');
function twt_route_facts($id,$airport,$region,$hotel=null){
 $metrics=twt_route_metrics($airport,$region,$hotel);$distance=get_post_meta($id,'distance_km',true);$duration=get_post_meta($id,'duration_min',true);$rows=$region&&$airport?deniz_region_price_rows($region->id,$airport->id):[];$private=null;$shared=null;
 foreach($rows as $row){$type=atp_is_shared_service($row)?'shared':'private';if($$type===null||(float)$row->one_way<$$type)$$type=(float)$row->one_way;}
 return ['distance'=>is_numeric($distance)&&$distance>0?(float)$distance:($metrics['distance']??null),'duration'=>is_numeric($duration)&&$duration>0?(float)$duration:($metrics['duration']??null),'private'=>$private,'shared'=>$shared,'prices'=>$rows];
}
function twt_route_fact_cards($facts){
 $cards=[
  'distance'=>['label'=>deniz_t('distance'),'value'=>$facts['distance']??null,'unit'=>'distance'],
  'duration'=>['label'=>deniz_t('estimated_time'),'value'=>$facts['duration']??null,'unit'=>'duration'],
 ];
 // Keep shared and private fares separate. Both values come directly from the active route price matrix.
 if(array_key_exists('shared',$facts)&&$facts['shared']!==null)$cards['shared']=['label'=>deniz_t('shared_transfer').' · '.deniz_t('starting_price').' · '.deniz_t('per_person'),'value'=>$facts['shared'],'unit'=>'money'];
 if(array_key_exists('private',$facts)&&$facts['private']!==null)$cards['private']=['label'=>deniz_t('private_transfer').' · '.deniz_t('starting_price').' · '.deniz_t('per_vehicle'),'value'=>$facts['private'],'unit'=>'money'];
 echo '<div class="twt-route-facts">';
 foreach($cards as $key=>$card){$value=$card['value'];$text='—';if($value!==null){if($card['unit']==='distance')$text=number_format_i18n($value,1).' km';elseif($card['unit']==='duration')$text=number_format_i18n($value,0).' '.deniz_t('minutes');else $text=deniz_money($value);}echo '<div class="twt-route-fact twt-route-fact-'.esc_attr($key).'"><small>'.esc_html($card['label']).'</small><strong data-route-metric="'.esc_attr($key).'">'.esc_html($text).'</strong></div>';}
 echo '</div><p class="twt-route-estimate-note">'.esc_html(deniz_t('route_estimate_note')).'</p>';
}
function twt_route_search($airport,$region,$hotel=null){if(!$airport)return;$ayt=$airport;include get_template_directory().'/template-parts/route-search.php';}
function twt_route_comparison($id,$facts){
 // Compare vehicle fares only; a per-person shuttle fare is not a taxi baseline.
 $base=$facts['private']??null;if($base===null||$base<=0)return;
 echo '<section class="twt-comparison"><div class="eyebrow">'.esc_html(deniz_t('taxi_comparison_kicker')).'</div><h2>'.esc_html(deniz_t('taxi_comparison_title')).'</h2><p>'.esc_html(deniz_t('taxi_comparison_intro')).'</p><div class="twt-compare-grid">';
 echo '<article class="twt-compare-best"><small>Antalya Transfer Pro</small><h3>'.esc_html(deniz_t('private_transfer')).'</h3><strong>'.esc_html(deniz_t('starting_price').' '.deniz_money($base)).'</strong><span>'.esc_html(deniz_t('per_vehicle')).'</span><p>'.esc_html(deniz_t('private_comparison_desc')).'</p></article>';
 $min=(float)get_post_meta($id,'twt_taxi_min',true);$max=(float)get_post_meta($id,'twt_taxi_max',true);$currency=get_post_meta($id,'twt_taxi_currency',true);$source=get_post_meta($id,'twt_taxi_source',true);$date=get_post_meta($id,'twt_taxi_checked',true);$currencies=deniz_currencies();$valid=$min>0&&$max>=$min&&isset($currencies[$currency])&&$currencies[$currency]['rate']>0&&wp_http_validate_url($source)&&preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)&&strtotime($date)>=strtotime('-30 days',time())&&strtotime($date)<=time();
 $low=$valid?$min/$currencies[$currency]['rate']:$base+10;$high=$valid?$max/$currencies[$currency]['rate']:$base+15;
 echo '<article><small>'.esc_html(deniz_t($valid?'independent_provider':'taxi_model_label')).'</small><h3>'.esc_html(deniz_t('metered_taxi')).'</h3><strong>'.esc_html(deniz_t('approximate').' '.deniz_money($low).' – '.deniz_money($high)).'</strong><span>'.esc_html(deniz_t('per_vehicle')).'</span><p>'.esc_html(deniz_t('taxi_comparison_desc')).'</p>';
 if($valid)echo '<a target="_blank" rel="nofollow noopener noreferrer" href="'.esc_url($source).'">'.esc_html(deniz_t('information_source')).'</a><small>'.esc_html(deniz_t('updated').' '.$date).' · '.esc_html(deniz_t('estimated_fare')).'</small>';
 else echo '<small class="twt-taxi-model-note">'.esc_html(sprintf(deniz_t('taxi_model_note'),deniz_money(10),deniz_money(15))).'</small>';
 echo '</article></div></section>';
}
add_action('add_meta_boxes',function(){add_meta_box('twt-comparison','Taksi karşılaştırması — doğrulanmış rota verisi','twt_comparison_box','transfer-route','normal','default');});
function twt_comparison_box($post){wp_nonce_field('twt_comparison','twt_comparison_nonce');echo '<p>Güncel kaynaklı taksi aralığı girilirse o tutar gösterilir. Aksi halde özel transfer başlangıç fiyatının 10–15 EUR üstü, açıkça karşılaştırma tahmini olarak gösterilir; gerçek taksi tarifesi değildir.</p>';foreach(['twt_taxi_min'=>'Taksi alt tutar','twt_taxi_max'=>'Taksi üst tutar','twt_taxi_currency'=>'Para birimi (TRY/EUR/USD/GBP)','twt_taxi_source'=>'Tarife/kaynak URL','twt_taxi_checked'=>'Kontrol tarihi (YYYY-MM-DD)'] as $key=>$label)echo '<p><label>'.esc_html($label).'<input style="width:100%" name="'.esc_attr($key).'" value="'.esc_attr(get_post_meta($post->ID,$key,true)).'"></label></p>';}
add_action('save_post_transfer-route',function($id){if(!isset($_POST['twt_comparison_nonce'])||!wp_verify_nonce($_POST['twt_comparison_nonce'],'twt_comparison')||!current_user_can('edit_post',$id)||wp_is_post_revision($id))return;foreach(['twt_taxi_min','twt_taxi_max','twt_taxi_currency','twt_taxi_source','twt_taxi_checked'] as $key){$value=wp_unslash($_POST[$key]??'');update_post_meta($id,$key,$key==='twt_taxi_source'?esc_url_raw($value):sanitize_text_field($value));}});
/* Creation happens on data saves; reconciliation is bounded and runs in Cron. */
remove_action('init','deniz_sync_airport_guides',40);remove_action('init','deniz_sync_region_guides',41);remove_action('init','deniz_sync_city_guides_live',42);
function twt_sync_airport_page($id){global $wpdb;$t=deniz_tables();$airport=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d AND active=1",$id));if(!$airport)return;$existing=get_posts(['post_type'=>'airport-guide','post_status'=>'any','posts_per_page'=>1,'meta_key'=>'dynamic_airport_id','meta_value'=>$id]);$slug=sanitize_title(($airport->iata?:$airport->name).'-airport-transfer');$post=$existing[0]??get_page_by_path($slug,OBJECT,'airport-guide');$pid=$post?$post->ID:wp_insert_post(['post_type'=>'airport-guide','post_status'=>'publish','post_title'=>$airport->name.' Transfer','post_name'=>$slug]);if($pid&&!is_wp_error($pid)){update_post_meta($pid,'dynamic_airport_id',$id);update_post_meta($pid,'twt_auto_generated',1);}}
function twt_sync_priced_region($id){global $wpdb;$t=deniz_tables();$region=$wpdb->get_row($wpdb->prepare("SELECT r.* FROM {$t['regions']} r WHERE r.id=%d AND r.active=1 AND EXISTS(SELECT 1 FROM {$t['prices']} p JOIN {$t['vehicles']} v ON v.id=p.vehicle_id AND v.active=1 JOIN {$t['airports']} a ON a.id=p.airport_id AND a.active=1 WHERE p.region_id=r.id AND p.active=1 AND p.one_way>0)",$id));if(!$region)return;$existing=get_posts(['post_type'=>'location','post_status'=>'any','posts_per_page'=>1,'meta_key'=>'dynamic_region_id','meta_value'=>$id]);$post=$existing[0]??get_page_by_path($region->slug,OBJECT,'location');$pid=$post?$post->ID:wp_insert_post(['post_type'=>'location','post_status'=>'publish','post_title'=>$region->name,'post_name'=>$region->slug]);if($pid&&!is_wp_error($pid)){update_post_meta($pid,'dynamic_region_id',$id);update_post_meta($pid,'twt_auto_generated',1);}if($region->city_id)deniz_sync_city_destination($region->city_id);}
add_action('init',function(){if(get_option('twt_page_sync_version')!=='28'){if(!wp_next_scheduled('twt_reconcile_pages',[0]))wp_schedule_single_event(time()+10,'twt_reconcile_pages',[0]);update_option('twt_page_sync_version','28',false);}if(!wp_next_scheduled('twt_page_reconcile_daily'))wp_schedule_event(time()+DAY_IN_SECONDS,'daily','twt_page_reconcile_daily');});
add_action('twt_page_reconcile_daily',function(){if(!wp_next_scheduled('twt_reconcile_pages',[0]))wp_schedule_single_event(time()+5,'twt_reconcile_pages',[0]);});
add_action('twt_reconcile_pages',function($offset){global $wpdb;$t=deniz_tables();$offset=absint($offset);if($offset===0){foreach($wpdb->get_col("SELECT id FROM {$t['airports']} WHERE active=1 ORDER BY id") as $airport_id)twt_sync_airport_page((int)$airport_id);}$pairs=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT p.airport_id,p.region_id FROM {$t['prices']} p JOIN {$t['airports']} a ON a.id=p.airport_id AND a.active=1 JOIN {$t['regions']} r ON r.id=p.region_id AND r.active=1 JOIN {$t['vehicles']} v ON v.id=p.vehicle_id AND v.active=1 WHERE p.active=1 AND p.one_way>0 ORDER BY p.airport_id,p.region_id LIMIT 50 OFFSET %d",$offset));foreach($pairs as $pair){twt_sync_priced_region($pair->region_id);deniz_sync_route_post($pair->airport_id,$pair->region_id);}if(count($pairs)===50&&!wp_next_scheduled('twt_reconcile_pages',[$offset+50]))wp_schedule_single_event(time()+30,'twt_reconcile_pages',[$offset+50]);},10,1);
add_action('switch_theme',function(){wp_clear_scheduled_hook('twt_page_reconcile_daily');});
