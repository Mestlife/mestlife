<?php
if (!defined('ABSPATH')) exit;
function deniz_currencies(){
 $auto=get_option('twt_fx_auto',true);$fx=$auto?get_option('twt_fx_snapshot',[]):[];$rates=$fx['rates']??[];
 return ['EUR'=>['symbol'=>'€','rate'=>1],'TRY'=>['symbol'=>'₺','rate'=>(float)($rates['TRY']??deniz_setting('rate_try','52'))],'USD'=>['symbol'=>'$','rate'=>(float)($rates['USD']??deniz_setting('rate_usd','1.17'))],'GBP'=>['symbol'=>'£','rate'=>(float)($rates['GBP']??deniz_setting('rate_gbp','0.87'))]];
}
function deniz_current_currency(){
 $all=deniz_currencies(); $cur=isset($_POST['currency'])?strtoupper(sanitize_key($_POST['currency'])):(isset($_GET['currency'])?strtoupper(sanitize_key($_GET['currency'])):(isset($_COOKIE['deniz_currency'])?strtoupper(sanitize_key($_COOKIE['deniz_currency'])):'EUR')); return isset($all[$cur])?$cur:'EUR';
}
function deniz_convert_price($eur,$currency=null){$currency=$currency?:deniz_current_currency();$all=deniz_currencies();return round((float)$eur*(float)$all[$currency]['rate'],2);}
function deniz_money($eur,$currency=null){$currency=$currency?:deniz_current_currency();$all=deniz_currencies();$n=deniz_convert_price($eur,$currency);$dec=fmod($n,1)==0?0:2;return $all[$currency]['symbol'].number_format($n,$dec,',','.');}
add_action('template_redirect',function(){ if(isset($_GET['currency'])&&isset(deniz_currencies()[strtoupper(sanitize_key($_GET['currency']))])) setcookie('deniz_currency',strtoupper(sanitize_key($_GET['currency'])),time()+31536000,COOKIEPATH?:'/'); });

function deniz_same_page_currency_url($currency){
 $currency=strtoupper(sanitize_key($currency));
 if(!isset(deniz_currencies()[$currency])) $currency='EUR';
 $relative=function_exists('deniz_current_request_relative_path')?deniz_current_request_relative_path():'/';
 $url=home_url('/'.ltrim($relative,'/'));
 $parts=wp_parse_url($_SERVER['REQUEST_URI']??'/');
 $query=[];
 if(!empty($parts['query'])) parse_str($parts['query'],$query);
 $query['currency']=$currency;
 return add_query_arg($query,$url);
}
