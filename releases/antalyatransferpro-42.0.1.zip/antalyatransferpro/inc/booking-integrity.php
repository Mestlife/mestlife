<?php
if(!defined('ABSPATH'))exit;
function twt_voucher_key($b){return hash_hmac('sha256',$b->id.'|'.$b->booking_ref,wp_salt('auth'));}
function twt_voucher_url($b){return add_query_arg(['ref'=>$b->booking_ref,'key'=>twt_voucher_key($b)],deniz_booking_page_url('template-booking-confirmation.php'));}
add_action('template_redirect',function(){if(!is_page_template('template-booking-confirmation.php'))return;nocache_headers();header('Referrer-Policy: no-referrer');header('X-Robots-Tag: noindex, noarchive');if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);global $wpdb;$t=deniz_tables();$ref=sanitize_text_field(wp_unslash($_GET['ref']??''));$b=$wpdb->get_row($wpdb->prepare("SELECT id,booking_ref FROM {$t['bookings']} WHERE booking_ref=%s",$ref));$key=is_scalar($_GET['key']??null)?sanitize_text_field(wp_unslash($_GET['key'])):'';if(!current_user_can('manage_options')&&(!$b||!hash_equals(twt_voucher_key($b),$key))){status_header(403);wp_die(esc_html(deniz_t('voucher_access_error')),esc_html(deniz_t('transfer_voucher')),['response'=>403]);}},0);
function twt_vehicle_available($vehicle,$date,$time){
 if(deniz_vehicle_date_blocked($vehicle,$date))return false;$ts=deniz_pickup_timestamp($date,$time);if(!$ts)return false;
 foreach(preg_split('/\r\n|\r|\n/',(string)($vehicle->unavailable_slots??'')) as $line){if(preg_match('/^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})$/',trim($line),$m)){$start=deniz_pickup_timestamp($m[1],$m[2]);$end=deniz_pickup_timestamp($m[1],$m[3]);if(!$start||!$end)continue;if($end<$start)$end+=DAY_IN_SECONDS;if($ts>=$start&&$ts<=$end)return false;}}
 return true;
}
function twt_validate_route($airport_id,$region_id,$hotel_id,$mode,$from_lat,$from_lng,$to_lat,$to_lng){
 global $wpdb;$t=deniz_tables();$airport=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['airports']} WHERE id=%d AND active=1",$airport_id));$region=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d AND active=1",$region_id));if(!$airport||!$region)return false;
 $alat=$mode==='hotel'?$to_lat:$from_lat;$alng=$mode==='hotel'?$to_lng:$from_lng;$lat=$mode==='hotel'?$from_lat:$to_lat;$lng=$mode==='hotel'?$from_lng:$to_lng;
 if(abs($lat)>90||abs($lng)>180||deniz_haversine($alat,$alng,$airport->lat,$airport->lng)>10)return false;
 $poly=json_decode($region->polygon,true);if(!deniz_point_in_polygon($lat,$lng,$poly))return false;
 if($hotel_id){$hotel=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE id=%d AND active=1 AND region_id=%d",$hotel_id,$region_id));if(!$hotel||deniz_haversine($lat,$lng,$hotel->lat,$hotel->lng)>.3)return false;}
 return true;
}
/* A server-issued signature binds a selected address to its real coordinates. */
function twt_address_signature($label,$lat,$lng,$region){return hash_hmac('sha256',wp_json_encode([$label,(string)$lat,(string)$lng,(int)$region]),wp_salt('nonce'));}
add_action('wp_ajax_twt_address_search','twt_address_search');add_action('wp_ajax_nopriv_twt_address_search','twt_address_search');
function twt_address_search(){check_ajax_referer('deniz_booking','nonce');global $wpdb;$t=deniz_tables();$rid=absint($_GET['region_id']??0);$q=sanitize_text_field(wp_unslash($_GET['q']??''));if(strlen($q)<3)wp_send_json_success([]);$r=$wpdb->get_row($wpdb->prepare("SELECT r.*,c.name city FROM {$t['regions']} r JOIN {$t['cities']} c ON c.id=r.city_id WHERE r.id=%d AND r.active=1",$rid));if(!$r)wp_send_json_success([]);$cache='twt_addr_'.md5($rid.'|'.$q.'|'.deniz_current_lang());$items=get_transient($cache);
 if($items===false){$items=[];$local=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE active=1 AND region_id=%d AND (name LIKE %s OR address LIKE %s) LIMIT 8",$rid,'%'.$wpdb->esc_like($q).'%','%'.$wpdb->esc_like($q).'%'));foreach($local as $h)$items[]=['label'=>$h->name.($h->address?' · '.$h->address:''),'lat'=>(string)$h->lat,'lng'=>(string)$h->lng];
 if(!$items){$now=microtime(true);$last=(float)get_option('twt_geocode_lock',0);if($last&&$now-$last<1)wp_send_json_error(['message'=>deniz_t('booking_processing')]);if($last)delete_option('twt_geocode_lock');if(!add_option('twt_geocode_lock',$now,'',false))wp_send_json_error(['message'=>deniz_t('booking_processing')]);$url=add_query_arg(['q'=>$q.', '.$r->name.', '.$r->city,'format'=>'jsonv2','limit'=>8,'accept-language'=>deniz_current_lang()],'https://nominatim.openstreetmap.org/search');$response=wp_remote_get($url,['timeout'=>7,'headers'=>['User-Agent'=>'AntalyaTransferPro/27 ('.home_url('/').')']]);if(!is_wp_error($response)&&wp_remote_retrieve_response_code($response)===200){foreach((array)json_decode(wp_remote_retrieve_body($response),true) as $x){if(isset($x['lat'],$x['lon'])&&deniz_point_in_polygon((float)$x['lat'],(float)$x['lon'],json_decode($r->polygon,true)))$items[]=['label'=>sanitize_text_field($x['display_name']),'lat'=>(string)$x['lat'],'lng'=>(string)$x['lon']];}}}
 set_transient($cache,$items,10*MINUTE_IN_SECONDS);}
 foreach($items as &$x)$x['signature']=twt_address_signature($x['label'],$x['lat'],$x['lng'],$rid);unset($x);wp_send_json_success($items);
}

add_action('template_redirect',function(){if(!twt_seo_private_page())return;if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);nocache_headers();},0);
