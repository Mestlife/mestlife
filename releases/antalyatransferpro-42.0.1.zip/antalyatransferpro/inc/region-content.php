<?php
if(!defined('ABSPATH')) exit;
function deniz_region_content_install(){if(get_option('twt_region_schema_version')==='33')return;global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=deniz_tables();$cc=$wpdb->get_charset_collate();atp_dbdelta("CREATE TABLE {$t['region_content']} (id bigint unsigned NOT NULL AUTO_INCREMENT,region_id bigint unsigned NOT NULL,lang varchar(6) NOT NULL DEFAULT 'tr',hero_title varchar(220) NULL,intro text NULL,about_title varchar(220) NULL,about_content longtext NULL,route_title varchar(220) NULL,route_content longtext NULL,seo_title varchar(190) NULL,seo_description text NULL,faq_json longtext NULL,updated_at datetime NULL,PRIMARY KEY(id),UNIQUE KEY region_lang(region_id,lang),KEY region_id(region_id)) $cc;");if(!$wpdb->last_error)update_option('twt_region_schema_version','33',false);}
add_action('init','deniz_region_content_install',7);
function deniz_region_content_get($region_id,$lang=null){global $wpdb;$t=deniz_tables();$lang=$lang?:deniz_current_lang();$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['region_content']} WHERE region_id=%d AND lang=%s",$region_id,$lang));return $row;}
function deniz_region_faqs($row){$j=$row&&!empty($row->faq_json)?json_decode($row->faq_json,true):[];return is_array($j)?$j:[];}
add_action('admin_menu',function(){add_submenu_page('deniz-os','Bölge İçerikleri','Bölge İçerikleri','manage_options','deniz-region-content','deniz_region_content_page');},24);
function deniz_region_content_normalize_json_payload($payload,$lang){
 if(!is_array($payload))return [];
 $langs=deniz_languages();
 $looks_multi=false;
 foreach(array_keys($payload) as $k){if(isset($langs[$k])&&is_array($payload[$k])){$looks_multi=true;break;}}
 return $looks_multi?$payload:[$lang=>$payload];
}
function deniz_region_content_sanitize_json_block($block,$existing=null){
 if(!is_array($block))return [];
 $aliases=[
  'hero_intro'=>'intro','intro'=>'intro','about_content'=>'about_content','route_content'=>'route_content'
 ];
 $out=[];
 foreach($aliases as $src=>$dst){
  if(!array_key_exists($src,$block))continue;
  $raw=is_scalar($block[$src])?(string)$block[$src]:'';
  $out[$dst]=wp_kses_post($raw);
 }
 return $out;
}
function deniz_region_content_upsert($region_id,$lang,$changes){
 global $wpdb;$t=deniz_tables();
 $current=deniz_region_content_get($region_id,$lang);
 $data=['region_id'=>$region_id,'lang'=>$lang,'updated_at'=>current_time('mysql')];
 foreach(['hero_title','intro','about_title','about_content','route_title','route_content','seo_title','seo_description','faq_json'] as $k){
  if(array_key_exists($k,$changes))$data[$k]=$changes[$k];
  elseif($current)$data[$k]=$current->$k;
  else $data[$k]='';
 }
 if($current)$wpdb->update($t['region_content'],$data,['id'=>$current->id]);else $wpdb->insert($t['region_content'],$data);
 return !$wpdb->last_error;
}
function deniz_region_content_page(){
 global $wpdb;$t=deniz_tables();deniz_region_content_install();
 $regions=$wpdb->get_results("SELECT r.id,r.name,c.name city,co.name country FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE r.active=1 ORDER BY co.name,c.name,r.name");
 $rid=absint($_REQUEST['region_id']??($regions[0]->id??0));$lang=sanitize_key($_REQUEST['content_lang']??'tr');if(!isset(deniz_languages()[$lang]))$lang='tr';
 $notice='';$notice_type='success';

 if(isset($_POST['deniz_import_region_json'])&&check_admin_referer('deniz_region_content_json')){
  $raw=wp_unslash($_POST['region_content_json']??'');
  $payload=json_decode($raw,true);
  if(json_last_error()!==JSON_ERROR_NONE){$notice='JSON okunamadı: '.json_last_error_msg();$notice_type='error';}
  else{
   $blocks=deniz_region_content_normalize_json_payload($payload,$lang);$saved=[];$errors=[];
   foreach($blocks as $code=>$block){
    $code=sanitize_key($code);if(!isset(deniz_languages()[$code])||!is_array($block))continue;
    $changes=deniz_region_content_sanitize_json_block($block,deniz_region_content_get($rid,$code));
    if(!$changes){$errors[]=$code.' için tanınan alan bulunamadı';continue;}
    if(deniz_region_content_upsert($rid,$code,$changes))$saved[]=$code;else $errors[]=$code.' kaydedilemedi';
   }
   if($saved)$notice='JSON içeriği kaydedildi: '.strtoupper(implode(', ',$saved)).'. JSON’da olmayan mevcut alanlara dokunulmadı.';
   if($errors){$notice.=($notice?' ':'').implode(' · ',$errors);$notice_type=$saved?'warning':'error';}
   if(!$saved&&!$errors){$notice='JSON içinde desteklenen dil veya alan bulunamadı.';$notice_type='error';}
  }
 }

 if(isset($_POST['deniz_save_region_content'])&&check_admin_referer('deniz_region_content')){
  $data=['intro'=>wp_kses_post(wp_unslash($_POST['intro']??'')),'about_content'=>wp_kses_post(wp_unslash($_POST['about_content']??'')),'route_content'=>wp_kses_post(wp_unslash($_POST['route_content']??''))];
  deniz_region_content_upsert($rid,$lang,$data);$notice='Özgün bölge metinleri kaydedildi. H1, title, meta, fiyatlar, servis türleri ve FAQ dinamik sistem tarafından üretilir.';$notice_type='success';
 }

 $row=$rid?deniz_region_content_get($rid,$lang):null;
 deniz_admin_shell_start('Bölge İçerikleri','Her transfer bölgesi için yalnızca özgün açıklama metinlerini yönetin. H1, SEO title, meta description, fiyat, servis türü ve FAQ canlı veriden otomatik üretilir.');
 if($notice)echo '<div class="notice notice-'.esc_attr($notice_type).' inline"><p>'.esc_html($notice).'</p></div>';
 echo '<form method="get" class="dos-panel"><input type="hidden" name="page" value="deniz-region-content"><div class="dos-2"><label>Bölge<select name="region_id" onchange="this.form.submit()">';foreach($regions as $r)echo '<option value="'.$r->id.'" '.selected($rid,$r->id,false).'>'.esc_html($r->country.' / '.$r->city.' / '.$r->name).'</option>';echo '</select></label><label>Dil<select name="content_lang" onchange="this.form.submit()">';foreach(deniz_languages() as $code=>$info)echo '<option value="'.$code.'" '.selected($lang,$code,false).'>'.esc_html($info['name']).'</option>';echo '</select></label></div></form>';

 // JSON bulk importer.
 $template=[
  'hero_intro'=>'','about_content'=>'','route_content'=>''
 ];
 $current=['hero_intro'=>$row->intro??'','about_content'=>$row->about_content??'','route_content'=>$row->route_content??''];
 echo '<section class="dos-panel twt-json-importer"><div class="twt-json-head"><div><span class="dos-badge">HIZLI İÇERİK AKTARIMI</span><h2>JSON ile tek seferde doldur</h2><p class="dos-muted">Tek dil JSON veya <b>tr / en / de / ru</b> içeren çok dilli JSON yapıştırabilirsiniz. Bu alan yalnızca özgün açıklama metinlerini yönetir. H1, SEO title, meta description, fiyat, servis türü, mesafe, süre ve FAQ canlı veriden otomatik gelir.</p></div><div class="twt-json-context"><b>'.esc_html(($regions[array_search($rid,array_column($regions,'id'))]->name??'Bölge')).'</b><span>'.esc_html(strtoupper($lang)).'</span></div></div>';
 echo '<form method="post" id="twt-region-json-form">';wp_nonce_field('deniz_region_content_json');echo '<input type="hidden" name="region_id" value="'.$rid.'"><input type="hidden" name="content_lang" value="'.esc_attr($lang).'"><textarea id="twt-region-json" name="region_content_json" rows="16" spellcheck="false" placeholder="JSON içeriğini buraya yapıştırın..."></textarea><div id="twt-json-status" class="twt-json-status" hidden></div><div class="twt-json-actions"><button type="button" class="dos-btn ghost" id="twt-json-template">Boş şablonu yükle</button><button type="button" class="dos-btn ghost" id="twt-json-current">Mevcut içeriği JSON yap</button><button type="button" class="dos-btn ghost" id="twt-json-preview">JSON’u kontrol et</button><button type="button" class="dos-btn ghost" id="twt-json-apply">Seçili dile alanlara uygula</button><button class="dos-btn" name="deniz_import_region_json" value="1">JSON’u Uygula & Kaydet</button></div></form></section>';

 echo '<form method="post" class="dos-panel" id="twt-region-fields">';wp_nonce_field('deniz_region_content');echo '<input type="hidden" name="region_id" value="'.$rid.'"><input type="hidden" name="content_lang" value="'.esc_attr($lang).'">';$ta=fn($k)=>esc_textarea($row->$k??'');echo '<div class="dos-panel" style="margin-bottom:18px;background:#f7fbf9;border:1px solid #cfe9dc"><b>Otomatik üretilen alanlar</b><p class="dos-muted" style="margin:6px 0 0">Sayfa H1, HTML/SEO title, meta description, başlangıç fiyatları, shuttle/private durumu, fiyat birimi, mesafe, süre, araçlar ve FAQ aktif veritabanı kayıtlarından dinamik oluşturulur. Burada yalnızca bölgeye özgü doğal açıklamaları yazın. Sabit ücret yazmayın: ücret içeren açıklama paragrafları ve sunulmayan shuttle hizmetine ilişkin metinler ön yüzde gösterilmez; güncel fiyat Fiyat Matrisi üzerinden gelir.</p></div><label>Hero / kısa özgün giriş<textarea name="intro" rows="4">'.$ta('intro').'</textarea></label><label>Bölge hakkında özgün açıklama<textarea name="about_content" rows="9">'.$ta('about_content').'</textarea></label><label>Rota / karşılama / yol hakkında özgün açıklama<textarea name="route_content" rows="9">'.$ta('route_content').'</textarea></label><button name="deniz_save_region_content" class="dos-btn full">Özgün İçeriği Kaydet</button></form>';
 echo '<script>(()=>{const area=document.getElementById("twt-region-json"),status=document.getElementById("twt-json-status"),fields=document.getElementById("twt-region-fields"),lang='.wp_json_encode($lang).',template='.wp_json_encode($template,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).',current='.wp_json_encode($current,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).';if(!area||!fields)return;const aliases={hero_intro:"intro",intro:"intro",about_content:"about_content",route_content:"route_content"};const show=(m,c="ok")=>{status.hidden=false;status.className="twt-json-status "+c;status.textContent=m};const parse=()=>{try{return JSON.parse(area.value)}catch(e){show("Geçersiz JSON: "+e.message,"err");return null}};const blockFor=o=>o&&typeof o==="object"&&!Array.isArray(o)&&(o.tr||o.en||o.de||o.ru)?(o[lang]||null):o;document.getElementById("twt-json-template").onclick=()=>{area.value=JSON.stringify(template,null,2);show("Boş şablon yüklendi.")};document.getElementById("twt-json-current").onclick=()=>{area.value=JSON.stringify(current,null,2);show("Mevcut içerik JSON alanına aktarıldı.")};document.getElementById("twt-json-preview").onclick=()=>{const o=parse();if(!o)return;const multi=o&&typeof o==="object"&&!Array.isArray(o)&&(o.tr||o.en||o.de||o.ru);const langs=multi?Object.keys(o).filter(k=>["tr","en","de","ru"].includes(k)):[];const b=blockFor(o);if(multi&&!b){show("JSON çok dilli ancak seçili "+lang.toUpperCase()+" bölümü yok. Kaydet butonu mevcut diğer dilleri yine kaydedebilir.","warn");return}const keys=b&&typeof b==="object"?Object.keys(b):[];show((multi?"Çok dilli JSON: "+langs.map(x=>x.toUpperCase()).join(", ")+" · ":"")+keys.length+" alan bulundu.")};document.getElementById("twt-json-apply").onclick=()=>{const o=parse();if(!o)return;const b=blockFor(o);if(!b||typeof b!=="object"||Array.isArray(b)){show("Seçili dil için içerik bulunamadı.","err");return}let n=0;Object.entries(aliases).forEach(([src,dst])=>{if(!(src in b))return;const el=fields.elements[dst];if(el){el.value=typeof b[src]==="string"?b[src]:"";n++}});show(n+" içerik alanı aşağıdaki editoryal alanlara uygulandı. H1, SEO title, meta description, FAQ, fiyat ve servis bilgileri dinamik sistem tarafından yönetilir. Kaydetmek için İçeriği Kaydet butonuna basabilirsiniz.")};})();</script>';
 deniz_admin_shell_end();
}
