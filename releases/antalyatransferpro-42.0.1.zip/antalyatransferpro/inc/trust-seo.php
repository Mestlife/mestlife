<?php
/**
 * Antalya Transfer Pro 41.4.0 — trust & SEO fixes.
 *
 *  1. Google reviews block (admin-editable, no fake schema).
 *  2. Per-region photos with real alt text (Transfer OS › Bölge Görselleri).
 *  3. One URL per region: /transfers/ayt-to-{region}-transfer/ → canonical to /antalya-{region}-transfer/.
 *  4. Technical SEO: hide WP version, noindex ?currency= URLs, nofollow currency links.
 */
if (!defined('ABSPATH')) exit;

/* =====================================================================
 * 0. UI strings (registered into the shared catalogue → Translation Center)
 * ===================================================================== */
add_filter('twt_ui_strings', function ($s) {
	$add = [
		'reviews_title'      => ['tr' => 'Yolcularımız ne diyor?', 'en' => 'What our passengers say', 'de' => 'Das sagen unsere Fahrgäste', 'ru' => 'Отзывы наших пассажиров'],
		'reviews_summary'    => ['tr' => 'Google\'da %2$s yorumdan ortalama %1$s', 'en' => 'Average %1$s from %2$s Google reviews', 'de' => 'Durchschnittlich %1$s aus %2$s Google-Bewertungen', 'ru' => 'Средняя оценка %1$s по %2$s отзывам в Google'],
		'reviews_all'        => ['tr' => 'Tüm yorumları Google\'da okuyun', 'en' => 'Read all reviews on Google', 'de' => 'Alle Bewertungen auf Google lesen', 'ru' => 'Все отзывы в Google'],
		'reviews_write'      => ['tr' => 'Yorum yazın', 'en' => 'Write a review', 'de' => 'Bewertung schreiben', 'ru' => 'Оставить отзыв'],
		'reviews_note'       => ['tr' => 'Yorumlar Google\'dan alınmıştır ve yazıldıkları dilde gösterilir.', 'en' => 'Reviews are taken from Google and shown in the language they were written in.', 'de' => 'Die Bewertungen stammen von Google und werden in der Originalsprache angezeigt.', 'ru' => 'Отзывы взяты из Google и показаны на языке оригинала.'],
		'reviews_stars'      => ['tr' => '5 üzerinden %s yıldız', 'en' => '%s out of 5 stars', 'de' => '%s von 5 Sternen', 'ru' => '%s из 5 звёзд'],
		'reviews_prev'       => ['tr' => 'Önceki yorumlar', 'en' => 'Previous reviews', 'de' => 'Vorherige Bewertungen', 'ru' => 'Предыдущие отзывы'],
		'reviews_next'       => ['tr' => 'Sonraki yorumlar', 'en' => 'Next reviews', 'de' => 'Nächste Bewertungen', 'ru' => 'Следующие отзывы'],
		'vehicle_desc_shared'=> ['tr' => 'Aynı yöne giden yolcularla paylaşılan, kişi başı fiyatlı konforlu shuttle. Otelinize kadar götürür.', 'en' => 'A comfortable shuttle shared with passengers heading the same way, priced per person and taking you to your hotel.', 'de' => 'Ein komfortabler Shuttle, den Sie mit Fahrgästen in dieselbe Richtung teilen – Preis pro Person, bis zu Ihrem Hotel.', 'ru' => 'Комфортный шаттл, который вы делите с пассажирами по тому же направлению. Цена за человека, доставка до отеля.'],
		'shared_dropoff'     => ['tr' => 'Otelinize kadar transfer', 'en' => 'Drop-off at your hotel', 'de' => 'Bis zu Ihrem Hotel', 'ru' => 'Доставка до отеля'],
	];
	foreach ($add as $k => $v) if (!isset($s[$k])) $s[$k] = $v;
	return $s;
});
function atp_ts_lang() { return function_exists('deniz_current_lang') ? deniz_current_lang() : 'tr'; }

/* =====================================================================
 * 1. Google reviews
 * ===================================================================== */
function atp_reviews_defaults() {
	return [
		'rating'    => '',
		'count'     => 0,
		'url'       => 'https://maps.app.goo.gl/zwwjRioiDtTfXA1EA',
		'write_url' => '',
		'lines'     => '', // Add only verified reviews in admin; existing saved settings are preserved.
	];
}
function atp_reviews_settings() {
	$o = get_option('atp_reviews', []);
	return array_merge(atp_reviews_defaults(), is_array($o) ? $o : []);
}
/** "Name | stars | YYYY-MM | lang | text" per line → array. Lines without text are skipped. */
function atp_reviews_parse($lines) {
	$out = [];
	foreach (preg_split('/\r\n|\r|\n/', (string) $lines) as $line) {
		$p = array_map('trim', explode('|', $line, 5));
		if (count($p) < 5 || $p[0] === '' || $p[4] === '') continue;
		$out[] = [
			'name'  => $p[0],
			'stars' => max(1, min(5, (int) $p[1])),
			'date'  => preg_match('/^\d{4}(-\d{2})?$/', $p[2]) ? $p[2] : '',
			'lang'  => preg_match('/^[a-z]{2}$/', $p[3]) ? $p[3] : '',
			'text'  => $p[4],
		];
	}
	return $out;
}
function atp_reviews_date_label($ym, $lang) {
	if (!$ym) return '';
	$months = [
		'tr' => ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
		'en' => ['January','February','March','April','May','June','July','August','September','October','November','December'],
		'de' => ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
		'ru' => ['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'],
	];
	if (strlen($ym) === 4) return $ym;
	[$y, $m] = array_map('intval', explode('-', $ym));
	$name = ($months[$lang] ?? $months['en'])[$m - 1] ?? '';
	return trim($name . ' ' . $y);
}
function atp_stars_svg($n) {
	$o = '';
	for ($i = 1; $i <= 5; $i++) {
		$o .= '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true" focusable="false" class="' . ($i <= $n ? 'on' : 'off') . '"><path d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.6 7.7l5.8-.8z"/></svg>';
	}
	return $o;
}
/** Renders the reviews band. $variant: 'home' | 'landing'. */
function atp_reviews_section($variant = 'home') {
	$s = atp_reviews_settings();
	$items = atp_reviews_parse($s['lines']);
	if (!$items) return;
	$lang   = atp_ts_lang();
	$rating = (float) str_replace(',', '.', (string) $s['rating']);
	$rating_txt = $lang === 'en' ? number_format($rating, 1, '.', '') : number_format($rating, 1, ',', '');
	$count  = (int) $s['count'];
	$id     = 'atp-reviews-' . $variant;
	?>
	<section class="atp-reviews atp-reviews--<?php echo esc_attr($variant); ?>" aria-labelledby="<?php echo esc_attr($id); ?>-h">
	  <div class="wrap atp-reviews-grid">
	    <div class="atp-reviews-score">
	      <h2 id="<?php echo esc_attr($id); ?>-h"><?php echo esc_html(deniz_t('reviews_title')); ?></h2>
	      <p class="atp-reviews-big"><span class="atp-reviews-num"><?php echo esc_html($rating_txt); ?></span><span class="atp-reviews-stars" role="img" aria-label="<?php echo esc_attr(sprintf(deniz_t('reviews_stars'), $rating_txt)); ?>"><?php echo atp_stars_svg((int) round($rating)); ?></span></p>
	      <p class="atp-reviews-sum"><?php echo esc_html(sprintf(deniz_t('reviews_summary'), $rating_txt, $count)); ?></p>
	      <div class="atp-reviews-actions">
	        <?php if (!empty($s['url'])): ?><a class="atp-reviews-btn" href="<?php echo esc_url($s['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html(deniz_t('reviews_all')); ?></a><?php endif; ?>
	        <?php $w = $s['write_url'] ?: $s['url']; if ($w): ?><a class="atp-reviews-link" href="<?php echo esc_url($w); ?>" target="_blank" rel="noopener"><?php echo esc_html(deniz_t('reviews_write')); ?></a><?php endif; ?>
	      </div>
	    </div>
	    <div class="atp-reviews-rail">
	      <div class="atp-reviews-track" id="<?php echo esc_attr($id); ?>-track" tabindex="0" role="region" aria-label="<?php echo esc_attr(deniz_t('reviews_title')); ?>">
	        <?php foreach ($items as $r): ?>
	        <figure class="atp-review">
	          <span class="atp-review-stars" role="img" aria-label="<?php echo esc_attr(sprintf(deniz_t('reviews_stars'), $r['stars'])); ?>"><?php echo atp_stars_svg($r['stars']); ?></span>
	          <blockquote<?php echo $r['lang'] ? ' lang="' . esc_attr($r['lang']) . '"' : ''; ?>><p><?php echo esc_html($r['text']); ?></p></blockquote>
	          <figcaption><b><?php echo esc_html($r['name']); ?></b><small><?php echo esc_html(trim('Google' . ($r['date'] ? ' · ' . atp_reviews_date_label($r['date'], $lang) : ''))); ?></small></figcaption>
	        </figure>
	        <?php endforeach; ?>
	      </div>
	      <div class="atp-reviews-nav">
	        <p class="atp-reviews-note"><?php echo esc_html(deniz_t('reviews_note')); ?></p>
	        <span><button type="button" data-rv-prev aria-controls="<?php echo esc_attr($id); ?>-track" aria-label="<?php echo esc_attr(deniz_t('reviews_prev')); ?>">‹</button><button type="button" data-rv-next aria-controls="<?php echo esc_attr($id); ?>-track" aria-label="<?php echo esc_attr(deniz_t('reviews_next')); ?>">›</button></span>
	      </div>
	    </div>
	  </div>
	</section>
	<?php
	static $js = false;
	if (!$js) { $js = true; ?>
	<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-rv-prev],[data-rv-next]');if(!b)return;var t=document.getElementById(b.getAttribute('aria-controls'));if(!t)return;var c=t.querySelector('.atp-review');var w=c?c.getBoundingClientRect().width+16:300;t.scrollBy({left:b.hasAttribute('data-rv-next')?w:-w,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});});</script>
	<?php }
}
add_action('wp_enqueue_scripts', function () {
	$front = is_front_page() || (function_exists('deniz_is_language_home_request') && deniz_is_language_home_request());
	$landing = function_exists('atp_landing_current') && atp_landing_current();
	if ($front || $landing) wp_enqueue_style('atp-reviews', get_template_directory_uri() . '/assets/css/reviews.css', [], wp_get_theme()->get('Version'));
}, 100);

/* =====================================================================
 * 2. Region photos + alt text
 * ===================================================================== */
function atp_region_images() { $o = get_option('atp_region_images', []); return is_array($o) ? array_map('absint', $o) : []; }
/** Stock fallbacks keyed by landing key (used only until a real photo is uploaded). */
function atp_region_stock_images() {
	$u = fn($id) => 'https://images.unsplash.com/' . $id . '?auto=format&fit=crop&w=900&q=78';
	return [
		'lara' => $u('photo-1507525428034-b723cf961d3e'), 'kundu' => $u('photo-1522708323590-d24dbb6b0267'),
		'konyaalti' => $u('photo-1500375592092-40eb2168fd21'), 'belek' => $u('photo-1506744038136-46273834b3fb'),
		'goynuk' => $u('photo-1473116763249-2faaef81ccda'), 'beldibi' => $u('photo-1473116763249-2faaef81ccda'),
		'kemer' => $u('photo-1468413253725-0d5181091126'), 'side' => $u('photo-1500530855697-b586d89ba3ee'),
		'tekirova' => $u('photo-1507525428034-b723cf961d3e'), 'manavgat' => $u('photo-1493558103817-58b2924bce98'),
		'cirali' => $u('photo-1504609813442-a8924e83f76e'), 'alanya' => $u('photo-1501785888041-af3ef285b470'),
	];
}
function atp_region_alt($name, $lang = null) {
	$lang = $lang ?: atp_ts_lang();
	$f = ['tr' => 'Antalya Havalimanı – %s transferi', 'en' => 'Antalya Airport to %s transfer', 'de' => 'Transfer Flughafen Antalya – %s', 'ru' => 'Трансфер из аэропорта Антальи: %s'];
	return sprintf($f[$lang] ?? $f['en'], $name);
}
/** ['url'=>..., 'alt'=>..., 'real'=>bool] for a DB region row. */
function atp_region_image($region, $size = 'large') {
	$name = function_exists('twt_entity_name') ? twt_entity_name($region, 'region') : ($region->name ?? '');
	$alt  = atp_region_alt($name);
	$imgs = atp_region_images();
	if ($region && !empty($imgs[(int) $region->id])) {
		$aid = $imgs[(int) $region->id];
		$url = wp_get_attachment_image_url($aid, $size);
		if ($url) {
			$own = trim((string) get_post_meta($aid, '_wp_attachment_image_alt', true));
			return ['url' => $url, 'alt' => $own ?: $alt, 'real' => true];
		}
	}
	$key = $region ? atp_dest_key_for_region($region) : null;
	$stock = atp_region_stock_images();
	return ['url' => ($key && isset($stock[$key])) ? $stock[$key] : get_template_directory_uri() . '/assets/images/hero-antalyatransfer-clean.jpg', 'alt' => $alt, 'real' => false];
}

add_action('admin_menu', function () {
	add_submenu_page('deniz-os', 'Bölge Görselleri', 'Bölge Görselleri', 'manage_options', 'atp-region-images', 'atp_region_images_page');
	add_submenu_page('deniz-os', 'Google Yorumları', 'Google Yorumları', 'manage_options', 'atp-reviews', 'atp_reviews_admin_page');
}, 45);
add_action('admin_enqueue_scripts', function ($hook) { if (strpos((string) $hook, 'atp-region-images') !== false) wp_enqueue_media(); });

function atp_region_images_page() {
	if (!current_user_can('manage_options')) return;
	if (isset($_POST['atp_save_region_images']) && check_admin_referer('atp_region_images')) {
		$map = [];
		foreach ((array) ($_POST['region_img'] ?? []) as $rid => $aid) { $rid = absint($rid); $aid = absint($aid); if ($rid && $aid) $map[$rid] = $aid; }
		update_option('atp_region_images', $map, false);
		echo '<div class="notice notice-success"><p>Bölge görselleri kaydedildi.</p></div>';
	}
	global $wpdb; $t = deniz_tables();
	$regions = (array) $wpdb->get_results("SELECT r.*,c.name city_name FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id WHERE r.active=1 ORDER BY COALESCE(c.name,''),r.name");
	$map = atp_region_images();
	echo '<div class="wrap"><h1>Bölge Görselleri</h1><p>Her bölge için o bölgeye ait <strong>gerçek bir fotoğraf</strong> seçin (ör. Belek sahili, Kemer marinası ya da o bölgedeki aracınız). Görsel; ana sayfa kartlarında, rota şeridinde ve SEO sayfasının üst alanında kullanılır.</p><p>Alt metin otomatik üretilir (ör. “Antalya Havalimanı – Belek transferi”). Medya Kütüphanesi\'nde görsele kendi alt metninizi yazarsanız o kullanılır. Görsel seçilmeyen bölgelerde geçici stok fotoğraf gösterilir.</p>';
	echo '<form method="post">'; wp_nonce_field('atp_region_images');
	echo '<table class="widefat striped"><thead><tr><th style="width:30%">Bölge</th><th style="width:22%">SEO sayfası</th><th>Görsel</th></tr></thead><tbody>';
	foreach ($regions as $r) {
		$aid = $map[(int) $r->id] ?? 0; $thumb = $aid ? wp_get_attachment_image_url($aid, 'thumbnail') : '';
		$key = atp_dest_key_for_region($r);
		echo '<tr><td><strong>' . esc_html($r->name) . '</strong><br><small>' . esc_html($r->city_name ?? '') . '</small></td>';
		echo '<td>' . ($key ? '<a href="' . esc_url(atp_landing_url($key, 'tr')) . '" target="_blank">' . esc_html(atp_slug($key, 'tr')) . '</a>' : '<span style="color:#787c82">—</span>') . '</td>';
		echo '<td><div style="display:flex;gap:12px;align-items:center"><img data-prev src="' . esc_url($thumb) . '" style="width:96px;height:64px;object-fit:cover;border-radius:6px;background:#f0f0f1' . ($thumb ? '' : ';display:none') . '" alt=""><input type="hidden" name="region_img[' . (int) $r->id . ']" value="' . (int) $aid . '"><button type="button" class="button atp-pick">Görsel seç</button><button type="button" class="button-link atp-clear"' . ($aid ? '' : ' style="display:none"') . '>Kaldır</button></div></td></tr>';
	}
	echo '</tbody></table><p><button class="button button-primary" name="atp_save_region_images" value="1">Kaydet</button></p></form></div>';
	?>
	<script>
	jQuery(function($){
	  $(document).on('click','.atp-pick',function(e){e.preventDefault();var cell=$(this).closest('td');var f=wp.media({title:'Bölge görseli seç',button:{text:'Bu görseli kullan'},library:{type:'image'},multiple:false});
	    f.on('select',function(){var a=f.state().get('selection').first().toJSON();cell.find('input').val(a.id);cell.find('[data-prev]').attr('src',(a.sizes&&a.sizes.thumbnail?a.sizes.thumbnail.url:a.url)).show();cell.find('.atp-clear').show();});f.open();});
	  $(document).on('click','.atp-clear',function(e){e.preventDefault();var cell=$(this).closest('td');cell.find('input').val('');cell.find('[data-prev]').hide();$(this).hide();});
	});
	</script>
	<?php
}

function atp_reviews_admin_page() {
	if (!current_user_can('manage_options')) return;
	if (isset($_POST['atp_save_reviews']) && check_admin_referer('atp_reviews')) {
		update_option('atp_reviews', [
			'rating'    => preg_replace('/[^0-9.,]/', '', (string) wp_unslash($_POST['rating'] ?? '')),
			'count'     => absint($_POST['count'] ?? 0),
			'url'       => esc_url_raw(wp_unslash($_POST['url'] ?? '')),
			'write_url' => esc_url_raw(wp_unslash($_POST['write_url'] ?? '')),
			'lines'     => sanitize_textarea_field(wp_unslash($_POST['lines'] ?? '')),
		], false);
		echo '<div class="notice notice-success"><p>Yorumlar kaydedildi.</p></div>';
	}
	$s = atp_reviews_settings();
	echo '<div class="wrap"><h1>Google Yorumları</h1><p>Bu yorumlar ana sayfada ve tüm SEO bölge sayfalarında gösterilir. Yeni yorum geldikçe buraya ekleyin.</p><form method="post">'; wp_nonce_field('atp_reviews');
	echo '<table class="form-table"><tr><th>Ortalama puan</th><td><input name="rating" value="' . esc_attr($s['rating']) . '" style="width:80px"> <span class="description">ör. 4.8</span></td></tr>';
	echo '<tr><th>Toplam yorum sayısı</th><td><input type="number" min="0" name="count" value="' . (int) $s['count'] . '" style="width:80px"></td></tr>';
	echo '<tr><th>Google Haritalar linki</th><td><input class="large-text" name="url" value="' . esc_attr($s['url']) . '"></td></tr>';
	echo '<tr><th>“Yorum yaz” linki</th><td><input class="large-text" name="write_url" value="' . esc_attr($s['write_url']) . '"><p class="description">Google İşletme Profili › “Yorum iste” bölümündeki kısa link (g.page/r/…/review). Boş kalırsa Haritalar linki kullanılır.</p></td></tr>';
	echo '<tr><th>Yorumlar</th><td><textarea name="lines" rows="12" class="large-text code">' . esc_textarea($s['lines']) . '</textarea><p class="description">Her satıra bir yorum: <code>İsim | Puan | YYYY-AA | dil | Yorum metni</code>. Tarih ve dil boş bırakılabilir. Metni olmayan yorumları eklemeyin. Yorumları kelimesi kelimesine kopyalayın, değiştirmeyin.</p></td></tr></table>';
	echo '<p><button class="button button-primary" name="atp_save_reviews" value="1">Kaydet</button></p></form></div>';
}

/* =====================================================================
 * 3. One URL per region (cannibalisation fix)
 * ===================================================================== */
/** region_id → landing key, cached; rebuilt when the price-region mapping changes. */
function atp_region_landing_map() {
	static $map = null; if ($map !== null) return $map;
	$map = get_transient('atp_region_landing_map_v1');
	if (is_array($map)) return $map;
	$map = [];
	if (function_exists('atp_dest_keys') && function_exists('deniz_tables')) {
		foreach (atp_dest_keys() as $k) { $r = atp_db_region($k); if ($r && !isset($map[(int) $r->id])) $map[(int) $r->id] = $k; }
		global $wpdb; $t = deniz_tables();
		foreach ((array) $wpdb->get_results("SELECT * FROM {$t['regions']} WHERE active=1") as $r) {
			if (isset($map[(int) $r->id])) continue;
			$k = atp_dest_for_region($r);
			if (!$k) { $hits = array_keys(array_filter(atp_price_region_map(), fn($id) => (int) $id === (int) $r->id)); if (count($hits) === 1) $k = $hits[0]; }
			if ($k) $map[(int) $r->id] = $k;
		}
	}
	set_transient('atp_region_landing_map_v1', $map, 12 * HOUR_IN_SECONDS);
	return $map;
}
foreach (['update_option_atp_destination_price_regions', 'add_option_atp_destination_price_regions', 'twt_regions_updated', 'switch_theme'] as $h) add_action($h, function () { delete_transient('atp_region_landing_map_v1'); });
function atp_dest_key_for_region($region) { if (!$region || empty($region->id)) return null; $m = atp_region_landing_map(); return $m[(int) $region->id] ?? null; }

/** Public link for a region card: the keyword landing page when one exists, else the route page. */
function atp_region_public_url($region, $airport = null) {
	$ayt = $airport && (($airport->iata ?? '') === 'AYT');
	if (($ayt || !$airport) && ($k = atp_dest_key_for_region($region))) return atp_landing_url($k);
	return deniz_region_route_url($region, $airport);
}
function atp_canonical_consolidation_on() { return (bool) apply_filters('atp_canonical_consolidation', get_option('atp_canonical_consolidation', '1') === '1'); }

/** Landing key that a region-level route/location post should defer to (null for hotel routes and unmapped regions). */
function atp_post_landing_key($post_id) {
	if (!atp_canonical_consolidation_on() || !function_exists('deniz_route_context')) return null;
	$type = get_post_type($post_id);
	if ($type === 'transfer-route') {
		$c = deniz_route_context($post_id);
		if (!$c || $c['h'] || !$c['r']) return null;
		if ($c['a'] && strtoupper((string) ($c['a']->iata ?? '')) !== 'AYT') return null;
		return atp_dest_key_for_region($c['r']);
	}
	if ($type === 'location') {
		$r = function_exists('deniz_db_region') ? deniz_db_region((int) get_post_meta($post_id, 'dynamic_region_id', true)) : null;
		if (!$r && function_exists('deniz_region_by_slug')) $r = deniz_region_by_slug(get_post_field('post_name', $post_id));
		return $r ? atp_dest_key_for_region($r) : null;
	}
	return null;
}
function atp_route_landing_key() {
	static $k = false; if ($k !== false) return $k;
	return $k = (is_singular(['transfer-route', 'location']) ? atp_post_landing_key(get_queried_object_id()) : null);
}
foreach (['wpseo_canonical', 'rank_math/frontend/canonical', 'aioseo_canonical_url'] as $f)
	add_filter($f, function ($v) { $k = atp_route_landing_key(); return $k ? atp_landing_url($k) : $v; }, 130);
/* Region route pages are left out of the sitemap — the landing page represents them. */
add_filter('twt_sitemap_exclude_post', function ($ex, $id) { return $ex || (bool) atp_post_landing_key($id); }, 10, 2);
add_action('update_option_atp_canonical_consolidation', function () { if (function_exists('twt_sm_flush_cache')) twt_sm_flush_cache(); });
add_action('update_option_atp_destination_price_regions', function () { if (function_exists('twt_sm_flush_cache')) twt_sm_flush_cache(); });

/* =====================================================================
 * 4. Technical SEO
 * ===================================================================== */
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');
/* ?currency=XXX only changes the displayed price — keep those URLs out of the index. */
add_filter('wp_robots', function ($r) {
	if (isset($_GET['currency'])) { $r['noindex'] = true; $r['follow'] = true; unset($r['index']); }
	return $r;
}, 60);
