<?php
if (!defined('ABSPATH')) exit;
add_action('add_meta_boxes',function(){
 add_meta_box('deniz_zone_map','Polygon Bölgesi','deniz_zone_map_box','transfer-zone','normal','high');
 add_meta_box('deniz_zone_prices','Araç Fiyat Matrisi','deniz_zone_prices_box','transfer-zone','normal','high');
 add_meta_box('deniz_vehicle_data','Araç Kapasitesi','deniz_vehicle_box','vehicle','normal','high');
});
function deniz_zone_map_box($post){
 wp_nonce_field('deniz_zone_save','deniz_zone_nonce'); $poly=get_post_meta($post->ID,'zone_polygon',true); ?>
<p>Haritada tıklayarak bölgenin sınırlarını çiz. Son noktadan sonra <b>Poligonu Tamamla</b> butonuna bas.</p><div id="deniz-zone-map" style="height:500px;border:1px solid #ccd0d4;border-radius:10px"></div>
<p><button type="button" class="button button-primary" id="deniz-finish-poly">Poligonu Tamamla</button> <button type="button" class="button" id="deniz-clear-poly">Temizle</button></p>
<textarea id="deniz-zone-polygon" name="zone_polygon" style="width:100%;height:90px" readonly><?php echo esc_textarea($poly); ?></textarea>
<?php }
function deniz_zone_prices_box($post){
 $matrix=get_post_meta($post->ID,'zone_prices',true); if(!is_array($matrix))$matrix=[];
 echo '<table class="widefat striped"><thead><tr><th>Araç</th><th>Tek Yön</th><th>Gidiş-Dönüş</th></tr></thead><tbody>';
 foreach(deniz_vehicle_list() as $v){$id=$v->ID;echo '<tr><td><strong>'.esc_html($v->post_title).'</strong></td><td><input type="number" step="0.01" min="0" name="zone_prices['.$id.'][oneway]" value="'.esc_attr($matrix[$id]['oneway']??'').'"></td><td><input type="number" step="0.01" min="0" name="zone_prices['.$id.'][return]" value="'.esc_attr($matrix[$id]['return']??'').'"></td></tr>';}
 echo '</tbody></table><p>Aynı polygon için her araç sınıfına ayrı net satış fiyatı verebilirsin.</p>';
}
function deniz_vehicle_box($post){
 $p=get_post_meta($post->ID,'vehicle_pax',true);$b=get_post_meta($post->ID,'vehicle_bags',true);$f=get_post_meta($post->ID,'vehicle_features',true); ?>
<p><label>Max Yolcu</label><br><input type="number" min="1" name="vehicle_pax" value="<?php echo esc_attr($p); ?>"></p>
<p><label>Max Bagaj</label><br><input type="number" min="0" name="vehicle_bags" value="<?php echo esc_attr($b); ?>"></p>
<p><label>Özellikler (her satıra bir özellik)</label><br><textarea name="vehicle_features" style="width:100%;height:100px"><?php echo esc_textarea($f); ?></textarea></p>
<?php }
add_action('save_post_transfer-zone',function($id){
 if(!isset($_POST['deniz_zone_nonce'])||!wp_verify_nonce($_POST['deniz_zone_nonce'],'deniz_zone_save')||!current_user_can('edit_post',$id))return;
 $raw=wp_unslash($_POST['zone_polygon']??''); $arr=json_decode($raw,true); if(is_array($arr))update_post_meta($id,'zone_polygon',wp_json_encode($arr));
 $prices=[]; foreach((array)($_POST['zone_prices']??[]) as $vid=>$row){$vid=(int)$vid;$prices[$vid]=['oneway'=>isset($row['oneway'])?floatval($row['oneway']):'','return'=>isset($row['return'])?floatval($row['return']):''];} update_post_meta($id,'zone_prices',$prices);
});
add_action('save_post_vehicle',function($id){ if(!current_user_can('edit_post',$id))return; if(isset($_POST['vehicle_pax']))update_post_meta($id,'vehicle_pax',(int)$_POST['vehicle_pax']); if(isset($_POST['vehicle_bags']))update_post_meta($id,'vehicle_bags',(int)$_POST['vehicle_bags']); if(isset($_POST['vehicle_features']))update_post_meta($id,'vehicle_features',sanitize_textarea_field($_POST['vehicle_features'])); });

add_action('admin_enqueue_scripts',function($hook){
 $screen=get_current_screen(); if(!$screen||$screen->post_type!=='transfer-zone')return;
 wp_enqueue_style('leaflet','https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',[], '1.9.4');
 wp_enqueue_script('leaflet','https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',[], '1.9.4',true);
 wp_enqueue_script('deniz-zone-admin',get_template_directory_uri().'/assets/js/admin-zone.js',['leaflet'],'2.0',true);
});
