<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function(){
 add_submenu_page('deniz-os','Hotel Manager','Hotel Manager','manage_options','deniz-hotel-manager','deniz_hotel_manager_page');
 add_submenu_page('deniz-os','Rezervasyonlar','Rezervasyonlar','manage_options','deniz-bookings','deniz_bookings_page');
},30);

function deniz_hic_preview_key($token){return 'deniz_hic_'.sanitize_key($token);}
function deniz_hic_get_preview($token){$v=get_transient(deniz_hic_preview_key($token));return is_array($v)?$v:null;}
function deniz_hic_set_preview($token,$data){set_transient(deniz_hic_preview_key($token),$data,2*HOUR_IN_SECONDS);}
function deniz_hic_history(){ $h=get_option('deniz_hotel_import_history',[]); return is_array($h)?$h:[]; }
function deniz_hic_add_history($row){$h=deniz_hic_history();array_unshift($h,$row);$h=array_slice($h,0,50);update_option('deniz_hotel_import_history',$h,false);}
function deniz_hic_candidate_key($x){return strtolower(($x['osm_type']??'').':'.($x['osm_id']??'').':'.round((float)($x['lat']??0),5).':'.round((float)($x['lng']??0),5).':'.sanitize_title($x['name']??''));}
function deniz_hic_analyze_candidate($x,$region){
 global $wpdb;$t=deniz_tables();$name=trim((string)($x['name']??''));$lat=(float)($x['lat']??0);$lng=(float)($x['lng']??0);$status='safe';$message='Polygon içinde, import için uygun.';$existing=0;
 if(!$name||!$lat||!$lng){$status='error';$message='Ad veya koordinat eksik.';}
 elseif(!deniz_point_in_polygon($lat,$lng,deniz_scan_polygon_points(json_decode($region->polygon,true)))){$status='error';$message='Bölge polygonu dışında.';}
 else{
  static $columns=null;if($columns===null)$columns=$wpdb->get_col("SHOW COLUMNS FROM {$t['hotels']}",0);if(!empty($x['osm_type'])&&!empty($x['osm_id'])&&in_array('osm_type',(array)$columns,true)&&in_array('osm_id',(array)$columns,true))$existing=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['hotels']} WHERE osm_type=%s AND osm_id=%d LIMIT 1",sanitize_key($x['osm_type']),absint($x['osm_id'])));
  if(!$existing){$rows=$wpdb->get_results($wpdb->prepare("SELECT id,name,lat,lng FROM {$t['hotels']} WHERE region_id=%d",$region->id));$norm=deniz_normalize_hotel_name($name);foreach($rows as $r){if(deniz_normalize_hotel_name($r->name)===$norm && deniz_haversine($lat,$lng,$r->lat,$r->lng)<0.45){$existing=(int)$r->id;break;}}}
  if($existing){$status='duplicate';$message='Mevcut otel kaydıyla eşleşiyor (#'.$existing.').';}
 }
 $x['status']=$status;$x['message']=$message;$x['existing_id']=$existing;return $x;
}
function deniz_hic_render_preview($preview){
 if(!$preview||empty($preview['candidates']))return '<div class="dos-empty">Henüz preview yok.</div>';
 $safe=0;$dup=0;$err=0;foreach($preview['candidates'] as $x){if(($x['status']??'')==='safe')$safe++;elseif(($x['status']??'')==='duplicate')$dup++;else$err++;}
 ob_start();echo '<section class="hic-preview"><div class="hic-stats"><span><b>'.count($preview['candidates']).'</b>Aday</span><span class="ok"><b>'.$safe.'</b>Safe</span><span class="warn"><b>'.$dup.'</b>Duplicate</span><span><b>'.$err.'</b>Hata</span></div><div class="dos-toolbar"><div><button type="button" class="dos-mini hic-select-safe">Safe Seç</button> <button type="button" class="dos-mini hic-clear">Temizle</button></div><button type="button" id="hic-commit-safe" class="dos-btn" data-token="'.esc_attr($preview['token']).'">Seçili Otelleri İçe Aktar</button></div><div id="hic-commit-result"></div><div class="dos-table-wrap"><table class="dos-table"><thead><tr><th>Use</th><th>Otel</th><th>Adres / Koordinat</th><th>Kaynak</th><th>Durum</th></tr></thead><tbody>';
 foreach($preview['candidates'] as $i=>$x){$st=$x['status']??'review';echo '<tr><td><input class="hic-check" type="checkbox" name="selected[]" value="'.$i.'" '.checked($st,'safe',false).' '.disabled($st!=='safe',true,false).'></td><td><b>'.esc_html($x['name']??'').'</b></td><td>'.esc_html($x['address']??'').'<small>'.esc_html(($x['lat']??'').' , '.($x['lng']??'')).'</small></td><td>'.esc_html($x['source']??'osm').'</td><td><span class="hic-pill '.$st.'">'.esc_html(strtoupper($st)).'</span><small>'.esc_html($x['message']??'').'</small></td></tr>';}
 echo '</tbody></table></div></section>';return ob_get_clean();
}

add_action('wp_ajax_deniz_hic_commit_ajax',function(){
    check_ajax_referer('deniz_os','nonce');
    if(!current_user_can('manage_options')) wp_send_json_error(['message'=>'Yetki yok.']);
    global $wpdb; $t=deniz_tables();
    $token=sanitize_key($_POST['preview_token']??'');
    $preview=deniz_hic_get_preview($token);
    if(!$preview) wp_send_json_error(['message'=>'Preview süresi dolmuş veya bulunamadı. Bölgeyi tekrar tarayın.']);
    $selected=array_values(array_unique(array_map('absint',(array)($_POST['selected']??[]))));
    if(!$selected) wp_send_json_error(['message'=>'Safe otel seçilmedi.']);
    [$region,$poly]=deniz_scan_region_context(absint($preview['region_id']??0));
    if(!$region || count($poly)<3) wp_send_json_error(['message'=>'Bölge veya polygon bulunamadı.']);
    $added=0;$skipped=0;$ids=[];$imported=[];$errors=[];
    foreach(array_slice($selected,0,20) as $i){
        $x=$preview['candidates'][$i]??null;
        if(!$x || ($x['status']??'')!=='safe'){ $skipped++; continue; }
        $lat=(float)($x['lat']??0);$lng=(float)($x['lng']??0);
        if(!$lat||!$lng||!deniz_point_in_polygon($lat,$lng,$poly)){$skipped++;$errors[]=['index'=>$i,'name'=>$x['name']??'','message'=>'Koordinat seçili bölge polygonu dışında.'];continue;}
        $fresh=deniz_hic_analyze_candidate($x,$region);
        if(($fresh['status']??'')!=='safe'){$skipped++;$errors[]=['index'=>$i,'name'=>$fresh['name']??'','message'=>$fresh['message']??'Kayıt uygun değil.'];$preview['candidates'][$i]=$fresh;continue;}
        $GLOBALS['twt_hotel_insert_error']='';$hid=deniz_scan_hotel_upsert($region,$fresh,$fresh['source']??'hotel-import-center');
        if($hid){$ids[]=(int)$hid;$imported[]=$i;$added++;}else{$skipped++;$errors[]=['index'=>$i,'name'=>$fresh['name'],'message'=>$GLOBALS['twt_hotel_insert_error']?:'Kayıt eklenemedi.'];}
    }
    deniz_hic_add_history([
      'batch'=>'DNZ-HI-'.gmdate('Ymd-His'),'created_at'=>current_time('mysql'),
      'region_id'=>(int)$region->id,'region'=>$region->name,'source'=>$preview['source']??'scan',
      'added'=>$added,'skipped'=>$skipped,'hotel_ids'=>$ids
    ]);
    if($added>0){
      foreach($imported as $i){ if(isset($preview['candidates'][$i])){$preview['candidates'][$i]['status']='imported';$preview['candidates'][$i]['message']='Hotel Directory veritabanına aktarıldı.';} }
    }
    deniz_hic_set_preview($token,$preview);
    wp_send_json_success([
      'added'=>$added,'skipped'=>$skipped,'ids'=>$ids,'imported'=>$imported,'errors'=>$errors,
      'directory_url'=>admin_url('admin.php?page=deniz-hotel-manager&tab=directory&imported='.$added)
    ]);
});

function deniz_hotel_manager_page(){
 global $wpdb;$t=deniz_tables();$tab=sanitize_key($_GET['tab']??'scan');if(!in_array($tab,['scan','directory','single','excel','coverage','history'],true))$tab='scan';
 $regions=$wpdb->get_results("SELECT r.*,c.name city,co.name country FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id LEFT JOIN {$t['countries']} co ON co.id=c.country_id WHERE r.active=1 ORDER BY co.name,c.name,r.name");
 if(isset($_POST['deniz_hic_commit'])&&check_admin_referer('deniz_hic_commit')){$token=sanitize_key($_POST['preview_token']??'');$preview=deniz_hic_get_preview($token);$selected=array_map('absint',(array)($_POST['selected']??[]));$added=0;if($preview){$region=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d",absint($preview['region_id'])));foreach($selected as $i){$x=$preview['candidates'][$i]??null;if(!$x||($x['status']??'')!=='safe'||!$region)continue;$hid=deniz_scan_hotel_upsert($region,$x,$x['source']??'hotel-import-center');if($hid){deniz_sync_all_hotel_routes($hid);$added++;}}deniz_hic_add_history(['batch'=>'DNZ-HI-'.gmdate('Ymd-His'),'created_at'=>current_time('mysql'),'region_id'=>$preview['region_id'],'region'=>$preview['region_name'],'source'=>$preview['source']??'scan','added'=>$added]);delete_transient(deniz_hic_preview_key($token));echo '<div class="notice notice-success"><p>'.$added.' otel içe aktarıldı.</p></div>';}}
 $rid=absint($_GET['region_id']??0);$preview_token=sanitize_key($_GET['preview_token']??'');$preview=$preview_token?deniz_hic_get_preview($preview_token):null;
 deniz_admin_shell_start('Hotel Import Center','Plugin örneğindeki güvenli akış: bölge seç → tara/analyze → preview → safe kayıtları seç → commit. Tarama hiçbir zaman doğrudan veritabanına yazmaz.');
 echo '<nav class="hic-tabs">';foreach(['scan'=>'Region Scan','directory'=>'Hotel Directory','single'=>'Add One Hotel','excel'=>'Excel Import','coverage'=>'Region Coverage','history'=>'Import History'] as $k=>$label)echo '<a class="'.($tab===$k?'active':'').'" href="'.esc_url(add_query_arg(['page'=>'deniz-hotel-manager','tab'=>$k],admin_url('admin.php'))).'">'.esc_html($label).'</a>';echo '</nav>';
 if($tab==='scan'){
  echo '<div class="dos-panel"><div class="dos-2"><label>Transfer Bölgesi<select id="hic-region"><option value="">Bölge seçin</option>';foreach($regions as $r)echo '<option value="'.$r->id.'" '.selected($rid,$r->id,false).'>'.esc_html($r->country.' / '.$r->city.' / '.$r->name).'</option>';echo '</select></label><label>Tarama limiti<select id="hic-limit"><option>40</option><option>80</option><option>150</option><option>250</option></select></label></div><p class="dos-muted">OSM/Overpass önce polygon bounding-box içinde aranır, sonuçlar polygon içinde tekrar doğrulanır. Overpass zayıf kalırsa Photon ve Nominatim fallback kullanılır.</p><button class="dos-btn" id="hic-scan">Bölgedeki Otelleri Tara</button><div id="hic-progress" class="hic-progress"></div></div>';
  if($preview)echo deniz_hic_render_preview($preview);
 } elseif($tab==='directory'){
  $q=sanitize_text_field($_GET['s']??'');$where='1=1';$args=[];if($q){$where.=' AND h.name LIKE %s';$args[]='%'.$wpdb->esc_like($q).'%';}$sql="SELECT h.*,r.name region,c.name city FROM {$t['hotels']} h LEFT JOIN {$t['regions']} r ON r.id=h.region_id LEFT JOIN {$t['cities']} c ON c.id=h.city_id WHERE $where ORDER BY h.name LIMIT 1500";if($args)$sql=$wpdb->prepare($sql,...$args);$rows=$wpdb->get_results($sql);echo '<div class="dos-panel"><form method="get" class="dos-filterbar"><input type="hidden" name="page" value="deniz-hotel-manager"><input type="hidden" name="tab" value="directory"><input name="s" value="'.esc_attr($q).'" placeholder="Otel ara"><button class="dos-btn">Ara</button><a class="dos-btn secondary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=deniz_export_hotels'),'deniz_export_hotels')).'">Excel İndir</a><button type="button" class="dos-btn secondary" id="duplicate-scan">Duplicate Tara</button></form><div id="duplicate-results"></div><div class="dos-table-wrap"><table class="dos-table"><thead><tr><th>Otel</th><th>Şehir / Bölge</th><th>Koordinat</th><th>Kaynak</th><th>SEO</th><th></th></tr></thead><tbody>';foreach($rows as $h)echo '<tr><td><b>'.esc_html($h->name).'</b><small>'.esc_html($h->address).'</small></td><td>'.esc_html($h->city.' / '.$h->region).'</td><td>'.esc_html($h->lat.', '.$h->lng).'</td><td>'.esc_html($h->source).'</td><td>'.($h->seo_title?'✓':'—').'</td><td><button class="dos-mini hm-edit" data-id="'.$h->id.'">Düzenle</button> <button class="dos-mini hm-sync" data-id="'.$h->id.'">SEO Sayfa</button></td></tr>';echo '</tbody></table></div></div>';
 } elseif($tab==='single'){
  echo '<div class="dos-panel"><h2>Otel Ekle / Güncelle</h2><form id="hotel-edit-form"><input type="hidden" name="id" id="hm_id"><label>Bölge<select name="region_id" id="hm_region" required><option value="">Seçin</option>';foreach($regions as $r)echo '<option value="'.$r->id.'">'.esc_html($r->country.' / '.$r->city.' / '.$r->name).'</option>';echo '</select></label><label>Otel adı<input name="name" id="hm_name" required></label><div class="dos-2"><label>Latitude<input name="lat" id="hm_lat" required></label><label>Longitude<input name="lng" id="hm_lng" required></label></div><label>Adres<textarea name="address" id="hm_address"></textarea></label><div class="dos-2"><label>Telefon<input name="phone" id="hm_phone"></label><label>Website<input name="website" id="hm_website"></label></div><div class="dos-2"><label>Yıldız<input name="stars" id="hm_stars" type="number" min="0" max="5" step="0.5"></label><label>Aktif<select name="active" id="hm_active"><option value="1">Aktif</option><option value="0">Pasif</option></select></label></div><label>SEO Title<input name="seo_title" id="hm_seo_title" maxlength="60"></label><label>Meta Description<textarea name="seo_description" id="hm_seo_description" maxlength="160"></textarea></label><button class="dos-btn full">Oteli Kaydet + Landing Page Üret</button><div id="hotel-save-msg"></div></form></div>';
 } elseif($tab==='excel'){
  echo '<div class="dos-panel"><h2>Excel / CSV Import</h2><p>Kolonlar: <code>name, region, lat, lng, address, phone, website, stars, seo_title, seo_description</code>.</p><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="deniz_import_hotels">';wp_nonce_field('deniz_import_hotels');echo '<input type="file" name="hotel_file" accept=".xlsx,.csv" required><button class="dos-btn" style="margin-top:12px">İçe Aktar</button></form></div>';
 } elseif($tab==='coverage'){
  echo '<div class="dos-panel"><table class="dos-table"><thead><tr><th>Ülke</th><th>Şehir</th><th>Bölge</th><th>Polygon</th><th>Oteller</th><th>Durum</th><th></th></tr></thead><tbody>';foreach($regions as $r){$n=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['hotels']} WHERE region_id=%d",$r->id));$st=$n===0?'Empty':($n<5?'Low':'Good');echo '<tr><td>'.esc_html($r->country).'</td><td>'.esc_html($r->city).'</td><td><b>'.esc_html($r->name).'</b></td><td>'.($r->polygon?'✓':'—').'</td><td>'.$n.'</td><td><span class="hic-pill '.strtolower($st).'">'.$st.'</span></td><td><a class="dos-mini" href="'.esc_url(add_query_arg(['page'=>'deniz-hotel-manager','tab'=>'scan','region_id'=>$r->id],admin_url('admin.php'))).'">Scan</a></td></tr>'; }echo '</tbody></table></div>';
 } else {
  $hist=deniz_hic_history();echo '<div class="dos-panel"><h2>Import History</h2><p>Her commit ayrı batch olarak kaydedilir.</p><table class="dos-table"><thead><tr><th>Batch</th><th>Tarih</th><th>Bölge</th><th>Kaynak</th><th>Eklenen</th></tr></thead><tbody>';foreach($hist as $h)echo '<tr><td><b>'.esc_html($h['batch']??'').'</b></td><td>'.esc_html($h['created_at']??'').'</td><td>'.esc_html($h['region']??'').'</td><td>'.esc_html($h['source']??'').'</td><td>'.intval($h['added']??0).'</td></tr>';echo '</tbody></table></div>';
 }
 deniz_admin_shell_end();
}

add_action('wp_ajax_deniz_save_hotel','deniz_ajax_save_hotel');
function deniz_ajax_save_hotel(){check_ajax_referer('deniz_os','nonce'); if(!current_user_can('manage_options'))wp_send_json_error('Yetki yok'); global $wpdb;$t=deniz_tables();$rid=absint($_POST['region_id']);$region=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE id=%d",$rid));if(!$region)wp_send_json_error('Bölge bulunamadı');$id=absint($_POST['id']??0);$name=sanitize_text_field($_POST['name']??'');$lat=(float)($_POST['lat']??0);$lng=(float)($_POST['lng']??0);if(!$name||!$lat||!$lng)wp_send_json_error('Ad ve koordinat gerekli.');$d=['city_id'=>$region->city_id,'region_id'=>$rid,'name'=>$name,'slug'=>sanitize_title($name),'lat'=>$lat,'lng'=>$lng,'address'=>sanitize_textarea_field($_POST['address']??''),'phone'=>sanitize_text_field($_POST['phone']??''),'website'=>esc_url_raw($_POST['website']??''),'stars'=>(float)($_POST['stars']??0),'seo_title'=>sanitize_text_field($_POST['seo_title']??''),'seo_description'=>sanitize_textarea_field($_POST['seo_description']??''),'source'=>'manual','active'=>absint($_POST['active']??1)];if($id)$wpdb->update($t['hotels'],$d,['id'=>$id]);else{$wpdb->insert($t['hotels'],$d);$id=$wpdb->insert_id;}deniz_sync_all_hotel_routes($id);wp_send_json_success(['id'=>$id,'message'=>'Otel kaydedildi ve uygun transfer landing page kayıtları senkronlandı.']);}
add_action('wp_ajax_deniz_get_hotel','deniz_ajax_get_hotel');function deniz_ajax_get_hotel(){check_ajax_referer('deniz_os','nonce');if(!current_user_can('manage_options'))wp_send_json_error('Yetki yok',403);global $wpdb;$t=deniz_tables();$h=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE id=%d",absint($_GET['id'])));$h?wp_send_json_success($h):wp_send_json_error('Bulunamadı');}
add_action('wp_ajax_deniz_sync_hotel','deniz_ajax_sync_hotel');function deniz_ajax_sync_hotel(){check_ajax_referer('deniz_os','nonce');if(!current_user_can('manage_options'))wp_send_json_error('Yetki yok',403);$id=absint($_POST['id']);deniz_sync_all_hotel_routes($id);wp_send_json_success('SEO transfer sayfaları senkronlandı.');}
add_action('wp_ajax_deniz_duplicates','deniz_ajax_duplicates');function deniz_ajax_duplicates(){check_ajax_referer('deniz_os','nonce');if(!current_user_can('manage_options'))wp_send_json_error('Yetki yok',403);global $wpdb;$t=deniz_tables();$rows=$wpdb->get_results("SELECT id,name,lat,lng,region_id FROM {$t['hotels']} WHERE active=1 ORDER BY region_id,name");$groups=[];foreach($rows as $h){$key=$h->region_id.'|'.deniz_normalize_hotel_name($h->name);$groups[$key][]=$h;}$dups=[];foreach($groups as $g)if(count($g)>1)$dups[]=array_map(fn($x)=>['id'=>(int)$x->id,'name'=>$x->name,'lat'=>$x->lat,'lng'=>$x->lng],$g);wp_send_json_success($dups);}

function deniz_xlsx_col($n){$s='';while($n>0){$n--;$s=chr(65+$n%26).$s;$n=intdiv($n,26);}return $s;}
function deniz_export_xlsx($rows,$headers){if(!class_exists('ZipArchive'))return false;$tmp=wp_tempnam('deniz-hotels.xlsx');$zip=new ZipArchive();$zip->open($tmp,ZipArchive::OVERWRITE);$xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';$all=array_merge([$headers],$rows);foreach($all as $ri=>$row){$r=$ri+1;$xml.='<row r="'.$r.'">';$ci=1;foreach($row as $v){$c=deniz_xlsx_col($ci++).$r;$xml.='<c r="'.$c.'" t="inlineStr"><is><t>'.htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES,'UTF-8').'</t></is></c>';}$xml.='</row>';}$xml.='</sheetData></worksheet>';$zip->addFromString('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');$zip->addFromString('_rels/.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');$zip->addFromString('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Hotels" sheetId="1" r:id="rId1"/></sheets></workbook>');$zip->addFromString('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');$zip->addFromString('xl/worksheets/sheet1.xml',$xml);$zip->close();return $tmp;}
add_action('admin_post_deniz_export_hotels',function(){if(!current_user_can('manage_options'))wp_die('Yetki yok');check_admin_referer('deniz_export_hotels');global $wpdb;$t=deniz_tables();$rows=$wpdb->get_results("SELECT h.name,r.name region,h.lat,h.lng,h.address,h.phone,h.website,h.stars,h.seo_title,h.seo_description FROM {$t['hotels']} h LEFT JOIN {$t['regions']} r ON r.id=h.region_id ORDER BY r.name,h.name",ARRAY_A);$data=array_map('array_values',$rows);$f=deniz_export_xlsx($data,['name','region','lat','lng','address','phone','website','stars','seo_title','seo_description']);if(!$f)wp_die('ZipArchive gerekli.');header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="deniz-hotels-'.date('Y-m-d').'.xlsx"');readfile($f);@unlink($f);exit;});
function deniz_read_xlsx($file){
 if(!class_exists('ZipArchive'))return [];$z=new ZipArchive();if($z->open($file)!==true)return [];
 $ss=[];$sx=$z->getFromName('xl/sharedStrings.xml');
 if($sx){$x=simplexml_load_string($sx);$ns=$x->getNamespaces(true);$m=$x->children($ns['']??'http://schemas.openxmlformats.org/spreadsheetml/2006/main');foreach($m->si as $si){$parts=[];if(isset($si->t))$parts[]=(string)$si->t;else foreach($si->r as $r)$parts[]=(string)$r->t;$ss[]=implode('',$parts);}}
 $sheet=$z->getFromName('xl/worksheets/sheet1.xml');$z->close();if(!$sheet)return [];$x=simplexml_load_string($sheet);$ns=$x->getNamespaces(true);$m=$x->children($ns['']??'http://schemas.openxmlformats.org/spreadsheetml/2006/main');$out=[];
 foreach($m->sheetData->row as $row){$vals=[];foreach($row->c as $c){$a=$c->attributes();$ref=(string)$a['r'];preg_match('/([A-Z]+)/',$ref,$mm);$col=0;foreach(str_split($mm[1]) as $ch)$col=$col*26+(ord($ch)-64);$type=(string)$a['t'];$v=$type==='inlineStr'?(string)$c->is->t:(string)$c->v;if($type==='s')$v=$ss[(int)$v]??'';$vals[$col-1]=$v;}ksort($vals);$out[]=array_values($vals);}return $out;
}
add_action('admin_post_deniz_import_hotels',function(){if(!current_user_can('manage_options'))wp_die('Yetki yok');check_admin_referer('deniz_import_hotels');if(empty($_FILES['hotel_file']['tmp_name']))wp_die('Dosya yok');$name=strtolower($_FILES['hotel_file']['name']);$rows=str_ends_with($name,'.csv')?array_map('str_getcsv',file($_FILES['hotel_file']['tmp_name'])):deniz_read_xlsx($_FILES['hotel_file']['tmp_name']);if(!$rows)wp_die('Dosya okunamadı');$headers=array_map(fn($x)=>sanitize_key($x),array_shift($rows));global $wpdb;$t=deniz_tables();$saved=0;foreach($rows as $row){$d=array_combine($headers,array_pad($row,count($headers),''));if(empty($d['name'])||empty($d['region']))continue;$region=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['regions']} WHERE name=%s LIMIT 1",$d['region']));if(!$region)continue;$lat=(float)($d['lat']??0);$lng=(float)($d['lng']??0);if(!$lat||!$lng)continue;$norm=deniz_normalize_hotel_name($d['name']);$cands=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE region_id=%d",$region->id));$id=0;foreach($cands as $c){if(deniz_normalize_hotel_name($c->name)===$norm && deniz_haversine($lat,$lng,$c->lat,$c->lng)<0.5){$id=$c->id;break;}}$rec=['city_id'=>$region->city_id,'region_id'=>$region->id,'name'=>sanitize_text_field($d['name']),'slug'=>sanitize_title($d['name']),'lat'=>$lat,'lng'=>$lng,'address'=>sanitize_text_field($d['address']??''),'phone'=>sanitize_text_field($d['phone']??''),'website'=>esc_url_raw($d['website']??''),'stars'=>(float)($d['stars']??0),'seo_title'=>sanitize_text_field($d['seo_title']??''),'seo_description'=>sanitize_textarea_field($d['seo_description']??''),'source'=>'excel','active'=>1];$id?$wpdb->update($t['hotels'],$rec,['id'=>$id]):($wpdb->insert($t['hotels'],$rec)&&$id=$wpdb->insert_id);if($id){deniz_sync_all_hotel_routes($id);$saved++;}}wp_safe_redirect(admin_url('admin.php?page=deniz-hotel-manager&imported='.$saved));exit;});

function deniz_bookings_page(){
 global $wpdb;$t=deniz_tables();
 $status=sanitize_key($_GET['status']??'');if(!in_array($status,['new','confirmed','assigned','completed','cancelled'],true))$status='';$q=sanitize_text_field(wp_unslash($_GET['q']??''));$paged=max(1,absint($_GET['paged']??1));$offset=($paged-1)*25;
 $where=['1=1'];$args=[];
 if($status){$where[]='b.status=%s';$args[]=$status;}
 if($q){$like='%'.$wpdb->esc_like($q).'%';$where[]='(b.booking_ref LIKE %s OR b.first_name LIKE %s OR b.last_name LIKE %s OR b.phone LIKE %s OR b.email LIKE %s OR b.pickup_label LIKE %s OR b.dropoff_label LIKE %s)';for($i=0;$i<7;$i++)$args[]=$like;}
 $sql="SELECT b.*,v.name vehicle,r.name region,h.name hotel,a.name airport,a.iata FROM {$t['bookings']} b LEFT JOIN {$t['vehicles']} v ON v.id=b.vehicle_id LEFT JOIN {$t['regions']} r ON r.id=b.region_id LEFT JOIN {$t['hotels']} h ON h.id=b.hotel_id LEFT JOIN {$t['airports']} a ON a.id=b.airport_id WHERE ".implode(' AND ',$where)." ORDER BY b.created_at DESC,b.id DESC LIMIT 25 OFFSET {$offset}";
 $rows=$args?$wpdb->get_results($wpdb->prepare($sql,$args)):$wpdb->get_results($sql);
 $count_sql="SELECT COUNT(*) FROM {$t['bookings']} b WHERE ".implode(' AND ',$where);$total=(int)$wpdb->get_var($args?$wpdb->prepare($count_sql,$args):$count_sql);
 $today=current_time('Y-m-d');$today_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE pickup_date=%s AND status NOT IN ('cancelled')",$today));$new_count=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['bookings']} WHERE status='new'");$cash_rows=$wpdb->get_results("SELECT currency,SUM(total_amount) amount FROM {$t['bookings']} WHERE payment_method='cash_to_driver' AND payment_status='cash_due' AND status<>'cancelled' GROUP BY currency");$cash_display=implode(' · ',array_map(function($r){return $r->currency.' '.number_format((float)$r->amount,2);},$cash_rows));
 deniz_admin_shell_start('Rezervasyonlar','Canlı rezervasyon listesi, durum yönetimi, müşteri detayları ve nakit tahsilat görünümü.');
 echo '<div class="dos-grid stats"><div class="dos-card"><span>Bugünkü transfer</span><strong>'.$today_count.'</strong></div><div class="dos-card"><span>Yeni rezervasyon</span><strong>'.$new_count.'</strong></div><div class="dos-card"><span>Nakit bekleyen</span><strong>'.esc_html($cash_display?:'—').'</strong></div></div>';
 echo '<div class="dos-panel"><div class="dos-booking-toolbar"><form method="get"><input type="hidden" name="page" value="deniz-bookings"><input name="q" value="'.esc_attr($q).'" placeholder="Ref, yolcu, telefon, otel..."><select name="status"><option value="">Tüm durumlar</option>';foreach(['new'=>'Yeni','confirmed'=>'Onaylı','assigned'=>'Atandı','completed'=>'Tamamlandı','cancelled'=>'İptal'] as $k=>$v)echo '<option value="'.$k.'" '.selected($status,$k,false).'>'.$v.'</option>';echo '</select><button class="dos-btn secondary">Filtrele</button></form><a class="dos-btn" href="'.esc_url(wp_nonce_url(admin_url('admin.php?page=deniz-bookings&deniz_export_bookings=1'),'deniz_export_bookings')).'">CSV İndir</a></div><div class="dos-table-wrap"><table class="dos-table"><thead><tr><th>Ref</th><th>Tarih</th><th>Misafir</th><th>Rota</th><th>Araç</th><th>Tutar</th><th>Ödeme</th><th>Operasyon</th></tr></thead><tbody>';
 if(!$rows)echo '<tr><td colspan="8">Kayıt bulunamadı.</td></tr>';
 foreach($rows as $b){$booking_extra_rows=$wpdb->get_results($wpdb->prepare("SELECT be.*,e.name FROM {$t['booking_extras']} be LEFT JOIN {$t['extras']} e ON e.id=be.extra_id WHERE be.booking_id=%d",$b->id));$extra_html='';foreach($booking_extra_rows as $x)$extra_html.='<small>＋ '.esc_html(twt_extra_receipt_name($x).' × '.(int)$x->qty.' · '.$b->currency.' '.number_format((float)$x->total_price,2)).'</small>';$mail=twt_mail_state($b->id);$mail_errors=implode(' · ',array_filter($mail['errors']??[]));$mail_label=!$mail?'Bildirim kaydı yok':((!empty($mail['customer'])?'Müşteri SMTP kabul ✓':'Müşteri bekliyor').' · '.(!empty($mail['admin'])?'Admin SMTP kabul ✓':'Admin bekliyor'));$voucher=twt_voucher_url($b);echo '<tr><td><b>'.esc_html($b->booking_ref).'</b><small>'.esc_html($b->created_at).'</small><small>'.esc_html($mail_label).'</small><small>'.esc_html($mail_errors).'</small>'.((empty($mail['customer'])||empty($mail['admin']))?'<a class="dos-mini" href="'.esc_url(wp_nonce_url(add_query_arg(['action'=>'twt_retry_mail','booking_id'=>$b->id],admin_url('admin-post.php')),'twt_retry_mail_'.$b->id)).'">E-postayı yeniden gönder</a>':'').'</td><td>'.esc_html($b->pickup_date.' '.$b->pickup_time).($b->direction==='return'?'<small>Dönüş: '.esc_html($b->return_date.' '.$b->return_time).'</small>':'').'</td><td><b>'.esc_html($b->first_name.' '.$b->last_name).'</b><small>'.esc_html($b->phone).'</small><small>'.esc_html($b->email).'</small></td><td>'.esc_html($b->pickup_label).' → '.esc_html($b->dropoff_label).'<small>'.esc_html(trim(twt_snapshot_name($b->id,'region',$b->region?:'').' '.($b->hotel?:''))).'</small></td><td>'.esc_html(twt_snapshot_name($b->id,'vehicle',$b->vehicle)).$extra_html.'<small>'.intval($b->passengers).' pax · '.intval($b->bags).' bag</small></td><td><b>'.esc_html($b->currency).' '.number_format((float)$b->total_amount,2).'</b><small>'.esc_html($b->flight_number?:'Flight not given').'</small></td><td>'.esc_html($b->payment_method==='cash_to_driver'?'Sürücüye nakit':$b->payment_method).'<small>'.esc_html($b->payment_status==='cash_due'?'Tahsilat bekliyor':$b->payment_status).'</small></td><td><form method="post" class="dos-booking-actions">';wp_nonce_field('deniz_booking_status');echo '<input type="hidden" name="booking_id" value="'.intval($b->id).'"><select name="status">';foreach(['new'=>'Yeni','confirmed'=>'Onaylı','assigned'=>'Atandı','completed'=>'Tamamlandı','cancelled'=>'İptal'] as $k=>$v)echo '<option value="'.$k.'" '.selected($b->status,$k,false).'>'.$v.'</option>';echo '</select><button class="dos-btn ghost" name="deniz_booking_status_save">Kaydet</button><a class="dos-mini" target="_blank" href="'.esc_url($voucher).'">Voucher</a></form></td></tr>';}
 echo '</tbody></table></div><nav class="twt-pagination" aria-label="Rezervasyon sayfaları">'.paginate_links(['base'=>add_query_arg('paged','%#%'),'format'=>'','current'=>$paged,'total'=>max(1,(int)ceil($total/25))]).'</nav><p class="dos-muted">'.intval($total).' rezervasyon · Sayfa '.intval($paged).'</p></div>';deniz_admin_shell_end();
}

/* =========================================================
 * Hotel Import Center - safe preview scan pipeline
 * Inspired by the supplied operational plugin: scan never writes directly.
 * Browser scans small bbox tiles; candidates are kept in a transient preview.
 * ======================================================= */
function deniz_hic_merge_candidates($token,$region_id,$items,$source){
    global $wpdb; $t=deniz_tables();
    $preview=deniz_hic_get_preview($token);
    if(!$preview || (int)$preview['region_id']!==(int)$region_id) return new WP_Error('preview','Preview bulunamadı.');
    [$region,$poly]=deniz_scan_region_context($region_id);
    if(!$region || count($poly)<3) return new WP_Error('region','Bölge/polygon bulunamadı.');
    $map=[];
    foreach((array)$preview['candidates'] as $x) $map[deniz_hic_candidate_key($x)]=$x;
    $accepted=0;$outside=0;
    foreach((array)$items as $x){
        $lat=(float)($x['lat']??0);$lng=(float)($x['lng']??0);$name=trim((string)($x['name']??''));
        if(!$name||!$lat||!$lng) continue;
        if(!deniz_point_in_polygon($lat,$lng,$poly)){ $outside++; continue; }
        $x['source']=$source;
        $x=deniz_hic_analyze_candidate($x,$region);
        $map[deniz_hic_candidate_key($x)]=$x;$accepted++;
    }
    $preview['candidates']=array_values($map);
    $preview['stats']['outside']=($preview['stats']['outside']??0)+$outside;
    deniz_hic_set_preview($token,$preview);
    return ['accepted'=>$accepted,'outside'=>$outside,'total'=>count($preview['candidates'])];
}
add_action('wp_ajax_deniz_hic_prepare',function(){
    check_ajax_referer('deniz_os','nonce'); if(!current_user_can('manage_options')) wp_send_json_error('Yetki yok');
    $rid=absint($_POST['region_id']??0);[$region,$poly]=deniz_scan_region_context($rid);
    if(!$region) wp_send_json_error('Bölge bulunamadı.'); if(count($poly)<3) wp_send_json_error('Bu bölgede geçerli polygon yok.');
    $limit=max(5,min(250,absint($_POST['limit']??40)));$token=wp_generate_password(20,false,false);
    $tiles=deniz_scan_make_tiles($poly, count($poly)>80?20:12);
    deniz_hic_set_preview($token,['token'=>$token,'region_id'=>$rid,'region_name'=>$region->name,'source'=>'region-scan','limit'=>$limit,'candidates'=>[],'stats'=>['outside'=>0,'tiles'=>count($tiles)],'created'=>time()]);
    wp_send_json_success(['token'=>$token,'region'=>$region->name,'tiles'=>$tiles,'total'=>count($tiles)]);
});
add_action('wp_ajax_deniz_hic_tile',function(){
    check_ajax_referer('deniz_os','nonce'); if(!current_user_can('manage_options')) wp_send_json_error('Yetki yok');
    $token=sanitize_key($_POST['token']??'');$rid=absint($_POST['region_id']??0);$s=(float)($_POST['south']??0);$w=(float)($_POST['west']??0);$n=(float)($_POST['north']??0);$e=(float)($_POST['east']??0);
    if(!$token||$n<=$s||$e<=$w) wp_send_json_error('Geçersiz tarama karesi.');
    $bbox=$s.','.$w.','.$n.','.$e;$errors=[];$items=[];$used='';
    foreach(deniz_scan_endpoints() as $ep){$r=deniz_scan_overpass($ep,$bbox);if($r['ok']){$items=$r['items'];$used=parse_url($ep,PHP_URL_HOST)?:$ep;break;}$errors[]=$r['error'];}
    $m=deniz_hic_merge_candidates($token,$rid,$items,'overpass');if(is_wp_error($m))wp_send_json_error($m->get_error_message());
    wp_send_json_success(array_merge($m,['endpoint'=>$used,'errors'=>$errors,'raw'=>count($items)]));
});

function deniz_hic_nominatim_once($region,$poly){
 $lats=array_column($poly,'lat');$lngs=array_column($poly,'lng');$viewbox=min($lngs).','.max($lats).','.max($lngs).','.min($lats);
 $base=deniz_setting('nominatim_url','https://nominatim.openstreetmap.org/search');$q='hotel resort '.$region->name.' '.$region->city.' '.$region->country;
 $url=add_query_arg(['format'=>'jsonv2','limit'=>50,'bounded'=>1,'viewbox'=>$viewbox,'addressdetails'=>1,'q'=>$q],$base);
 $res=wp_remote_get($url,['timeout'=>6,'redirection'=>1,'headers'=>['User-Agent'=>'AntalyaTransferProHotelImport/8.0','Accept'=>'application/json']]);if(is_wp_error($res)||wp_remote_retrieve_response_code($res)!==200)return [];$data=json_decode(wp_remote_retrieve_body($res),true);$items=[];
 foreach((array)$data as $x){if(!isset($x['lat'],$x['lon']))continue;$name=$x['name']??explode(',',$x['display_name']??'')[0]??'';if(!$name)continue;$items[]=['name'=>$name,'lat'=>(float)$x['lat'],'lng'=>(float)$x['lon'],'address'=>$x['display_name']??'','osm_type'=>$x['osm_type']??'','osm_id'=>$x['osm_id']??0];}return $items;
}
function deniz_hic_photon_once($region,$poly){
 $lats=array_column($poly,'lat');$lngs=array_column($poly,'lng');$bbox=min($lngs).','.min($lats).','.max($lngs).','.max($lats);$base=deniz_setting('photon_url','https://photon.komoot.io/api/');
 $url=add_query_arg(['q'=>'hotel '.$region->name.' '.$region->city,'limit'=>50,'bbox'=>$bbox,'lang'=>'en'],$base);$res=wp_remote_get($url,['timeout'=>6,'redirection'=>1,'headers'=>['User-Agent'=>'AntalyaTransferProHotelImport/8.0','Accept'=>'application/json']]);if(is_wp_error($res)||wp_remote_retrieve_response_code($res)!==200)return [];$data=json_decode(wp_remote_retrieve_body($res),true);$items=[];
 foreach((array)($data['features']??[]) as $f){$p=$f['properties']??[];$c=$f['geometry']['coordinates']??[];if(count($c)<2||empty($p['name']))continue;$items[]=['name'=>$p['name'],'lat'=>(float)$c[1],'lng'=>(float)$c[0],'address'=>implode(', ',array_filter([$p['street']??'',$p['district']??'',$p['city']??'',$p['country']??''])),'osm_type'=>$p['osm_type']??'','osm_id'=>$p['osm_id']??0];}return $items;
}

add_action('wp_ajax_deniz_hic_fallback',function(){
    check_ajax_referer('deniz_os','nonce'); if(!current_user_can('manage_options')) wp_send_json_error('Yetki yok');
    $token=sanitize_key($_POST['token']??'');$rid=absint($_POST['region_id']??0);[$region,$poly]=deniz_scan_region_context($rid);
    if(!$region||count($poly)<3) wp_send_json_error('Bölge/polygon bulunamadı.');
    $lats=array_column($poly,'lat');$lngs=array_column($poly,'lng');$south=min($lats);$north=max($lats);$west=min($lngs);$east=max($lngs);
    $nom=deniz_hic_nominatim_once($region,$poly);$pho=deniz_hic_photon_once($region,$poly);
    $a=deniz_hic_merge_candidates($token,$rid,$nom,'nominatim');$b=deniz_hic_merge_candidates($token,$rid,$pho,'photon');
    $p=deniz_hic_get_preview($token);wp_send_json_success(['nominatim'=>count($nom),'photon'=>count($pho),'total'=>count($p['candidates']??[])]);
});
