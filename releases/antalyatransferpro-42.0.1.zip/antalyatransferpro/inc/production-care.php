<?php
if(!defined('ABSPATH'))exit;
/* Migrations run in admin, never in visitor requests. Existing rows keep an unknown timestamp. */
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||get_option('twt_timestamp_schema')==='33'||get_transient('twt_timestamp_retry'))return;
 global $wpdb;$t=deniz_tables();$ok=true;
 foreach(['cities','regions','airports','hotels','vehicles','prices'] as $key){$table=$t[$key];$cols=$wpdb->get_col("SHOW COLUMNS FROM `$table`",0);if(!in_array('twt_updated_at',(array)$cols,true)&&$wpdb->query("ALTER TABLE `$table` ADD COLUMN twt_updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP")===false)$ok=false;}
 if($ok)update_option('twt_timestamp_schema','33',false);else set_transient('twt_timestamp_retry',true,300);
});
function twt_real_updated_timestamp($id){
 static $cache=[];if(isset($cache[$id]))return $cache[$id];
 $stamp=get_post_modified_time('U',true,$id);global $wpdb;$t=deniz_tables();$times=[];
 if(get_option('twt_timestamp_schema')==='33'){
  $type=get_post_type($id);$map=['destination'=>['cities','dynamic_city_id'],'location'=>['regions','dynamic_region_id'],'airport-guide'=>['airports','dynamic_airport_id'],'vehicle'=>['vehicles','dynamic_vehicle_id']];
  if(isset($map[$type])){$row_id=(int)get_post_meta($id,$map[$type][1],true);if($row_id)$times[]=$wpdb->get_var($wpdb->prepare("SELECT twt_updated_at FROM {$t[$map[$type][0]]} WHERE id=%d",$row_id));}
  $rid=(int)get_post_meta($id,'dynamic_region_id',true);$aid=(int)get_post_meta($id,'dynamic_airport_id',true);
  if($rid){$where=$aid?$wpdb->prepare('region_id=%d AND airport_id=%d',$rid,$aid):$wpdb->prepare('region_id=%d',$rid);$times[]=$wpdb->get_var("SELECT MAX(twt_updated_at) FROM {$t['prices']} WHERE $where");$local_updated=$wpdb->get_var($wpdb->prepare("SELECT MAX(updated_at) FROM {$t['region_content']} WHERE region_id=%d",$rid));if($local_updated){try{$stamp=max((int)$stamp,(new DateTimeImmutable($local_updated,wp_timezone()))->getTimestamp());}catch(Exception $e){}}}
 }
 foreach($times as $value)if($value){$ts=strtotime($value.' UTC');if($ts)$stamp=max((int)$stamp,$ts);}
 return $cache[$id]=(int)$stamp;
}
function twt_real_updated_label($id){$stamp=twt_real_updated_timestamp($id);return $stamp?wp_date(get_option('date_format'),$stamp):deniz_t('update_date_unknown');
}
function twt_stale_vehicle_ids(){static $ids=null;if($ids!==null)return $ids;global $wpdb;$t=deniz_tables();return $ids=array_map('intval',$wpdb->get_col("SELECT DISTINCT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key='dynamic_vehicle_id' LEFT JOIN {$t['vehicles']} v ON v.id=CAST(m.meta_value AS UNSIGNED) WHERE p.post_type='vehicle' AND p.post_status='publish' AND (v.id IS NULL OR v.active=0)"));}
add_filter('wp_sitemaps_posts_query_args',function($args,$type){if($type==='vehicle')$args['post__not_in']=array_unique(array_merge($args['post__not_in']??[],twt_stale_vehicle_ids()));return $args;},20,2);
function twt_cleanup_vehicle_pages(){
 global $wpdb;$t=deniz_tables();$ids=$wpdb->get_col("SELECT DISTINCT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key='dynamic_vehicle_id' JOIN {$wpdb->postmeta} a ON a.post_id=p.ID AND a.meta_key='twt_auto_generated' AND a.meta_value='1' LEFT JOIN {$t['vehicles']} v ON v.id=CAST(m.meta_value AS UNSIGNED) WHERE p.post_type='vehicle' AND p.post_status='publish' AND (v.id IS NULL OR v.active=0) ORDER BY p.ID LIMIT 50");foreach($ids as $id)wp_update_post(['ID'=>(int)$id,'post_status'=>'draft']);if(count($ids)===50&&!wp_next_scheduled('twt_cleanup_vehicle_pages'))wp_schedule_single_event(time()+30,'twt_cleanup_vehicle_pages');
}
add_action('twt_cleanup_vehicle_pages','twt_cleanup_vehicle_pages');add_action('twt_fleet_daily','twt_cleanup_vehicle_pages');
add_action('init',function(){if(get_option('twt_cleanup_version')!=='33'){if(!wp_next_scheduled('twt_cleanup_vehicle_pages'))wp_schedule_single_event(time()+10,'twt_cleanup_vehicle_pages');update_option('twt_cleanup_version','33',false);}if(!wp_next_scheduled('twt_refresh_fx'))wp_schedule_event(time()+20,'twicedaily','twt_refresh_fx');});
function twt_parse_fx($rows){
 if(!is_array($rows))return false;$rates=[];$dates=[];foreach($rows as $row){$quote=strtoupper($row['quote']??'');if(strtoupper($row['base']??'')!=='EUR'||!in_array($quote,['TRY','USD','GBP'],true))continue;$rate=$row['rate']??null;$date=$row['date']??'';$ts=strtotime($date);if(!is_numeric($rate)||!is_finite((float)$rate)||$rate<=0||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)||!$ts||$ts<time()-14*DAY_IN_SECONDS||$ts>time()+DAY_IN_SECONDS)return false;$rates[$quote]=(float)$rate;$dates[$quote]=$date;}
 if(count($rates)!==3)return false;return ['rates'=>$rates,'dates'=>$dates,'date'=>min($dates),'source'=>'Frankfurter / ECB','fetched_at'=>time()];
}
function twt_refresh_fx(){
 if(!get_option('twt_fx_auto',true))return;$lock='twt_fx_lock';$old=(int)get_option($lock,0);if($old&&$old<time()-60)delete_option($lock);if(!add_option($lock,time(),'','no'))return;
 try{$response=wp_remote_get('https://api.frankfurter.dev/v2/providers/ecb/rates?base=EUR&quotes=TRY,USD,GBP',['timeout'=>5,'limit_response_size'=>16384]);$data=!is_wp_error($response)&&wp_remote_retrieve_response_code($response)===200?twt_parse_fx(json_decode(wp_remote_retrieve_body($response),true)):false;if($data){update_option('twt_fx_snapshot',$data,false);delete_option('twt_fx_error');}else update_option('twt_fx_error',['at'=>time(),'message'=>is_wp_error($response)?$response->get_error_message():'Kur yanıtı geçersiz; son geçerli değer korunuyor.'],false);}finally{delete_option($lock);}
}
add_action('twt_refresh_fx','twt_refresh_fx');
add_action('switch_theme',function(){wp_clear_scheduled_hook('twt_refresh_fx');wp_clear_scheduled_hook('twt_cleanup_vehicle_pages');});
function twt_localized_vehicle_features($v,$lang=null){
 $lang=$lang?:deniz_current_lang();$raw=deniz_translation_override('entity_vehicle_'.(int)$v->id.'_features',$lang,'');if($raw)return array_filter(array_map('trim',preg_split('/[\r\n|,]+/u',$raw)));
 $items=preg_split('/[\r\n|]+/u',str_replace('\\n',"\n",(string)$v->features));$lookup=[];foreach(twt_ui_strings() as $key=>$row)foreach($row as $value)$lookup[mb_strtolower(trim($value))]=$key;
 $aliases=['air conditioning'=>'feature_ac','klima'=>'feature_ac','wi-fi'=>'feature_wifi','wifi'=>'feature_wifi','leather seats'=>'feature_leather','deri koltuk'=>'feature_leather','usb charging'=>'feature_usb','usb şarj'=>'feature_usb','meet & greet'=>'meet_greet','flight monitoring'=>'flight_tracking','private vehicle'=>'private_transfer'];$out=[];$unknown=false;
 foreach($items as $text){$text=trim($text);if(!$text)continue;$key=$lookup[mb_strtolower($text)]??$aliases[mb_strtolower($text)]??null;if($key)$out[]=deniz_translation_override($key,$lang,twt_ui_default($key,$lang));elseif($lang==='tr')$out[]=$text;else $unknown=true;}
 if($unknown)$out[]=deniz_translation_override('feature_on_request',$lang,twt_ui_default('feature_on_request',$lang));return array_values(array_unique($out));
}
add_action('admin_menu',function(){add_submenu_page('deniz-os','Sistem Sağlığı & Kurlar','Sistem Sağlığı & Kurlar','manage_options','twt-care','twt_care_page');});
function twt_care_page(){
 if(!current_user_can('manage_options'))return;if(isset($_POST['twt_care_save'])){check_admin_referer('twt_care');update_option('twt_fx_auto',isset($_POST['fx_auto']),false);if(isset($_POST['refresh_fx']))twt_refresh_fx();}
 global $wpdb;$t=deniz_tables();$fx=get_option('twt_fx_snapshot',[]);$error=get_option('twt_fx_error',[]);deniz_admin_shell_start('Sistem Sağlığı & Kurlar','Gerçek sunucu durumunu kontrol edin. SMTP kabul sonucu, gelen kutusu teslim kanıtı değildir.');echo '<form method="post" class="dos-panel">';wp_nonce_field('twt_care');echo '<h2>Döviz kurları</h2><label><input type="checkbox" name="fx_auto" '.checked(get_option('twt_fx_auto',true),true,false).'> Otomatik kur (EUR bazlı ECB / Frankfurter)</label><p>Otomatik kapalıyken mevcut manuel ayarlar kullanılır. Hata halinde son geçerli otomatik kur korunur.</p><p>Veri tarihi: '.esc_html($fx['date']??'Henüz alınmadı').' · Son başarılı kontrol: '.esc_html(isset($fx['fetched_at'])?wp_date('d.m.Y H:i',$fx['fetched_at']):'—').'</p><p>';foreach(deniz_currencies() as $code=>$row)echo esc_html($code.' '.$row['rate']).' &nbsp; ';echo '</p>';if($error)echo '<p>'.esc_html($error['message']).'</p>';echo '<button class="dos-btn" name="twt_care_save">Kaydet</button> <button class="dos-btn secondary" name="twt_care_save" value="1" onclick="this.form.insertAdjacentHTML(\'beforeend\',\'<input type=hidden name=refresh_fx value=1>\')">Kurları şimdi kontrol et</button></form>';
 echo '<div class="dos-panel"><h2>Rezervasyon ve kuyruk kontrolleri</h2><table class="dos-table"><tbody>';
 foreach(['Cron devre dışı'=>defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON?'Evet — sunucu Cron ayarı gerekli':'Hayır','Kur işi'=>wp_next_scheduled('twt_refresh_fx')?wp_date('d.m.Y H:i',wp_next_scheduled('twt_refresh_fx')):'Planlanmamış','Mail kurtarma işi'=>wp_next_scheduled('twt_mail_recovery')?wp_date('d.m.Y H:i',wp_next_scheduled('twt_mail_recovery')):'Planlanmamış','Veri tarihi şeması'=>get_option('twt_timestamp_schema')==='33'?'Hazır':'Yükseltme bekliyor'] as $label=>$value)echo '<tr><td>'.esc_html($label).'</td><td>'.esc_html($value).'</td></tr>';
 $engines=$wpdb->get_results($wpdb->prepare('SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN (%s,%s)',$t['bookings'],$t['booking_extras']));foreach($engines as $row)echo '<tr><td>'.esc_html($row->TABLE_NAME).'</td><td>'.esc_html($row->ENGINE.($row->ENGINE==='InnoDB'?' · İşlem desteği hazır':' · Transaction için InnoDB gerekli')).'</td></tr>';echo '</tbody></table><p>Canlı kabul testi: tek yön + dönüş; otel seçimi + elle adres; ekstralar; fiyat; voucher; müşteri ve admin gelen kutusu; çift tıklamada tek kayıt. Bu ekran testi yapılmış olarak işaretlemez.</p></div>';
 $vehicles=$wpdb->get_results("SELECT id,name,features FROM {$t['vehicles']} WHERE active=1 AND features IS NOT NULL AND features<>'' ORDER BY name LIMIT 50");echo '<div class="dos-panel"><h2>Araç özellikleri çeviri kontrolü</h2><p>Standart özellikler sözlükten çevrilir. Özgün özellikler Çeviri Merkezi içindeki entity_vehicle_ID_features alanından tamamlanmalıdır. Özgün sayfa metinleri İçerik Çeviri Kontrolü ekranında bulunur.</p><table class="dos-table"><tbody>';foreach($vehicles as $v){echo '<tr><td>'.esc_html($v->name).'</td>';foreach(['en','de','ru'] as $lang)echo '<td>'.esc_html(strtoupper($lang).' · '.(deniz_translation_override('entity_vehicle_'.$v->id.'_features',$lang,'')?'Özel çeviri hazır':'Sözlük / özel çeviri kontrolü')).'</td>';echo '</tr>';}echo '</tbody></table></div>';deniz_admin_shell_end();
}
