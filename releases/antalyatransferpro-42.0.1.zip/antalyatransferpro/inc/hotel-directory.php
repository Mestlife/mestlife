<?php
if (!defined('ABSPATH')) exit;
/* SQL-backed hotel pages: imports are visible immediately; hotel requests never generate route posts. */
function twt_is_hotels_page(){return (bool)get_query_var('twt_hotels') || is_page('hotels');}
function twt_hotel_url($hotel,$lang=null){return deniz_url('hotels/'.sanitize_title($hotel->slug?:$hotel->name).'-'.(int)$hotel->id,$lang);}
function twt_hotel_entity(){
 static $loaded=false,$hotel=null;
 if($loaded)return $hotel;$loaded=true;$id=absint(get_query_var('twt_hotel'));if(!$id)return null;
 global $wpdb;$t=deniz_tables();
 $hotel=$wpdb->get_row($wpdb->prepare("SELECT h.*,r.name region_name,c.name city_name FROM {$t['hotels']} h JOIN {$t['regions']} r ON r.id=h.region_id AND r.active=1 JOIN {$t['cities']} c ON c.id=h.city_id AND c.active=1 WHERE h.id=%d AND h.active=1",$id));return $hotel;
}
function twt_hotel_place_name($hotel,$kind){return twt_entity_name((object)['id'=>$hotel->{$kind.'_id'},'name'=>$hotel->{$kind.'_name'}],$kind);}
function twt_hotels_title(){ $h=twt_hotel_entity();return $h?sprintf(deniz_t('hotel_transfer_title'),twt_entity_name($h,'hotel')):deniz_t('hotel_directory_title'); }
function twt_hotels_description(){ $h=twt_hotel_entity();return $h?sprintf(deniz_t('hotel_transfer_intro'),twt_entity_name($h,'hotel'),twt_hotel_place_name($h,'region'),twt_hotel_place_name($h,'city')):deniz_t('hotel_directory_intro'); }
function twt_hotels_canonical($lang=null){$h=twt_hotel_entity();$url=$h?twt_hotel_url($h,$lang):deniz_url('hotels',$lang);$page=max(1,absint($_GET['hotels_page']??1));return !$h&&$page>1?add_query_arg('hotels_page',$page,$url):$url;}
add_filter('query_vars',function($vars){return array_merge($vars,['twt_hotels','twt_hotel','twt_hotel_sitemap']);});
add_action('init',function(){
 add_rewrite_rule('^hotel-sitemap\.xml$','index.php?twt_hotel_sitemap=index','top');
 add_rewrite_rule('^hotel-sitemap-([1-9][0-9]*)\.xml$','index.php?twt_hotel_sitemap=$matches[1]','top');
 foreach(array_merge([''],array_keys(deniz_languages())) as $lang){$prefix=$lang?$lang.'/':'';$args=$lang?'&deniz_lang='.$lang:'';
  add_rewrite_rule('^'.$prefix.'hotels/?$','index.php?pagename=hotels&twt_hotels=1'.$args,'top');
  add_rewrite_rule('^'.$prefix.'hotels/([^/]+)-([1-9][0-9]*)/?$','index.php?pagename=hotels&twt_hotels=1&twt_hotel=$matches[2]'.$args,'top');
 }
 if(get_option('twt_hotels_release')!=='39'){
  $page=get_page_by_path('hotels');if(!$page){$id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Hotels','post_name'=>'hotels']);if(!$id||is_wp_error($id))return;}
  flush_rewrite_rules(false);update_option('twt_hotels_release','39',false);
 }
},30);
add_action('template_redirect',function(){
 if(!twt_is_hotels_page())return;
 if(get_query_var('twt_hotel')&&!twt_hotel_entity()){global $wp_query;$wp_query->set_404();status_header(404);return;}
 // Old hotel names and language-free links resolve to one stable, language-specific URL.
 $target=twt_hotels_canonical();$current=home_url(deniz_current_request_relative_path());
 $target_path=wp_parse_url($target,PHP_URL_PATH);$current_path=wp_parse_url($current,PHP_URL_PATH);
 if(untrailingslashit($target_path)!==untrailingslashit($current_path)){
  $query=[];parse_str(wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_QUERY)?:'',$query);unset($query['twt_hotel'],$query['twt_hotels'],$query['deniz_lang']);if($query)$target=add_query_arg($query,$target);
  wp_safe_redirect($target,301);exit;
 }
},5);
add_filter('redirect_canonical',function($url){return twt_is_hotels_page()?false:$url;});
add_filter('template_include',function($template){return twt_is_hotels_page()&&!is_404()?get_template_directory().'/template-hotels.php':$template;},99);
add_action('wp_enqueue_scripts',function(){if(!twt_is_hotels_page()||is_404())return;wp_enqueue_style('twt-route-page',get_template_directory_uri().'/assets/css/route-page.css',['twt-pages'],wp_get_theme()->get('Version'));wp_enqueue_style('twt-hubs',get_template_directory_uri().'/assets/css/premium-hubs.css',['twt-route-page'],wp_get_theme()->get('Version'));wp_enqueue_style('twt-hotels',get_template_directory_uri().'/assets/css/hotel-directory.css',['twt-hubs'],wp_get_theme()->get('Version'));});
add_filter('wp_robots',function($robots){if(twt_is_hotels_page()&&(isset($_GET['hotel_q'])||isset($_GET['hotel_city'])||isset($_GET['hotel_region']))){$robots['noindex']=true;unset($robots['index']);}return $robots;},40);
// Keep common SEO plugins' metadata aligned with the SQL detail endpoint.
foreach(['wpseo_title','rank_math/frontend/title','aioseo_title'] as $filter)add_filter($filter,function($value){return twt_is_hotels_page()?deniz_seo_trim(twt_hotels_title().' | Antalya Transfer Pro',70):$value;},99);
foreach(['wpseo_metadesc','rank_math/frontend/description','aioseo_description'] as $filter)add_filter($filter,function($value){return twt_is_hotels_page()?deniz_seo_trim(twt_hotels_description(),160):$value;},99);
foreach(['wpseo_canonical','rank_math/frontend/canonical','aioseo_canonical_url'] as $filter)add_filter($filter,function($value){return twt_is_hotels_page()?twt_hotels_canonical():$value;},99);

function twt_hotel_directory_render(){
 global $wpdb;$t=deniz_tables();$page=max(1,min(100000,absint($_GET['hotels_page']??1)));$city=absint($_GET['hotel_city']??0);$region=absint($_GET['hotel_region']??0);$q=sanitize_text_field(wp_unslash($_GET['hotel_q']??''));$q=mb_substr($q,0,120);
 $where='h.active=1 AND r.active=1 AND c.active=1';$args=[];
 if($city){$where.=' AND h.city_id=%d';$args[]=$city;}if($region){$where.=' AND h.region_id=%d';$args[]=$region;}if($q!==''){$where.=' AND (h.name LIKE %s OR h.address LIKE %s)';$args[]='%'.$wpdb->esc_like($q).'%';$args[]='%'.$wpdb->esc_like($q).'%';}
 $join="FROM {$t['hotels']} h JOIN {$t['regions']} r ON r.id=h.region_id JOIN {$t['cities']} c ON c.id=h.city_id WHERE $where";
 $count="SELECT COUNT(*) $join";$total=(int)$wpdb->get_var($args?$wpdb->prepare($count,...$args):$count);
 $sql="SELECT h.*,r.name region_name,c.name city_name $join ORDER BY h.name,h.id LIMIT 24 OFFSET %d";$hotels=$wpdb->get_results($wpdb->prepare($sql,...array_merge($args,[($page-1)*24])));
 $cities=$wpdb->get_results("SELECT c.* FROM {$t['cities']} c WHERE c.active=1 AND EXISTS(SELECT 1 FROM {$t['hotels']} h JOIN {$t['regions']} r ON r.id=h.region_id AND r.active=1 WHERE h.city_id=c.id AND h.active=1) ORDER BY c.name");
 $regions=$wpdb->get_results($city?$wpdb->prepare("SELECT r.* FROM {$t['regions']} r WHERE r.active=1 AND r.city_id=%d ORDER BY r.name",$city):"SELECT r.* FROM {$t['regions']} r WHERE r.active=1 AND EXISTS(SELECT 1 FROM {$t['hotels']} h WHERE h.region_id=r.id AND h.active=1) ORDER BY r.name");
 echo '<div class="twt-route-page twt-hub-page twt-hotel-directory">';twt_hub_hero(twt_hotels_title(),twt_hotels_description(),deniz_t('hotels_heading'));
 echo '<section class="twt-route-section twt-route-soft"><div class="twt-route-wrap"><form class="twt-hotel-filters" method="get" action="'.esc_url(deniz_url('hotels')).'"><label>'.esc_html(deniz_t('hotel_find')).'<input type="search" name="hotel_q" value="'.esc_attr($q).'" placeholder="'.esc_attr(deniz_t('hotel_find')).'" maxlength="120"></label><label>'.esc_html(deniz_t('hotel_city')).'<select name="hotel_city"><option value="0">'.esc_html(deniz_t('hotel_all_cities')).'</option>';
 foreach($cities as $row)echo '<option value="'.(int)$row->id.'" '.selected($city,$row->id,false).'>'.esc_html(twt_entity_name($row,'city')).'</option>';
 echo '</select></label><label>'.esc_html(deniz_t('hotel_region')).'<select name="hotel_region"><option value="0">'.esc_html(deniz_t('hotel_all_regions')).'</option>';
 foreach($regions as $row)echo '<option value="'.(int)$row->id.'" '.selected($region,$row->id,false).'>'.esc_html(twt_entity_name($row,'region')).'</option>';
 echo '</select></label><button class="twt-route-button" type="submit">'.esc_html(deniz_t('search')).'</button><a class="twt-hotel-reset" href="'.esc_url(deniz_url('hotels')).'">'.esc_html(deniz_t('hotel_reset')).'</a></form><p class="twt-hotel-count" role="status">'.esc_html(sprintf(deniz_t('hotel_results'),number_format_i18n($total))).'</p><div class="twt-hub-grid">';$items=[];
 foreach($hotels as $hotel){$name=twt_entity_name($hotel,'hotel');$url=twt_hotel_url($hotel);twt_hub_card($name,$url,(int)($hotel->image_id??0),twt_hotel_place_name($hotel,'region').' · '.twt_hotel_place_name($hotel,'city'));$items[]=['@type'=>'ListItem','position'=>($page-1)*24+count($items)+1,'name'=>$name,'url'=>$url];}
 echo '</div>';if(!$hotels)echo '<p class="twt-route-empty">'.esc_html(deniz_t('hotel_no_match')).'</p>';
 if($total>24)echo '<nav class="twt-pagination" aria-label="'.esc_attr(deniz_t('hotels_heading')).'">'.paginate_links(['base'=>add_query_arg('hotels_page','%#%',twt_hotels_canonical()),'format'=>'','current'=>$page,'total'=>(int)ceil($total/24),'add_args'=>array_filter(['hotel_q'=>$q,'hotel_city'=>$city,'hotel_region'=>$region])]).'</nav>';
 echo '</div></section><section class="twt-route-section"><div class="twt-route-wrap twt-route-reading">';twt_public_faq([['q'=>deniz_t('hotel_faq_q'),'a'=>deniz_t('hotel_faq_a')],['q'=>deniz_t('faq_price_q'),'a'=>deniz_t('price_explanation')]]);echo '</div></section></div>';twt_hub_itemlist($items);
}
function twt_hotel_detail_render(){
 global $wpdb;$t=deniz_tables();$hotel=twt_hotel_entity();$region=deniz_db_region($hotel->region_id);$name=twt_entity_name($hotel,'hotel');$lang=atp_lang();
 $regionName=twt_hotel_place_name($hotel,'region');$cityName=twt_hotel_place_name($hotel,'city');
 $airports=$wpdb->get_results($wpdb->prepare("SELECT DISTINCT a.* FROM {$t['airports']} a JOIN {$t['prices']} p ON p.airport_id=a.id AND p.active=1 AND p.one_way>0 JOIN {$t['vehicles']} v ON v.id=p.vehicle_id AND v.active=1 WHERE a.active=1 AND p.region_id=%d ORDER BY a.name",$hotel->region_id));
 $main=$airports[0]??atp_ayt();$metrics=($main&&$region)?twt_route_metrics($main,$region,$hotel):[];$from=($main&&function_exists('deniz_region_from_price'))?deniz_region_from_price((int)$hotel->region_id,(int)$main->id):null;
 $destKey=atp_dest_for_region($region);
 $T=[
  'tr'=>['facts'=>['Bölge','Mesafe','Yol süresi','Başlangıç fiyatı'],'quick_q'=>'%s transferi ne kadar sürer ve ne kadar tutar?','quick_a1'=>'Antalya Havalimanı ile %s arası yaklaşık %s km ve ortalama %s dakikadır.','quick_a2'=>'%s için özel transferiniz ara durak yapmadan doğrudan otel girişine gider.','price1'=>'Araç başı fiyatlar %s\'dan başlar; uçuşunuz gecikse bile fiyat değişmez.','price2'=>'Fiyatınızı yukarıdaki formda saniyeler içinde görebilirsiniz.','why_h'=>'%s transferinde neden biz?','why'=>['Varış salonunda isim tabelasıyla karşılama','Uçuş takibi – rötarda ek ücret yok','Otel kapısına kadar, ara durak yok','Bebek ve çocuk koltuğu talebe göre','Sürücüye nakit ödeme','TÜRSAB 18926 belgeli acente'],'area_h'=>'%s bölgesi hakkında','area_more'=>'%s transfer sayfasını inceleyin','near_h'=>'%s bölgesindeki diğer oteller','prices_h'=>'Araçlar ve sabit fiyatlar','return_h'=>'Dönüş: otelden havalimanına','return_t'=>'Dönüş transferinizi aynı rezervasyonda ekleyin. Dış hat uçuşlarında uçuştan yaklaşık %s önce otelden alınmanızı öneririz; sürücünüz resepsiyonda sizi bekler.','map'=>'Otel konumunu haritada aç','book'=>'Bu otel için transfer ara'],
  'en'=>['facts'=>['Area','Distance','Drive time','Prices from'],'quick_q'=>'How long is the transfer to %s and how much does it cost?','quick_a1'=>'From Antalya Airport to %s it is about %s km and usually around %s minutes.','quick_a2'=>'Your private transfer to %s drives straight to the hotel entrance with no stops.','price1'=>'Prices start from %s per vehicle and stay the same even if your flight is late.','price2'=>'See your fixed price in seconds with the search form above.','why_h'=>'Why book your %s transfer with us?','why'=>['Meet & greet with a name sign in arrivals','Flight tracking – no extra charge for delays','Door to door, no stops on the way','Baby and child seats on request','Pay your driver in cash','Licensed agency – TÜRSAB 18926'],'area_h'=>'About %s','area_more'=>'See the %s transfer page','near_h'=>'More hotels in %s','prices_h'=>'Vehicles & fixed prices','return_h'=>'Return: hotel to airport','return_t'=>'Add your return transfer in the same booking. For international flights we recommend a hotel pickup about %s before departure; your driver meets you at reception.','map'=>'Open hotel location in maps','book'=>'Search a transfer for this hotel'],
  'de'=>['facts'=>['Region','Entfernung','Fahrzeit','Preise ab'],'quick_q'=>'Wie lange dauert der Transfer zum %s und was kostet er?','quick_a1'=>'Vom Flughafen Antalya zum %s sind es etwa %s km, meist rund %s Minuten.','quick_a2'=>'Ihr Privattransfer zum %s fährt ohne Zwischenstopp direkt bis zum Hoteleingang.','price1'=>'Preise ab %s pro Fahrzeug – unverändert, auch wenn Ihr Flug Verspätung hat.','price2'=>'Ihren Festpreis sehen Sie in Sekunden im Suchformular oben.','why_h'=>'Warum Ihren Transfer zum %s bei uns buchen?','why'=>['Empfang mit Namensschild in der Ankunftshalle','Flugverfolgung – keine Aufpreise bei Verspätung','Von Tür zu Tür, ohne Zwischenstopps','Baby- und Kindersitze auf Anfrage','Barzahlung beim Fahrer','Lizenzierte Agentur – TÜRSAB 18926'],'area_h'=>'Über %s','area_more'=>'Zur Transferseite %s','near_h'=>'Weitere Hotels in %s','prices_h'=>'Fahrzeuge & Festpreise','return_h'=>'Rückfahrt: Hotel zum Flughafen','return_t'=>'Buchen Sie den Rücktransfer gleich mit. Bei internationalen Flügen empfehlen wir die Abholung am Hotel etwa %s vor Abflug; Ihr Fahrer wartet an der Rezeption.','map'=>'Hotelstandort in Karten öffnen','book'=>'Transfer für dieses Hotel suchen'],
  'ru'=>['facts'=>['Район','Расстояние','Время в пути','Цены от'],'quick_q'=>'Сколько ехать до отеля %s и сколько стоит трансфер?','quick_a1'=>'От аэропорта Антальи до отеля %s около %s км, обычно примерно %s минут.','quick_a2'=>'Индивидуальный трансфер в %s едет прямо до входа в отель без остановок.','price1'=>'Цены от %s за автомобиль и не меняются при задержке рейса.','price2'=>'Фиксированную цену вы увидите за секунды в форме поиска выше.','why_h'=>'Почему трансфер в %s стоит заказать у нас?','why'=>['Встреча с табличкой в зале прилёта','Отслеживание рейса — без доплат за задержку','От двери до двери, без остановок','Детские кресла по запросу','Оплата наличными водителю','Лицензированное агентство – TÜRSAB 18926'],'area_h'=>'О районе %s','area_more'=>'Страница трансфера: %s','near_h'=>'Другие отели: %s','prices_h'=>'Автомобили и фиксированные цены','return_h'=>'Обратно: из отеля в аэропорт','return_t'=>'Добавьте обратный трансфер в то же бронирование. Для международных рейсов рекомендуем выезд из отеля примерно за %s до вылета; водитель встретит вас на ресепшене.','map'=>'Открыть отель на карте','book'=>'Найти трансфер в этот отель'],
 ][$lang];
 echo '<div class="twt-route-page twt-hub-page twt-hotel-detail">';twt_hub_hero(twt_hotels_title(),twt_hotels_description(),$name,$main,$region,false,(int)($hotel->image_id??0),$hotel);
 // facts strip
 echo '<section class="atp-hotel-facts"><div class="twt-route-wrap"><div class="atp-facts atp-facts-light">';
 echo '<div><small>'.esc_html($T['facts'][0]).'</small><b>'.esc_html($regionName).'</b></div>';
 if(!empty($metrics['distance']))echo '<div><small>'.esc_html($T['facts'][1]).'</small><b>'.esc_html(number_format_i18n($metrics['distance'],0)).' km</b></div>';
 if(!empty($metrics['duration']))echo '<div><small>'.esc_html($T['facts'][2]).'</small><b>~'.(int)$metrics['duration'].' '.esc_html(deniz_t('minutes')).'</b></div>';
 echo '<div><small>'.esc_html($T['facts'][3]).'</small><b>'.($from?esc_html(deniz_money((float)$from)):'<a href="#route-search">'.esc_html(deniz_t('check_fare')).'</a>').'</b></div></div></div></section>';
 // quick answer
 echo '<section class="twt-route-section"><div class="twt-route-wrap twt-route-reading"><div class="knowledge-answer atp-quick"><div class="knowledge-answer-label">'.esc_html(deniz_t('quick_answer')).'</div><h2>'.esc_html(sprintf($T['quick_q'],$name)).'</h2><p>'.esc_html((!empty($metrics['distance'])&&!empty($metrics['duration'])?sprintf($T['quick_a1'],$name,number_format_i18n($metrics['distance'],0),(int)$metrics['duration']):sprintf($T['quick_a2'],$name)).' '.($from?sprintf($T['price1'],deniz_money((float)$from)):$T['price2'])).'</p></div>';
 echo '<div class="twt-hotel-address"><h2>'.esc_html($name).'</h2><p>'.esc_html($regionName.' · '.$cityName).'</p>';if($hotel->address)echo '<address>'.esc_html($hotel->address).'</address>';if(is_numeric($hotel->lat)&&is_numeric($hotel->lng))echo '<p><a class="atp-link" href="'.esc_url('https://www.google.com/maps/search/?api=1&query='.(float)$hotel->lat.','.(float)$hotel->lng).'" target="_blank" rel="noopener">'.esc_html($T['map']).' →</a></p>';echo '</div></div></section>';
 // prices per airport
 echo '<section class="twt-route-section twt-route-soft"><div class="twt-route-wrap"><h2>'.esc_html($T['prices_h']).'</h2>';
 if(!$airports)echo '<p class="twt-route-empty">'.esc_html(deniz_t('no_public_price')).' <a class="atp-link" href="'.esc_url(atp_whatsapp_link($name)).'" target="_blank" rel="noopener nofollow">WhatsApp →</a></p>';
 foreach($airports as $airport){$prices=deniz_region_price_rows($hotel->region_id,$airport->id);if(!$prices)continue;echo '<article class="twt-hotel-airport"><div><small>'.esc_html(deniz_t('airport_transfer')).'</small><h3>'.esc_html(twt_entity_name($airport,'airport').' → '.$name).'</h3></div>';
  echo '<div class="twt-route-vehicles">';foreach($prices as $row){$vehicle=(object)['id'=>$row->vehicle_id,'name'=>$row->vehicle];echo '<article class="twt-route-vehicle"><div class="twt-route-vehicle-photo">';if($row->image_id)echo wp_get_attachment_image($row->image_id,'medium',false,['loading'=>'lazy','decoding'=>'async']);else echo twt_icon('users');echo '</div><div class="twt-route-vehicle-copy"><small>'.esc_html(deniz_t($row->pricing_type==='per_person'?'shared_transfer':'private_transfer')).'</small><h3>'.esc_html(twt_entity_name($vehicle,'vehicle')).'</h3><p>'.(int)$row->pax.' '.esc_html(deniz_t('passengers')).' · '.(int)$row->bags.' '.esc_html(deniz_t('bags')).'</p><div class="twt-route-fare"><span><small>'.esc_html(deniz_t('one_way')).'</small><b>'.esc_html(deniz_money($row->one_way)).'</b></span>';if($row->return_price>0)echo '<span><small>'.esc_html(deniz_t('return')).'</small><b>'.esc_html(deniz_money($row->return_price)).'</b></span>';echo '</div><small>'.esc_html(deniz_t($row->pricing_type==='per_person'?'per_person':'per_vehicle')).'</small></div></article>';}
  if(!twt_seo_plugin_active()){ $offers=[];foreach($prices as $row)$offers[]=['@type'=>'Offer','name'=>twt_entity_name((object)['id'=>$row->vehicle_id,'name'=>$row->vehicle],'vehicle'),'priceCurrency'=>'EUR','price'=>(float)$row->one_way,'url'=>deniz_search_url_for($airport,$region,$hotel),'availability'=>'https://schema.org/InStock'];deniz_schema_json(['@context'=>'https://schema.org','@type'=>'Service','@id'=>twt_hotel_url($hotel).'#airport-'.(int)$airport->id,'name'=>twt_entity_name($airport,'airport').' → '.$name,'serviceType'=>'Airport transfer','provider'=>['@id'=>home_url('/#organization')],'areaServed'=>['@type'=>'Place','name'=>$regionName],'offers'=>$offers,'inLanguage'=>$lang]);}
  echo '</div><a class="twt-route-button" href="#route-search">'.esc_html($T['book']).' →</a></article>';}
 echo '</div></section>';
 // why + meeting + return
 echo '<section class="atp-section atp-why"><div class="wrap"><h2 class="atp-center">'.esc_html(sprintf($T['why_h'],$name)).'</h2><ul class="atp-why-grid">';foreach($T['why'] as $w)echo '<li>'.esc_html($w).'</li>';echo '</ul></div></section>';
 echo '<section class="twt-route-section"><div class="twt-route-wrap twt-route-reading"><h2>'.esc_html(deniz_t('pickup_note')).'</h2><p>'.esc_html(deniz_t('pickup_guidance')).'</p><h2>'.esc_html($T['return_h']).'</h2><p>'.esc_html(sprintf($T['return_t'],atp_ret_text($metrics['duration']??null,$lang))).'</p>';
 if($destKey){echo '<h2>'.esc_html(sprintf($T['area_h'],atp_place($destKey,$lang))).'</h2><p>'.esc_html(atp_ld()['dest'][$destKey]['about'][$lang]??'').'</p><p><a class="atp-link" href="'.esc_url(atp_landing_url($destKey)).'">'.esc_html(sprintf($T['area_more'],atp_meta($destKey)['h1'])).' →</a></p>';}
 echo '</div></section>';
 // nearby hotels
 $near=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['hotels']} WHERE active=1 AND region_id=%d AND id<>%d ORDER BY name LIMIT 12",$hotel->region_id,$hotel->id));
 if($near){echo '<section class="twt-route-section twt-route-soft"><div class="twt-route-wrap"><h2>'.esc_html(sprintf($T['near_h'],$regionName)).'</h2><div class="hotel-link-grid">';foreach($near as $h)echo '<a href="'.esc_url(twt_hotel_url($h)).'"><span><b>'.esc_html(twt_entity_name($h,'hotel')).'</b><small>'.esc_html($h->address??'').'</small></span><em>→</em></a>';echo '</div></div></section>';}
 // FAQ + related transfers
 echo '<section class="twt-route-section"><div class="twt-route-wrap twt-route-reading">';twt_public_faq([['q'=>deniz_t('hotel_faq_q'),'a'=>deniz_t('hotel_faq_a')]]);echo '</div></section>';
 echo '<section class="twt-route-section twt-route-soft"><div class="twt-route-wrap"><h2>'.esc_html(atp_l('services_h')).'</h2>';atp_link_cards(array_values(array_filter(array_merge($destKey?[$destKey]:[],['airport','hotel','vip','hub']))),$lang);echo '</div></section></div>';
 deniz_schema_json(['@context'=>'https://schema.org','@type'=>'WebPage','@id'=>twt_hotel_url($hotel).'#webpage','url'=>twt_hotel_url($hotel),'name'=>twt_hotels_title(),'description'=>twt_hotels_description(),'inLanguage'=>$lang,'about'=>array_filter(['@type'=>'Hotel','name'=>$name,'address'=>$hotel->address?:null,'containedInPlace'=>['@type'=>'Place','name'=>$regionName.', '.$cityName],'geo'=>is_numeric($hotel->lat)&&is_numeric($hotel->lng)?['@type'=>'GeoCoordinates','latitude'=>(float)$hotel->lat,'longitude'=>(float)$hotel->lng]:null])]);
}
function twt_hotel_sitemap_urls($page_num){
 global $wpdb;$t=deniz_tables();$rows=$wpdb->get_results($wpdb->prepare("SELECT h.* FROM {$t['hotels']} h JOIN {$t['regions']} r ON r.id=h.region_id AND r.active=1 JOIN {$t['cities']} c ON c.id=h.city_id AND c.active=1 WHERE h.active=1 ORDER BY h.id LIMIT 250 OFFSET %d",(max(1,(int)$page_num)-1)*250));$out=[];foreach($rows as $h)foreach(deniz_languages() as $lang=>$info)$out[]=['loc'=>twt_hotel_url($h,$lang)];return $out;
}
function twt_hotel_sitemap_pages(){global $wpdb;$t=deniz_tables();return (int)ceil((int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['hotels']} h JOIN {$t['regions']} r ON r.id=h.region_id AND r.active=1 JOIN {$t['cities']} c ON c.id=h.city_id AND c.active=1 WHERE h.active=1")/250);}
// Standalone discovery also works when an SEO plugin disables native WP sitemaps.
add_action('template_redirect',function(){
 $requested=get_query_var('twt_hotel_sitemap');if(!$requested)return;$pages=twt_hotel_sitemap_pages();$index=$requested==='index';$page=absint($requested);
 if(!$index&&(!$page||$page>$pages)){status_header(404);header('Content-Type: text/plain; charset=utf-8');echo 'Sitemap not found';exit;}
 status_header(200);header('Content-Type: application/xml; charset=utf-8');header('X-Robots-Tag: noindex, follow');
 $escape=function($value){return htmlspecialchars($value,ENT_XML1|ENT_QUOTES,'UTF-8');};echo '<?xml version="1.0" encoding="UTF-8"?>';
 if($index){echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';for($i=1;$i<=$pages;$i++)echo '<sitemap><loc>'.$escape(home_url('/hotel-sitemap-'.$i.'.xml')).'</loc></sitemap>';echo '</sitemapindex>';}
 else{echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';foreach(twt_hotel_sitemap_urls($page) as $item)echo '<url><loc>'.$escape($item['loc']).'</loc></url>';echo '</urlset>';}exit;
},0);
/* robots.txt sitemap line is handled centrally (inc/seo-landings.php → /sitemap.xml). */
// A bounded SQL sitemap; no massive post generation, current active status on every page.
add_action('wp_sitemaps_init',function(){
 $provider=new class extends WP_Sitemaps_Provider{
  public function __construct(){$this->name='twt-hotels';$this->object_type='twt-hotels';}
  public function get_url_list($page_num,$subtype=''){
   return twt_hotel_sitemap_urls($page_num);
  }
  public function get_max_num_pages($subtype=''){return twt_hotel_sitemap_pages();}
 };wp_register_sitemap_provider('twt-hotels',$provider);
});
