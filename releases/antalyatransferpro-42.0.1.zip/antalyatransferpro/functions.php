<?php
if (!defined('ABSPATH')) exit;
require_once get_template_directory() . '/inc/ui-i18n.php';
require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/i18n.php';
require_once get_template_directory() . '/inc/currency.php';
require_once get_template_directory() . '/inc/cpt.php';
require_once get_template_directory() . '/inc/meta.php';
require_once get_template_directory() . '/inc/schema.php';
require_once get_template_directory() . '/inc/transfer-engine.php';
require_once get_template_directory() . '/inc/admin-zones.php';
require_once get_template_directory() . '/inc/antalya-seo.php';
require_once get_template_directory() . '/inc/dynamic-data.php';
require_once get_template_directory() . '/inc/content-hub.php';
require_once get_template_directory() . '/inc/admin-operations.php';

require_once get_template_directory() . '/inc/hotel-manager.php';
require_once get_template_directory() . '/inc/booking-engine.php';

require_once get_template_directory() . '/inc/pro-core.php';
require_once get_template_directory() . '/inc/translation-center.php';
require_once get_template_directory() . '/inc/region-content.php';
require_once get_template_directory() . '/inc/google-integrations.php';
require_once get_template_directory() . '/inc/brand-core.php';
require_once get_template_directory() . '/inc/seo-landings.php';
require_once get_template_directory() . '/inc/mail-service.php';
require_once get_template_directory() . '/inc/seo-premium.php';

function twt_extra_receipt_name($x,$lang=null){$snap=get_option('twt_booking_snapshot_'.(int)($x->booking_id??0),[]);if(isset($snap['extras'][(int)$x->extra_id]))return $snap['extras'][(int)$x->extra_id];$lang=$lang?:deniz_current_lang();$key='entity_extra_'.(int)$x->extra_id.'_name';return deniz_translation_override($key,$lang,$x->name?:'Extra');}

require_once get_template_directory().'/inc/booking-integrity.php';

require_once get_template_directory().'/inc/public-pages.php';

require_once get_template_directory().'/inc/route-experience.php';

require_once get_template_directory().'/inc/route-page.php';

require_once get_template_directory().'/inc/premium-hubs.php';

require_once get_template_directory().'/inc/production-care.php';

require_once get_template_directory().'/inc/release-care.php';
require_once get_template_directory().'/inc/hotel-directory.php';
require_once get_template_directory().'/inc/time-select.php';
require_once get_template_directory().'/inc/sitemap-pro.php';
require_once get_template_directory().'/inc/blog-studio.php';
require_once get_template_directory().'/inc/trust-seo.php';

require_once get_template_directory().'/inc/seo-hardening.php';

require_once get_template_directory().'/inc/experience.php';
require_once get_template_directory().'/inc/pricing-integrity.php';
