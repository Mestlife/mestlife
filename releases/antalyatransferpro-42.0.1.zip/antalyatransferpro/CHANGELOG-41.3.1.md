# 41.3.1 – Destination Fiyat Bölgesi Eşleştirmesi

- SEO Sayfaları ekranına tüm destinationlar için **Destination → Fiyat Bölgesi Eşleştirmesi** tablosu geri eklendi.
- Her destination için Fiyat Matrisi içindeki aktif bir bölge manuel olarak seçilebilir.
- “Otomatik eşleştirme” seçeneği mevcut slug/ad eşleştirme davranışını korur.
- Manuel eşleme yalnızca SEO landing sayfasındaki canlı fiyat kaynağını değiştirir; mesafe/süre, destination koordinatı ve SEO içeriğini değiştirmez.
- Lara, Kundu ve diğer tüm destinationlar aynı ekrandan bağımsız olarak farklı fiyat bölgelerine bağlanabilir.
