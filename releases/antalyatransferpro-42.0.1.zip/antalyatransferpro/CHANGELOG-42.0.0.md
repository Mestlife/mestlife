# 42.0.0

- Ana sayfa ve mobil rezervasyon tasarımı yenilendi; mevcut dil ve URL yapısı korundu.
- Antalya saat dilimiyle tarih doğrulaması, form içi hatalar, yön değiştirirken otel koruma, klavye erişimi ve son fiyat kontrolü.
- Eksik tarih, geçersiz dönüş ve son kontrol onayı sunucuda doğrulanır. İmzalı voucher ve idempotency korunur.
- İlk yüklemeden dış harita kaynakları kaldırıldı; WebP hero ve derlenmiş CSS/JS eklendi.
- Genel/AI bot kısıtlamaları eşitlendi; özel sayfalarda HTTP noindex; bölge breadcrumb ve telefon şeması düzeltildi.
- Test kopyası ve veritabanı bu pakete dahil değildir. Canlı medya, eklentiler, SMTP ve hosting performansı yayın öncesinde doğrulanmalıdır.
