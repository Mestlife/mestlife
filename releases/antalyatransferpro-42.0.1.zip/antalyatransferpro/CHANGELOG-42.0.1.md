# 42.0.1 — fiyat kaydı ve dinamik shuttle

- İki yönü boş/0 olan eski ücretler artık atlanmaz; kayıt pasifleştirilir. Tek yönü boşaltmak yalnızca o yönü satışa kapatır.
- Fiyat matrisi tek JSON alanıyla taşınır; satır sayısı kontrol edilir. Çok sayıda form alanının sunucuda kesilmesine karşı koruma eklendi.
- Tüm fiyatlar doğrulanır. Yazma hataları kontrol edilir; fiyat tablosundaki işlem tamamlanamazsa değişiklikler geri alınır (InnoDB). Yanlış başarı mesajı kaldırıldı.
- Yönetim panelinde kayıt durumu ve ağ hatası görünür. İlgili tema önbellekleri yenilenir; desteklenen eklenti temizleme kancaları çağrılır. Hosting/CDN temizliği garanti edilmez.
- Lara Beach / Kundu gibi birleşik bölge isimleri, tek ve açık eşleşme varsa çözümlenir. Lara'nın araç tablosu ve bölgeye hazır rezervasyon formu açılır.
- Tek yön shuttle fiyatı olmayan bölgede ilgili fiyat kartı, başlık/meta, açıklama ve FAQ teklifleri/şema çıktısı kaldırılır. Fiyat yeniden girilirse teklif geri gelir. Başka bölgelerdeki geçerli shuttle hizmetleri korunur.
- Özgün açıklamalardaki sabit fiyat içeren paragraflar gösterilmez; ücretler fiyat matrisinden gelir. Açıklamalar veritabanından silinmez.
- Pasif araç fiyatları ana sayfa minimumuna dahil edilmez.

## Güncelleme sonrası

Önce yedek/staging. Temayı güncelledikten sonra WordPress yönetim ekranını tam yenileyin; Fiyat Matrisi'ni yeniden açıp hedef ücretleri girerek kaydedin. Eski sürümde kaydedilemeyen yeni ücretler geri getirilemez. Servisi bölgeden tümüyle kaldırmak için hem tek yön hem gidiş-dönüş alanını boş/0 kaydedin. Ana sayfa/bölge kartları uygun aktif araçların en düşük tek yön ücretini gösterir; tek bir aracı artırmak minimumu her zaman artırmaz.

Canlı sitede değişiklik yapılmadı. Canlı Lara sayfasında inceleme sırasında 19 EUR shuttle ve 27 EUR özel transfer gözlendi. Yeni kayıt davranışı, yüklenen yedekten hazırlanan izole test kopyasında doğrulandı; canlı yönetim/veritabanı erişimi yok.
