# Antalya Transfer Pro 41.2.4

- Fixed FAQ intent matching centrally for TR/EN/DE/RU; price answers no longer leak into distance, duration, booking-notice or luggage questions.
- Destination H1 is now generated dynamically from airport/city + destination and is not read from manual region content.
- Destination SEO titles are generated dynamically in TR/EN/DE/RU.
- Destination meta descriptions now use live distance, duration and active shuttle/private prices when available, with a natural no-price fallback.
- All SEO/FAQ prices come from active price rows + active vehicles and are converted with the current currency system.
- FAQ JSON-LD continues to use the same FAQ array that is rendered on screen.
- Region Content is used only for authored hero/about/route copy; it does not override H1/title/meta/FAQ/price/distance/duration.
- Service structured-data offers now use the current currency and converted live prices.
- Existing URLs, canonical, hreflang, sitemap, booking flow and pricing engine were left intact.
