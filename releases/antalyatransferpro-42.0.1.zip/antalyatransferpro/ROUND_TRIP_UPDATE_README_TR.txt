ANTALYA TRANSFER PRO — GİDİŞ DÖNÜŞ BİLGİLERİ

Önceki kapsamlı SEO/GEO/AEO paketinin üzerine hazırlandı. Bu ZIP tek başına tam temadır.

- Gidiş ve dönüş güzergahları voucher ve müşteri/admin e-postasına ayrı yazılır.
- Dönüş tarihi ve saati gösterilir.
- Rezervasyon formuna opsiyonel dönüş uçuş numarası alanı eklendi.
- Dönüş uçuşu rezervasyon snapshot seçeneğine yazılır; mevcut SQL tablo şeması değiştirilmez.
- Daha önce kaydedilmiş rezervasyonların dönüş uçuşları girilmediği için 'Belirtilmedi' gösterilir.
- Tek yön rezervasyonu eski şekilde devam eder.
- Fiyatlar ve rezervasyon iş akışı aynı kalır.

NOT: E-posta gönderimi WordPress Cron, SMTP ve posta teslim koşullarına bağlıdır.
Canlı ortamda test rezervasyonu yapıp müşteri ve yönetici e-postasını doğrulayın.
Canlı sunucuda çalışma testi yapılmadı. Önce yedek ve tercihen staging test önerilir.
