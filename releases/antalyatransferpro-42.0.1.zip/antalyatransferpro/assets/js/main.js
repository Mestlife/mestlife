document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const id=a.getAttribute('href');if(id.length>1){const t=document.querySelector(id);if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth',block:'start'});}}}));
 const toggle=document.querySelector('.app-menu-toggle'),drawer=document.querySelector('.app-mobile-drawer');
 if(toggle&&drawer){toggle.addEventListener('click',()=>{const open=document.body.classList.toggle('menu-open');toggle.setAttribute('aria-expanded',open?'true':'false');});drawer.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{document.body.classList.remove('menu-open');toggle.setAttribute('aria-expanded','false');}));}
 const q=document.querySelector('.typing-query');if(q){const phrases=['Antalya Airport to Belek transfer','Antalya Airport to Kundu hotel','Private transfer to Side'];let i=0;setInterval(()=>{q.classList.add('fade');setTimeout(()=>{i=(i+1)%phrases.length;q.textContent=phrases[i];q.classList.remove('fade');},240);},3200);}
});
