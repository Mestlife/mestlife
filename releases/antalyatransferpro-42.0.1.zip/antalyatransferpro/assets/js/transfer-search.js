function atpSearchError(form,message,input){
 const box=form.querySelector('.atp-form-error');
 if(box){box.textContent=message;box.hidden=false;if(input)input.focus();else box.focus();}
 else if(input){input.setCustomValidity(message);input.reportValidity();input.addEventListener('input',()=>input.setCustomValidity(''),{once:true});}
}
(()=>{
  const cfg=window.DenizTransfer||{};
  const t=(key,fallback='')=>cfg.strings?.[key]||fallback||key;
  const esc=s=>String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const airportFromForm=form=>({label:form.dataset.airportName||'Antalya Airport (AYT)',lat:form.dataset.airportLat||'36.8987',lng:form.dataset.airportLng||'30.8005',airport_id:form.dataset.airportId||'',source:'local',type:'airport'});
  function setPicked(input,x){input.value=x.label||'';input.dataset.lat=x.lat||'';input.dataset.lng=x.lng||'';input.dataset.airportId=x.airport_id||'';input.dataset.regionId=x.region_id||'';input.dataset.hotelId=x.hotel_id||'';input.dataset.source=x.source||'';input.dataset.type=x.type||'';}
  function clearPicked(input){input.value='';['lat','lng','airportId','regionId','hotelId','source','type'].forEach(k=>delete input.dataset[k]);}
  const iconFor=t=>t==='hotel'?'H':t==='airport'?'✈':t==='region'?'◎':'•';
  function initInput(input){
    const wrap=input.closest('.geo-field')||input.parentElement,menu=document.createElement('div');
    menu.className='geo-results geo-results-v12 twt-location-menu';menu.id='twt-locations-'+Math.random().toString(36).slice(2);menu.setAttribute('role','listbox');document.body.appendChild(menu);
    input.setAttribute('role','combobox');input.setAttribute('aria-controls',menu.id);input.setAttribute('aria-expanded','false');input.setAttribute('aria-autocomplete','list');
    let timer,seq=0,controller;
    const close=()=>{menu.replaceChildren();input.setAttribute('aria-expanded','false');};input._twtCloseLocations=()=>{++seq;clearTimeout(timer);controller?.abort();close();};
    const position=()=>{if(!menu.childNodes.length)return;const r=input.getBoundingClientRect(),v=window.visualViewport,top=v?v.offsetTop:0,left=v?v.offsetLeft:0,bottom=top+(v?v.height:window.innerHeight),right=left+(v?v.width:window.innerWidth),below=bottom-r.bottom-12,above=r.top-top-12,up=below<140&&above>below,space=Math.max(72,Math.min(320,up?above:below));
      const width=Math.max(0,Math.min(Math.max(r.width,260),right-left-20)),x=Math.max(left+10,Math.min(r.left,right-width-10));
      menu.style.width=width+'px';menu.style.left=x+'px';menu.style.maxHeight=space+'px';menu.style.top=(up?Math.max(top+10,r.top-6-Math.min(menu.scrollHeight,space)):Math.min(r.bottom+6,bottom-space-10))+'px';
    };
    const show=()=>{input.setAttribute('aria-expanded','true');position();};
    input.addEventListener('input',()=>{clearTimeout(timer);controller?.abort();const my=++seq;['lat','lng','airportId','regionId','hotelId','source','type'].forEach(k=>delete input.dataset[k]);const q=input.value.trim();close();if(q.length<2)return;timer=setTimeout(async()=>{
      controller=new AbortController();const request=controller,timeout=setTimeout(()=>request.abort(),9000);menu.innerHTML='<div class="geo-loading"><i></i><span>'+esc(t('local_search_loading'))+'</span></div>';show();
      let items=[],failed=false;try{const u=cfg.ajax+'?action=deniz_location_search&lang='+encodeURIComponent(cfg.lang||'en')+'&q='+encodeURIComponent(q);const r=await fetch(u,{credentials:'same-origin',signal:request.signal});if(!r.ok)throw new Error('search');const j=await r.json();if(!j.success||!Array.isArray(j.data))throw new Error('search');items=j.data;}catch(e){failed=true;}finally{clearTimeout(timeout);}
      if(my!==seq)return;menu.replaceChildren();if(!items.length){menu.innerHTML='<div class="geo-empty"><b>'+esc(t(failed?'location_search_error':'no_results'))+'</b><span>'+esc(t('search_hint'))+'</span></div>';show();return;}
      const rank=x=>x.type==='airport'?0:x.type==='region'?1:x.type==='hotel'?(x.source==='local'?2:3):4;items=items.map((x,i)=>[x,i]).sort((a,b)=>rank(a[0])-rank(b[0])||a[1]-b[1]).map(p=>p[0]);
      let last='';items.forEach(x=>{const group=t(x.type==='airport'?'airports':x.type==='region'?'transfer_areas':x.type==='hotel'?(x.source==='local'?'saved_hotels':'hotels_turkey'):'locations');if(group!==last){const h=document.createElement('div');h.className='geo-group';h.textContent=group;h.setAttribute('role','presentation');menu.appendChild(h);last=group;}
        const button=document.createElement('button');button.type='button';button.className='geo-option geo-option-v12';button.setAttribute('role','option');button.innerHTML='<span class="geo-icon '+esc(x.type||'place')+'">'+esc(iconFor(x.type))+'</span><span class="geo-copy"><strong>'+esc(x.label)+'</strong><small>'+esc(t(x.source==='local'?'verified_location':'map_location'))+'</small></span><span class="geo-arrow">↗</span>';button.addEventListener('mousedown',e=>e.preventDefault());button.onclick=()=>{++seq;setPicked(input,x);close();input.dispatchEvent(new Event('change',{bubbles:true}));};menu.appendChild(button);});show();
    },260);});
    input.addEventListener('focus',position);input.addEventListener('keydown',e=>{if(e.key==='Escape'){input._twtCloseLocations();return;}if(e.key==='ArrowDown'&&menu.childNodes.length){e.preventDefault();menu.querySelector('button')?.focus();}});
    menu.addEventListener('keydown',e=>{const options=[...menu.querySelectorAll('button')],i=options.indexOf(document.activeElement);if(e.key==='Escape'){input._twtCloseLocations();input.focus();}if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();options[Math.max(0,Math.min(options.length-1,i+(e.key==='ArrowDown'?1:-1)))]?.focus();}});
    document.addEventListener('click',e=>{if(!wrap.contains(e.target)&&!menu.contains(e.target))input._twtCloseLocations();});
    window.addEventListener('scroll',position,{passive:true,capture:true});window.addEventListener('resize',position,{passive:true});window.visualViewport?.addEventListener('resize',position,{passive:true});window.visualViewport?.addEventListener('scroll',position,{passive:true});
  }
  function modeUI(form,mode,preserve=false){
    const from=form.querySelector('[name=from]'),to=form.querySelector('[name=to]'),dir=form.querySelector('[name=direction]'),service=form.querySelector('[name=service_mode]'),ret=form.querySelector('.return-row'),rl=form.querySelector('[name=return_date]'),rt=form.querySelector('[name=return_time]'),airport=airportFromForm(form);
    const labels=[t('from_airport'),t('to_destination'),t('from_destination'),t('to_airport'),t('location_placeholder')];
    const oldMode=service.value;const oldDestination=oldMode==='hotel'?from:to;if(oldDestination.dataset.regionId)form._lastDestination={label:oldDestination.value,lat:oldDestination.dataset.lat,lng:oldDestination.dataset.lng,region_id:oldDestination.dataset.regionId,hotel_id:oldDestination.dataset.hotelId,type:oldDestination.dataset.type,source:oldDestination.dataset.source};
    service.value=mode;form.querySelectorAll('[data-transfer-mode]').forEach(b=>{const active=b.dataset.transferMode===mode;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
    dir.value=mode==='return'?'return':'oneway';
    if(preserve&&form.dataset.routePreset==='1')form._routeDestination={label:to.value,lat:to.dataset.lat,lng:to.dataset.lng,region_id:to.dataset.regionId,hotel_id:to.dataset.hotelId,type:to.dataset.hotelId?'hotel':'region',source:'local'};
    if(form.dataset.routePreset==='1'&&form._routeDestination){if(mode==='hotel'){setPicked(from,form._routeDestination);setPicked(to,airport);}else{setPicked(from,airport);setPicked(to,form._routeDestination);}}else if(form._lastDestination){if(mode==='hotel'){setPicked(from,form._lastDestination);setPicked(to,airport);}else{setPicked(from,airport);setPicked(to,form._lastDestination);}}else if(preserve){}else if(mode==='hotel'){clearPicked(from);setPicked(to,airport);from.placeholder=labels[4];}else{setPicked(from,airport);clearPicked(to);to.placeholder=labels[4];}
    form.querySelector('[data-from-label]').textContent=labels[mode==='hotel'?2:0];form.querySelector('[data-to-label]').textContent=labels[mode==='hotel'?3:1];
    ret.hidden=mode!=='return';rl.required=rt.required=mode==='return';
    form.querySelectorAll('[data-geocode]').forEach(input=>input._twtCloseLocations?.());
  }
  document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('[data-geocode]').forEach(initInput);document.querySelectorAll('#deniz-transfer-form').forEach(form=>{form.querySelectorAll('[data-transfer-mode]').forEach(b=>b.addEventListener('click',()=>modeUI(form,b.dataset.transferMode)));const swap=form.querySelector('.search-swap');if(swap)swap.addEventListener('click',()=>{const a=form.querySelector('[name=from]'),b=form.querySelector('[name=to]');const x={label:a.value,lat:a.dataset.lat,lng:a.dataset.lng,airport_id:a.dataset.airportId,region_id:a.dataset.regionId,hotel_id:a.dataset.hotelId,source:a.dataset.source,type:a.dataset.type};const y={label:b.value,lat:b.dataset.lat,lng:b.dataset.lng,airport_id:b.dataset.airportId,region_id:b.dataset.regionId,hotel_id:b.dataset.hotelId,source:b.dataset.source,type:b.dataset.type};setPicked(a,y);setPicked(b,x);});form.addEventListener('submit',e=>{const a=form.querySelector('[name=from]'),b=form.querySelector('[name=to]');if(!a?.dataset.lat||!b?.dataset.lat){e.preventDefault();atpSearchError(form,t('choose_locations'),!a?.dataset.lat?a:b);return;}if(form.querySelector('[name=direction]').value==='return'&&(!form.querySelector('[name=return_date]').value||!form.querySelector('[name=return_time]').value)){e.preventDefault();atpSearchError(form,t('enter_return'));return;}const values={from_lat:a.dataset.lat,from_lng:a.dataset.lng,to_lat:b.dataset.lat,to_lng:b.dataset.lng,airport_id:a.dataset.airportId||b.dataset.airportId||'',region_id:b.dataset.regionId||a.dataset.regionId||'',hotel_id:b.dataset.hotelId||a.dataset.hotelId||''};Object.entries(values).forEach(([n,v])=>{const h=form.querySelector('[name="'+n+'"]');if(h)h.value=v;});});modeUI(form,'airport',form.dataset.routePreset==='1');});});
})();

/* v41.1.5 booking notice UX — impossible pickup times are disabled before search. */
document.addEventListener('DOMContentLoaded',()=>{
 const t=(key,fallback='')=>window.DenizTransfer?.strings?.[key]||fallback||key;
 const pad=n=>String(n).padStart(2,'0');
 const antalya=d=>new Date(d.getTime()+3*3600000);
 const ymd=d=>{const a=antalya(d);return `${a.getUTCFullYear()}-${pad(a.getUTCMonth()+1)}-${pad(a.getUTCDate())}`;};
 const localHour=d=>antalya(d).getUTCHours(),localMinute=d=>antalya(d).getUTCMinutes();
 const ceil5=d=>{const x=new Date(d);x.setSeconds(0,0);const r=x.getMinutes()%5;if(r)x.setMinutes(x.getMinutes()+(5-r));return x;};
 const parseDT=(date,time)=>{if(!date||!time)return null;const x=new Date(`${date}T${time}:00+03:00`);return Number.isNaN(x.getTime())?null:x;};
 const msg=(key,hours)=>String(t(key,key==='notice_hours'?`Please book at least ${hours} hours before pickup.`:key)).replace('%d',hours);

 document.querySelectorAll('#deniz-transfer-form').forEach(form=>{
  const hours=Math.max(0,Number(form.dataset.minNotice||8));
  const date=form.querySelector('[name=date]'),time=form.querySelector('[name=time]'),timeRoot=time?.closest('[data-time-select]');
  const hour=timeRoot?.querySelector('[data-time-hour]'),minute=timeRoot?.querySelector('[data-time-minute]');
  const returnDate=form.querySelector('[name=return_date]'),returnTime=form.querySelector('[name=return_time]'),returnRoot=returnTime?.closest('[data-time-select]');
  const returnHour=returnRoot?.querySelector('[data-time-hour]'),returnMinute=returnRoot?.querySelector('[data-time-minute]');
  if(!date||!time||!hour||!minute)return;

  const earliest=()=>ceil5(new Date(Date.now()+hours*3600000));
  const clearTime=(h,m,hidden,root)=>{h.value='';m.value='';hidden.value='';root?._twtTimeRefresh?.();};
  const refreshRoot=root=>root?._twtTimeRefresh?.();

  const applyOutbound=()=>{
   const min=earliest(),minDate=ymd(min);
   date.min=minDate;
   if(!date.value||date.value<minDate)date.value=minDate;
   const same=date.value===minDate;
   [...hour.options].forEach(o=>{o.disabled=!!o.value&&same&&Number(o.value)<localHour(min);});
   if(hour.value&&hour.selectedOptions[0]?.disabled)clearTime(hour,minute,time,timeRoot);
   [...minute.options].forEach(o=>{o.disabled=!!o.value&&same&&Number(hour.value)===localHour(min)&&Number(o.value)<localMinute(min);});
   if(minute.value&&minute.selectedOptions[0]?.disabled){minute.value='';time.value='';}
   refreshRoot(timeRoot);
   applyReturn();
  };

  const applyReturn=()=>{
   if(!returnDate||!returnTime||!returnHour||!returnMinute)return;
   const out=parseDT(date.value,time.value);
   const baseDate=out?ymd(out):date.value||ymd(earliest());
   returnDate.min=baseDate;
   if(returnDate.value&&returnDate.value<baseDate)returnDate.value=baseDate;
   if(!returnDate.value){
    [...returnHour.options].forEach(o=>o.disabled=false);
    [...returnMinute.options].forEach(o=>o.disabled=false);
    refreshRoot(returnRoot);return;
   }
   const same=!!out&&returnDate.value===ymd(out);
   [...returnHour.options].forEach(o=>{o.disabled=!!o.value&&same&&Number(o.value)<localHour(out);});
   if(returnHour.value&&returnHour.selectedOptions[0]?.disabled)clearTime(returnHour,returnMinute,returnTime,returnRoot);
   [...returnMinute.options].forEach(o=>{o.disabled=!!o.value&&same&&Number(returnHour.value)===localHour(out)&&Number(o.value)<=localMinute(out);});
   if(returnMinute.value&&returnMinute.selectedOptions[0]?.disabled){returnMinute.value='';returnTime.value='';}
   refreshRoot(returnRoot);
  };

  date.addEventListener('change',applyOutbound);
  hour.addEventListener('change',applyOutbound);
  minute.addEventListener('change',()=>{applyOutbound();applyReturn();});
  time.addEventListener('change',applyReturn);
  returnDate?.addEventListener('change',applyReturn);
  returnHour?.addEventListener('change',applyReturn);
  returnMinute?.addEventListener('change',applyReturn);
  form.querySelectorAll('[data-transfer-mode]').forEach(b=>b.addEventListener('click',()=>setTimeout(applyReturn,0)));

  form.addEventListener('submit',e=>{
   const out=parseDT(date.value,time.value),min=earliest();
   if(!out||out<min){
    e.preventDefault();e.stopImmediatePropagation();
    atpSearchError(form,msg('notice_hours',hours),date);
    applyOutbound();
    return;
   }
   if(form.querySelector('[name=direction]')?.value==='return'){
    const ret=parseDT(returnDate?.value,returnTime?.value);
    if(!ret||ret<=out){
     e.preventDefault();e.stopImmediatePropagation();
     atpSearchError(form,t('return_after_outbound','Return journey must be later than the outbound journey.'),returnDate);
     applyReturn();
    }
   }
  },true);

  applyOutbound();
 });
});
