/* Small enhancements; booking and public content stay server-rendered. */
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('.atp-arrival-photo').forEach(img=>{img.addEventListener('error',()=>img.hidden=true)});
 document.querySelectorAll('.v18-destination-photo,.ev-media img,.summary-vehicle-image img').forEach(img=>{
  img.addEventListener('error',()=>{img.hidden=true;img.parentElement.classList.add('atp-missing-media')});
 });
 const status=document.getElementById('quote-status');
 if(status){
  const retry=()=>{if(!status.classList.contains('error')||status.querySelector('.atp-quote-retry'))return;const b=document.createElement('button');b.type='button';b.className='atp-quote-retry';b.textContent=window.ATPExperience?.retry||'Try again';b.addEventListener('click',()=>location.reload());status.append(b)};
  new MutationObserver(retry).observe(status,{attributes:true,attributeFilter:['class']});retry();
 }
});
document.addEventListener('DOMContentLoaded',()=>{
 const search=document.querySelector('.atp-search-panel');
 if(search&&'IntersectionObserver' in window)new IntersectionObserver(entries=>document.body.classList.toggle('atp-search-visible',entries[0].isIntersecting),{threshold:0}).observe(search);
});
