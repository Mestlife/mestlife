document.addEventListener('DOMContentLoaded',()=>{
 const f=document.getElementById('deniz-booking-form'),cfg=window.DenizBookingForm;if(!f||!cfg)return;
 const t=k=>cfg.strings?.[k]||k,input=f.querySelector('[data-verified-address]'),key=f.querySelector('[name=request_key]');
 const storageKey='twt-request:'+location.pathname+location.search;
 try{const saved=sessionStorage.getItem(storageKey);if(saved&&key)key.value=saved;else if(key)sessionStorage.setItem(storageKey,key.value);}catch(e){}
 f.addEventListener('twt-booking-created',()=>{try{sessionStorage.removeItem(storageKey);}catch(e){}});
 if(!input)return;const box=document.createElement('div');box.className='twt-address-options';box.setAttribute('role','list');input.parentElement.appendChild(box);let timer,sequence=0;
 const fields=['address_lat','address_lng','address_signature'].map(n=>f.querySelector('[name='+n+']'));
 input.addEventListener('input',()=>{fields.forEach(x=>x.value='');clearTimeout(timer);const seq=++sequence;box.replaceChildren();const q=input.value.trim();if(q.length<3)return;
 timer=setTimeout(async()=>{box.textContent=t('local_search_loading');try{const params=new URLSearchParams({action:'twt_address_search',nonce:cfg.nonce,lang:cfg.lang,region_id:cfg.region_id,q});const response=await fetch(cfg.ajax+'?'+params,{credentials:'same-origin'}),j=await response.json();if(seq!==sequence)return;box.replaceChildren();if(!j.success){box.textContent=j.data?.message||t('connection_error');return;}const items=j.data||[];if(!items.length){box.textContent=t('address_not_found');return;}items.forEach(x=>{const b=document.createElement('button');b.type='button';b.textContent=x.label;b.addEventListener('click',()=>{input.value=x.label;fields[0].value=x.lat;fields[1].value=x.lng;fields[2].value=x.signature;input.setCustomValidity('');box.replaceChildren();const preview=document.querySelector('[data-hotel-address-preview]');if(preview){preview.textContent=x.label;preview.parentElement.hidden=false;}});box.appendChild(b);});}catch(e){if(seq===sequence)box.textContent=t('connection_error');}},450);
 });
 f.addEventListener('submit',e=>{if(input.value.trim()&&!fields[2].value){e.preventDefault();e.stopImmediatePropagation();input.setCustomValidity(t('select_verified_address'));input.reportValidity();}else input.setCustomValidity('');},true);
 input.addEventListener('input',()=>input.setCustomValidity(''));
});
