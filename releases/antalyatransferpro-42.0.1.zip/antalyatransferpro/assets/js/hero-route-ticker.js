/* Native horizontal scrolling: mouse controls, keyboard and touch. No hidden links. */
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('.twt-home-routes').forEach(root=>{
  const track=root.querySelector('.twt-home-route-track');if(!track)return;
  const move=dir=>{const max=track.scrollWidth-track.clientWidth;let target=track.scrollLeft+dir*track.clientWidth;if(target>max+2)target=0;if(target<0)target=max;track.scrollTo({left:target,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});};
  root.querySelector('[data-route-prev]')?.addEventListener('click',()=>move(-1));
  root.querySelector('[data-route-next]')?.addEventListener('click',()=>move(1));
  track.addEventListener('keydown',e=>{if(e.target!==track)return;if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();move(e.key==='ArrowRight'?1:-1);}});
 });
});
