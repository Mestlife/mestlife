document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.mobile-summary-toggle'),summary=document.querySelector('.checkout-summary-card');
 if(toggle&&summary)toggle.addEventListener('click',()=>{const open=summary.classList.toggle('is-open');toggle.setAttribute('aria-expanded',String(open));});
 document.querySelectorAll('.extra-card').forEach(card=>{const name=card.querySelector('b')?.textContent||'';card.querySelectorAll('.extra-qty button').forEach(button=>button.setAttribute('aria-label',(Number(button.dataset.step)>0?'+ ':'− ')+name));card.querySelector('input')?.setAttribute('aria-label',name);});
});

// Fit the complete amount; never shorten, clip or split a monetary value.
document.addEventListener('DOMContentLoaded',()=>{
 const selector='.ev-price,#live-total,[data-booking-total]';
 const originals=new WeakMap(),observed=new WeakSet();let frame;
 function fit(){document.querySelectorAll(selector).forEach(el=>{if(!el.clientWidth)return;if(!originals.has(el))originals.set(el,parseFloat(getComputedStyle(el).fontSize));const base=originals.get(el);el.style.setProperty('font-size',base+'px','important');let size=base;while(el.scrollWidth>el.clientWidth+1&&size>10){size-=.5;el.style.setProperty('font-size',size+'px','important');}});}
 const schedule=()=>{if(frame)return;frame=requestAnimationFrame(()=>{frame=0;fit();});};
 const resize=typeof ResizeObserver!=='undefined'?new ResizeObserver(schedule):null;
 function watch(){document.querySelectorAll(selector).forEach(el=>{if(observed.has(el))return;observed.add(el);resize?.observe(el);});schedule();}
 const root=document.querySelector('.booking-page');if(root){new MutationObserver(watch).observe(root,{childList:true,subtree:true,characterData:true});watch();}
 window.addEventListener('resize',()=>{document.querySelectorAll(selector).forEach(el=>{el.style.removeProperty('font-size');originals.delete(el);});schedule();},{passive:true});
 document.fonts?.ready.then(schedule);
});
