document.addEventListener('DOMContentLoaded',()=>{
 const el=document.getElementById('deniz-zone-map'); if(!el||typeof L==='undefined')return;
 const ta=document.getElementById('deniz-zone-polygon'); let points=[]; try{points=JSON.parse(ta.value||'[]')}catch(e){}
 const map=L.map(el).setView([36.89,30.70],9); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
 let line=null, poly=null, markers=[];
 function draw(){markers.forEach(m=>map.removeLayer(m));markers=[];if(line)map.removeLayer(line);if(poly)map.removeLayer(poly); points.forEach(p=>markers.push(L.circleMarker([p.lat,p.lng],{radius:5}).addTo(map))); if(points.length>1)line=L.polyline(points.map(p=>[p.lat,p.lng])).addTo(map); ta.value=JSON.stringify(points);}
 if(points.length){draw(); if(points.length>=3){poly=L.polygon(points.map(p=>[p.lat,p.lng])).addTo(map);map.fitBounds(poly.getBounds());}}
 map.on('click',e=>{points.push({lat:+e.latlng.lat.toFixed(6),lng:+e.latlng.lng.toFixed(6)});draw();});
 document.getElementById('deniz-finish-poly')?.addEventListener('click',()=>{if(points.length<3)return alert('En az 3 nokta seçmelisin.');if(poly)map.removeLayer(poly);poly=L.polygon(points.map(p=>[p.lat,p.lng])).addTo(map);ta.value=JSON.stringify(points);});
 document.getElementById('deniz-clear-poly')?.addEventListener('click',()=>{points=[];draw();ta.value='[]';});
});
