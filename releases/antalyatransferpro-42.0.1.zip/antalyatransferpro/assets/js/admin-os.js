(function($){
 const A=window.DenizOS||{}; let regionMap,regionLayer,drawn,airportMap,airportLayer,airportMarker;
 function msg(el,txt,ok=true){$(el).html('<div class="'+(ok?'dos-success':'dos-error')+'">'+txt+'</div>')}
 function ringToPts(r){return (r||[]).map(x=>Array.isArray(x)?{lat:+x[1],lng:+x[0]}:null).filter(p=>p&&Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&Math.abs(p.lat)<=90&&Math.abs(p.lng)<=180);}
 function geoToLatLngs(g){if(!g||!g.coordinates)return[];if(g.type==='Polygon')return ringToPts(g.coordinates[0]);if(g.type==='MultiPolygon'){const polys=g.coordinates.slice().sort((a,b)=>(b[0]||[]).length-(a[0]||[]).length);return ringToPts((polys[0]||[])[0]);}return[];}
 function circlePts(lat,lng,km,n){const out=[];n=n||28;const dLat=km/111.32,dLng=km/(111.32*Math.cos(lat*Math.PI/180));for(let i=0;i<n;i++){const a=2*Math.PI*i/n;out.push({lat:+(lat+dLat*Math.sin(a)).toFixed(7),lng:+(lng+dLng*Math.cos(a)).toFixed(7)});}return out;}
 function approxArea(item){const lat=+item.lat,lng=+item.lon;if(!Number.isFinite(lat)||!Number.isFinite(lng))return[];const bb=(item.boundingbox||[]).map(Number);let km={beach:1.6,locality:2,neighbourhood:1.5,quarter:1.8,suburb:2.5,village:2.5,hamlet:1.2,town:4,road:1.5}[item.type]||2;if(bb.length===4&&bb.every(Number.isFinite)){const h=(bb[1]-bb[0])*111.32/2,w=(bb[3]-bb[2])*111.32*Math.cos(lat*Math.PI/180)/2;km=Math.max(km,Math.min(6,Math.max(h,w)));}return circlePts(lat,lng,km);}
 function normalizeCoords(raw){
  let d=typeof raw==='string'?JSON.parse(raw):raw;
  while(Array.isArray(d)&&d.length===1&&Array.isArray(d[0])&&Array.isArray(d[0][0])) d=d[0];
  if(!Array.isArray(d)) throw new Error('Koordinat listesi JSON dizi formatında olmalı.');
  const pts=d.map(p=>{
   if(Array.isArray(p)&&p.length>=2)return {lat:+p[0],lng:+p[1]};
   if(p&&typeof p==='object'&&p.lat!==undefined&&(p.lng!==undefined||p.lon!==undefined))return {lat:+p.lat,lng:+(p.lng??p.lon)};
   throw new Error('Her nokta [lat,lng] veya {lat,lng} olmalı.');
  }).filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&Math.abs(p.lat)<=90&&Math.abs(p.lng)<=180);
  if(pts.length<3)throw new Error('Polygon için en az 3 geçerli koordinat gerekli.');
  return pts;
 }
 function arrayFormat(pts){return JSON.stringify([pts.map(p=>[+p.lat,+p.lng])]);}
 function selectedText(id){return $(id+' option:selected').text().trim();}
 function filterCities(countrySel,citySel,preferred){const cid=$(countrySel).val();let first='';$(citySel+' option').each(function(){if(!this.value)return;const ok=String($(this).data('country'))===String(cid);$(this).prop('hidden',!ok).prop('disabled',!ok);if(ok&&!first)first=this.value;});if(preferred&&$(citySel+' option[value="'+preferred+'"]').length)$(citySel).val(String(preferred));else if(!$(citySel).val()||$(citySel+' option:selected').prop('disabled'))$(citySel).val(first);}
 function cityCenter(cityId){const c=(A.cities||[]).find(x=>String(x.id)===String(cityId));return c&&c.lat&&c.lng?[+c.lat,+c.lng]:null;}
 function drawRegion(pts,writeManual=true){pts=(pts||[]).map(p=>({lat:+p.lat,lng:+p.lng})).filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lng));if(pts.length<3)throw new Error('Geçerli polygon için en az 3 koordinat gerekli.');drawn.clearLayers();regionLayer=L.polygon(pts.map(p=>[p.lat,p.lng])).addTo(drawn);regionMap.fitBounds(regionLayer.getBounds(),{padding:[24,24]});$('#region_polygon').val(JSON.stringify(pts));if(writeManual)$('#region_coordinates').val(arrayFormat(pts));}
 function syncRegionLayer(layer){const pts=layer.getLatLngs()[0].map(p=>({lat:+p.lat.toFixed(7),lng:+p.lng.toFixed(7)}));$('#region_polygon').val(JSON.stringify(pts));$('#region_coordinates').val(arrayFormat(pts));}
 function initRegion(){let el=document.getElementById('region-map');if(!el)return;const cc=cityCenter($('#region_city').val())||[36.9,30.75];regionMap=L.map(el).setView(cc,10);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(regionMap);drawn=new L.FeatureGroup().addTo(regionMap);let control=new L.Control.Draw({draw:{polyline:false,rectangle:false,circle:false,circlemarker:false,marker:false,polygon:{allowIntersection:false,showArea:true}},edit:{featureGroup:drawn}});regionMap.addControl(control);regionMap.on(L.Draw.Event.CREATED,e=>{drawn.clearLayers();drawn.addLayer(e.layer);regionLayer=e.layer;syncRegionLayer(e.layer)});regionMap.on(L.Draw.Event.EDITED,e=>e.layers.eachLayer(syncRegionLayer));}
 async function boundary(query,target,mode){let r=await $.get(A.ajax,{action:'deniz_boundary',nonce:A.nonce,q:query,cc:(((Array.isArray(A.countries)?A.countries:[]).find(c=>String(c.id)===String($(target==='region'?'#region_country':'#airport_country').val()))||{}).code||'')});if(!r||!r.success||!Array.isArray(r.data)||!r.data.length)throw new Error('OSM/Nominatim üzerinde bu isimle sonuç bulunamadı. Bölge adını kontrol edin veya haritada elle çizin.');
  const polys=r.data.filter(x=>x.geojson&&(x.geojson.type==='Polygon'||x.geojson.type==='MultiPolygon')&&geoToLatLngs(x.geojson).length>=3);
  polys.sort((a,b)=>((b.category==='boundary')-(a.category==='boundary'))||((+b.importance||0)-(+a.importance||0)));
  let item=polys[0]||null,pts=item?geoToLatLngs(item.geojson):[],approx=false;
  if(!item){item=r.data.find(x=>x.category==='place')||r.data[0];if(target==='region'&&mode!=='auto')throw new Error('“'+query.split(',')[0]+'” için OSM’de resmi sınır yok (yalnızca nokta bulundu). “Otomatik Çiz” ile yaklaşık alan oluşturabilir veya haritada elle çizebilirsiniz.');pts=approxArea(item);approx=true;}
  if(target==='region'){drawRegion(pts,true);}else{$('#airport_lat').val(item.lat);$('#airport_lng').val(item.lon);if(pts.length>=3){$('#airport_polygon').val(JSON.stringify(pts));if(airportLayer)airportMap.removeLayer(airportLayer);airportLayer=L.polygon(pts.map(p=>[p.lat,p.lng])).addTo(airportMap);airportMap.fitBounds(airportLayer.getBounds());}else if(Number.isFinite(+item.lat)&&Number.isFinite(+item.lon)){airportMap.setView([+item.lat,+item.lon],13);}}
  item._approx=approx;return item;}
 $(document).on('change','#region_country',function(){filterCities('#region_country','#region_city');const cc=cityCenter($('#region_city').val());if(regionMap&&cc)regionMap.setView(cc,10);});
 $(document).on('change','#region_city',function(){const cc=cityCenter(this.value);if(regionMap&&cc)regionMap.setView(cc,10);});
 $(document).on('change','#airport_country',function(){filterCities('#airport_country','#airport_city');const cc=cityCenter($('#airport_city').val());if(airportMap&&cc)airportMap.setView(cc,11);});
 $(document).on('change','#airport_city',function(){const cc=cityCenter(this.value);if(airportMap&&cc)airportMap.setView(cc,11);});
 $(document).on('click','#boundary-find,#boundary-auto',async e=>{e.preventDefault();const mode=e.currentTarget.id==='boundary-auto'?'auto':'find',btn=$(e.currentTarget),old=btn.text();let n=$('#region_name').val(),city=selectedText('#region_city'),country=selectedText('#region_country');if(!n||!$('#region_city').val())return msg('#region-msg','Ülke, şehir ve bölge adını seçin/yazın.',false);btn.prop('disabled',true).text('Aranıyor…');try{const it=await boundary([n,city,country].filter(Boolean).join(', '),'region',mode);msg('#region-msg',it._approx?'OSM’de resmi sınır olmadığı için “'+n+'” çevresine yaklaşık bir alan çizildi. Köşeleri düzenle aracıyla sürükleyerek netleştirip kaydedin.':'OSM/Nominatim sınırı bulundu ve polygon haritaya çizildi. Kontrol edip “Bölgeyi Kaydet”e basın.');}catch(err){msg('#region-msg',err.message||'Beklenmeyen hata',false)}finally{btn.prop('disabled',false).text(old)}});
 $(document).on('click','#coordinates-draw',e=>{e.preventDefault();try{const pts=normalizeCoords($('#region_coordinates').val());drawRegion(pts,false);$('#region_coordinates').val(arrayFormat(pts));msg('#region-msg',pts.length+' koordinat okundu; polygon otomatik çizildi.');}catch(err){msg('#region-msg',err.message,false)}});
 $(document).on('click','#coordinates-copy',e=>{e.preventDefault();try{const pts=normalizeCoords($('#region_polygon').val());$('#region_coordinates').val(arrayFormat(pts));msg('#region-msg','Haritadaki polygon koordinat alanına aktarıldı.');}catch(err){msg('#region-msg','Önce haritada polygon oluşturun.',false)}});
 $(document).on('click','#polygon-clear',e=>{e.preventDefault();drawn&&drawn.clearLayers();$('#region_polygon,#region_coordinates').val('');regionLayer=null});
 $(document).on('click','#region-save',async e=>{e.preventDefault();if(!$('#region_name').val()||!$('#region_city').val())return msg('#region-msg','Şehir ve bölge adını girin.',false);if(!$('#region_polygon').val())return msg('#region-msg','Kaydetmeden önce haritada bir polygon oluşturun.',false);let r=await $.post(A.ajax,{action:'deniz_save_region',nonce:A.nonce,id:$('#region_id').val(),city_id:$('#region_city').val(),name:$('#region_name').val(),polygon:$('#region_polygon').val()});if(r.success){msg('#region-msg','Bölge kaydedildi. Sayfa yenileniyor…');setTimeout(()=>location.reload(),700)}else msg('#region-msg',r.data||'Kaydedilemedi',false)});
 $(document).on('click','.edit-region',async function(){let r=await $.get(A.ajax,{action:'deniz_get_region',nonce:A.nonce,id:$(this).data('id')});if(!r.success)return;const city=(A.cities||[]).find(x=>String(x.id)===String(r.data.city_id));if(city){$('#region_country').val(String(city.country_id));filterCities('#region_country','#region_city',r.data.city_id);}$('#region_id').val(r.data.id);$('#region_name').val(r.data.name);const poly=Array.isArray(r.data.polygon)?r.data.polygon:[];$('#region_polygon').val(poly.length?JSON.stringify(poly):'');$('#region_coordinates').val(poly.length?arrayFormat(poly):'');if(poly.length>=3){try{drawRegion(poly,false);}catch(err){msg('#region-msg',err.message,false);}}else{drawn&&drawn.clearLayers();msg('#region-msg','Bu bölgenin kayıtlı polygonu yok; Sınırı Bul, Otomatik Çiz veya elle çizim kullanın.',false);}window.scrollTo({top:0,behavior:'smooth'})});
 $(document).on('click','.scan-hotels',async function(){
  const b=$(this), old=b.text(), regionId=b.data('id');
  b.prop('disabled',true).text('Tarama hazırlanıyor…');
  let totalSaved=0,totalSeen=0,okTiles=0,failedTiles=0,endpoints={};
  try{
   const prep=await $.post(A.ajax,{action:'deniz_scan_prepare',nonce:A.nonce,region_id:regionId});
   if(!prep.success)throw new Error(prep.data||'Tarama hazırlanamadı.');
   const tiles=prep.data.tiles||[];
   if(!tiles.length)throw new Error('Polygon için taranacak alan oluşturulamadı.');
   for(let i=0;i<tiles.length;i++){
    const t=tiles[i]; b.text('OSM taranıyor '+(i+1)+'/'+tiles.length+' · '+totalSaved+' otel');
    try{
     const r=await $.post(A.ajax,{action:'deniz_scan_tile',nonce:A.nonce,region_id:regionId,south:t.south,west:t.west,north:t.north,east:t.east});
     if(r.success){okTiles++;totalSaved+=Number(r.data.saved||0);totalSeen+=Number(r.data.seen||0);if(r.data.endpoint)endpoints[r.data.endpoint]=(endpoints[r.data.endpoint]||0)+1;}
     else failedTiles++;
    }catch(e){failedTiles++;}
    await new Promise(resolve=>setTimeout(resolve,180));
   }
   b.text('Nominatim + Photon kontrolü…');
   let fb={success:false,data:{}};try{fb=await $.post(A.ajax,{action:'deniz_scan_fallback',nonce:A.nonce,region_id:regionId});}catch(e){}
   if(fb.success){totalSaved+=Number(fb.data.saved||0);totalSeen+=Number(fb.data.seen||0);}
   const ep=Object.keys(endpoints).map(k=>k+' ('+endpoints[k]+' kare)').join(', ');
   const extra=fb.success?'Nominatim: '+(fb.data.nominatim||0)+' · Photon: '+(fb.data.photon||0):'Nominatim/Photon fallback tamamlanamadı';
   alert('Tarama tamamlandı.\n'+totalSaved+' otel kaydedildi/güncellendi.\n'+totalSeen+' polygon içi aday işlendi.\nOSM kareleri: '+okTiles+' başarılı / '+failedTiles+' başarısız.\n'+(ep?'Overpass: '+ep+'\n':'')+extra);
   location.reload();
  }catch(err){alert(err.message||'Otel taraması tamamlanamadı.');}
  finally{b.prop('disabled',false).text(old);}
 });
 function setAirportMarker(lat,lng,zoom=14){lat=+lat;lng=+lng;if(!Number.isFinite(lat)||!Number.isFinite(lng))return;if(airportMarker)airportMap.removeLayer(airportMarker);airportMarker=L.marker([lat,lng]).addTo(airportMap);airportMap.setView([lat,lng],zoom);}
 function initAirport(){let el=document.getElementById('airport-map');if(!el)return;const cc=cityCenter($('#airport_city').val())||[36.8987,30.8005];airportMap=L.map(el).setView(cc,12);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(airportMap);setAirportMarker($('#airport_lat').val()||cc[0],$('#airport_lng').val()||cc[1],13);}
 $(document).on('click','#airport-find',async e=>{e.preventDefault();try{const city=selectedText('#airport_city'),country=selectedText('#airport_country');let r=await $.get(A.ajax,{action:'deniz_boundary',nonce:A.nonce,q:[($('#airport_name').val()||'Airport'),city,country].filter(Boolean).join(', ')});if(!r.success||!r.data.length)throw new Error();let x=r.data[0];$('#airport_lat').val(x.lat);$('#airport_lng').val(x.lon);setAirportMarker(x.lat,x.lon,14);}catch(e){alert('Havalimanı bulunamadı')}});
 $(document).on('click','#airport-boundary',async e=>{e.preventDefault();try{const city=selectedText('#airport_city'),country=selectedText('#airport_country');await boundary([($('#airport_name').val()||'Airport'),city,country].filter(Boolean).join(', '),'airport')}catch(err){alert(err.message)}});
 $(document).on('change','#airport_lat,#airport_lng',()=>{if(airportMap)setAirportMarker($('#airport_lat').val(),$('#airport_lng').val(),14)});
 $(document).on('click','#airport-save',async e=>{e.preventDefault();let r=await $.post(A.ajax,{action:'deniz_save_airport',nonce:A.nonce,id:$('#airport_id').val(),city_id:$('#airport_city').val(),name:$('#airport_name').val(),iata:$('#airport_iata').val(),lat:$('#airport_lat').val(),lng:$('#airport_lng').val(),polygon:$('#airport_polygon').val()});if(r.success)location.reload();else alert(r.data||'Hata')});
 $(document).on('click','#price-load',async e=>{e.preventDefault();let a=$('#price_airport').val(),c=$('#price_city').val();if(!a||!c)return;$('#price-matrix').html('<div class="dos-empty">Fiyat tablosu hazırlanıyor…</div>');let r=await $.get(A.ajax,{action:'deniz_price_matrix',nonce:A.nonce,airport_id:a,city_id:c});$('#price-matrix').html(r.success?r.data.html:'Hata')});
 $(document).on('submit','#price-form',async function(e){
  e.preventDefault();const form=this,button=form.querySelector('[type=submit]');if(button.disabled)return;
  const fields=[...form.querySelectorAll('input[name^="p["]')],matrix={};let count=0;
  fields.forEach(input=>{const m=input.name.match(/^p\[(\d+)\]\[(\d+)\]\[(one_way|return_price)\]$/);if(!m)return;matrix[m[1]]??={};if(!matrix[m[1]][m[2]]){matrix[m[1]][m[2]]={};count++;}matrix[m[1]][m[2]][m[3]]=input.value;});
  let box=form.querySelector('[data-price-result]');if(!box){box=document.createElement('div');box.dataset.priceResult='';box.setAttribute('role','status');box.setAttribute('aria-live','polite');form.append(box);}
  const notice=(text,ok)=>{box.className=ok?'dos-success':'dos-error';box.textContent=text;};
  button.disabled=true;form.setAttribute('aria-busy','true');notice('Fiyatlar kaydediliyor…',true);
  try{const response=await fetch(A.ajax,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action:'deniz_save_prices',nonce:A.nonce,airport_id:form.elements.airport_id.value,matrix_json:JSON.stringify(matrix),matrix_count:String(count)})});const result=await response.json();notice(result.data?.message||(typeof result.data==='string'?result.data:'Kaydedilemedi. Lütfen tekrar deneyin.'),response.ok&&result.success);}
  catch(error){notice('Sunucudan yanıt alınamadı. Kaydı doğrulamak için tabloyu yeniden açın; ardından gerekiyorsa tekrar kaydedin.',false);}
  finally{button.disabled=false;form.removeAttribute('aria-busy');}
 });
 $(document).on('input','#hotel-filter',function(){let q=this.value.toLowerCase();$('.dos-table tbody tr').each(function(){$(this).toggle($(this).text().toLowerCase().includes(q))})});
 $(function(){filterCities('#region_country','#region_city',$('#region_city').val());filterCities('#airport_country','#airport_city',$('#airport_city').val());initRegion();initAirport();});
})(jQuery);

jQuery(function($){
 const A=window.DenizOS||{};
 $(document).on('submit','#hotel-edit-form',async function(e){e.preventDefault();const data=$(this).serializeArray();data.push({name:'action',value:'deniz_save_hotel'},{name:'nonce',value:A.nonce});const r=await $.post(A.ajax,$.param(data));$('#hotel-save-msg').html(r.success?'<div class="dos-success">'+r.data.message+'</div>':'<div class="dos-error">'+(r.data||'Hata')+'</div>');if(r.success)setTimeout(()=>location.reload(),700);});
 $(document).on('click','.hm-edit',async function(){const r=await $.get(A.ajax,{action:'deniz_get_hotel',nonce:A.nonce,id:$(this).data('id')});if(!r.success)return;const h=r.data;['id','region','name','lat','lng','address','phone','website','stars','active','seo_title','seo_description'].forEach(k=>$('#hm_'+k).val(h[k==='region'?'region_id':k]??''));window.scrollTo({top:0,behavior:'smooth'});});
 $(document).on('click','.hm-sync',async function(){const b=$(this);b.prop('disabled',true).text('Senkron…');const r=await $.post(A.ajax,{action:'deniz_sync_hotel',nonce:A.nonce,id:b.data('id')});b.prop('disabled',false).text('SEO Sayfa');alert(r.success?r.data:(r.data||'Hata'));});
 $(document).on('click','#duplicate-scan',async function(){const box=$('#duplicate-results').html('<div class="dos-empty">Taranıyor…</div>');const r=await $.get(A.ajax,{action:'deniz_duplicates',nonce:A.nonce});if(!r.success)return box.html('<div class="dos-error">Tarama başarısız.</div>');if(!r.data.length)return box.html('<div class="dos-success">Aynı isim/bölge eşleşmesine göre duplicate bulunmadı.</div>');let html='<h3>Olası Duplicate Grupları</h3>';r.data.forEach(g=>{html+='<div class="dup-group">'+g.map(x=>'<b>#'+x.id+' '+x.name+'</b>').join('<span> ↔ </span>')+'</div>'});box.html(html);});
});

/* Deniz Hotel Import Center V8: preview-first region scan. */
jQuery(function($){
 const A=window.DenizOS||{};
 $(document).on('click','#hic-scan',async function(e){
  e.preventDefault();const btn=$(this),rid=$('#hic-region').val(),limit=$('#hic-limit').val()||40,box=$('#hic-progress');
  if(!rid){box.html('<div class="dos-error">Önce transfer bölgesi seçin.</div>');return;}
  btn.prop('disabled',true).text('Tarama hazırlanıyor…'); box.html('<div class="hic-progressbar"><i style="width:2%"></i></div><b>Polygon hazırlanıyor…</b>');
  try{
   const prep=await $.post(A.ajax,{action:'deniz_hic_prepare',nonce:A.nonce,region_id:rid,limit:limit});if(!prep.success)throw new Error(prep.data||'Tarama hazırlanamadı.');
   const token=prep.data.token,tiles=prep.data.tiles||[];let ok=0,failed=0,total=0,eps={};
   for(let i=0;i<tiles.length;i++){
    const t=tiles[i],pct=Math.max(3,Math.round(((i+1)/(tiles.length+1))*88));
    box.html('<div class="hic-progressbar"><i style="width:'+pct+'%"></i></div><b>OSM taranıyor '+(i+1)+' / '+tiles.length+'</b><small>'+total+' aday · '+failed+' başarısız kare</small>');
    try{const r=await $.post(A.ajax,{action:'deniz_hic_tile',nonce:A.nonce,token:token,region_id:rid,south:t.south,west:t.west,north:t.north,east:t.east});if(r.success){ok++;total=Number(r.data.total||total);if(r.data.endpoint)eps[r.data.endpoint]=(eps[r.data.endpoint]||0)+1;}else failed++;}catch(err){failed++;}
    await new Promise(resolve=>setTimeout(resolve,120));
   }
   box.html('<div class="hic-progressbar"><i style="width:94%"></i></div><b>Photon + Nominatim kontrol ediliyor…</b>');
   try{const fb=await $.post(A.ajax,{action:'deniz_hic_fallback',nonce:A.nonce,token:token,region_id:rid});if(fb.success)total=Number(fb.data.total||total);}catch(err){}
   box.html('<div class="hic-progressbar"><i style="width:100%"></i></div><b>Preview hazır: '+total+' aday</b><small>'+ok+' başarılı · '+failed+' başarısız OSM karesi</small>');
   const u=new URL(window.location.href);u.searchParams.set('page','deniz-hotel-manager');u.searchParams.set('tab','scan');u.searchParams.set('region_id',rid);u.searchParams.set('preview_token',token);setTimeout(()=>window.location.href=u.toString(),500);
  }catch(err){box.html('<div class="dos-error">'+(err.message||'Tarama başarısız.')+'</div>');btn.prop('disabled',false).text('Bölgedeki Otelleri Tara');}
 });
 $(document).on('click','.hic-select-safe',function(){$('.hic-check:not(:disabled)').prop('checked',true)});
 $(document).on('click','.hic-clear',function(){ $('.hic-check').prop('checked',false)});
});

/* V9 vehicle media picker + reliable hotel import commit */
jQuery(function($){
  let denizVehicleFrame=null;
  $(document).on('click','#vehicle_image_select',function(e){
    e.preventDefault();
    if(typeof wp==='undefined' || !wp.media){ alert('WordPress Media Library yüklenemedi.'); return; }
    if(!denizVehicleFrame){
      denizVehicleFrame=wp.media({title:'Araç görseli seç',button:{text:'Bu görseli kullan'},multiple:false,library:{type:'image'}});
      denizVehicleFrame.on('select',function(){
        const a=denizVehicleFrame.state().get('selection').first().toJSON();
        $('#vehicle_image_id').val(a.id);
        const url=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);
        $('#vehicle_image_preview').html('<img src="'+url+'" alt="">');
      });
    }
    denizVehicleFrame.open();
  });
  $(document).on('click','#vehicle_image_remove',function(e){e.preventDefault();$('#vehicle_image_id').val('');$('#vehicle_image_preview').html('<em>Henüz görsel seçilmedi</em>');});

  $(document).on('click','#hic-commit-safe',async function(e){
    e.preventDefault();
    const btn=$(this), token=btn.data('token');
    const selected=$('.hic-check:checked:not(:disabled)').map(function(){return $(this).val();}).get();
    const box=$('#hic-commit-result');
    if(!selected.length){box.html('<div class="dos-error">İçe aktarılacak en az bir Safe otel seçin.</div>');return;}
    btn.prop('disabled',true).text('Oteller aktarılıyor…');box.html('<div class="dos-empty">Veritabanına aktarılıyor…</div>');
    try{
      let added=0,skipped=0,url='',errors=[];
      for(let start=0;start<selected.length;start+=20){
       const r=await $.post((window.DenizOS||{}).ajax,{action:'deniz_hic_commit_ajax',nonce:(window.DenizOS||{}).nonce,preview_token:token,selected:selected.slice(start,start+20)});
       if(!r.success)throw new Error(r.data?.message||'Import başarısız.');
       const d=r.data||{};added+=Number(d.added||0);skipped+=Number(d.skipped||0);url=d.directory_url;errors.push(...(d.errors||[]));
       (d.imported||[]).forEach(index=>$('.hic-check').filter(function(){return String($(this).val())===String(index);}).closest('tr').addClass('hic-imported').find('input').prop('checked',false).prop('disabled',true));
       box.empty().append($('<div>').addClass(added?'dos-success':'dos-error').text(added+' otel aktarıldı. '+skipped+' kayıt atlandı.'));
      }
      const d={added,directory_url:url};errors.slice(0,10).forEach(x=>box.append($('<div>').addClass('dos-error').text(x.name+': '+x.message)));
      btn.prop('disabled',false).text('Seçili Otelleri İçe Aktar');
      if(Number(d.added||0)>0&&!errors.length){ setTimeout(function(){window.location.href=d.directory_url;},1200); }
    }catch(err){box.html('<div class="dos-error">'+(err.message||'Import başarısız.')+'</div>');btn.prop('disabled',false).text('Seçili Otelleri İçe Aktar');}
  });
});
