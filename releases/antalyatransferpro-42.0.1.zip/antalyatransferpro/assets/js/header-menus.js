document.addEventListener('DOMContentLoaded',()=>{
 const pickers=[...document.querySelectorAll('[data-header-picker]')];
 pickers.forEach(picker=>{
  const summary=picker.querySelector('summary');
  picker.addEventListener('toggle',()=>{summary.setAttribute('aria-expanded',String(picker.open));if(picker.open)pickers.forEach(other=>{if(other!==picker)other.open=false;});});
  picker.addEventListener('keydown',e=>{if(e.key==='Escape'){picker.open=false;summary.focus();}});
  picker.addEventListener('focusout',e=>{if(e.relatedTarget&&!picker.contains(e.relatedTarget))picker.open=false;});
 });
 document.addEventListener('click',e=>pickers.forEach(picker=>{if(!picker.contains(e.target))picker.open=false;}));
});
