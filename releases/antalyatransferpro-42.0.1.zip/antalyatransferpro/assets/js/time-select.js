(()=>{'use strict';
 document.addEventListener('DOMContentLoaded',()=>{
  const closeAll=(except)=>document.querySelectorAll('.twt-time-panel.open').forEach(panel=>{
   if(panel!==except){
    panel.classList.remove('open');
    panel.parentElement?.querySelector('.twt-time-display')?.setAttribute('aria-expanded','false');
   }
  });

  document.querySelectorAll('[data-time-select]').forEach(root=>{
   const hour=root.querySelector('[data-time-hour]'),minute=root.querySelector('[data-time-minute]'),input=root.querySelector('input'),form=root.closest('form'),row=root.closest('.return-row');
   const nativeDivider=root.querySelector('span[aria-hidden="true"]');
   if(!hour||!minute||!input)return;

   hour.classList.add('twt-native-time-select');
   minute.classList.add('twt-native-time-select');
   hour.setAttribute('aria-hidden','true');
   minute.setAttribute('aria-hidden','true');
   hour.tabIndex=-1;
   minute.tabIndex=-1;
   if(nativeDivider) nativeDivider.classList.add('twt-native-time-divider');

   const ui=document.createElement('span');
   ui.className='twt-time-ui';
   const trigger=document.createElement('button');
   trigger.type='button';
   trigger.className='twt-time-display';
   trigger.setAttribute('aria-haspopup','dialog');
   trigger.setAttribute('aria-expanded','false');
   trigger.innerHTML='<span class="twt-time-value">-- : --</span><span class="twt-time-caret">▾</span>';

   const panel=document.createElement('span');
   panel.className='twt-time-panel';
   panel.id='atp-time-'+Math.random().toString(36).slice(2);
   panel.setAttribute('role','dialog');
   trigger.setAttribute('aria-controls',panel.id);
   const panelLabel=(root.closest('label')?.querySelector('span')?.textContent||hour.getAttribute('aria-label')||'Time').trim();
   panel.setAttribute('aria-label',panelLabel);trigger.setAttribute('aria-label',panelLabel);
   const hourLabel=(hour.getAttribute('aria-label')||'Hour').trim();
   const minuteLabel=(minute.getAttribute('aria-label')||'Minute').trim();
   panel.innerHTML='\
     <span class="twt-time-panel-head">\
       <span class="twt-time-panel-label">'+panelLabel+'</span>\
       <strong class="twt-time-panel-current">--:--</strong>\
     </span>\
     <span class="twt-time-panel-body">\
       <span class="twt-time-group twt-time-hours">\
         <span class="twt-time-group-title">'+hourLabel+'</span>\
         <span class="twt-time-grid twt-time-grid-hour"></span>\
       </span>\
       <span class="twt-time-group twt-time-minutes">\
         <span class="twt-time-group-title">'+minuteLabel+'</span>\
         <span class="twt-time-grid twt-time-grid-minute"></span>\
       </span>\
     </span>';
   ui.append(trigger,panel);
   root.appendChild(ui);

   const gridHour=panel.querySelector('.twt-time-grid-hour');
   const gridMinute=panel.querySelector('.twt-time-grid-minute');
   const current=panel.querySelector('.twt-time-panel-current');
   const valueText=trigger.querySelector('.twt-time-value');

   const buildGrid=(select,grid,type)=>{
    grid.innerHTML='';
    [...select.options].forEach(opt=>{
      if(opt.value==='') return;
      const item=document.createElement('button');
      item.type='button';
      item.className='twt-time-cell';
      item.dataset.value=opt.value;
      item.textContent=opt.textContent;
      item.disabled=!!opt.disabled;
      item.classList.toggle('unavailable',!!opt.disabled);
      item.setAttribute('aria-disabled',opt.disabled?'true':'false');
      if(opt.value===select.value)item.classList.add('selected');
      item.addEventListener('click',e=>{
        e.preventDefault();e.stopPropagation();
        if(item.disabled)return;
        select.value=opt.value;
        select.dispatchEvent(new Event('change',{bubbles:true}));
        if(type==='minute'){
          trigger.focus();
          panel.classList.remove('open');
          trigger.setAttribute('aria-expanded','false');
        }
      });
      grid.appendChild(item);
    });
   };

   buildGrid(hour,gridHour,'hour');
   buildGrid(minute,gridMinute,'minute');

   const getLabel=()=>`${hour.value||'--'} : ${minute.value||'--'}`;
   const getCompact=()=>`${hour.value||'--'}:${minute.value||'--'}`;

   const refreshGrid=(select,grid)=>{
    [...select.options].forEach(opt=>{
      if(opt.value==='') return;
      const item=grid.querySelector(`.twt-time-cell[data-value="${CSS.escape(opt.value)}"]`);
      if(!item)return;
      item.disabled=!!opt.disabled;
      item.classList.toggle('unavailable',!!opt.disabled);
      item.classList.toggle('selected',opt.value===select.value);
      item.setAttribute('aria-disabled',opt.disabled?'true':'false');
    });
   };

   const sync=()=>{
    input.value=hour.value!==''&&minute.value!==''?`${hour.value}:${minute.value}`:'';
    valueText.textContent=getLabel();
    current.textContent=getCompact();
    input.dispatchEvent(new Event('change',{bubbles:true}));
   };

   const state=()=>{
    const active=!row||!row.hidden;
    hour.required=minute.required=active;
    hour.disabled=minute.disabled=!active;
    input.disabled=!active;
    trigger.disabled=!active;
    ui.classList.toggle('is-disabled',!active);
    if(!active){
      panel.classList.remove('open');
      trigger.setAttribute('aria-expanded','false');
    }
   };

   root._twtTimeRefresh=()=>{
    refreshGrid(hour,gridHour);
    refreshGrid(minute,gridMinute);
    sync();
    state();
   };

   trigger.addEventListener('click',e=>{
    e.preventDefault();e.stopPropagation();
    if(trigger.disabled)return;
    const willOpen=!panel.classList.contains('open');
    closeAll(panel);
    panel.classList.toggle('open',willOpen);
    trigger.setAttribute('aria-expanded',willOpen?'true':'false');
   });

   trigger.addEventListener('keydown',e=>{
    if(['ArrowDown','Enter',' '].includes(e.key)){
      e.preventDefault();
      if(trigger.disabled)return;
      closeAll(panel);
      panel.classList.add('open');
      trigger.setAttribute('aria-expanded','true');
    }
    if(e.key==='Escape'){
      panel.classList.remove('open');
      trigger.setAttribute('aria-expanded','false');
    }
   });

   hour.addEventListener('change',()=>{ refreshGrid(hour,gridHour); sync(); });
   minute.addEventListener('change',()=>{ refreshGrid(minute,gridMinute); sync(); });

   state();
   sync();
   root._twtTimeRefresh();

   if(row)new MutationObserver(state).observe(row,{attributes:true,attributeFilter:['hidden']});
   [hour,minute].forEach(select=>select.addEventListener('invalid',e=>{e.preventDefault();closeAll(panel);panel.classList.add('open');trigger.setAttribute('aria-expanded','true');trigger.focus();}));
   if(form){
    form.addEventListener('reset',()=>setTimeout(()=>root._twtTimeRefresh?.(),0));
    form.addEventListener('click',e=>{if(e.target.closest('[data-transfer-mode]'))setTimeout(()=>root._twtTimeRefresh?.(),0);});
   }
  });

  document.addEventListener('click',e=>{
   if(!e.target.closest('.twt-time-ui')){
    closeAll();
    document.querySelectorAll('.twt-time-display[aria-expanded="true"]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
   }
  });
  document.addEventListener('keydown',e=>{
   if(e.key==='Escape'){
    closeAll();
    document.querySelectorAll('.twt-time-display[aria-expanded="true"]').forEach(btn=>btn.setAttribute('aria-expanded','false'));
   }
  });
 });
})();
