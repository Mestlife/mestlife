<?php
/* Front page redesigned in a cleaner shuttle-booking style */
global $wpdb; $dt=deniz_tables(); $ayt=deniz_dynamic_airport('AYT'); $home_regions=deniz_dynamic_regions('antalya');
$lang=deniz_current_lang();
$brand=function_exists('twt_brand_name')?twt_brand_name():'Antalya Transfer Pro';
$c=[];
foreach(['kicker'=>'hero_kicker','h1'=>'hero_title','h1b'=>'hero_tagline','lead'=>'hero_lead','search_sub'=>'search_sub','dest'=>'dest_title','dest_sub'=>'dest_intro','fleet'=>'fleet_title','fleet_sub'=>'fleet_intro','faq'=>'faq_title','faq_sub'=>'faq_intro'] as $field=>$key) $c[$field]=deniz_t($key);
$faq_rows=atp_faq_merge([['q'=>deniz_t('faq_2_q'),'a'=>deniz_t('faq_2_a')],['q'=>deniz_t('faq_4_q'),'a'=>deniz_t('faq_4_a')]]); /* faq_1 duplicated the driver-meeting question from the FAQ engine */

$region_meta=[
 'lara'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80'],
 'kundu'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'],
 'konyaalti'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=80'],
 'belek'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80'],
 'goynuk'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1473116763249-2faaef81ccda?auto=format&fit=crop&w=1200&q=80'],
 'kemer'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1468413253725-0d5181091126?auto=format&fit=crop&w=1200&q=80'],
 'side'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'],
 'tekirova'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80'],
 'manavgat'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=1200&q=80'],
 'olympos'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1504609813442-a8924e83f76e?auto=format&fit=crop&w=1200&q=80'],
 'cirali'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=80'],
 'alanya'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80'],
];

foreach($region_meta as $slug=>&$meta){$meta['note']=deniz_t('region_note_'.$slug);}unset($meta);
$dbvehicles=deniz_dynamic_vehicles();
$hero_img='https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=82';

/* Hero route ticker: only real regions with a live airport price are shown. */
$hero_routes=[];
$preferred_keys=['kemer','alanya','belek','side','lara','kundu','manavgat','goynuk'];
$ordered_regions=(array)$home_regions;
usort($ordered_regions,function($a,$b)use($preferred_keys){
 $ka=array_search(atp_dest_key_for_region($a),$preferred_keys,true); $kb=array_search(atp_dest_key_for_region($b),$preferred_keys,true);
 $ka=$ka===false?99:$ka; $kb=$kb===false?99:$kb; return $ka<=>$kb ?: strcmp((string)$a->name,(string)$b->name);
});
foreach($ordered_regions as $r){
 if(!$ayt) break;
 $price=deniz_region_from_price((int)$r->id,(int)$ayt->id);
 if(!$price || (float)$price<=0) continue;
 $region_label=twt_entity_name($r,'region');
 $img=atp_region_image($r,'thumbnail');
 $hero_routes[]=[
  'name'=>$region_label,
  'title'=>twt_entity_name($ayt,'airport').' → '.$region_label,
  'price'=>deniz_money((float)$price),
  'url'=>atp_region_public_url($r,$ayt),
  'image'=>$img['url'],
  'alt'=>$img['alt'],
 ];
 if(count($hero_routes)>=6) break;
}

get_header();
atp_faq_schema($faq_rows);
?>

<section class="twt-home-hero atp-arrival" id="transfer-search">
  <img class="atp-arrival-photo" src="<?php echo esc_url(atp_img('hero-arrival.webp')); ?>" alt="" width="1450" height="605" fetchpriority="high" decoding="async">
  <div class="wrap atp-arrival-grid">
    <div class="atp-arrival-copy">
      <div class="atp-arrival-eyebrow"><span></span><?php echo esc_html(atp_experience_text('eyebrow')); ?></div>
      <h1><?php echo esc_html($c['h1']); ?></h1>
      <p class="atp-arrival-title"><?php echo esc_html(atp_experience_text('headline')); ?></p>
      <p class="atp-arrival-intro"><?php echo esc_html(atp_experience_text('intro')); ?></p>
      <div class="atp-arrival-points"><span>✓ <?php echo esc_html(deniz_t('meet_greet')); ?></span><span>✓ <?php echo esc_html(deniz_t('flight_tracking')); ?></span></div>
      <a class="atp-arrival-license" href="<?php echo esc_url(atp_contact()['tursab_url']); ?>" target="_blank" rel="noopener"><b>TÜRSAB</b> <?php echo esc_html(atp_l('licence')); ?> · <?php echo esc_html(atp_contact()['tursab']); ?> →</a>
    </div>
    <div class="atp-search-panel">
      <div class="atp-search-heading"><span>01 — 03</span><h2><?php echo esc_html(atp_experience_text('search_title')); ?></h2><p><?php echo esc_html(atp_experience_text('search_help')); ?></p></div>
      <?php include get_template_directory().'/template-parts/search-form.php'; ?>
      <p class="atp-search-reassurance"><?php echo esc_html(atp_experience_text('reassurance')); ?></p>
    </div>
  </div>
</section>
<?php if($hero_routes): ?>
<section class="atp-route-ribbon"><div class="wrap"><b><?php echo esc_html(atp_experience_text('popular')); ?></b><div><?php foreach(array_slice($hero_routes,0,4) as $route): ?><a href="<?php echo esc_url($route['url']); ?>"><span>AYT → <?php echo esc_html($route['name']); ?></span><strong><?php echo esc_html($route['price']); ?> <small>→</small></strong></a><?php endforeach; ?></div></div></section>
<?php endif; ?>

<section class="twt-home-trustbar">
  <div class="wrap">
    <div><i><?php echo twt_icon('tag'); ?></i><span><b><?php echo esc_html(deniz_t('fixed_prices')); ?></b><small><?php echo esc_html(deniz_t('no_hidden_fees')); ?></small></span></div>
    <div><i><?php echo twt_icon('users'); ?></i><span><b><?php echo esc_html(deniz_t('meet_greet')); ?></b><small><?php echo esc_html(deniz_t('at_airport')); ?></small></span></div>
    <div><i><?php echo twt_icon('plane'); ?></i><span><b><?php echo esc_html(deniz_t('flight_tracking')); ?></b><small><?php echo esc_html(deniz_t('track_flight')); ?></small></span></div>
    <div><i><?php echo twt_icon('support'); ?></i><span><b><?php echo esc_html(deniz_t('support')); ?></b><small><?php echo esc_html(deniz_t('always_here')); ?></small></span></div>
    <div><i><?php echo twt_icon('card'); ?></i><span><b><?php echo esc_html(deniz_t('cash_driver')); ?></b><small><?php echo esc_html(deniz_t('pay_arrival')); ?></small></span></div>
  </div>
</section>

<?php atp_reviews_section('home'); ?>

<section class="atp-service-answer" id="about-us"><div class="wrap">
  <div><div class="eyebrow"><?php echo esc_html(deniz_t('airport_transfer')); ?></div><h2><?php echo esc_html(atp_experience_text('quick_title')); ?></h2><p><?php echo esc_html(atp_experience_text('quick_answer')); ?></p></div>
  <ol class="atp-booking-steps"><li><span>01</span><?php echo esc_html(atp_experience_text('step1')); ?></li><li><span>02</span><?php echo esc_html(atp_experience_text('step2')); ?></li><li><span>03</span><?php echo esc_html(atp_experience_text('step3')); ?></li></ol>
</div></section>

<section class="app-section v18-destinations">
  <div class="wrap">
    <div class="v18-section-head inline-head">
      <div>
        <small><?php echo esc_html(deniz_t('destinations')); ?></small>
        <h2><?php echo esc_html($c['dest']); ?></h2>
        <p><?php echo esc_html($c['dest_sub']); ?></p>
      </div>
      <a href="<?php echo esc_url(get_post_type_archive_link('transfer-route')); ?>"><?php echo esc_html(deniz_t('all_destinations')); ?> →</a>
    </div>
    <div class="v18-destination-grid">
      <?php foreach(array_slice($ordered_regions,0,8) as $r): $slug=sanitize_title($r->slug ?: $r->name); $dkey=atp_dest_key_for_region($r); $meta=$region_meta[$slug] ?? ($dkey&&isset($region_meta[$dkey])?$region_meta[$dkey]:['tag'=>'','time'=>'','note'=>'','img'=>$hero_img]); if(empty($meta['note'])||$meta['note']==='region_note_'.$slug){ $about=$dkey?(atp_ld()['dest'][$dkey]['about'][atp_lang()]??''):''; $meta['note']=$about?wp_trim_words($about,14):''; } $mt=($ayt&&function_exists('twt_route_metrics'))?twt_route_metrics($ayt,$r):[]; $meta['tag']=!empty($mt['distance'])?round($mt['distance']).' km':''; $meta['time']=!empty($mt['duration'])?'~'.(int)$mt['duration'].' '.deniz_t('minutes'):''; $rp=deniz_region_from_price($r->id,$ayt?$ayt->id:0); ?>
        <?php $rimg=atp_region_image($r,'medium_large'); ?>
        <a class="v18-destination-card" href="<?php echo esc_url(atp_region_public_url($r,$ayt)); ?>">
          <div class="v18-destination-image"><img class="v18-destination-photo" src="<?php echo esc_url($rimg['url']); ?>" alt="<?php echo esc_attr($rimg['alt']); ?>" loading="lazy" decoding="async" width="400" height="138"><?php if($meta['tag']): ?><span><?php echo esc_html($meta['tag']); ?></span><?php endif; ?></div>
          <div class="v18-destination-body">
            <h3><?php echo esc_html(twt_entity_name($r,'region')); ?></h3>
            <p><?php echo esc_html($meta['note']); ?></p>
            <div class="v18-destination-meta"><strong><?php echo $rp ? esc_html(deniz_t('starting_price').' '.deniz_money((float)$rp)) : esc_html(deniz_t('check_fare')); ?></strong><small><?php echo esc_html($meta['time']); ?></small></div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <div class="atp-home-links"><h3><?php echo esc_html(atp_l('all_dest_h')); ?></h3><?php atp_link_cards(['belek','kemer','side','alanya','lara','kundu','manavgat','konyaalti','tekirova','goynuk','kadriye','mahmutlar'],atp_lang()); ?><p><a class="atp-btn atp-btn-line" href="<?php echo esc_url(atp_landing_url('hub')); ?>"><?php echo esc_html(atp_l('see_all')); ?> →</a></p></div>
  </div>
</section>

<section class="app-section v18-vehicle-showcase">
  <div class="wrap">
    <div class="v18-section-head">
      <small><?php echo esc_html(deniz_t('our_fleet')); ?></small>
      <h2><?php echo esc_html($c['fleet']); ?></h2>
      <p><?php echo esc_html($c['fleet_sub']); ?></p>
    </div>
    <?php if($dbvehicles):
      $is_shared_v=fn($x)=>(($x->pricing_type??'')==='per_person')||(($x->service_type??'')==='shuttle');
      $v=$dbvehicles[0]; foreach($dbvehicles as $cand){ if(!$is_shared_v($cand)){ $v=$cand; break; } }
      $v_shared=$is_shared_v($v);
      $img=$v->image_id?wp_get_attachment_image_url($v->image_id,'full'):''; ?>
      <article class="v18-vehicle-card">
        <div class="v18-vehicle-copy">
          <small class="atp-vehicle-kind"><?php echo esc_html(deniz_t($v_shared?'shared_transfer':'private_transfer')); ?></small>
          <h3><?php echo esc_html(twt_entity_name($v,'vehicle')); ?></h3>
          <div class="v18-vehicle-specs"><?php echo (int)$v->pax; ?> <?php echo esc_html(deniz_t('passengers')); ?> · <?php echo (int)$v->bags; ?> <?php echo esc_html(deniz_t('bags')); ?></div>
          <p><?php echo esc_html(deniz_t($v_shared?'vehicle_desc_shared':'vehicle_desc')); ?></p>
          <ul>
            <li><?php echo esc_html(deniz_t('english_driver')); ?></li>
            <li><?php echo esc_html(deniz_t('air_conditioned')); ?></li>
            <li><?php echo esc_html(deniz_t('flight_pickup')); ?></li>
            <li><?php echo esc_html(deniz_t('cash_available')); ?></li>
            <li><?php echo esc_html(deniz_t('child_seats')); ?></li>
            <li><?php echo esc_html(deniz_t($v_shared?'shared_dropoff':'door_service')); ?></li>
          </ul>
          <div class="v18-vehicle-actions">
            <a href="<?php echo esc_url(get_post_type_archive_link('vehicle')); ?>" class="v18-btn v18-btn-secondary"><?php echo esc_html(deniz_t('all_vehicles')); ?></a>
            <a href="#transfer-search" class="v18-btn v18-btn-primary"><?php echo esc_html(deniz_t('book_transfer')); ?></a>
          </div>
        </div>
        <div class="v18-vehicle-media">
          <?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr(twt_entity_name($v,'vehicle').' – '.deniz_t($v_shared?'shared_transfer':'private_transfer')); ?>" loading="lazy"><?php else: ?><div class="v18-vehicle-placeholder"><span></span></div><?php endif; ?>
        </div>
      </article>
    <?php else: ?>
      <div class="knowledge-empty"><?php echo esc_html(deniz_t('vehicle_empty')); ?></div>
    <?php endif; ?>
  </div>
</section>

<section class="app-section v18-how" id="how-it-works">
  <div class="wrap">
    <div class="v18-section-head">
      <small><?php echo esc_html(deniz_t('how_it_works')); ?></small>
      <h2><?php echo esc_html(deniz_t('how_title')); ?></h2>
    </div>
    <div class="v18-step-grid">
      <article><i>01</i><h3><?php echo esc_html(deniz_t('step1_title')); ?></h3><p><?php echo esc_html(deniz_t('step1_desc')); ?></p></article>
      <article><i>02</i><h3><?php echo esc_html(deniz_t('step2_title')); ?></h3><p><?php echo esc_html(deniz_t('step2_desc')); ?></p></article>
      <article><i>03</i><h3><?php echo esc_html(deniz_t('step3_title')); ?></h3><p><?php echo esc_html(deniz_t('step3_desc')); ?></p></article>
      <article><i>04</i><h3><?php echo esc_html(deniz_t('step4_title')); ?></h3><p><?php echo esc_html(deniz_t('step4_desc')); ?></p></article>
    </div>
  </div>
</section>

<section class="app-section v18-faq" id="faq">
  <div class="wrap faq-wrap">
    <div class="v18-section-head center-head">
      <small><?php echo esc_html(deniz_t('faq_kicker')); ?></small>
      <h2><?php echo esc_html($c['faq']); ?></h2>
      <p><?php echo esc_html($c['faq_sub']); ?></p>
    </div>
    <div class="v18-faq-list">
      <?php foreach($faq_rows as $i=>$row): ?>
      <details <?php echo $i===0?'open':''; ?>><summary><?php echo esc_html($row['q']); ?></summary><p><?php echo esc_html($row['a']); ?></p></details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
