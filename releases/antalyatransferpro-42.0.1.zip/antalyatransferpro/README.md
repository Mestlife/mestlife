# Antalya Transfer Pro – WordPress Teması (v41)

## Kurulum
1. Görünüm › Temalar › Yeni Ekle › Tema Yükle → `antalyatransferpro.zip` → Etkinleştir.
2. Ayarlar › Kalıcı Bağlantılar → “Yazı ismi” → Kaydet (rewrite kurallarını yeniler).
3. Tema ilk açılışta otomatik olarak: site adı, ana sayfa (Home) ve blog sayfası, şirket bilgileri (telefon, adres, WhatsApp) ayarlanır.
4. Önbellek eklentisi / Cloudflare varsa önbelleği temizleyin.

## Dinamik veriler (sabit rakam yok)
- **Fiyat:** Fiyat matrisinden (Transfer Operasyon › Fiyatlar) en düşük araç fiyatı.
- **Mesafe / süre:** Önce fiyat matrisindeki havalimanı + bölge rotası, yoksa sayfa koordinatları üzerinden OSRM yol rotası (30 gün önbellek, saatlik cron ile eksikler tamamlanır).
- **Yönetim:** Transfer Operasyon › **SEO Sayfaları** → canlı km/dk, kaynak, manuel düzeltme ve “Eksik mesafeleri şimdi hesapla” butonu.
- Değer henüz yoksa sayfada rakam gösterilmez, metin otomatik olarak rakamsız versiyona geçer.
- Oteller, araçlar ve fiyat tablosu ilgili bölge veritabanında varsa SEO sayfalarında otomatik görünür.

## SEO sayfaları (37 sayfa × TR/EN/DE/RU = 148 URL)
Örnekler: `/tr/antalya-transfer/`, `/en/antalya-airport-transfer/`, `/en/antalya-airport-to-hotel-transfer/`, `/de/antalya-belek-transfer/`, `/ru/antalya-kemer-transfer/` …
Metinler `inc/seo-landings.json` dosyasındadır (kod değiştirmeden düzenlenebilir).

## Teknik SEO
- `/robots.txt`, `/wp-sitemap.xml`, `/landing-sitemap.xml` (hreflang), `/hotel-sitemap.xml`, `/llms.txt`, `/sitemap.xml` → 301.
- Her sayfada ≥13 SSS + tek FAQPage şeması; TravelAgency/LocalBusiness (TÜRSAB 18926, adres, telefon), Service, Place, Breadcrumb, WebPage şemaları; canonical + hreflang (x-default: EN).
- Search Console’a `wp-sitemap.xml`, `landing-sitemap.xml`, `hotel-sitemap.xml` gönderin.
- Yoast / Rank Math kullanılırsa tema kendi meta/şema çıktısını kapatır; SEO sayfalarının başlık/açıklama/canonical değerleri eklentiye aktarılır.

## İletişim bilgileri
`inc/brand-core.php` → `atp_contact()` (telefon, WhatsApp, adres, TÜRSAB no).
