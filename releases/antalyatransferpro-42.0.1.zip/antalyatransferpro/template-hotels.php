<?php
if(!defined('ABSPATH'))exit;
get_header();
if(twt_hotel_entity())twt_hotel_detail_render();else twt_hotel_directory_render();
get_footer();
