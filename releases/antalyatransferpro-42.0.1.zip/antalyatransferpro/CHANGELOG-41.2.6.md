# 41.2.6

- Added a custom Antalya Transfer Pro favicon/app-icon family.
- Added 16, 32, 48, 180, 192 and 512 px PNG assets plus a multi-size ICO.
- Theme favicon is now used consistently on public pages and wp-admin.
- Added theme-version query strings to favicon assets to reduce stale browser caching.
- No booking, pricing, route, language, SEO URL, canonical, hreflang or sitemap logic changed.
