<?php get_header(); get_template_part('template-parts/single-transfer-content'); get_footer(); ?>
