<?php
/* Front page redesigned in a cleaner shuttle-booking style */
global $wpdb; $dt=deniz_tables(); $ayt=deniz_dynamic_airport('AYT'); $home_regions=deniz_dynamic_regions('antalya');
$lang=deniz_current_lang();
$brand=function_exists('twt_brand_name')?twt_brand_name():'Antalya Transfer Pro';
$c=[];
foreach(['kicker'=>'hero_kicker','h1'=>'hero_title','h1b'=>'hero_tagline','lead'=>'hero_lead','search_sub'=>'search_sub','dest'=>'dest_title','dest_sub'=>'dest_intro','fleet'=>'fleet_title','fleet_sub'=>'fleet_intro','faq'=>'faq_title','faq_sub'=>'faq_intro'] as $field=>$key) $c[$field]=deniz_t($key);
$faq_rows=atp_faq_merge([['q'=>deniz_t('faq_2_q'),'a'=>deniz_t('faq_2_a')],['q'=>deniz_t('faq_4_q'),'a'=>deniz_t('faq_4_a')]]); /* faq_1 duplicated the driver-meeting question from the FAQ engine */

$region_meta=[
 'lara'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80'],
 'kundu'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'],
 'konyaalti'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=80'],
 'belek'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80'],
 'goynuk'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1473116763249-2faaef81ccda?auto=format&fit=crop&w=1200&q=80'],
 'kemer'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1468413253725-0d5181091126?auto=format&fit=crop&w=1200&q=80'],
 'side'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'],
 'tekirova'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80'],
 'manavgat'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=1200&q=80'],
 'olympos'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1504609813442-a8924e83f76e?auto=format&fit=crop&w=1200&q=80'],
 'cirali'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=80'],
 'alanya'=>['note'=>'','img'=>'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80'],
];

foreach($region_meta as $slug=>&$meta){$meta['note']=deniz_t('region_note_'.$slug);}unset($meta);
$dbvehicles=deniz_dynamic_vehicles();
$hero_img='https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=82';

/* Hero route ticker: only real regions with a live airport price are shown. */
$hero_routes=[];
$preferred_keys=['kemer','alanya','belek','side','lara','kundu','manavgat','goynuk'];
$ordered_regions=(array)$home_regions;
usort($ordered_regions,function($a,$b)use($preferred_keys){
 $ka=array_search(atp_dest_key_for_region($a),$preferred_keys,true); $kb=array_search(atp_dest_key_for_region($b),$preferred_keys,true);
 $ka=$ka===false?99:$ka; $kb=$kb===false?99:$kb; return $ka<=>$kb ?: strcmp((string)$a->name,(string)$b->name);
});
foreach($ordered_regions as $r){
 if(!$ayt) break;
 $price=deniz_region_from_price((int)$r->id,(int)$ayt->id);
 if(!$price || (float)$price<=0) continue;
 $region_label=twt_entity_name($r,'region');
 $img=atp_region_image($r,'thumbnail');
 $hero_routes[]=[
  'name'=>$region_label,
  'title'=>twt_entity_name($ayt,'airport').' → '.$region_label,
  'price'=>deniz_money((float)$price),
  'url'=>atp_region_public_url($r,$ayt),
  'image'=>$img['url'],
  'alt'=>$img['alt'],
 ];
 if(count($hero_routes)>=6) break;
}

get_header();
atp_faq_schema($faq_rows);
?>

<section class="twt-home-hero atp-arrival" id="transfer-search">
  <img class="atp-arrival-photo" src="<?php echo esc_url(atp_home_image_url('hero',atp_img('hero-arrival.webp'))); ?>" alt="" width="1450" height="605" fetchpriority="high" decoding="async">
  <div class="wrap atp-arrival-grid">
    <div class="atp-arrival-copy">
      <div class="atp-arrival-eyebrow"><span></span><?php echo esc_html(atp_experience_text('eyebrow')); ?></div>
      <h1><?php echo esc_html($c['h1']); ?></h1>
      <p class="atp-arrival-title"><?php echo esc_html(atp_experience_text('headline')); ?></p>
      <p class="atp-arrival-intro"><?php echo esc_html(atp_experience_text('intro')); ?></p>
      <div class="atp-arrival-points"><span>✓ <?php echo esc_html(deniz_t('meet_greet')); ?></span><span>✓ <?php echo esc_html(deniz_t('flight_tracking')); ?></span></div>
      <a class="atp-arrival-license" href="<?php echo esc_url(atp_contact()['tursab_url']); ?>" target="_blank" rel="noopener"><b>TÜRSAB</b> <?php echo esc_html(atp_l('licence')); ?> · <?php echo esc_html(atp_contact()['tursab']); ?> →</a>
    </div>
    <div class="atp-search-panel">
      <div class="atp-search-heading"><span>01 — 03</span><h2><?php echo esc_html(atp_experience_text('search_title')); ?></h2><p><?php echo esc_html(atp_experience_text('search_help')); ?></p></div>
      <?php include get_template_directory().'/template-parts/search-form.php'; ?>
      <p class="atp-search-reassurance"><?php echo esc_html(atp_experience_text('reassurance')); ?></p>
    </div>
  </div>
</section>
<?php if($hero_routes): ?>
<section class="atp-route-ribbon"><div class="wrap"><b><?php echo esc_html(atp_experience_text('popular')); ?></b><div><?php foreach(array_slice($hero_routes,0,4) as $route): ?><a href="<?php echo esc_url($route['url']); ?>"><span>AYT → <?php echo esc_html($route['name']); ?></span><strong><?php echo esc_html($route['price']); ?> <small>→</small></strong></a><?php endforeach; ?></div></div></section>
<?php endif; ?>

<section class="twt-home-trustbar">
  <div class="wrap">
    <div><i><?php echo twt_icon('tag'); ?></i><span><b><?php echo esc_html(deniz_t('fixed_prices')); ?></b><small><?php echo esc_html(deniz_t('no_hidden_fees')); ?></small></span></div>
    <div><i><?php echo twt_icon('users'); ?></i><span><b><?php echo esc_html(deniz_t('meet_greet')); ?></b><small><?php echo esc_html(deniz_t('at_airport')); ?></small></span></div>
    <div><i><?php echo twt_icon('plane'); ?></i><span><b><?php echo esc_html(deniz_t('flight_tracking')); ?></b><small><?php echo esc_html(deniz_t('track_flight')); ?></small></span></div>
    <div><i><?php echo twt_icon('support'); ?></i><span><b><?php echo esc_html(deniz_t('support')); ?></b><small><?php echo esc_html(deniz_t('always_here')); ?></small></span></div>
    <div><i><?php echo twt_icon('card'); ?></i><span><b><?php echo esc_html(deniz_t('cash_driver')); ?></b><small><?php echo esc_html(deniz_t('pay_arrival')); ?></small></span></div>
  </div>
</section>

<?php atp_reviews_section('home'); ?>

<section class="atp-service-answer" id="about-us"><div class="wrap">
  <div><div class="eyebrow"><?php echo esc_html(deniz_t('airport_transfer')); ?></div><h2><?php echo esc_html(atp_experience_text('quick_title')); ?></h2><p><?php echo esc_html(atp_experience_text('quick_answer')); ?></p></div>
  <ol class="atp-booking-steps"><li><span>01</span><?php echo esc_html(atp_experience_text('step1')); ?></li><li><span>02</span><?php echo esc_html(atp_experience_text('step2')); ?></li><li><span>03</span><?php echo esc_html(atp_experience_text('step3')); ?></li></ol>
</div></section>

<section class="app-section v18-destinations">
  <div class="wrap">
    <div class="v18-section-head inline-head">
      <div>
        <small><?php echo esc_html(deniz_t('destinations')); ?></small>
        <h2><?php echo esc_html($c['dest']); ?></h2>
        <p><?php echo esc_html($c['dest_sub']); ?></p>
      </div>
      <a href="<?php echo esc_url(get_post_type_archive_link('transfer-route')); ?>"><?php echo esc_html(deniz_t('all_destinations')); ?> →</a>
    </div>
    <div class="v18-destination-grid">
      <?php foreach(array_slice($ordered_regions,0,8) as $r): $slug=sanitize_title($r->slug ?: $r->name); $dkey=atp_dest_key_for_region($r); $meta=$region_meta[$slug] ?? ($dkey&&isset($region_meta[$dkey])?$region_meta[$dkey]:['tag'=>'','time'=>'','note'=>'','img'=>$hero_img]); if(empty($meta['note'])||$meta['note']==='region_note_'.$slug){ $about=$dkey?(atp_ld()['dest'][$dkey]['about'][atp_lang()]??''):''; $meta['note']=$about?wp_trim_words($about,14):''; } $mt=($ayt&&function_exists('twt_route_metrics'))?twt_route_metrics($ayt,$r):[]; $meta['tag']=!empty($mt['distance'])?round($mt['distance']).' km':''; $meta['time']=!empty($mt['duration'])?'~'.(int)$mt['duration'].' '.deniz_t('minutes'):''; $rp=deniz_region_from_price($r->id,$ayt?$ayt->id:0); ?>
        <?php $rimg=atp_region_image($r,'medium_large'); ?>
        <a class="v18-destination-card" href="<?php echo esc_url(atp_region_public_url($r,$ayt)); ?>">
          <div class="v18-destination-image"><img class="v18-destination-photo" src="<?php echo esc_url($rimg['url']); ?>" alt="<?php echo esc_attr($rimg['alt']); ?>" loading="lazy" decoding="async" width="400" height="138"><?php if($meta['tag']): ?><span><?php echo esc_html($meta['tag']); ?></span><?php endif; ?></div>
          <div class="v18-destination-body">
            <h3><?php echo esc_html(twt_entity_name($r,'region')); ?></h3>
            <p><?php echo esc_html($meta['note']); ?></p>
            <div class="v18-destination-meta"><strong><?php echo $rp ? esc_html(deniz_t('starting_price').' '.deniz_money((float)$rp)) : esc_html(deniz_t('check_fare')); ?></strong><small><?php echo esc_html($meta['time']); ?></small></div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <div class="atp-home-links"><h3><?php echo esc_html(atp_l('all_dest_h')); ?></h3><?php atp_link_cards(['belek','kemer','side','alanya','lara','kundu','manavgat','konyaalti','tekirova','goynuk','kadriye','mahmutlar'],atp_lang()); ?><p><a class="atp-btn atp-btn-line" href="<?php echo esc_url(atp_landing_url('hub')); ?>"><?php echo esc_html(atp_l('see_all')); ?> →</a></p></div>
  </div>
</section>

<section class="app-section v18-vehicle-showcase">
  <div class="wrap">
    <div class="v18-section-head">
      <small><?php echo esc_html(deniz_t('our_fleet')); ?></small>
      <h2><?php echo esc_html($c['fleet']); ?></h2>
      <p><?php echo esc_html($c['fleet_sub']); ?></p>
    </div>
    <?php if($dbvehicles):
      $is_shared_v=fn($x)=>(($x->pricing_type??'')==='per_person')||(($x->service_type??'')==='shuttle');
      $v=$dbvehicles[0]; foreach($dbvehicles as $cand){ if(!$is_shared_v($cand)){ $v=$cand; break; } }
      $v_shared=$is_shared_v($v);
      $img=$v->image_id?wp_get_attachment_image_url($v->image_id,'full'):''; ?>
      <article class="v18-vehicle-card">
        <div class="v18-vehicle-copy">
          <small class="atp-vehicle-kind"><?php echo esc_html(deniz_t($v_shared?'shared_transfer':'private_transfer')); ?></small>
          <h3><?php echo esc_html(twt_entity_name($v,'vehicle')); ?></h3>
          <div class="v18-vehicle-specs"><?php echo (int)$v->pax; ?> <?php echo esc_html(deniz_t('passengers')); ?> · <?php echo (int)$v->bags; ?> <?php echo esc_html(deniz_t('bags')); ?></div>
          <p><?php echo esc_html(deniz_t($v_shared?'vehicle_desc_shared':'vehicle_desc')); ?></p>
          <ul>
            <li><?php echo esc_html(deniz_t('english_driver')); ?></li>
            <li><?php echo esc_html(deniz_t('air_conditioned')); ?></li>
            <li><?php echo esc_html(deniz_t('flight_pickup')); ?></li>
            <li><?php echo esc_html(deniz_t('cash_available')); ?></li>
            <li><?php echo esc_html(deniz_t('child_seats')); ?></li>
            <li><?php echo esc_html(deniz_t($v_shared?'shared_dropoff':'door_service')); ?></li>
          </ul>
          <div class="v18-vehicle-actions">
            <a href="<?php echo esc_url(get_post_type_archive_link('vehicle')); ?>" class="v18-btn v18-btn-secondary"><?php echo esc_html(deniz_t('all_vehicles')); ?></a>
            <a href="#transfer-search" class="v18-btn v18-btn-primary"><?php echo esc_html(deniz_t('book_transfer')); ?></a>
          </div>
        </div>
        <div class="v18-vehicle-media">
          <?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr(twt_entity_name($v,'vehicle').' – '.deniz_t($v_shared?'shared_transfer':'private_transfer')); ?>" loading="lazy"><?php else: ?><div class="v18-vehicle-placeholder"><span></span></div><?php endif; ?>
        </div>
      </article>
    <?php else: ?>
      <div class="knowledge-empty"><?php echo esc_html(deniz_t('vehicle_empty')); ?></div>
    <?php endif; ?>
  </div>
</section>

<section class="app-section v18-how" id="how-it-works">
  <div class="wrap">
    <div class="v18-section-head">
      <small><?php echo esc_html(deniz_t('how_it_works')); ?></small>
      <h2><?php echo esc_html(deniz_t('how_title')); ?></h2>
    </div>
    <?php $atp_why_image=atp_home_image_url('why',''); if($atp_why_image): ?><figure class="atp-home-intro-photo"><img src="<?php echo esc_url($atp_why_image); ?>" alt="<?php echo esc_attr(deniz_t('how_title')); ?>" width="1200" height="480" loading="lazy" decoding="async" style="width:100%;height:auto;max-height:480px;object-fit:cover;border-radius:16px"></figure><?php endif; ?>
    <div class="v18-step-grid">
      <article><i>01</i><h3><?php echo esc_html(deniz_t('step1_title')); ?></h3><p><?php echo esc_html(deniz_t('step1_desc')); ?></p></article>
      <article><i>02</i><h3><?php echo esc_html(deniz_t('step2_title')); ?></h3><p><?php echo esc_html(deniz_t('step2_desc')); ?></p></article>
      <article><i>03</i><h3><?php echo esc_html(deniz_t('step3_title')); ?></h3><p><?php echo esc_html(deniz_t('step3_desc')); ?></p></article>
      <article><i>04</i><h3><?php echo esc_html(deniz_t('step4_title')); ?></h3><p><?php echo esc_html(deniz_t('step4_desc')); ?></p></article>
    </div>
  </div>
</section>

<?php
$atp_blog_lang=atp_lang();
$atp_home_guide_args=['post_type'=>'post','post_status'=>'publish','posts_per_page'=>3,'orderby'=>'date','order'=>'DESC'];
if($atp_blog_lang!=='tr')$atp_home_guide_args['meta_query']=[['key'=>'deniz_'.$atp_blog_lang.'_title','value'=>'','compare'=>'!='],['key'=>'deniz_'.$atp_blog_lang.'_content','value'=>'','compare'=>'!=']];
$atp_home_guides=get_posts($atp_home_guide_args);
$atp_blog_text=[
 'en'=>['kicker'=>'TRAVEL JOURNAL','title'=>'Airport transfer tips & travel guides','desc'=>'Helpful answers for your next Antalya journey.','more'=>'Read article','all'=>'All travel guides'],
 'de'=>['kicker'=>'REISEJOURNAL','title'=>'Flughafentransfer-Tipps & Reiseführer','desc'=>'Praktische Antworten für Ihre nächste Antalya-Reise.','more'=>'Artikel lesen','all'=>'Alle Reiseartikel'],
 'ru'=>['kicker'=>'ЖУРНАЛ ПУТЕШЕСТВИЙ','title'=>'Советы по трансферу и путеводители','desc'=>'Полезные ответы для поездки в Анталью.','more'=>'Читать статью','all'=>'Все статьи'],
 'tr'=>['kicker'=>'SEYAHAT REHBERİ','title'=>'Havalimanı transfer ipuçları ve gezi rehberleri','desc'=>'Antalya seyahatiniz için faydalı cevaplar.','more'=>'Yazıyı oku','all'=>'Tüm rehberler']
][$atp_blog_lang] ?? [];
if($atp_home_guides): ?>

<style id="atp-travel-guides-critical">
/* Self-contained homepage editorial component. Works independently of theme stylesheet ordering. */
#travel-guides.atp-home-blog{display:block!important;position:relative!important;clear:both!important;box-sizing:border-box!important;width:100%!important;max-width:none!important;min-width:0!important;background:#f3f6fa!important;margin:0!important;padding:72px 24px 88px!important;color:#142a43!important;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;font-size:16px!important;line-height:1.5!important;text-align:left!important;}
#travel-guides *,#travel-guides *::before,#travel-guides *::after{box-sizing:border-box!important}
#travel-guides .atp-home-blog-container{display:block!important;width:100%!important;max-width:1200px!important;margin:0 auto!important;padding:0!important}
#travel-guides .atp-home-blog-heading{display:flex!important;justify-content:space-between!important;align-items:flex-end!important;gap:24px!important;margin:0 0 30px!important;padding:0!important;width:100%!important}
#travel-guides .atp-home-blog-kicker{display:block!important;color:#875321!important;text-transform:uppercase!important;letter-spacing:2px!important;font-size:12px!important;font-weight:800!important;margin-bottom:8px!important}
#travel-guides .atp-home-blog-heading h2{font-family:Inter,system-ui,sans-serif!important;font-size:clamp(27px,3vw,39px)!important;line-height:1.16!important;font-weight:800!important;letter-spacing:-.6px!important;margin:0 0 12px!important;color:#102946!important}
#travel-guides .atp-home-blog-heading p{font-size:15px!important;line-height:1.6!important;color:#566a80!important;margin:0!important}
#travel-guides .atp-home-blog-all{display:inline-flex!important;flex-shrink:0!important;align-items:center!important;gap:8px!important;color:#875321!important;font-size:14px!important;font-weight:700!important;text-decoration:none!important;white-space:nowrap!important}
#travel-guides .atp-home-blog-grid{display:grid!important;width:100%!important;max-width:none!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:24px!important;margin:0!important;padding:0!important;align-items:stretch!important;}
#travel-guides .atp-home-blog-card{display:flex!important;flex-direction:column!important;width:100%!important;min-width:0!important;max-width:none!important;height:auto!important;float:none!important;margin:0!important;padding:0!important;background:white!important;border:1px solid #e1e7ee!important;border-radius:16px!important;overflow:hidden!important;box-shadow:0 12px 32px rgba(11,34,60,.07)!important;}
#travel-guides .atp-home-blog-photo{display:block!important;width:100%!important;height:230px!important;min-height:230px!important;max-height:230px!important;margin:0!important;padding:0!important;background:#e5edf3!important;border:0!important;overflow:hidden!important;text-decoration:none!important}
#travel-guides .atp-home-blog-photo>span{display:grid!important;place-items:center!important;height:100%!important;color:#566a80!important;font-weight:700!important}
#travel-guides .atp-home-blog-photo img{display:block!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:cover!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;transition:transform .25s ease}
#travel-guides .atp-home-blog-card:hover img{transform:scale(1.035)}
#travel-guides .atp-home-blog-body{display:flex!important;flex-direction:column!important;flex:1!important;min-width:0!important;gap:0!important;padding:21px 22px 24px!important;text-align:left!important}
#travel-guides .atp-home-blog-body small{display:block!important;font-size:12px!important;line-height:1.4!important;font-weight:600!important;color:#566a80!important;margin:0 0 9px!important}
#travel-guides .atp-home-blog-body h3{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:2!important;overflow:hidden!important;font:750 19px/1.38 Inter,system-ui,sans-serif!important;letter-spacing:-.2px!important;color:#142f4b!important;margin:0 0 12px!important;padding:0!important}
#travel-guides .atp-home-blog-body h3 a{font:inherit!important;color:inherit!important;text-decoration:none!important}
#travel-guides .atp-home-blog-body p{display:-webkit-box!important;-webkit-box-orient:vertical!important;-webkit-line-clamp:3!important;overflow:hidden!important;color:#617286!important;font-size:14px!important;line-height:1.65!important;margin:0 0 18px!important;padding:0!important}
#travel-guides .atp-home-blog-read{display:inline-flex!important;align-items:center!important;align-self:flex-start!important;color:#875321!important;text-decoration:none!important;font-size:14px!important;line-height:1.4!important;font-weight:750!important;margin:auto 0 0!important;padding:0!important}
@media(max-width:900px){#travel-guides .atp-home-blog-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
@media(max-width:620px){#travel-guides.atp-home-blog{padding:48px 16px 58px!important}#travel-guides .atp-home-blog-grid{grid-template-columns:minmax(0,1fr)!important;gap:17px!important}#travel-guides .atp-home-blog-heading{flex-direction:column!important;align-items:flex-start!important;gap:14px!important}#travel-guides .atp-home-blog-photo{height:215px!important;min-height:215px!important;max-height:215px!important}}
</style>
<section class="atp-home-blog" id="travel-guides" aria-labelledby="atp-home-blog-title"><div class="atp-home-blog-container">
 <div class="atp-home-blog-heading"><div><span class="atp-home-blog-kicker"><?php echo esc_html($atp_blog_text['kicker']); ?></span><h2 id="atp-home-blog-title"><?php echo esc_html($atp_blog_text['title']); ?></h2><p><?php echo esc_html($atp_blog_text['desc']); ?></p></div><a class="atp-home-blog-all" href="<?php echo esc_url(deniz_url('blog',$atp_blog_lang)); ?>"><?php echo esc_html($atp_blog_text['all']); ?> <span aria-hidden="true">↗</span></a></div>
 <div class="atp-home-blog-grid">
 <?php foreach($atp_home_guides as $guide):
 $translated=get_post_meta($guide->ID,'deniz_'.$atp_blog_lang.'_title',true);
 $title=$atp_blog_lang==='tr'?get_the_title($guide):$translated;
 if(!$title || ($atp_blog_lang!=='tr' && !get_post_meta($guide->ID,'deniz_'.$atp_blog_lang.'_content',true))) continue;
 $summary=$atp_blog_lang==='tr'?get_post_field('post_excerpt',$guide->ID):get_post_meta($guide->ID,'deniz_'.$atp_blog_lang.'_excerpt',true);
 $image=get_the_post_thumbnail_url($guide->ID,'medium_large'); ?>
 <article class="atp-home-blog-card"><a class="atp-home-blog-photo" href="<?php echo esc_url(twt_post_lang_url($guide,$atp_blog_lang)); ?>">
 <?php if($image): echo wp_get_attachment_image(get_post_thumbnail_id($guide),'medium_large',false,['alt'=>$title,'loading'=>'lazy','decoding'=>'async','sizes'=>'(max-width: 620px) 100vw, (max-width: 900px) 50vw, 400px']); else: ?><span>ANTALYA TRANSFER PRO</span><?php endif; ?>
 </a><div class="atp-home-blog-body"><small><?php echo esc_html(get_the_date('d.m.Y',$guide)); ?></small><h3><a href="<?php echo esc_url(twt_post_lang_url($guide,$atp_blog_lang)); ?>"><?php echo esc_html($title); ?></a></h3><?php if($summary): ?><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($summary),19)); ?></p><?php endif; ?><a class="atp-home-blog-read" href="<?php echo esc_url(twt_post_lang_url($guide,$atp_blog_lang)); ?>"><?php echo esc_html($atp_blog_text['more']); ?> →</a></div></article>
 <?php endforeach; ?></div></div></section>
<?php endif; ?>

<section class="app-section v18-faq" id="faq">
  <div class="wrap faq-wrap">
    <div class="v18-section-head center-head">
      <small><?php echo esc_html(deniz_t('faq_kicker')); ?></small>
      <h2><?php echo esc_html($c['faq']); ?></h2>
      <p><?php echo esc_html($c['faq_sub']); ?></p>
    </div>
    <div class="v18-faq-list">
      <?php foreach($faq_rows as $i=>$row): ?>
      <details <?php echo $i===0?'open':''; ?>><summary><?php echo esc_html($row['q']); ?></summary><p><?php echo esc_html($row['a']); ?></p></details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
