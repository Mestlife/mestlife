# 42.0.7 — Panel, blog ve üretim düzeltmeleri

- Personel yetkileri panel, fiyat/bölge AJAX uçları ve yerel kayıt ekranlarında uygulanır. Blog görevlisi kendi yazılarını panel içinde düzenler. Engellenen hesapların oturumları kapatılır ve tekrar girişleri reddedilir.
- Kaydedilen marka, telefon, WhatsApp, e-posta, adres, logo ve lisans bilgileri ortak veri kaynağından okunur. Sosyal bağlantılar altbilgi ve kuruluş şemasına bağlanır.
- Hero görseli ve preload aynı seçili fotoğrafı kullanır. Tanıtım fotoğrafı seçildiğinde Nasıl Çalışır alanında gösterilir. Bölge görseli eşlemesi önceki kaydı güncelleyebilir.
- Otomatik/manuel kur tercihi panelde açıkça gösterilir; varsayılan gösterim para birimi uygulanır. Fiyat matrisinin baz para birimi EUR olarak korunur. Geçersiz kur değerleri reddedilir.
- Gemini işlemleri kullanıcıya ait kalıcı iş kayıtlarında, dil başına ayrı saklanır. Devam etme tamamlanmış diller için yeniden API çağrısı yapmaz. Eşzamanlı istekler kilitlenir; final kayıt tekrarları aynı taslağı döndürür.
- Gemini çıktısının alan tipleri, SSS yapısı, temel içerik uzunluğu, başlık ve tablo yapısı doğrulanır. HTML izin verilen etiketlerle sınırlıdır; yalnızca ilgili işte sağlanan URL'ler korunur.
- Sabit tahmini model zinciri kaldırılır. API hesabından model kataloğu yüklenebilir ve model kimliği kaydedilebilir. Tek bir üretim isteğinin bağlantı zaman aşımı 40 saniye ile sınırlıdır; başarısız adım elle devam ettirilebilir.
- Taslak, fotoğraf indirilmeden önce kaydedilir. Görsel servisi başarısız olsa da yazı korunur. Otomatik dış kaynak araştırması veya kaynak doğrulaması yapıldığı iddia edilmez.
- Türkçe ana sayfa blog kartları doğru özet alanını okur. Diğer dillerde yalnızca çevirisi bulunan yazılar listelenir. Arşiv bağlantısı mevcut dili korur; kart fotoğrafları uyarlanabilir boyutlarla sunulur.
- Blog kartlarında küçük metinlerin renk kontrastı iyileştirilir. Üretim JS'i ayrı, küçültülmüş dosya olarak sunulur.

Tema güncellemesi WordPress seçenekleri, fiyatlar ve mevcut yazıları silmez. Güncellemeden önce dosya/veritabanı yedeği alın. Bu paket canlı siteye otomatik kurulmaz. Gerçek Gemini/Pexels anahtarlarıyla ücretli üretim çalıştırılmadı; sağlayıcı hata ve devam senaryoları yerel test yanıtlarıyla doğrulandı.
