<?php
if (!defined('ABSPATH')) exit;
/** Shared authorization for standalone screens and their server-side actions. */
function atp_operation_allowed($cap) {
    if (!is_user_logged_in() || get_user_meta(get_current_user_id(), 'matvip_blocked', true)) return false;
    if (current_user_can('manage_options')) return true;
    $allowed = ['matvip_access','matvip_bookings','matvip_prices','matvip_locations','matvip_vehicles','matvip_blog','matvip_translations'];
    return in_array($cap, $allowed, true) && current_user_can('matvip_access') && current_user_can($cap);
}
function atp_ai_allowed() {
    if (get_user_meta(get_current_user_id(), 'matvip_blocked', true)) return false;
    $user = wp_get_current_user();
    return in_array('matvip_operator', (array)$user->roles, true)
        ? atp_operation_allowed('matvip_blog') && current_user_can('upload_files')
        : is_user_logged_in() && current_user_can('edit_posts') && current_user_can('upload_files');
}

add_filter('wp_authenticate_user',function($user){
    if($user instanceof WP_User && get_user_meta($user->ID,'matvip_blocked',true))return new WP_Error('account_disabled','This account is disabled.');
    return $user;
},20);
add_action('init',function(){
    if(!is_user_logged_in() || !get_user_meta(get_current_user_id(),'matvip_blocked',true))return;
    wp_logout();
    if(wp_doing_ajax())wp_send_json_error('This account is disabled.',403);
    wp_safe_redirect(home_url('/admin-panelss/'));exit;
},1);
