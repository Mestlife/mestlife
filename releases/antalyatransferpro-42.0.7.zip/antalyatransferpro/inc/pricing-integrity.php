<?php
/** Price Matrix: explicit removals, atomic writes and truthful save responses. */
if(!defined('ABSPATH'))exit;
function atp_normalize_fare($raw){
    if(!is_scalar($raw)&&$raw!==null)return new WP_Error('invalid_fare','Fiyat alanı geçersiz.');
    $raw=trim((string)$raw);
    if($raw==='')return null;
    if(!preg_match('/^\d{1,10}(?:[.,]\d{1,2})?$/D',$raw))return new WP_Error('invalid_fare','Fiyatlar negatif olamaz; en fazla iki ondalık basamak kullanın.');
    $value=round((float)str_replace(',','.',$raw),2);
    return $value>0?$value:null;
}
function atp_save_price_matrix($airport_id,$matrix,$expected_count=null){
    global $wpdb;$t=deniz_tables();$airport_id=absint($airport_id);
    if(!$airport_id||!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['airports']} WHERE id=%d AND active=1",$airport_id)))return new WP_Error('invalid_airport','Geçerli bir havalimanı seçin.');
    if(!is_array($matrix)||!$matrix)return new WP_Error('empty_matrix','Fiyat tablosu alınamadı. Sayfayı yenileyip tekrar deneyin.');
    $rows=[];$regions=[];
    $valid_regions=array_map('intval',$wpdb->get_col("SELECT id FROM {$t['regions']} WHERE active=1"));
    $valid_vehicles=array_map('intval',$wpdb->get_col("SELECT id FROM {$t['vehicles']} WHERE active=1"));
    foreach($matrix as $rid=>$vehicles){
        if(!ctype_digit((string)$rid)||!in_array((int)$rid,$valid_regions,true)||!is_array($vehicles))return new WP_Error('invalid_region','Tabloda geçersiz bir bölge var. Yeniden açın.');
        foreach($vehicles as $vid=>$values){
            if(!ctype_digit((string)$vid)||!in_array((int)$vid,$valid_vehicles,true)||!is_array($values)||!array_key_exists('one_way',$values)||!array_key_exists('return_price',$values))return new WP_Error('incomplete_matrix','Tablo eksik veya değişmiş. Sayfayı yenileyin; fiyatlar değiştirilmedi.');
            $ow=atp_normalize_fare($values['one_way']);$rt=atp_normalize_fare($values['return_price']);
            if(is_wp_error($ow))return $ow;if(is_wp_error($rt))return $rt;
            $rows[]=['airport_id'=>$airport_id,'region_id'=>(int)$rid,'vehicle_id'=>(int)$vid,'one_way'=>$ow,'return_price'=>$rt,'currency'=>'EUR','active'=>($ow!==null||$rt!==null)?1:0];
            $regions[(int)$rid]=true;
        }
    }
    if(!$rows||($expected_count!==null&&count($rows)!==(int)$expected_count))return new WP_Error('incomplete_matrix','Tablonun tamamı ulaşmadı. Fiyatlar değiştirilmedi.');
    // One airport matrix at a time; an error rolls the whole submitted matrix back.
    $lock='atp_prices_'.$airport_id;
    if(!(int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,5)',$lock)))return new WP_Error('prices_busy','Başka bir fiyat kaydı sürüyor; tekrar deneyin.');
    $changed=0;$disabled=0;$ok=false;
    try{
        if($wpdb->query('START TRANSACTION')===false)throw new RuntimeException('transaction');
        foreach($rows as $row){
            $id=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['prices']} WHERE airport_id=%d AND region_id=%d AND vehicle_id=%d",$airport_id,$row['region_id'],$row['vehicle_id']));
            if(!$id&&!$row['active'])continue;
            $result=$id?$wpdb->update($t['prices'],$row,['id'=>(int)$id]):$wpdb->insert($t['prices'],$row);
            if($result===false)throw new RuntimeException('write');
            $changed+=(int)($result>0);if(!$row['active'])$disabled++;
        }
        if($wpdb->query('COMMIT')===false)throw new RuntimeException('commit');
        $ok=true;
    }catch(Throwable $e){$wpdb->query('ROLLBACK');}
    finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    if(!$ok)return new WP_Error('price_write_failed','Fiyatlar kaydedilemedi. Hiçbir değişiklik uygulanmadı. Tekrar deneyin; sorun sürerse hosting veritabanı kayıtlarını kontrol edin.');
    $sync_ok=true;
    foreach(array_keys($regions) as $rid){
        try{deniz_sync_route_post($airport_id,$rid);if(function_exists('twt_sync_priced_region'))twt_sync_priced_region($rid);}
        catch(Throwable $e){$sync_ok=false;}
    }
    delete_transient('twt_stale_content_ids');delete_transient('atp_region_landing_map_v1');
    if(function_exists('twt_sm_flush_cache'))twt_sm_flush_cache();
    // Supported hooks only; no assumption that a host/CDN cache is present or purged.
    do_action('atp_prices_updated',$airport_id,array_keys($regions));
    do_action('litespeed_purge_all');
    if(function_exists('rocket_clean_domain'))rocket_clean_domain();
    if(function_exists('w3tc_flush_all'))w3tc_flush_all();
    if(function_exists('wp_cache_clear_cache'))wp_cache_clear_cache();
    return ['changed'=>$changed,'disabled'=>$disabled,'submitted'=>count($rows),'synced'=>$sync_ok,'message'=>$sync_ok?'Fiyatlar kaydedildi. Boş veya 0 olan ücretler satıştan kaldırıldı.':'Fiyatlar kaydedildi; bazı içeriklerin senkronlanması tamamlanamadı. Yönetim ekranından kontrol edin.'];
}
function atp_ajax_save_prices(){
    check_ajax_referer('deniz_os','nonce');
    if(!atp_operation_allowed('matvip_prices'))wp_send_json_error(['message'=>'Yetki yok.'],403);
    if(isset($_POST['matrix_json'])){
        if(!is_string($_POST['matrix_json']))wp_send_json_error(['message'=>'Tablo verisi geçersiz.'],400);
        $matrix=json_decode(wp_unslash($_POST['matrix_json']),true);
        if(json_last_error()!==JSON_ERROR_NONE)wp_send_json_error(['message'=>'Tablo eksik veya geçersiz; kaydedilmedi.'],400);
    }else{$matrix=wp_unslash($_POST['p']??[]);}
    $count=isset($_POST['matrix_count'])?absint($_POST['matrix_count']):null;
    $result=atp_save_price_matrix(absint($_POST['airport_id']??0),$matrix,$count);
    if(is_wp_error($result))wp_send_json_error(['code'=>$result->get_error_code(),'message'=>$result->get_error_message()],400);
    wp_send_json_success($result);
}
remove_action('wp_ajax_deniz_save_prices','deniz_ajax_save_prices');
add_action('wp_ajax_deniz_save_prices','atp_ajax_save_prices');

function atp_is_shared_service($row){return ($row->pricing_type??'')==='per_person'||($row->service_type??'')==='shuttle';}
function atp_mentions_shared_service($text){return (bool)preg_match('/\b(?:shuttle|shared|sammel(?:shuttle|transfer)?)\b|paylaşımlı|шаттл|совместн|общий трансфер/iu',wp_strip_all_tags((string)$text));}
/** Omit unavailable service claims at rendering time; never rewrite authored DB content. */
function atp_contains_literal_fare($text){return (bool)preg_match('/(?:[€₺$£]\s*\d|\d(?:[.,]\d{1,2})?\s*(?:EUR|USD|GBP|TRY|TL|€|₺|\$|£))/iu',wp_strip_all_tags((string)$text));}
function atp_available_service_text($text,$ctx,$authored=false){
    if(($ctx['shared']??null)!==null&&!$authored)return (string)$text;
    $sentences=preg_split('/(?<=[.!?])\s+/u',trim((string)$text));
    return implode(' ',array_filter($sentences,function($sentence)use($ctx,$authored){return !(($ctx['shared']??null)===null&&atp_mentions_shared_service($sentence))&&!($authored&&atp_contains_literal_fare($sentence));}));
}
function atp_available_service_html($html,$ctx){
    $html=wp_kses_post(wpautop((string)$html));
    return preg_replace_callback('~<(p|li|h[1-6])\b[^>]*>.*?</\1>~isu',function($m)use($ctx){return ((($ctx['shared']??null)===null&&atp_mentions_shared_service($m[0]))||atp_contains_literal_fare($m[0]))?'':$m[0];},$html);
}
