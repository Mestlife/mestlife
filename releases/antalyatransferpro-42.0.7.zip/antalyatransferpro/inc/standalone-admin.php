<?php
/**
 * Antalya Transfer Pro | standalone operations panel
 * URL: /admin-panelss/  (NOT the WordPress dashboard)
 * Runs through WP authentication and existing booking/location/price tables.
 * No parallel store or duplicate public theme templates are created.
 */
if (!defined('ABSPATH')) exit;


function atp_panel_brand_settings(){return array_merge(['company'=>'','phone_display'=>'','phone'=>'','whatsapp'=>'','email'=>'','street'=>'','locality'=>'','region'=>'Antalya','country'=>'TR','license'=>'','license_url'=>'','logo_url'=>'','hero_image'=>'','instagram'=>'','facebook'=>''],(array)get_option('atp_panel_brand_settings',[]));}
function atp_panel_brand_sanitize($input){$out=[];foreach(atp_panel_brand_settings() as $k=>$v){$raw=(string)($input[$k]??'');$out[$k]=in_array($k,['license_url','logo_url','hero_image','instagram','facebook'],true)?esc_url_raw($raw):($k==='email'?sanitize_email($raw):sanitize_text_field($raw));}return $out;}

function matvip_panel_url($tab = 'dashboard', $args = []) {
    return add_query_arg(array_merge(['tab' => $tab], $args), home_url('/admin-panelss/'));
}
function matvip_is_panel_request() {
    $path = wp_parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    $prefix = wp_parse_url(home_url('/admin-panelss/'), PHP_URL_PATH);
    return is_string($path) && rtrim($path, '/') === rtrim((string) $prefix, '/');
}
function matvip_permission($cap) {
    return atp_operation_allowed($cap);
}
function matvip_allowed_tabs() {
    return [
      'dashboard' => 'matvip_access', 'bookings' => 'matvip_bookings',
      'prices' => 'matvip_prices', 'regions' => 'matvip_locations',
      'countries' => 'matvip_locations', 'airports' => 'matvip_locations',
      'vehicles' => 'matvip_vehicles', 'extras' => 'matvip_vehicles',
      'hotels' => 'matvip_locations', 'visuals' => 'manage_options', 'blog' => 'matvip_blog',
      'translations' => 'matvip_translations', 'settings' => 'manage_options',
      'users' => 'manage_options',
    ];
}
function matvip_get_language() {
    $l = sanitize_key($_GET['lang'] ?? $_COOKIE['matvip_panel_lang'] ?? 'en');
    return in_array($l, ['tr', 'en', 'de', 'ru'], true) ? $l : 'en';
}
function matvip_words() {
    return [
      'tr' => ['panel'=>'Yönetim Paneli','dashboard'=>'Genel Bakış','bookings'=>'Rezervasyonlar','prices'=>'Fiyat Matrisi','regions'=>'Bölgeler & Harita','countries'=>'Ülke & Şehirler','airports'=>'Havalimanları','vehicles'=>'Araç Filosu','extras'=>'Ek Hizmetler','hotels'=>'Oteller','visuals'=>'Ana Sayfa Görselleri','blog'=>'Blog Stüdyosu','translations'=>'Çeviri Merkezi','settings'=>'Site Ayarları','users'=>'Kullanıcılar','operations'=>'Operasyon','catalogue'=>'Ürün & İçerik','system'=>'Sistem','website'=>'Siteyi Görüntüle','logout'=>'Çıkış','login'=>'Giriş Yap','email'=>'Kullanıcı adı / e-posta','password'=>'Şifre','signin'=>'Güvenli Giriş','welcome'=>'İşletmenizi tek merkezden yönetin.','notallowed'=>'Bu modül için yetkiniz bulunmuyor.','save'=>'Kaydet','delete'=>'Sil','edit'=>'Düzenle','new'=>'Yeni','cancel'=>'İptal','status'=>'Durum','active'=>'Aktif','inactive'=>'Pasif','published'=>'Yayında','draft'=>'Taslak','guide'=>'WordPress yönetim panelinden ayrı, mevcut tema verileriyle çalışan yönetim arayüzü.'],
      'en' => ['panel'=>'Management Panel','dashboard'=>'Overview','bookings'=>'Reservations','prices'=>'Price Matrix','regions'=>'Regions & Map','countries'=>'Countries & Cities','airports'=>'Airports','vehicles'=>'Vehicle Fleet','extras'=>'Extras','hotels'=>'Hotels','visuals'=>'Homepage Images','blog'=>'Blog Studio','translations'=>'Translation Centre','settings'=>'Site Settings','users'=>'Users','operations'=>'Operations','catalogue'=>'Products & Content','system'=>'System','website'=>'View Website','logout'=>'Sign out','login'=>'Sign in','email'=>'Username / email','password'=>'Password','signin'=>'Secure Sign In','welcome'=>'Manage your operation in one place.','notallowed'=>'You do not have permission for this module.','save'=>'Save','delete'=>'Delete','edit'=>'Edit','new'=>'New','cancel'=>'Cancel','status'=>'Status','active'=>'Active','inactive'=>'Inactive','published'=>'Published','draft'=>'Draft','guide'=>'A dedicated management area outside the WordPress dashboard, connected to your live theme data.'],
      'de' => ['panel'=>'Verwaltung','dashboard'=>'Übersicht','bookings'=>'Buchungen','prices'=>'Preismatrix','regions'=>'Regionen & Karte','countries'=>'Länder & Städte','airports'=>'Flughäfen','vehicles'=>'Fuhrpark','extras'=>'Zusatzleistungen','hotels'=>'Hotels','visuals'=>'Startseitenbilder','blog'=>'Blog-Studio','translations'=>'Übersetzungen','settings'=>'Website-Einstellungen','users'=>'Benutzer','operations'=>'Betrieb','catalogue'=>'Produkte & Inhalte','system'=>'System','website'=>'Website ansehen','logout'=>'Abmelden','login'=>'Anmelden','email'=>'Benutzername / E-Mail','password'=>'Passwort','signin'=>'Sicher anmelden','welcome'=>'Verwalten Sie Ihren Betrieb zentral.','notallowed'=>'Sie haben keine Berechtigung für dieses Modul.','save'=>'Speichern','delete'=>'Löschen','edit'=>'Bearbeiten','new'=>'Neu','cancel'=>'Abbrechen','status'=>'Status','active'=>'Aktiv','inactive'=>'Inaktiv','published'=>'Veröffentlicht','draft'=>'Entwurf','guide'=>'Separater Verwaltungsbereich außerhalb des WordPress-Dashboards mit Live-Themendaten.'],
      'ru' => ['panel'=>'Панель управления','dashboard'=>'Обзор','bookings'=>'Бронирования','prices'=>'Тарифы','regions'=>'Регионы и карта','countries'=>'Страны и города','airports'=>'Аэропорты','vehicles'=>'Автопарк','extras'=>'Дополнительные услуги','hotels'=>'Отели','visuals'=>'Изображения сайта','blog'=>'Блог','translations'=>'Переводы','settings'=>'Настройки сайта','users'=>'Пользователи','operations'=>'Операции','catalogue'=>'Услуги и контент','system'=>'Система','website'=>'Открыть сайт','logout'=>'Выйти','login'=>'Войти','email'=>'Логин / e-mail','password'=>'Пароль','signin'=>'Безопасный вход','welcome'=>'Управляйте бизнесом в одном месте.','notallowed'=>'У вас нет доступа к этому разделу.','save'=>'Сохранить','delete'=>'Удалить','edit'=>'Изменить','new'=>'Новый','cancel'=>'Отмена','status'=>'Статус','active'=>'Активно','inactive'=>'Неактивно','published'=>'Опубликовано','draft'=>'Черновик','guide'=>'Отдельная панель управления вне WordPress, связанная с данными вашего сайта.'],
    ];
}
function matvip_t($key) { $l = matvip_get_language(); $a = matvip_words(); return $a[$l][$key] ?? $a['en'][$key] ?? $key; }

// Only grant the explicit capabilities chosen by an administrator; never grant manage_options.
add_action('init', function () {
    if (get_option('matvip_panel_role_installed') === '2') return;
    if (!get_role('matvip_operator')) add_role('matvip_operator', 'Transfer Panel Operator', ['read' => true]);
    $role = get_role('matvip_operator');
    if ($role) $role->add_cap('read');
    update_option('matvip_panel_role_installed', '2', false);
}, 7);

// Restrict panel-only users from using the regular WordPress admin interface.
add_action('admin_init', function () {
    if (wp_doing_ajax() || (defined('DOING_CRON') && DOING_CRON) || current_user_can('manage_options') || basename((string)($_SERVER['PHP_SELF']??'')) === 'async-upload.php') return;
    $u = wp_get_current_user();
    if ($u->exists() && in_array('matvip_operator', (array) $u->roles, true)) {
        wp_safe_redirect(matvip_panel_url()); exit;
    }
}, 1);
add_filter('show_admin_bar', function ($show) { return matvip_is_panel_request() ? false : $show; });
add_filter('login_redirect', function ($redirect_to, $requested, $user) {
    if ($user instanceof WP_User && in_array('matvip_operator', (array) $user->roles, true)) return matvip_panel_url();
    return $redirect_to;
}, 10, 3);

function matvip_panel_process_action($tab) {
    if ($tab === 'visuals' && isset($_POST['matvip_save_visuals'])) {
        if (!matvip_permission('manage_options') || !isset($_POST['matvip_visual_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['matvip_visual_nonce'])), 'matvip_save_visuals')) return new WP_Error('nonce','Güvenlik doğrulaması başarısız.');
        $new=[]; foreach (['belek','kemer','side','alanya','why','hero'] as $key) {
            $id=absint($_POST['visual_image'][$key] ?? 0);
            if ($id && wp_attachment_is_image($id)) $new[$key]=$id;
        }
        // Persist region photos in the same option consumed by public region landing pages.
        global $wpdb; $tt=deniz_tables();
        $ids=array_map('intval',(array)$wpdb->get_col("SELECT id FROM {$tt['regions']}"));
        $region_images=[];
        foreach ($ids as $rid) {
            $aid=absint($_POST['region_img'][$rid]??0);
            if ($aid && wp_attachment_is_image($aid)) $region_images[$rid]=$aid;
        }
        $previous_home=(array)get_option('matvip_home_visuals',[]);
        $previous_regions=(array)get_option('atp_region_images',[]);
        // A newly selected home image also updates the region unless its separate image was explicitly changed.
        foreach ($ids as $rid) {
            $row=$wpdb->get_row($wpdb->prepare("SELECT name FROM {$tt['regions']} WHERE id=%d",$rid));
            $key=$row?sanitize_title(remove_accents($row->name)):'';
            if (in_array($key,['belek','kemer','side','alanya'],true) && !empty($new[$key]) && ((int)($new[$key])!==(int)($previous_home[$key]??0) || empty($region_images[$rid])) && ((int)($region_images[$rid]??0)===(int)($previous_regions[$rid]??0) || empty($region_images[$rid]))) $region_images[$rid]=$new[$key];
        }
        update_option('atp_region_images',$region_images,false);
        update_option('matvip_home_visuals',$new,false);
        return 'Görseller kaydedildi.';
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return null;
    $action = sanitize_key($_POST['matvip_action'] ?? '');
    if (!$action) return null; // Native OS forms handle their own nonce in their normal page functions.
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'matvip_' . $action)) return new WP_Error('csrf', 'Security check failed.');
    $redirect = matvip_panel_url($tab);
    global $wpdb;
    $t = deniz_tables();
    switch ($action) {
        case 'booking_status':
            if (!matvip_permission('matvip_bookings')) break;
            $id = absint($_POST['id'] ?? 0);
            $status = sanitize_key($_POST['status'] ?? '');
            if (!in_array($status, ['new','confirmed','assigned','completed','cancelled'], true)) break;
            $wpdb->update($t['bookings'], ['status' => $status], ['id' => $id], ['%s'], ['%d']);
            break;
        case 'vehicle_state':
            if (!matvip_permission('matvip_vehicles')) break;
            $id = absint($_POST['id'] ?? 0);
            $state = sanitize_key($_POST['state'] ?? '');
            if (!in_array($state, ['enable', 'disable', 'remove'], true) || !$id) break;
            $v = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$t['vehicles']} WHERE id=%d", $id));
            if (!$v) break;
            $bookings = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE vehicle_id=%d", $id));
            if ($state === 'remove' && !$bookings) {
                $wpdb->delete($t['prices'], ['vehicle_id' => $id], ['%d']);
                $wpdb->delete($t['vehicles'], ['id' => $id], ['%d']);
                if (function_exists('twt_cleanup_vehicle_pages')) twt_cleanup_vehicle_pages();
            } else {
                $wpdb->update($t['vehicles'], ['active' => $state === 'enable' ? 1 : 0], ['id' => $id], ['%d'], ['%d']);
                if (function_exists('twt_sync_vehicle_page')) twt_sync_vehicle_page($id);
            }
            if (function_exists('twt_sm_flush_cache')) twt_sm_flush_cache();
            break;
        case 'region_state':
            if (!matvip_permission('matvip_locations')) break;
            $id = absint($_POST['id'] ?? 0);
            $state = sanitize_key($_POST['state'] ?? '');
            if ($id && in_array($state,['enable','disable'],true))
                $wpdb->update($t['regions'], ['active' => $state === 'enable' ? 1 : 0], ['id'=>$id], ['%d'], ['%d']);
            break;
        case 'blog_save':
            if (!matvip_permission('matvip_blog')) break;
            $post_id = absint($_POST['post_id'] ?? 0);
            if ($post_id && !matvip_can_edit_blog($post_id)) return new WP_Error('permission','Permission denied.');
            $original = $post_id ? json_decode((string)get_post_meta($post_id,'twt_bs_source',true),true) : [];
            $data = is_array($original) ? $original : [];
            foreach (['tr','en','de','ru'] as $lang) {
                $src = isset($_POST['content'][$lang]) && is_array($_POST['content'][$lang]) ? wp_unslash($_POST['content'][$lang]) : [];
                $data[$lang] = array_merge(isset($data[$lang]) && is_array($data[$lang]) ? $data[$lang] : [], [
                  'title' => sanitize_text_field($src['title'] ?? ''),
                  'slug' => sanitize_title($src['slug'] ?? ''),
                  'excerpt' => sanitize_textarea_field($src['excerpt'] ?? ''),
                  'seo_title' => sanitize_text_field($src['seo_title'] ?? ''),
                  'seo_description' => sanitize_textarea_field($src['seo_description'] ?? ''),
                  'focus_keyword' => sanitize_text_field($src['focus_keyword'] ?? ''),
                  'hero_subtitle' => sanitize_text_field($src['hero_subtitle'] ?? ''),
                  'content' => wp_kses_post($src['content'] ?? ''),
                  'featured_image_alt' => sanitize_text_field($src['featured_image_alt'] ?? ''),
                ]);
            }
            foreach (['tr','en','de','ru'] as $lang) {
                $raw_faq=wp_unslash($_POST['faq'][$lang]??'[]');
                if(!is_string($raw_faq))return new WP_Error('faq','Invalid FAQ data.');
                $faq=json_decode($raw_faq,true);
                if(!is_array($faq))return new WP_Error('faq','FAQ must be a JSON list.');
                foreach($faq as $row)if(!is_array($row)||!isset($row['q'],$row['a'])||!is_string($row['q'])||!is_string($row['a']))return new WP_Error('faq','Each FAQ needs text q and a fields.');
                $data[$lang]['faq']=$faq;
            }
            $status = sanitize_key($_POST['status'] ?? 'draft');
            if (!in_array($status, ['draft','publish'],true)) $status='draft';
            if($status==='publish' && !current_user_can('publish_posts'))$status='draft';
            // Operators can edit their own posts; admin can edit every post.
            $old_images = $post_id ? array_map('absint',array_filter(explode(',',(string)get_post_meta($post_id,'twt_bs_images',true)))) : [];
            $result = twt_bs_save($data, ['post_id'=>$post_id, 'status'=>$status, 'featured'=>absint($_POST['featured'] ?? 0),'images'=>$old_images]);
            if (is_wp_error($result)) return $result;
            $redirect = matvip_panel_url('blog', ['edit' => $result, 'saved' => 1]);
            break;
        case 'blog_trash':
            if (!matvip_permission('matvip_blog')) break;
            $post_id = absint($_POST['post_id'] ?? 0);
            if (!$post_id || !matvip_can_edit_blog($post_id)) return new WP_Error('permission','Permission denied.');
            wp_trash_post($post_id);
            break;
        case 'create_user':
            if (!current_user_can('manage_options')) break;
            $username = sanitize_user(wp_unslash($_POST['username'] ?? ''));
            $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
            $password = (string) wp_unslash($_POST['password'] ?? '');
            if (!$username || !is_email($email) || strlen($password) < 12) return new WP_Error('invalid','Enter a valid username, email and a password of at least 12 characters.');
            if (username_exists($username) || email_exists($email)) return new WP_Error('duplicate','This username or email is already in use.');
            $uid = wp_create_user($username, $password, $email);
            if (is_wp_error($uid)) return $uid;
            $u = new WP_User($uid); $u->set_role('matvip_operator');
            matvip_set_user_caps($u, (array) ($_POST['permissions'] ?? []));
            break;
        case 'update_user':
            if (!current_user_can('manage_options')) break;
            $uid = absint($_POST['id'] ?? 0); $u = get_user_by('id',$uid);
            if (!$u || !in_array('matvip_operator',(array)$u->roles,true)) break;
            matvip_set_user_caps($u,(array)($_POST['permissions'] ?? []));
            update_user_meta($uid,'matvip_blocked',!empty($_POST['blocked']) ? 1 : 0);
            if (!empty($_POST['blocked'])) WP_Session_Tokens::get_instance($uid)->destroy_all();
            $new_password = (string) wp_unslash($_POST['new_password'] ?? '');
            if ($new_password !== '') {
                if (strlen($new_password) < 12) return new WP_Error('password','Password must be at least 12 characters.');
                wp_set_password($new_password, $uid);
            }
            break;
        case 'brand_save':
            if (!current_user_can('manage_options')) break;
            $raw = isset($_POST['brand']) && is_array($_POST['brand']) ? wp_unslash($_POST['brand']) : [];
            $saved = atp_panel_brand_sanitize($raw);
            foreach(['rate_try','rate_usd','rate_gbp','min_notice_hours','free_cancel_hours'] as $field){
                if(!isset($_POST['transfer'][$field]) || $_POST['transfer'][$field]==='')continue;
                $number=$_POST['transfer'][$field];
                if(!is_scalar($number)||!is_numeric($number)||(float)$number<0||(float)$number>=10000000||(str_starts_with($field,'rate_')&&(float)$number<=0))return new WP_Error('settings','Enter positive exchange rates and non-negative booking hours.');
            }
            update_option('atp_panel_brand_settings',$saved,false);
            if(isset($_POST['fx_mode_present']))update_option('twt_fx_auto',!empty($_POST['fx_auto']),false);
            $extras = get_option('deniz_transfer_settings',[]);
            if (!is_array($extras)) $extras = [];
            foreach (['currency','rate_try','rate_usd','rate_gbp','min_notice_hours','free_cancel_hours'] as $key) {
                if (!isset($_POST['transfer'][$key])) continue;
                $val = sanitize_text_field(wp_unslash($_POST['transfer'][$key]));
                if ($key === 'currency') { if (in_array($val,['EUR','TRY','USD','GBP'],true)) $extras[$key]=$val; }
                elseif (is_numeric($val) && (float)$val >= 0 && (float)$val < 10000000) $extras[$key] = $val;
            }
            foreach (['company'=>'company_name','phone_display'=>'support_phone','whatsapp'=>'whatsapp_number','email'=>'support_email'] as $source=>$target) {
                if ($saved[$source] !== '') $extras[$target] = $saved[$source];
            }
            $contact = atp_contact();
            $extras['company_address'] = $contact['address'];
            update_option('deniz_transfer_settings',$extras,false);
            if (function_exists('twt_sm_flush_cache')) twt_sm_flush_cache();
            break;
        default:
            return new WP_Error('unknown','Unsupported action.');
    }
    wp_safe_redirect(add_query_arg('ok',1,$redirect)); exit;
}
function matvip_permission_options() {
    return ['matvip_bookings'=>'Rezervasyonlar','matvip_prices'=>'Fiyatlar','matvip_locations'=>'Bölge/Harita/Havalimanı','matvip_vehicles'=>'Araçlar/Ek hizmetler','matvip_blog'=>'Blog (4 dil)','matvip_translations'=>'Çeviri merkezi'];
}
function matvip_set_user_caps(WP_User $user, $requested) {
    foreach (matvip_permission_options() as $cap=>$name) $user->remove_cap($cap);
    $requested = array_map('sanitize_key',$requested);
    $user->add_cap('matvip_access',true);
    foreach (array_keys(matvip_permission_options()) as $cap) if (in_array($cap,$requested,true)) $user->add_cap($cap,true);
    if (in_array('matvip_blog',$requested,true)) {
        $user->add_cap('edit_posts',true); $user->add_cap('publish_posts',true);
    } else { $user->remove_cap('edit_posts'); $user->remove_cap('publish_posts'); }
    if (in_array('matvip_vehicles',$requested,true) || in_array('matvip_blog',$requested,true)) $user->add_cap('upload_files',true);
    else $user->remove_cap('upload_files');
}
function matvip_can_edit_blog($id) {
    $p = get_post($id);
    return $p && $p->post_type === 'post' && (current_user_can('manage_options') || (matvip_permission('matvip_blog') && (int)$p->post_author === get_current_user_id()));
}

add_action('template_redirect', function () {
    if (!matvip_is_panel_request()) return;
    if (isset($_GET['lang']) && in_array(sanitize_key($_GET['lang']), ['tr','en','de','ru'],true)) {
        setcookie('matvip_panel_lang', sanitize_key($_GET['lang']), ['expires'=>time()+180*DAY_IN_SECONDS,'path'=>'/','secure'=>is_ssl(),'httponly'=>true,'samesite'=>'Lax']);
    }
    nocache_headers(); status_header(200);
    header('X-Robots-Tag: noindex, nofollow, noarchive',true);
    header('X-Frame-Options: SAMEORIGIN',true);
    $notice = null;
    if (!is_user_logged_in() && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['matvip_login'])) {
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'matvip_login')) $notice = new WP_Error('csrf','Security check failed.');
        else {
            $username = sanitize_text_field(wp_unslash($_POST['username'] ?? ''));
            if (is_email($username)) { $u = get_user_by('email', $username); if ($u) $username = $u->user_login; }
            $auth = wp_signon(['user_login'=>$username,'user_password'=>(string)wp_unslash($_POST['password'] ?? ''),'remember'=>!empty($_POST['remember'])],is_ssl());
            if (!is_wp_error($auth)) { wp_safe_redirect(matvip_panel_url()); exit; }
            $notice = new WP_Error('login','Giriş bilgilerini kontrol edin / Please check your credentials.');
        }
    }
    $tab = sanitize_key($_GET['tab'] ?? 'dashboard');
    $allowed = matvip_allowed_tabs();
    if (!isset($allowed[$tab])) $tab='dashboard';
    if (is_user_logged_in()) {
        if (!matvip_permission('matvip_access')) { status_header(403); $notice=new WP_Error('access','Bu hesaba panel erişimi tanımlanmamış.'); }
        elseif (!matvip_permission($allowed[$tab])) { status_header(403); $notice=new WP_Error('cap',matvip_t('notallowed')); }
        else $notice = matvip_panel_process_action($tab);
    }
    matvip_panel_render($tab,$notice);
    exit;
}, 0);

add_action('wp_enqueue_scripts', function () {
    if (!matvip_is_panel_request()) return;
    wp_enqueue_style('matvip-standalone-admin',get_template_directory_uri().'/assets/css/standalone-admin.css',[],wp_get_theme()->get('Version'));
    if (!matvip_permission('matvip_access')) return;
    // Admin OS was designed for wp-admin: mount exactly the same maps, pricing, image-picker JS on our standalone page.
    wp_enqueue_style('matvip-os','https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',[],'1.9.4');
    wp_enqueue_style('matvip-draw','https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css',['matvip-os'],'1.0.4');
    wp_enqueue_script('leaflet','https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',[],'1.9.4',true);
    wp_enqueue_script('leaflet-draw','https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js',['leaflet'],'1.0.4',true);
    wp_enqueue_style('matvip-existing-admin',get_template_directory_uri().'/assets/css/admin-os.css',[],wp_get_theme()->get('Version'));
    wp_enqueue_style('matvip-standalone-admin',get_template_directory_uri().'/assets/css/standalone-admin.css',['matvip-existing-admin'],wp_get_theme()->get('Version'));
    wp_enqueue_script('deniz-admin-os',get_template_directory_uri().'/assets/js/admin-os.js',['jquery','leaflet','leaflet-draw'],wp_get_theme()->get('Version'),true);
    if (is_user_logged_in() && (matvip_permission('matvip_vehicles') || matvip_permission('matvip_blog') || matvip_permission('manage_options'))) wp_enqueue_media();
    global $wpdb; $tb=deniz_tables();
    $countries=$wpdb->get_results("SELECT id,name,code FROM {$tb['countries']} WHERE active=1 ORDER BY name");
    $cities=$wpdb->get_results("SELECT id,country_id,name,slug,lat,lng FROM {$tb['cities']} WHERE active=1 ORDER BY name");
    wp_localize_script('deniz-admin-os','DenizOS',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('deniz_os'),'defaultCity'=>'Antalya','defaultCountry'=>'Turkey','countries'=>$countries,'cities'=>$cities]);
    wp_enqueue_script('matvip-standalone',get_template_directory_uri().'/assets/js/standalone-admin.js',['jquery','deniz-admin-os'],wp_get_theme()->get('Version'),true);
}, 99998);

function matvip_panel_render($tab,$notice) {
    show_admin_bar(false); // The standalone panel owns its full viewport.
    $signed_in = is_user_logged_in() && matvip_permission('matvip_access');
    $authorized = $signed_in && matvip_permission(matvip_allowed_tabs()[$tab]);
    $u = wp_get_current_user();
    ?><!doctype html><html lang="<?php echo esc_attr(matvip_get_language()); ?>"><head>
      <meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?php echo esc_html(matvip_t($tab).' · Antalya Transfer Pro'); ?></title>
      <?php wp_head(); ?>
      </head><body class="matvip-admin-page <?php echo $signed_in ? 'matvip-authenticated' : 'matvip-anonymous'; ?>">
    <?php if (!$signed_in): ?>
      <main class="matvip-login-area"><div class="matvip-login-card">
        <img src="<?php echo esc_url(twt_brand_logo_url()); ?>" alt="Antalya Transfer Pro" class="matvip-login-logo">
        <div class="matvip-eyebrow">ANTALYA TRANSFER PRO</div><h1><?php echo esc_html(matvip_t('signin')); ?></h1><p><?php echo esc_html(matvip_t('guide')); ?></p>
        <?php matvip_show_notice($notice); ?>
        <?php if (is_user_logged_in()): ?><p><a href="<?php echo esc_url(wp_logout_url(matvip_panel_url())); ?>">Sign out / Çıkış yap</a></p><?php else: ?><form method="post" class="matvip-login-form"><?php wp_nonce_field('matvip_login'); ?>
          <label><?php echo esc_html(matvip_t('email')); ?><input name="username" required autocomplete="username"></label>
          <label><?php echo esc_html(matvip_t('password')); ?><input name="password" type="password" required autocomplete="current-password"></label>
          <label class="matvip-inline"><input type="checkbox" name="remember" value="1"> <?php echo esc_html(matvip_get_language()==='tr'?'Oturumu açık tut':'Remember me'); ?></label>
          <button class="matvip-primary" name="matvip_login" value="1"><?php echo esc_html(matvip_t('login')); ?></button>
        </form><?php endif; ?>
        <div class="matvip-language-links"><?php matvip_lang_links($tab); ?></div>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="matvip-back">← <?php echo esc_html(matvip_t('website')); ?></a>
      </div></main>
    <?php else: ?>
     <div class="matvip-shell"><aside class="matvip-sidebar" id="matvip-sidebar">
        <div class="matvip-logo"><span class="matvip-logo-mark">A<span>TP</span></span><div><strong>ANTALYA</strong><small>TRANSFER PRO · CONTROL</small></div></div>
        <div class="matvip-sidebar-scroll">
          <?php matvip_nav_group(matvip_t('operations'),['dashboard','bookings','prices','regions','countries','airports'],$tab); ?>
          <?php matvip_nav_group(matvip_t('catalogue'),['vehicles','extras','hotels','visuals','blog','translations'],$tab); ?>
          <?php matvip_nav_group(matvip_t('system'),['settings','users'],$tab); ?>
        </div>
        <div class="matvip-user"><span class="matvip-avatar"><?php echo esc_html(mb_strtoupper(mb_substr($u->display_name?:$u->user_login,0,1))); ?></span><div><strong><?php echo esc_html($u->display_name ?: $u->user_login); ?></strong><small><?php echo current_user_can('manage_options')?'Administrator':'Operator'; ?></small></div></div>
      </aside><div class="matvip-main-col"><header class="matvip-topbar">
       <button type="button" class="matvip-mobile-toggle" id="matvip-mobile-menu" aria-label="Menu">☰</button>
       <div class="matvip-breadcrumb"><span>ANTALYA TRANSFER PRO</span><span class="matvip-crumb-sep">/</span><strong><?php echo esc_html(matvip_t($tab)); ?></strong></div>
       <div class="matvip-top-actions"><div class="matvip-language-links"><?php matvip_lang_links($tab); ?></div><a class="matvip-top-site" href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">↗ <?php echo esc_html(matvip_t('website')); ?></a><a class="matvip-signout" href="<?php echo esc_url(wp_logout_url(matvip_panel_url())); ?>"><?php echo esc_html(matvip_t('logout')); ?></a></div>
      </header><main class="matvip-content">
       <?php if (isset($_GET['ok'])) echo '<div class="matvip-alert success">'.esc_html(matvip_get_language()==='tr'?'İşlem tamamlandı.':'Saved successfully.').'</div>'; ?>
       <?php matvip_show_notice($notice); ?>
       <?php if ($authorized) matvip_panel_content($tab); ?>
      </main><footer class="matvip-footer">© <?php echo esc_html(date_i18n('Y')); ?> Antalya Transfer Pro · Standalone Operations</footer></div></div>
    <?php endif; ?>
    <?php wp_footer(); ?></body></html><?php
}
function matvip_show_notice($notice) {
    if (is_wp_error($notice)) echo '<div class="matvip-alert error">'.esc_html($notice->get_error_message()).'</div>';
}
function matvip_lang_links($tab) {
    foreach (['en'=>'EN','de'=>'DE','ru'=>'RU','tr'=>'TR'] as $k=>$label) {
        echo '<a class="'.($k===matvip_get_language()?'current':'').'" href="'.esc_url(add_query_arg('lang',$k,matvip_panel_url($tab))).'" lang="'.esc_attr($k).'">'.esc_html($label).'</a>';
    }
}
function matvip_nav_group($title,$tabs,$active) {
    $icons = ['dashboard'=>'◫','bookings'=>'▤','prices'=>'€','regions'=>'⌖','countries'=>'◈','airports'=>'✈','vehicles'=>'▣','extras'=>'✦','hotels'=>'⌂','visuals'=>'▧','blog'=>'▧','translations'=>'文','settings'=>'⚙','users'=>'♙'];
    echo '<nav class="matvip-navigation" aria-label="'.esc_attr($title).'"><span class="matvip-nav-heading">'.esc_html($title).'</span>';
    foreach ($tabs as $tab) if (matvip_permission(matvip_allowed_tabs()[$tab])) echo '<a class="matvip-nav-link '.($active===$tab?'selected':'').'" href="'.esc_url(matvip_panel_url($tab)).'"><span class="matvip-nav-icon">'.esc_html($icons[$tab]).'</span>'.esc_html(matvip_t($tab)).'</a>';
    echo '</nav>';
}
function matvip_panel_content($tab) {
    switch ($tab) {
      case 'dashboard': matvip_dashboard(); break;
      case 'bookings': matvip_bookings(); break;
      case 'prices': deniz_prices_page(); break;
      case 'regions': deniz_regions_page(); matvip_region_toggles(); break;
      case 'countries': deniz_locations_page(); break;
      case 'airports': deniz_airports_page(); break;
      case 'vehicles': deniz_vehicles_page(); matvip_vehicle_toggles(); break;
      case 'extras': deniz_extras_page(); break;
      case 'hotels': matvip_hotels_scanner_page(); deniz_hotels_page(); break;
      case 'visuals': matvip_home_visuals_page(); break;
      case 'blog': if(isset($_GET['edit']))matvip_blog_editor(absint($_GET['edit']));else atp_ai_screen(false); break;
      case 'translations': deniz_translation_center_page(); break;
      case 'settings': matvip_settings_page(); break;
      case 'users': matvip_users_page(); break;
    }
}
function matvip_panel_headline($title,$subtitle='') {
    echo '<div class="matvip-section-heading"><div><span class="matvip-eyebrow">ANTALYA TRANSFER PRO</span><h1>'.esc_html($title).'</h1><p>'.esc_html($subtitle).'</p></div></div>';
}
function matvip_dashboard() {
    global $wpdb; $t=deniz_tables();
    $bookings = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['bookings']} WHERE status='new'");
    $today=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE pickup_date=%s AND status<>'cancelled'",current_time('Y-m-d')));
    $vehicles=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['vehicles']} WHERE active=1");
    $prices=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['prices']} WHERE active=1 AND one_way>0");
    matvip_panel_headline(matvip_t('dashboard'),matvip_t('welcome'));
    echo '<div class="matvip-stats">';
    foreach ([['New bookings',$bookings,'bookings'],['Today’s transfers',$today,'bookings'],['Active vehicles',$vehicles,'vehicles'],['Priced routes',$prices,'prices']] as $c)
        if (matvip_permission(matvip_allowed_tabs()[$c[2]])) echo '<a class="matvip-stat" href="'.esc_url(matvip_panel_url($c[2])).'"><span>'.esc_html($c[0]).'</span><strong>'.(int)$c[1].'</strong><small>View details →</small></a>';
    echo '</div><div class="matvip-shortcuts">';
    foreach (['prices'=>'Manage route prices','regions'=>'Draw region boundaries','vehicles'=>'Manage vehicle fleet','blog'=>'Publish in 4 languages','translations'=>'Localize site text','users'=>'Manage staff access'] as $section=>$label) {
        if (!matvip_permission(matvip_allowed_tabs()[$section])) continue;
        echo '<a href="'.esc_url(matvip_panel_url($section)).'" class="matvip-shortcut"><span class="matvip-shortcut-graphic">↗</span><strong>'.esc_html(matvip_t($section)).'</strong><small>'.esc_html($label).'</small></a>';
    }
    echo '</div>';
}
function matvip_bookings() {
    global $wpdb;
    $t=deniz_tables();
    $lang=matvip_get_language();
    if(!in_array($lang,['tr','en','de','ru'],true)) $lang='tr';
    $words=[
      'tr'=>['subtitle'=>'Rezervasyonları, uçuşları, dönüşleri, ödemeleri ve operasyon durumlarını tek ekranda yönetin.','all'=>'Tüm rezervasyonlar','today'=>'Bugün','tomorrow'=>'Yarın','future'=>'İleri tarihli','completed'=>'Tamamlanan','cancelled'=>'İptal','search'=>'Rezervasyon kodu, yolcu, telefon, rota, e-posta...','find'=>'Ara','ref'=>'Rezervasyon','guest'=>'Misafir','route'=>'Güzergâh','pickup'=>'Tarih ve saat','vehicle'=>'Araç','fare'=>'Toplam tutar','status'=>'Durum','details'=>'Tüm detaylar','return'=>'Dönüş transferi','outbound'=>'Gidiş transferi','oneway'=>'Tek yön','roundtrip'=>'Gidiş – dönüş','payment'=>'Ödeme','extras'=>'Ek hizmetler','flight'=>'Uçuş','notes'=>'Notlar','bags'=>'Bagaj','passengers'=>'Yolcu','created'=>'Oluşturulma','cash'=>'Sürücüye nakit','voucher'=>'Voucher aç','save'=>'Kaydet','empty'=>'Bu filtrede rezervasyon bulunamadı.','showing'=>'Gösterilen','total'=>'Toplam kayıt','previous'=>'Önceki','next'=>'Sonraki','price_missing'=>'Fiyat kaydı 0 veya eksik','price_note'=>'Toplam fiyat, rezervasyonda kaydedilen tutardır; gidiş-dönüş için iki bacağı da kapsar.','email'=>'E-posta','phone'=>'Telefon','paystatus'=>'Tahsilat durumu','date'=>'Transfer tarihi','new'=>'Yeni','confirmed'=>'Onaylı','assigned'=>'Atandı','done'=>'Tamamlandı','void'=>'İptal','pending'=>'Bekliyor'],
      'en'=>['subtitle'=>'Manage bookings, flights, return journeys, payments and operating status in one place.','all'=>'All bookings','today'=>'Today','tomorrow'=>'Tomorrow','future'=>'Upcoming','completed'=>'Completed','cancelled'=>'Cancelled','search'=>'Booking reference, guest, phone, route, email...','find'=>'Search','ref'=>'Reference','guest'=>'Guest','route'=>'Route','pickup'=>'Pickup','vehicle'=>'Vehicle','fare'=>'Total fare','status'=>'Status','details'=>'Full details','return'=>'Return transfer','outbound'=>'Outbound transfer','oneway'=>'One way','roundtrip'=>'Round trip','payment'=>'Payment','extras'=>'Extras','flight'=>'Flight','notes'=>'Notes','bags'=>'Bags','passengers'=>'Passengers','created'=>'Created','cash'=>'Cash to driver','voucher'=>'Open voucher','save'=>'Save','empty'=>'No bookings for this filter.','showing'=>'Showing','total'=>'Total bookings','previous'=>'Previous','next'=>'Next','price_missing'=>'Fare missing or zero','price_note'=>'The fare is the saved booking total; it covers both legs of a round trip.','email'=>'Email','phone'=>'Phone','paystatus'=>'Payment status','date'=>'Travel date','new'=>'New','confirmed'=>'Confirmed','assigned'=>'Assigned','done'=>'Completed','void'=>'Cancelled','pending'=>'Pending'],
      'de'=>['subtitle'=>'Buchungen, Flüge, Rückfahrten, Zahlungen und Betriebsstatus zentral verwalten.','all'=>'Alle Buchungen','today'=>'Heute','tomorrow'=>'Morgen','future'=>'Bevorstehend','completed'=>'Abgeschlossen','cancelled'=>'Storniert','search'=>'Buchungscode, Gast, Telefon, Strecke, E-Mail...','find'=>'Suchen','ref'=>'Buchung','guest'=>'Gast','route'=>'Strecke','pickup'=>'Abholung','vehicle'=>'Fahrzeug','fare'=>'Gesamtpreis','status'=>'Status','details'=>'Alle Details','return'=>'Rückfahrt','outbound'=>'Hinfahrt','oneway'=>'Einfache Fahrt','roundtrip'=>'Hin- und Rückfahrt','payment'=>'Zahlung','extras'=>'Extras','flight'=>'Flug','notes'=>'Notizen','bags'=>'Gepäck','passengers'=>'Fahrgäste','created'=>'Erstellt','cash'=>'Bar beim Fahrer','voucher'=>'Voucher öffnen','save'=>'Speichern','empty'=>'Keine Buchungen für diesen Filter.','showing'=>'Angezeigt','total'=>'Buchungen gesamt','previous'=>'Zurück','next'=>'Weiter','price_missing'=>'Preis fehlt oder ist null','price_note'=>'Der gespeicherte Gesamtpreis umfasst bei Hin- und Rückfahrt beide Strecken.','email'=>'E-Mail','phone'=>'Telefon','paystatus'=>'Zahlungsstatus','date'=>'Reisedatum','new'=>'Neu','confirmed'=>'Bestätigt','assigned'=>'Zugewiesen','done'=>'Abgeschlossen','void'=>'Storniert','pending'=>'Ausstehend'],
      'ru'=>['subtitle'=>'Управляйте бронированиями, рейсами, обратными поездками, оплатой и статусами в одном месте.','all'=>'Все бронирования','today'=>'Сегодня','tomorrow'=>'Завтра','future'=>'Предстоящие','completed'=>'Завершённые','cancelled'=>'Отменённые','search'=>'Номер брони, пассажир, телефон, маршрут, e-mail...','find'=>'Поиск','ref'=>'Бронирование','guest'=>'Пассажир','route'=>'Маршрут','pickup'=>'Дата и время','vehicle'=>'Автомобиль','fare'=>'Общая стоимость','status'=>'Статус','details'=>'Все детали','return'=>'Обратный трансфер','outbound'=>'Трансфер туда','oneway'=>'В одну сторону','roundtrip'=>'Туда и обратно','payment'=>'Оплата','extras'=>'Доп. услуги','flight'=>'Рейс','notes'=>'Примечания','bags'=>'Багаж','passengers'=>'Пассажиры','created'=>'Создано','cash'=>'Наличными водителю','voucher'=>'Открыть ваучер','save'=>'Сохранить','empty'=>'Бронирований по фильтру нет.','showing'=>'Показано','total'=>'Всего бронирований','previous'=>'Назад','next'=>'Вперёд','price_missing'=>'Цена отсутствует или равна нулю','price_note'=>'Сохранённая общая стоимость включает обе поездки при бронировании туда и обратно.','email'=>'Эл. почта','phone'=>'Телефон','paystatus'=>'Статус оплаты','date'=>'Дата поездки','new'=>'Новое','confirmed'=>'Подтверждено','assigned'=>'Назначено','done'=>'Завершено','void'=>'Отменено','pending'=>'Ожидает']
    ];
    $w=$words[$lang];
    $today=current_time('Y-m-d');$tomorrow=wp_date('Y-m-d',strtotime($today.' +1 day'),wp_timezone());
    $filter=sanitize_key($_GET['view']??'all');if(!in_array($filter,['all','today','tomorrow','future','completed','cancelled'],true))$filter='all';
    $q=sanitize_text_field(wp_unslash($_GET['q']??''));$page=max(1,absint($_GET['paged']??1));$per=25;
    $where=['1=1'];$args=[];
    $legdate="(b.pickup_date=%s OR (b.direction='return' AND b.return_date=%s))";
    if($filter==='today'||$filter==='tomorrow'){$d=$filter==='today'?$today:$tomorrow;$where[]=$legdate;$args[]=$d;$args[]=$d;$where[]="b.status NOT IN ('cancelled','completed')";}
    if($filter==='future'){$where[]="(b.pickup_date>%s OR (b.direction='return' AND b.return_date>%s))";$args[]=$tomorrow;$args[]=$tomorrow;$where[]="b.status NOT IN ('cancelled','completed')";}
    if($filter==='completed')$where[]="b.status='completed'";
    if($filter==='cancelled')$where[]="b.status='cancelled'";
    if($q!==''){$like='%'.$wpdb->esc_like($q).'%';$where[]='(b.booking_ref LIKE %s OR b.first_name LIKE %s OR b.last_name LIKE %s OR b.phone LIKE %s OR b.email LIKE %s OR b.pickup_label LIKE %s OR b.dropoff_label LIKE %s)';for($i=0;$i<7;$i++)$args[]=$like;}
    $base=" FROM {$t['bookings']} b LEFT JOIN {$t['vehicles']} v ON v.id=b.vehicle_id WHERE ".implode(' AND ',$where);
    $total=(int)$wpdb->get_var($args?$wpdb->prepare('SELECT COUNT(*)'.$base,$args):'SELECT COUNT(*)'.$base);
    $sql='SELECT b.*, v.name AS vehicle_name'.$base.' ORDER BY b.pickup_date ASC,b.pickup_time ASC,b.id DESC LIMIT %d OFFSET %d';
    $rows=$wpdb->get_results($wpdb->prepare($sql,array_merge($args,[$per,($page-1)*$per])));
    $counts=[];
    $counts['all']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['bookings']}");
    foreach(['today'=>$today,'tomorrow'=>$tomorrow] as $key=>$d)$counts[$key]=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE (pickup_date=%s OR (direction='return' AND return_date=%s)) AND status NOT IN ('cancelled','completed')",$d,$d));
    $counts['future']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE (pickup_date>%s OR (direction='return' AND return_date>%s)) AND status NOT IN ('cancelled','completed')",$tomorrow,$tomorrow));
    $counts['completed']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['bookings']} WHERE status='completed'");
    $counts['cancelled']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['bookings']} WHERE status='cancelled'");
    matvip_panel_headline(matvip_t('bookings'),$w['subtitle']);
    echo '<div class="matvip-ops-tabs">';foreach(['all','today','tomorrow','future','completed','cancelled'] as $key)echo '<a class="matvip-ops-tab '.($key===$filter?'is-current':'').'" href="'.esc_url(add_query_arg(['tab'=>'bookings','view'=>$key,'q'=>$q],matvip_panel_url('bookings'))).'"><span>'.esc_html($w[$key]).'</span><strong>'.intval($counts[$key]).'</strong></a>';echo '</div>';
    echo '<div class="dos-panel matvip-ops-panel"><form class="matvip-ops-filter" method="get"><input type="hidden" name="tab" value="bookings"><input type="hidden" name="view" value="'.esc_attr($filter).'"><input type="search" name="q" value="'.esc_attr($q).'" placeholder="'.esc_attr($w['search']).'"><button class="dos-btn">'.esc_html($w['find']).'</button></form>';
    echo '<p class="matvip-ops-note">'.esc_html($w['price_note']).'</p><div class="dos-table-wrap"><table class="dos-table matvip-ops-table"><thead><tr>';
    foreach(['ref','guest','route','pickup','vehicle','fare','status','details'] as $key)echo '<th>'.esc_html($w[$key]).'</th>';echo '</tr></thead><tbody>';
    foreach($rows as $b){$ret=$b->direction==='return' && !empty($b->return_date);$fare=isset($b->total_amount)?(float)$b->total_amount:0;$currency=$b->currency?:'EUR';$voucher=twt_voucher_url($b);
      $extras=$wpdb->get_results($wpdb->prepare("SELECT be.*,e.name FROM {$t['booking_extras']} be LEFT JOIN {$t['extras']} e ON e.id=be.extra_id WHERE be.booking_id=%d",$b->id));
      $extra=[];foreach($extras as $x)$extra[]=($x->name?:'Extra').' × '.(int)$x->qty.' · '.number_format_i18n((float)$x->total_price,2).' '.$currency;
      $statusNames=['new'=>$w['new'],'confirmed'=>$w['confirmed'],'assigned'=>$w['assigned'],'completed'=>$w['done'],'cancelled'=>$w['void']];
      echo '<tr><td><strong>'.esc_html($b->booking_ref).'</strong><small>'.esc_html($w['created'].': '.$b->created_at).'</small>'.($ret?'<span class="matvip-ops-pill">'.esc_html($w['roundtrip']).'</span>':'').'</td>';
      echo '<td><strong>'.esc_html(trim($b->first_name.' '.$b->last_name)).'</strong><small>'.esc_html($b->phone).'</small></td>';
      echo '<td><div class="matvip-ops-route">'.esc_html($b->pickup_label).' → '.esc_html($b->dropoff_label).'</div>'.($ret?'<small>↩ '.esc_html($w['return']).'</small>':'').'</td>';
      echo '<td><strong>'.esc_html($b->pickup_date).'</strong><small>'.esc_html($b->pickup_time).'</small>'.($ret?'<small>↩ '.esc_html($b->return_date.' '.$b->return_time).'</small>':'').'</td>';
      echo '<td>'.esc_html($b->vehicle_name?:'—').'<small>'.(int)$b->passengers.' '.esc_html($w['passengers']).' · '.(int)$b->bags.' '.esc_html($w['bags']).'</small></td>';
      echo '<td>'.($fare>0?'<strong class="matvip-ops-fare">'.esc_html(number_format_i18n($fare,2).' '.$currency).'</strong>':'<span class="matvip-ops-alert">'.esc_html($w['price_missing']).'</span>').'<small>'.esc_html($b->payment_status).'</small></td>';
      echo '<td><form method="post" class="matvip-ops-status">';wp_nonce_field('matvip_booking_status');echo '<input type="hidden" name="matvip_action" value="booking_status"><input type="hidden" name="id" value="'.(int)$b->id.'"><select name="status">';foreach($statusNames as $value=>$label)echo '<option value="'.esc_attr($value).'" '.selected($b->status,$value,false).'>'.esc_html($label).'</option>';echo '</select><button type="submit" class="dos-mini">'.esc_html($w['save']).'</button></form></td>';
      echo '<td><details class="matvip-ops-details"><summary>'.esc_html($w['details']).'</summary><div class="matvip-ops-detailbox">';
      $info=[[$w['ref'],$b->booking_ref],[$w['guest'],trim($b->first_name.' '.$b->last_name)],[$w['email'],$b->email],[$w['phone'],$b->phone],[$w['vehicle'],$b->vehicle_name],[$w['passengers'],(int)$b->passengers],[$w['bags'],(int)$b->bags],[$w['flight'],$b->flight_number],[$w['outbound'],$b->pickup_date.' '.$b->pickup_time.' | '.$b->pickup_label.' → '.$b->dropoff_label]];
      if($ret)$info[]=[$w['return'],$b->return_date.' '.$b->return_time.' | '.$b->dropoff_label.' → '.$b->pickup_label];
      $info[]=[$w['fare'],number_format_i18n($fare,2).' '.$currency];$info[]=[$w['payment'],$b->payment_method==='cash_to_driver'?$w['cash']:$b->payment_method];$info[]=[$w['paystatus'],$b->payment_status];$info[]=[$w['extras'],implode(' · ',$extra)];$info[]=[$w['notes'],$b->notes];$info[]=[$w['created'],$b->created_at];
      foreach($info as $item)if((string)$item[1]!=='')echo '<div><span>'.esc_html($item[0]).'</span><b>'.esc_html($item[1]).'</b></div>';
      echo '<a target="_blank" rel="noopener noreferrer" class="dos-btn" href="'.esc_url($voucher).'">'.esc_html($w['voucher']).' ↗</a></div></details></td></tr>';
    }
    if(!$rows)echo '<tr><td colspan="8">'.esc_html($w['empty']).'</td></tr>';echo '</tbody></table></div>';
    $pages=(int)ceil($total/$per);echo '<div class="matvip-ops-pagination"><span>'.esc_html($w['showing']).' '.count($rows).' · '.esc_html($w['total']).': '.intval($total).'</span><div>';
    if($page>1)echo '<a href="'.esc_url(add_query_arg(['tab'=>'bookings','view'=>$filter,'q'=>$q,'paged'=>$page-1],matvip_panel_url('bookings'))).'">← '.esc_html($w['previous']).'</a>';
    if($page<$pages)echo '<a href="'.esc_url(add_query_arg(['tab'=>'bookings','view'=>$filter,'q'=>$q,'paged'=>$page+1],matvip_panel_url('bookings'))).'">'.esc_html($w['next']).' →</a>';
    echo '</div></div></div>';
}
function matvip_vehicle_toggles() {
    global $wpdb; $t=deniz_tables();
    $all=$wpdb->get_results("SELECT id,name,active,pax,bags FROM {$t['vehicles']} ORDER BY name");
    echo '<section class="dos-panel matvip-fitted"><h2>Vehicle availability & removal</h2><p>Vehicles with reservation history cannot be deleted; they can only be deactivated to preserve booking records.</p><div class="dos-table-wrap"><table class="dos-table"><thead><tr><th>Vehicle</th><th>Capacity</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
    foreach ($all as $v) {
        $used=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['bookings']} WHERE vehicle_id=%d",$v->id));
        echo '<tr><td>'.esc_html($v->name).'</td><td>'.(int)$v->pax.' / '.(int)$v->bags.'</td><td>'.($v->active?esc_html(matvip_t('active')):esc_html(matvip_t('inactive'))).'</td><td><form method="post" class="matvip-inline-actions">'; wp_nonce_field('matvip_vehicle_state');
        echo '<input type="hidden" name="matvip_action" value="vehicle_state"><input type="hidden" name="id" value="'.(int)$v->id.'"><button class="dos-mini" name="state" value="'.($v->active?'disable':'enable').'">'.($v->active?'Disable':'Enable').'</button>';
        if (!$used) echo ' <button class="dos-mini matvip-danger" name="state" value="remove" data-confirm="Are you sure?">Delete</button>';
        echo '</form></td></tr>';
    }
    echo '</tbody></table></div></section>';
}
function matvip_region_toggles() {
    global $wpdb;$t=deniz_tables();$rows=$wpdb->get_results("SELECT id,name,active FROM {$t['regions']} ORDER BY name");
    echo '<section class="dos-panel matvip-fitted"><h2>Region availability</h2><p>Disable a region to stop new quotations from using it without deleting the polygon and historical data.</p><div class="dos-table-wrap"><table class="dos-table"><tbody>';
    foreach ($rows as $r) {echo '<tr><td>'.esc_html($r->name).'</td><td>'.($r->active?'Active':'Inactive').'</td><td><form method="post">';wp_nonce_field('matvip_region_state');echo '<input type="hidden" name="matvip_action" value="region_state"><input type="hidden" name="id" value="'.(int)$r->id.'"><button class="dos-mini" name="state" value="'.($r->active?'disable':'enable').'">'.($r->active?'Disable':'Enable').'</button></form></td></tr>';}echo '</tbody></table></div></section>';
}
function matvip_users_page() {
    matvip_panel_headline(matvip_t('users'),'Create secure, limited-access accounts without giving anyone WordPress administrator privileges.');
    echo '<div class="matvip-manage-grid"><section class="dos-panel"><h2>Create panel user</h2><form method="post">';wp_nonce_field('matvip_create_user');
    echo '<input type="hidden" name="matvip_action" value="create_user"><label>Username<input name="username" required autocomplete="off"></label><label>Email<input name="email" type="email" required></label><label>Temporary password (12+ characters)<input name="password" type="password" required minlength="12" autocomplete="new-password"></label><h3>Module permissions</h3>';
    foreach (matvip_permission_options() as $cap=>$label) echo '<label class="matvip-check"><input type="checkbox" name="permissions[]" value="'.esc_attr($cap).'"> '.esc_html($label).'</label>';
    echo '<button type="submit" class="matvip-primary">Create user</button></form></section><section class="dos-panel"><h2>Panel users</h2>';
    $users=get_users(['role'=>'matvip_operator','orderby'=>'registered','order'=>'DESC']);
    foreach ($users as $u) {
        echo '<details class="matvip-staff-item"><summary><strong>'.esc_html($u->display_name?:$u->user_login).'</strong><span>'.esc_html($u->user_email).' · '.(get_user_meta($u->ID,'matvip_blocked',true)?'Disabled':'Active').'</span></summary><form method="post">';wp_nonce_field('matvip_update_user');
        echo '<input type="hidden" name="matvip_action" value="update_user"><input type="hidden" name="id" value="'.(int)$u->ID.'"><p>Access rights</p>';
        foreach (matvip_permission_options() as $cap=>$label) echo '<label class="matvip-check"><input type="checkbox" name="permissions[]" value="'.esc_attr($cap).'" '.checked($u->has_cap($cap),true,false).'> '.esc_html($label).'</label>';
        echo '<label class="matvip-check"><input type="checkbox" name="blocked" value="1" '.checked((int)get_user_meta($u->ID,'matvip_blocked',true),1,false).'> Disable access</label><label>Reset password (optional, at least 12 chars)<input type="password" name="new_password" minlength="12" autocomplete="new-password"></label><button class="dos-btn" type="submit">Save permissions</button></form></details>';
    }
    if (!$users) echo '<p>No operator accounts yet.</p>';
    echo '</section></div>';
}
function matvip_settings_page() {
    matvip_panel_headline(matvip_t('settings'),'Existing live theme settings · brand identity, contact channels, supported currency and booking rules.');
    $brand=array_merge(['company'=>twt_brand_name(),'phone_display'=>atp_contact()['phone_display'],'phone'=>atp_contact()['phone'],'whatsapp'=>atp_contact()['whatsapp'],'email'=>atp_contact()['email'],'street'=>atp_contact()['street'],'locality'=>atp_contact()['locality'],'region'=>atp_contact()['region'],'country'=>atp_contact()['country'],'license'=>atp_contact()['tursab'],'license_url'=>atp_contact()['tursab_url'],'logo_url'=>twt_brand_logo_url()],array_filter(atp_panel_brand_settings(),static function($v){return $v!=='';}));$transfer=get_option('deniz_transfer_settings',[]); if (!is_array($transfer)) $transfer=[]; $transfer=array_merge(['rate_try'=>deniz_setting('rate_try','52'),'rate_usd'=>deniz_setting('rate_usd','1.17'),'rate_gbp'=>deniz_setting('rate_gbp','0.87'),'min_notice_hours'=>deniz_min_notice_hours(),'free_cancel_hours'=>deniz_cancel_hours()],$transfer);
    echo '<form method="post" class="matvip-settings-form">';wp_nonce_field('matvip_brand_save');
    echo '<input type="hidden" name="matvip_action" value="brand_save"><section class="dos-panel"><h2>Brand & Contact</h2><div class="matvip-form-grid">';
    foreach (['company'=>'Legal company name','phone_display'=>'Display phone','phone'=>'Phone (international)','whatsapp'=>'WhatsApp number','email'=>'Support email','street'=>'Verified address','locality'=>'District','region'=>'City','country'=>'Country code','license'=>'Verified tourism license number','license_url'=>'License verification URL','logo_url'=>'Logo URL','hero_image'=>'Hero image URL','instagram'=>'Instagram URL','facebook'=>'Facebook URL'] as $key=>$label) {
        $type=$key==='email'?'email':(in_array($key,['license_url','logo_url','hero_image','instagram','facebook'],true)?'url':'text');
        echo '<label>'.esc_html($label).'<input type="'.esc_attr($type).'" name="brand['.esc_attr($key).']" value="'.esc_attr($brand[$key]??'').'"></label>';
    }
    echo '</div></section><section class="dos-panel"><h2>Pricing & booking policy</h2><div class="matvip-form-grid">';
    foreach (['currency'=>'Default display currency (matrix stays EUR)','rate_try'=>'1 EUR in TRY','rate_usd'=>'1 EUR in USD','rate_gbp'=>'1 EUR in GBP','min_notice_hours'=>'Minimum booking notice (hours)','free_cancel_hours'=>'Free cancellation (hours)'] as $key=>$label) {
        echo '<label>'.esc_html($label);
        if ($key==='currency') {echo '<select name="transfer[currency]">';foreach (['EUR','TRY','USD','GBP'] as $code) echo '<option '.selected($transfer[$key]??'EUR',$code,false).' value="'.$code.'">'.$code.'</option>';echo '</select>';}
        else echo '<input name="transfer['.esc_attr($key).']" type="number" min="0" step="'.(str_contains($key,'hours')?'1':'0.0001').'" value="'.esc_attr($transfer[$key]??'').'">';
        echo '</label>';
    }
    echo '</div><input type="hidden" name="fx_mode_present" value="1"><label><input type="checkbox" name="fx_auto" value="1" '.checked(get_option('twt_fx_auto',true),true,false).'> Automatic exchange rates</label><p>When enabled, the latest automatic rates take priority. Turn this off to use the manual rates above. Route prices remain EUR.</p></section><button class="matvip-primary" type="submit">'.esc_html(matvip_t('save')).'</button></form>';
    echo '<div class="dos-panel"><h2>Gemini &amp; Pexels</h2><p>Manage API keys and models in the Blog Studio.</p><a class="matvip-primary" href="'.esc_url(matvip_panel_url('blog')).'">AI Blog Studio →</a></div>';
}

/** Homepage image manager. Media IDs persist in WordPress library and are safe to reuse. */
function matvip_home_visuals_page() {
    if (!matvip_permission('manage_options')) return;
    $saved=get_option('matvip_home_visuals',[]); if (!is_array($saved)) $saved=[];
    matvip_panel_headline(matvip_t('visuals'), 'Manage home and all registered region photos without changing the design.');
    echo '<form method="post" class="dos-panel matvip-visual-panel">';
    echo '<p><strong>Önemli:</strong> Görseli seçtikten sonra mutlaka Kaydet düğmesine basın. Kaydedilen fotoğraflar dört dilde aynı kullanılır.</p><button class="dos-btn" type="submit" name="matvip_save_visuals" value="1" style="margin-bottom:18px">Görselleri Kaydet</button>';
    wp_nonce_field('matvip_save_visuals','matvip_visual_nonce');
    echo '<div class="matvip-image-grid">';
    foreach (['belek'=>'Belek','kemer'=>'Kemer','side'=>'Side','alanya'=>'Alanya','why'=>'Tanıtım alanı','hero'=>'Üst kapak / Hero'] as $key=>$label) {
        $id=absint($saved[$key]??0);$url=$id?wp_get_attachment_image_url($id,'large'):'';
        echo '<div class="matvip-image-card"><h3>'.esc_html($label).'</h3><div class="matvip-image-preview">'.($url?'<img src="'.esc_url($url).'" alt="">':'<span>Tema varsayılan görseli kullanılıyor</span>').'</div><input type="hidden" name="visual_image['.esc_attr($key).']" value="'.$id.'"><div class="dos-actions"><button type="button" class="dos-btn secondary matvip-pick-image">Görsel Seç</button><button type="button" class="dos-btn ghost matvip-clear-image">Varsayılana dön</button></div></div>';
    }
    echo '</div>';
    global $wpdb; $t=deniz_tables();
    $regions=(array)$wpdb->get_results("SELECT r.id,r.name,c.name city FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id ORDER BY c.name,r.name");
    $images=function_exists('atp_region_images')?atp_region_images():[];
    echo '<h2 style="margin-top:30px">Tüm Kayıtlı Bölgelerin Görselleri</h2><p>Aşağıdaki görseller bölge/SEO sayfalarında kullanılır; bütün kayıtlı bölgeler otomatik listelenir.</p><div class="matvip-image-grid">';
    foreach($regions as $r){
      $id=absint($images[$r->id]??0);$url=$id?wp_get_attachment_image_url($id,'medium'):'';
      echo '<div class="matvip-image-card"><h3>'.esc_html(($r->city?$r->city.' / ':'').$r->name).'</h3><div class="matvip-image-preview">'.($url?'<img src="'.esc_url($url).'" alt="">':'<span>Varsayılan görsel</span>').'</div><input type="hidden" name="region_img['.(int)$r->id.']" value="'.$id.'"><div class="dos-actions"><button type="button" class="dos-btn secondary matvip-pick-image">Görsel Seç</button><button type="button" class="dos-btn ghost matvip-clear-image">Kaldır</button></div></div>';
    }
    echo '</div><p>Önerilen: yatay, kaliteli WebP/JPG; bölge kartları için konu kadrajın ortasında olsun. Görseller tüm dillerde aynı şekilde güncellenir.</p><button class="dos-btn" type="submit" name="matvip_save_visuals" value="1">Görselleri Kaydet</button></form>';
    echo '<style>.matvip-image-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(235px,1fr));gap:18px}.matvip-image-card{padding:15px;border:1px solid #e4e6ea;border-radius:14px;background:#fff}.matvip-image-card h3{margin:0 0 10px}.matvip-image-preview{height:150px;background:#f2f4f7;border:1px dashed #c5cbd3;border-radius:10px;display:grid;place-items:center;overflow:hidden;color:#667085}.matvip-image-preview img{width:100%;height:100%;object-fit:cover}.matvip-image-card .dos-actions{margin-top:12px;display:flex;flex-wrap:wrap;gap:7px}</style>';
    echo '<script>jQuery(function($){$(document).on("click",".matvip-pick-image",function(){var card=$(this).closest(".matvip-image-card"),frame=wp.media({title:"Görsel seç",button:{text:"Bu görseli kullan"},multiple:false,library:{type:"image"}});frame.on("select",function(){var obj=frame.state().get("selection").first().toJSON();card.find("input[type=hidden]").val(obj.id);card.find(".matvip-image-preview").html($("<img>").attr("src",obj.sizes&&obj.sizes.medium?obj.sizes.medium.url:obj.url));});frame.open();});$(document).on("click",".matvip-clear-image",function(){var c=$(this).closest(".matvip-image-card");c.find("input[type=hidden]").val(0);c.find(".matvip-image-preview").text("Tema varsayılan görseli kullanılıyor");});});</script>';
}
function matvip_hotels_scanner_page() {
    if (!matvip_permission('matvip_locations')) return;
    global $wpdb;$t=deniz_tables();
    $regions=$wpdb->get_results("SELECT r.id,r.name,r.polygon,c.name AS city FROM {$t['regions']} r LEFT JOIN {$t['cities']} c ON c.id=r.city_id WHERE r.active=1 ORDER BY c.name,r.name");
    echo '<div class="dos-panel" style="margin-bottom:20px"><h2>Polygon ile Otel Tarama</h2><p>Kayıtlı bölge sınırları içindeki otelleri OpenStreetMap ve desteklenen kaynaklardan tara, mevcut otel veritabanına kaydet veya güncelle.</p>';
    if (!$regions) echo '<p>Kayıtlı aktif bölge bulunamadı. Önce Bölgeler & Harita ekranından bölge ekleyin.</p>';
    else {
        echo '<div class="dos-2"><label>Taranacak Bölge<select id="matvip-scan-region">';
        $selected=absint($_GET['region_id']??0);
        foreach ($regions as $r) {
            $poly=deniz_scan_polygon_points(json_decode($r->polygon,true));$valid=count($poly)>=3;
            echo '<option value="'.intval($r->id).'" data-valid="'.($valid?'1':'0').'" '.selected($selected,$r->id,false).'>'.esc_html(($r->city?$r->city.' / ':'').$r->name.($valid?'':' — polygon eksik')).'</option>';
        }
        echo '</select></label><div style="align-self:end"><button type="button" class="dos-btn scan-hotels" id="matvip-run-scan">Seçilen Bölgeyi Tara</button></div></div><p id="matvip-scan-status" role="status">Büyük bölgelerin taranması zaman alabilir. İşlem sırasında sayfayı kapatmayın.</p>';
        echo '<script>jQuery(function($){function syncScan(){var o=$("#matvip-scan-region option:selected"),valid=o.attr("data-valid")==="1";$("#matvip-run-scan").data("id",o.val()).attr("data-id",o.val()).prop("disabled",!valid);$("#matvip-scan-status").text(valid?"Hazır: "+o.text()+" — Büyük bölgelerde tarama uzun sürebilir.":"Bu bölgenin geçerli polygonu yok. Önce Bölgeler & Harita bölümünden sınırı kaydedin.");}$(document).on("change","#matvip-scan-region",syncScan);syncScan();});</script>';
    }
    echo '</div>';
}

// Each language is its own authenticated request, so the progress UI reflects actual completion.

function matvip_blog_editor($id) {
 if(!matvip_can_edit_blog($id)){echo '<p>Permission denied.</p>';return;}
 $post=get_post($id);$data=json_decode((string)get_post_meta($id,'twt_bs_source',true),true);
 if(!is_array($data))$data=[];
 echo '<p><a href="'.esc_url(matvip_panel_url('blog')).'">← Blog Studio</a></p><h1>Edit article #'.(int)$id.'</h1><form method="post" class="dos-panel" id="matvip-blog-form">';
 wp_nonce_field('matvip_blog_save');echo '<input type="hidden" name="matvip_action" value="blog_save"><input type="hidden" name="post_id" value="'.(int)$id.'"><input type="hidden" name="featured" value="'.(int)get_post_thumbnail_id($id).'">';
 foreach(atp_ai_langs() as $lang=>$label){
  $row=$data[$lang]??[];
  if(!$row){
   $prefix=$lang==='tr'?'':'deniz_'.$lang.'_';
   $row=['title'=>$lang==='tr'?$post->post_title:get_post_meta($id,$prefix.'title',true),'slug'=>$lang==='tr'?$post->post_name:get_post_meta($id,$prefix.'slug',true),'content'=>$lang==='tr'?$post->post_content:get_post_meta($id,$prefix.'content',true),'excerpt'=>$lang==='tr'?$post->post_excerpt:get_post_meta($id,$prefix.'excerpt',true)];
   foreach(['seo_title','seo_description','hero_subtitle'] as $key)$row[$key]=get_post_meta($id,$prefix.$key,true);
   $row['focus_keyword']=get_post_meta($id,'deniz_'.$lang.'_focus_keyword',true);$row['featured_image_alt']=get_post_meta($id,'deniz_'.$lang.'_image_alt',true);$row['faq']=twt_post_faq($id,$lang);
  }
  echo '<details open class="matvip-staff-item"><summary>'.esc_html($label).'</summary><div class="matvip-form-grid">';
  foreach(['title','slug','excerpt','seo_title','seo_description','focus_keyword','hero_subtitle','featured_image_alt','content'] as $key){
   $value=is_string($row[$key]??null)?$row[$key]:'';echo '<label>'.esc_html(ucwords(str_replace('_',' ',$key)));
   if(in_array($key,['content','excerpt','seo_description'],true))echo '<textarea name="content['.esc_attr($lang).']['.esc_attr($key).']" rows="'.($key==='content'?16:3).'" '.($key==='content'?'required':'').'>'.esc_textarea($value).'</textarea>';
   else echo '<input name="content['.esc_attr($lang).']['.esc_attr($key).']" value="'.esc_attr($value).'" '.(in_array($key,['title','slug'],true)?'required':'').'>';
   echo '</label>';
  }
  echo '<label>FAQs (JSON: q / a)<textarea name="faq['.esc_attr($lang).']" rows="8">'.esc_textarea(wp_json_encode($row['faq']??[],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</textarea></label></div></details>';
 }
 echo '<label>Status <select name="status"><option value="draft" '.selected($post->post_status,'draft',false).'>Draft</option>';
 if(current_user_can('publish_posts'))echo '<option value="publish" '.selected($post->post_status,'publish',false).'>Published</option>';
 echo '</select></label><button type="submit" class="matvip-primary">Save article</button></form>';
}
