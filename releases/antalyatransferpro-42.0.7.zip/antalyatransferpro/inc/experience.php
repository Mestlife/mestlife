<?php
/** Public experience: local assets, accessible booking and concise source information. */
if (!defined('ABSPATH')) exit;
function atp_experience_text($key) {
    $copy = [
      'tr'=>[
        'eyebrow'=>'ANTALYA’YA HOŞ GELDİNİZ', 'headline'=>'Yolculuğunuz rahat başlasın.',
        'intro'=>'Antalya Havalimanı’ndan otelinize, size uygun araçla. Güzergâhınızı seçin, güncel fiyatları karşılaştırın ve transferinizi ayırın.',
        'search_title'=>'Transferinizi planlayın', 'search_help'=>'Tüm saatler Antalya yerel saatidir (UTC+3).',
        'search_cta'=>'Araçları ve fiyatları gör', 'reassurance'=>'Ödeme sürücüye nakit · Toplam fiyat onaydan önce gösterilir',
        'quick_title'=>'Antalya transferiniz, net bilgilerle.',
        'quick_answer'=>'Antalya Transfer Pro, Antalya Havalimanı (AYT) ile oteller ve tatil bölgeleri arasında transfer sunar. Özel transferde fiyat araç başına; paylaşımlı servis sunulan rotalarda kişi başınadır. Araç, bagaj kapasitesi ve toplam tutar rezervasyondan önce gösterilir.',
        'step1'=>'Güzergâhınızı seçin', 'step2'=>'Aracınızı karşılaştırın', 'step3'=>'Bilgileri girin ve onaylayın',
        'popular'=>'Popüler güzergâhlar', 'edit'=>'Güzergâhı düzenle', 'review'=>'Yolculuk bilgilerini ve toplam fiyatı kontrol ettim.',
        'review_error'=>'Lütfen yolculuk bilgilerini ve toplam fiyatı kontrol edip onaylayın.',
        'privacy'=>'Verileriniz yalnızca rezervasyon işlemleri için kullanılır.', 'image_placeholder'=>'Araç görseli',
        'retry'=>'Tekrar dene', 'choose_time'=>'Lütfen bir saat seçin.', 'back'=>'Araçlara dön',
      ],
      'en'=>[
        'eyebrow'=>'WELCOME TO ANTALYA', 'headline'=>'A relaxed start to your journey.',
        'intro'=>'From Antalya Airport to your hotel, in a vehicle that suits you. Choose your route, compare current fares and book your transfer.',
        'search_title'=>'Plan your transfer', 'search_help'=>'All times are local to Antalya (UTC+3).',
        'search_cta'=>'See vehicles & prices', 'reassurance'=>'Pay the driver in cash · See the total before confirming',
        'quick_title'=>'Your Antalya transfer, clearly explained.',
        'quick_answer'=>'Antalya Transfer Pro provides transfers between Antalya Airport (AYT), hotels and resort areas. Private transfers are priced per vehicle; shared services, where offered, are priced per person. Vehicle and luggage capacity and the total fare are shown before booking.',
        'step1'=>'Choose your route', 'step2'=>'Compare your vehicles', 'step3'=>'Enter details & confirm',
        'popular'=>'Popular routes', 'edit'=>'Edit your route', 'review'=>'I have checked the journey details and total price.',
        'review_error'=>'Please check and confirm your journey details and total price.',
        'privacy'=>'Your details are used to arrange your booking.', 'image_placeholder'=>'Vehicle image',
        'retry'=>'Try again', 'choose_time'=>'Please choose a time.', 'back'=>'Back to vehicles',
      ],
      'de'=>[
        'eyebrow'=>'WILLKOMMEN IN ANTALYA', 'headline'=>'Entspannt in den Urlaub starten.',
        'intro'=>'Vom Flughafen Antalya zu Ihrem Hotel, im passenden Fahrzeug. Route wählen, aktuelle Preise vergleichen und Transfer buchen.',
        'search_title'=>'Ihren Transfer planen', 'search_help'=>'Alle Zeiten gelten für Antalya (UTC+3).',
        'search_cta'=>'Fahrzeuge & Preise ansehen', 'reassurance'=>'Barzahlung beim Fahrer · Gesamtpreis vor der Bestätigung',
        'quick_title'=>'Ihr Antalya-Transfer, klar erklärt.',
        'quick_answer'=>'Antalya Transfer Pro bietet Transfers zwischen dem Flughafen Antalya (AYT), Hotels und Ferienregionen. Privattransfers werden pro Fahrzeug berechnet, angebotene Sammeltransfers pro Person. Fahrzeug, Gepäckkapazität und Gesamtpreis werden vor der Buchung angezeigt.',
        'step1'=>'Route wählen', 'step2'=>'Fahrzeuge vergleichen', 'step3'=>'Daten eingeben & bestätigen',
        'popular'=>'Beliebte Routen', 'edit'=>'Route ändern', 'review'=>'Ich habe die Reisedaten und den Gesamtpreis geprüft.',
        'review_error'=>'Bitte prüfen und bestätigen Sie Reisedaten und Gesamtpreis.',
        'privacy'=>'Ihre Angaben werden zur Abwicklung Ihrer Buchung verwendet.', 'image_placeholder'=>'Fahrzeugbild',
        'retry'=>'Erneut versuchen', 'choose_time'=>'Bitte eine Uhrzeit wählen.', 'back'=>'Zurück zu Fahrzeugen',
      ],
      'ru'=>[
        'eyebrow'=>'ДОБРО ПОЖАЛОВАТЬ В АНТАЛЬЮ', 'headline'=>'Начните путешествие спокойно.',
        'intro'=>'Из аэропорта Антальи в отель на подходящем автомобиле. Выберите маршрут, сравните актуальные цены и забронируйте трансфер.',
        'search_title'=>'Спланируйте трансфер', 'search_help'=>'Время указано по Анталье (UTC+3).',
        'search_cta'=>'Посмотреть автомобили и цены', 'reassurance'=>'Наличными водителю · Итоговая цена до подтверждения',
        'quick_title'=>'Ваш трансфер в Анталье: главное.',
        'quick_answer'=>'Antalya Transfer Pro предлагает трансферы между аэропортом Антальи (AYT), отелями и курортами. Индивидуальный трансфер оплачивается за автомобиль, групповой, где доступен, — за человека. Вместимость, багаж и итоговая цена указаны до бронирования.',
        'step1'=>'Выберите маршрут', 'step2'=>'Сравните автомобили', 'step3'=>'Введите данные и подтвердите',
        'popular'=>'Популярные маршруты', 'edit'=>'Изменить маршрут', 'review'=>'Я проверил данные поездки и итоговую цену.',
        'review_error'=>'Проверьте и подтвердите данные поездки и итоговую цену.',
        'privacy'=>'Ваши данные используются для оформления бронирования.', 'image_placeholder'=>'Изображение автомобиля',
        'retry'=>'Повторить', 'choose_time'=>'Выберите время.', 'back'=>'Назад к автомобилям',
      ],
    ];
    $lang=deniz_current_lang();
    $value=$copy[$lang][$key]??$copy['en'][$key]??$key;
    return deniz_translation_override('experience_'.$key,$lang,$value);
}
add_action('wp_enqueue_scripts',function(){
    $version=wp_get_theme()->get('Version');
    wp_enqueue_style('atp-experience',get_template_directory_uri().'/assets/css/experience.css',['atp-brand'],$version);
    wp_enqueue_script('atp-experience',get_template_directory_uri().'/assets/js/experience.js',[],$version,true);
    wp_localize_script('atp-experience','ATPExperience',['choose_time'=>atp_experience_text('choose_time'),'retry'=>atp_experience_text('retry')]);
},110);
add_filter('script_loader_tag',function($tag,$handle){
    $handles=['deniz-main','twt-header-menus','deniz-transfer-search','deniz-vehicle-results','deniz-booking','twt-address-verify','twt-time-select','twt-mobile-checkout','atp-experience'];
    if(in_array($handle,$handles,true)&&strpos($tag,' defer')===false)$tag=str_replace('<script ','<script defer ',$tag);
    return $tag;
},10,2);
add_action('wp_head',function(){
    if(is_front_page())echo '<link rel="preload" as="image" href="'.esc_url(atp_home_image_url('hero',atp_img('hero-arrival.webp'))).'">'."\n";
},1);
/* Invalid booking parameters cannot be indexed or cached, including HTTP errors. */
add_action('template_redirect',function(){
    if(!twt_seo_private_page())return;
    header('X-Robots-Tag: noindex, noarchive');
    header('Referrer-Policy: same-origin');
},-1);
/* Compile locally at release time. WordPress never needs Node or a network build. */
add_action('wp_enqueue_scripts',function(){
    $dir=get_template_directory();$uri=get_template_directory_uri();
    if(!is_file($dir.'/assets/dist/core.min.css'))return;
    $styles=wp_styles();
    if(isset($styles->registered['deniz-style']))$styles->registered['deniz-style']->src=$uri.'/assets/dist/core.min.css';
    foreach(['twt-home','twt-pages','twt-location-menu','twt-time-select'] as $handle){
        if(isset($styles->registered[$handle]))$styles->registered[$handle]->src=false;
    }
},120);
function atp_compiled_asset_url($src){
    $uri=get_template_directory_uri();
    if(strpos($src,$uri.'/assets/css/')!==0&&strpos($src,$uri.'/assets/js/')!==0)return $src;
    $path=wp_parse_url($src,PHP_URL_PATH);$name=basename($path);
    $min=preg_replace('/\.(css|js)$/','.min.$1',$name);
    if(!is_file(get_template_directory().'/assets/dist/'.$min))return $src;
    $query=wp_parse_url($src,PHP_URL_QUERY);
    return $uri.'/assets/dist/'.$min.($query?'?'.$query:'');
}
add_filter('style_loader_src','atp_compiled_asset_url');
add_filter('script_loader_src','atp_compiled_asset_url');
