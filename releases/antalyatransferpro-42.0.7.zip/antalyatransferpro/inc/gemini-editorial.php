<?php
/** Durable, owner-scoped editorial workflow. All generated articles remain drafts. */
if (!defined('ABSPATH')) exit;
function atp_ai_langs(){return ['en'=>'English','de'=>'Deutsch','ru'=>'Русский','tr'=>'Türkçe'];}
function atp_ai_settings(){return (array)get_option('atp_ai_editorial_settings',[]);}
function atp_ai_model_valid($model){return is_string($model) && (bool)preg_match('/^gemini-[a-z0-9][a-z0-9.-]{1,100}$/D',$model);}
add_action('admin_post_atp_ai_settings',function(){
 if (!atp_operation_allowed('manage_options')) wp_die('Not authorized');
 check_admin_referer('atp_ai_settings');$old=atp_ai_settings();$new=[];
 foreach(['gemini_key','pexels_key'] as $key){
  $raw=$_POST[$key]??'';if(!is_string($raw))wp_die('Invalid API key');
  $v=trim(wp_unslash($raw));$new[$key]=!empty($_POST['clear_'.$key])?'':($v!==''?$v:($old[$key]??''));
 }
 $model=wp_unslash($_POST['model']??'');if(!atp_ai_model_valid($model))wp_die('Enter a valid Gemini model ID.');
 $new['model']=$model;update_option('atp_ai_editorial_settings',$new,false);
 wp_safe_redirect(add_query_arg('settings','saved',wp_get_referer()?:matvip_panel_url('blog')));exit;
});
add_action('wp_ajax_atp_ai_models',function(){
 if(!atp_operation_allowed('manage_options'))wp_send_json_error('Access denied',403);
 check_ajax_referer('atp_ai_nonce','nonce');$cfg=atp_ai_settings();
 if(empty($cfg['gemini_key']))wp_send_json_error('Save your Gemini key first.',400);
 $r=wp_remote_get('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000',['timeout'=>15,'headers'=>['x-goog-api-key'=>$cfg['gemini_key']]]);
 if(is_wp_error($r))wp_send_json_error('Could not connect to the model catalogue.',503);
 if(wp_remote_retrieve_response_code($r)!==200)wp_send_json_error('Model catalogue HTTP '.wp_remote_retrieve_response_code($r).'. Check the saved key and account access.',400);
 $body=json_decode(wp_remote_retrieve_body($r),true);$models=[];
 foreach(($body['models']??[]) as $m){$id=str_replace('models/','',$m['name']??'');if(atp_ai_model_valid($id)&&in_array('generateContent',(array)($m['supportedGenerationMethods']??[]),true))$models[]=$id;}
 if(!$models)wp_send_json_error('No generateContent models were returned for this key.',400);
 sort($models);wp_send_json_success($models);
});
function atp_ai_research($keyword,$lang='en'){
 $posts=get_posts(['post_type'=>['post','page','transfer-route'],'post_status'=>'publish','numberposts'=>18,'s'=>$keyword]);
 if(count($posts)<5)$posts=array_merge($posts,get_posts(['post_type'=>['post','page','transfer-route'],'post_status'=>'publish','numberposts'=>12]));
 $links=[];$seen=[];
 foreach($posts as $post){
  if($post->post_type==='post'){
   if($lang!=='tr'&&(!get_post_meta($post->ID,'deniz_'.$lang.'_title',true)||!get_post_meta($post->ID,'deniz_'.$lang.'_content',true)))continue;
   $url=twt_post_lang_url($post,$lang);$title=$lang==='tr'?get_the_title($post):get_post_meta($post->ID,'deniz_'.$lang.'_title',true);
  }else{
   $url=get_permalink($post);$path=wp_parse_url($url,PHP_URL_PATH);$base=wp_parse_url(home_url('/'),PHP_URL_PATH);
   if($base&&$base!=='/'&&strpos($path,$base)===0)$path=substr($path,strlen($base));
   $path=preg_replace('~^/?(?:tr|en|de|ru)(?:/|$)~','/',(string)$path);$url=deniz_url(trim($path,'/'),$lang);$title=get_the_title($post);
  }
  if(!$url||isset($seen[$url]))continue;$seen[$url]=true;$links[]=['title'=>$title,'url'=>$url];if(count($links)>=16)break;
 }
 return $links;
}
function atp_ai_prompt($keyword,$lang,$links){
 $name=atp_ai_langs()[$lang];
 $data=['keyword'=>$keyword,'language'=>$name,'site'=>home_url('/'),'relevant_internal_links'=>$links,
 'source_policy'=>'Only the supplied internal URLs are available. External source pages have not been fetched. Do not cite external URLs or claim external research.'
 ];
 return 'You are an experienced HUMAN travel editor and airport-transfer specialist writing for Antalya Transfer Pro. Generate ONE standalone, outstanding original article in '. $name .'. All editorial sentences, headings, FAQ questions and answers, meta fields and ALT text MUST be in '. $name .'. Do not mix English with German/Russian/Turkish except genuine names, airport codes, protected brands or proper nouns. Translate search phrases into natural native phrasing, not literal word-for-word translations. Topic data: '.wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n".
 'Writing requirements: Treat the focus keyword as central: mention its natural-language form in title, first 100 words, an appropriate H2, image ALT and conclusion when genuinely fitting. Build strong topical coverage using close variants and entities rather than mechanical keyword repetition. For relevant terms you may repeat naturally across tables, captions and FAQ answers, but never stuff awkward exact-match phrases. A comparison table must have truly useful columns and accurate caveats. Include short bullet lists and a concise question-answer block optimized for travellers, not spam. Include 2-5 genuinely useful internal links picked only from the supplied real URLs, preferably service pages and matching routes. Do not add external citations: no external source content has been fetched. Do not claim research, firsthand experience or verification. The supplied internal links establish URLs, not factual proof of every claim. Lead with a concrete 40-75 word direct answer to the passenger question. Include short paragraphs, authentic local route decision advice (airport terminals, luggage, arrival procedure, family travel, booking), 4-7 specific informative H2s, H3 only when useful; an HTML comparison table with thead, tbody and 3-5 meaningful rows comparing travel options or planning trade-offs; factual constraints and caveats; at least 5 distinct user questions and direct answers in faq. Write natural, varied prose, no generic AI filler (no delve, ultimate guide, game changer, seamless journey), no fabricated firsthand experience. Aim 1100-1600 high-quality native-language words without padding. Use HTML h2,h3,p,ul,ol,table,thead,tbody,tr,th,td,a,strong. NO h1, scripts, inline style, iframe or image tags. A natural short-tail primary keyword prominently in title, first paragraph, one useful H2 and elsewhere where it genuinely helps; related terms and variations; NO forced density target or repetitive keyword stuffing. Include 2-5 natural internal links ONLY if they match exactly one of the provided real URLs; correct language paths if applicable; do not invent internal URLs. Use only the supplied internal links. Omit external links. Never invent quotes, community sentiment, prices, timetables, distances, guarantees, legal rules or research. Avoid citing Reddit as proof of facts; attribute such anecdotes as opinions. Comparison table should clarify that costs and journeys vary, not state unverified numbers. A brief practical checklist and a measured CTA are helpful. Keep all content specifically relevant to the chosen keyword. Give SEO title <=60 chars, meta description <=155 chars, natural concise slug (ascii-hyphen), featured_image_alt, two content image_alts, hero_subtitle, translated focus_keyword, 5-7 FAQs, excerpt. Output ONE JSON object ONLY without fences: {"title":"","slug":"","excerpt":"","seo_title":"","seo_description":"","focus_keyword":"","hero_subtitle":"","featured_image_alt":"","image_alts":["",""],"content":"<p>...</p>","faq":[{"q":"...","a":"..."}]}. No markdown or extra prose.';
}
function atp_ai_call_gemini($keyword,$lang,$links=null,$model=null){
 $cfg=atp_ai_settings();$key=$cfg['gemini_key']??'';
 if(!$key)return new WP_Error('config','Gemini API key is missing.');
 $model=$model?:($cfg['model']??'gemini-2.5-flash');
 if(!atp_ai_model_valid($model))return new WP_Error('config','Check the selected Gemini model.');
 if($links===null)$links=atp_ai_research($keyword,$lang);
 $payload=['contents'=>[['parts'=>[['text'=>atp_ai_prompt($keyword,$lang,$links)]]]],'generationConfig'=>['responseMimeType'=>'application/json','temperature'=>0.75,'maxOutputTokens'=>7500]];
 // One bounded API request per stage. Retrying never repeats an already saved language.
 $res=wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/'.rawurlencode($model).':generateContent',['timeout'=>40,'headers'=>['x-goog-api-key'=>$key,'Content-Type'=>'application/json'],'body'=>wp_json_encode($payload)]);
 if(is_wp_error($res))return new WP_Error('retryable','Gemini connection timed out or failed. Saved languages are safe; retry to continue.');
 $http=(int)wp_remote_retrieve_response_code($res);$body=json_decode(wp_remote_retrieve_body($res),true);
 if($http!==200){
  $retry=in_array($http,[429,500,502,503,504],true);
  return new WP_Error($retry?'retryable':'config','Gemini HTTP '.$http.'. '.($retry?'Please wait and resume this job.':'Check your API key, model catalogue and account permissions.'));
 }
 if(($body['candidates'][0]['finishReason']??'')==='MAX_TOKENS')return new WP_Error('format','Gemini reached the output limit. Resume to regenerate this language.');
 $raw='';foreach(($body['candidates'][0]['content']['parts']??[]) as $part){if(empty($part['thought'])&&isset($part['text'])&&is_string($part['text']))$raw.=$part['text'];}
 $data=json_decode(trim(preg_replace('/^```(?:json)?\s*|\s*```$/i','',trim($raw))),true);
 return is_array($data)?$data:new WP_Error('format','Gemini returned incomplete JSON. Resume to regenerate this language.');
}
function atp_ai_clean_article($data,$lang,$links=[]){
 if(!is_array($data))return new WP_Error('format','Invalid article');
 $required=['title','slug','excerpt','seo_title','seo_description','focus_keyword','featured_image_alt','content'];
 foreach($required as $k)if(!isset($data[$k])||!is_string($data[$k])||trim($data[$k])==='')return new WP_Error('format',strtoupper($lang).' invalid '.$k);
 foreach(['hero_subtitle'] as $k){if(isset($data[$k])&&!is_string($data[$k]))return new WP_Error('format','Invalid '.$k);$data[$k]=sanitize_text_field($data[$k]??'');}
 foreach(['title','excerpt','focus_keyword','featured_image_alt'] as $k)$data[$k]=sanitize_text_field($data[$k]);
 $data['slug']=sanitize_title($data['slug']);if($data['slug']==='')return new WP_Error('format','Invalid slug');
 $data['seo_title']=mb_substr(sanitize_text_field($data['seo_title']),0,60);$data['seo_description']=mb_substr(sanitize_text_field($data['seo_description']),0,155);
 $alts=$data['image_alts']??[];if(!is_array($alts))return new WP_Error('format','Invalid image ALT list');
 foreach($alts as $alt)if(!is_string($alt))return new WP_Error('format','Invalid image ALT');
 $data['image_alts']=array_map('sanitize_text_field',array_slice($alts,0,2));
 if(!isset($data['faq'])||!is_array($data['faq'])||count($data['faq'])<5||count($data['faq'])>10)return new WP_Error('format','Provide 5–10 complete FAQs.');
 $faq=[];$seen=[];
 foreach($data['faq'] as $row){
  if(!is_array($row)||!isset($row['q'],$row['a'])||!is_string($row['q'])||!is_string($row['a']))return new WP_Error('format','Invalid FAQ structure');
  $q=sanitize_text_field($row['q']);$a=sanitize_textarea_field($row['a']);
  if(trim($q)===''||trim($a)===''||mb_strlen($q)>300||mb_strlen($a)>3000||isset($seen[mb_strtolower($q)]))return new WP_Error('format','FAQ answers must be complete and questions must be distinct.');
  $seen[mb_strtolower($q)]=true;$faq[]=['q'=>$q,'a'=>$a];
 }
 $data['faq']=$faq;
 $tags=['h2'=>[],'h3'=>[],'p'=>[],'ul'=>[],'ol'=>[],'li'=>[],'table'=>[],'thead'=>[],'tbody'=>[],'tr'=>[],'th'=>['scope'=>true],'td'=>[],'a'=>['href'=>true,'title'=>true],'strong'=>[],'em'=>[],'br'=>[]];
 $html=wp_kses($data['content'],$tags);$allowed=[];
 foreach($links as $link)if(isset($link['url'])&&is_string($link['url']))$allowed[]=untrailingslashit($link['url']);
 $processor=new WP_HTML_Tag_Processor($html);
 while($processor->next_tag(['tag_name'=>'A'])){
  $url=$processor->get_attribute('href');
  if(!is_string($url)||!in_array(untrailingslashit(html_entity_decode($url,ENT_QUOTES,'UTF-8')),$allowed,true))$processor->remove_attribute('href');
 }
 $html=$processor->get_updated_html();
 foreach(['title','excerpt','focus_keyword','featured_image_alt','seo_title','seo_description'] as $key)if(trim($data[$key])==='')return new WP_Error('format','Empty article field after cleaning: '.$key);
 if(substr_count(strtolower($html),'<h2')<4||stripos($html,'<table')===false||stripos($html,'<th')===false||substr_count(strtolower($html),'<tr')<4)return new WP_Error('format','Article needs four headings and a comparison table with a header and three data rows.');
 if(twt_bs_word_count(wp_strip_all_tags($html))<600)return new WP_Error('format','Article is too short. Resume to regenerate this language.');
 $data['content']=$html;return $data;
}
function atp_ai_pexels($term,$job_id=''){
 if(!current_user_can('upload_files'))return new WP_Error('permission','Media upload permission is required.');
 if($job_id){$existing=get_posts(['post_type'=>'attachment','post_status'=>'inherit','meta_key'=>'_atp_ai_job_image','meta_value'=>$job_id,'fields'=>'ids','posts_per_page'=>1]);if($existing)return (int)$existing[0];}
 $cfg=atp_ai_settings();$key=$cfg['pexels_key']??'';if(!$key)return new WP_Error('pexels','Pexels API key is missing.');
 $url=add_query_arg(['query'=>$term.' Antalya airport travel','orientation'=>'landscape','per_page'=>8],'https://api.pexels.com/v1/search');
 $r=wp_remote_get($url,['timeout'=>25,'headers'=>['Authorization'=>$key]]);if(is_wp_error($r))return $r;
 if((int)wp_remote_retrieve_response_code($r)!==200)return new WP_Error('pexels','Pexels HTTP '.wp_remote_retrieve_response_code($r));
 $photos=(array)(json_decode(wp_remote_retrieve_body($r),true)['photos']??[]);if(!$photos)return new WP_Error('pexels','No suitable Pexels photos found.');
 $photo=$photos[0];$image=$photo['src']['large2x']??$photo['src']['large']??'';if(!$image)return new WP_Error('pexels','Pexels photo URL unavailable.');
 require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
 $tmp=download_url($image,35);if(is_wp_error($tmp))return $tmp;
 $file=['name'=>'antalyatransferpro-pexels-'.absint($photo['id']).'.jpg','tmp_name'=>$tmp];$id=media_handle_sideload($file,0,sanitize_text_field($photo['alt']??'Antalya travel'),['meta_input'=>['_atp_ai_job_image'=>$job_id]]);
 if(is_wp_error($id)){@unlink($tmp);return $id;}
 update_post_meta($id,'_atp_pexels_source',esc_url_raw($photo['url']??''));update_post_meta($id,'_atp_pexels_photographer',sanitize_text_field($photo['photographer']??''));return (int)$id;
}

function atp_ai_job_key($id){return 'atp_ai_job_'.hash('sha256',$id);}
function atp_ai_load_job($id){
 if(!is_string($id)||!preg_match('/^[a-f0-9-]{36}$/D',$id))return new WP_Error('job','Invalid job ID.');
 $job=get_option(atp_ai_job_key($id));
 if(!is_array($job)||(int)($job['owner']??0)!==get_current_user_id())return new WP_Error('job','Job not found for this account.');
 return $job;
}
function atp_ai_save_job($job){$job['updated']=time();return update_option(atp_ai_job_key($job['id']),$job,false);}
function atp_ai_job_result($job){return ['job_id'=>$job['id'],'keyword'=>$job['keyword'],'completed'=>array_keys($job['articles']),'post_id'=>(int)($job['post_id']??0),'edit_url'=>empty($job['post_id'])?'':atp_ai_edit_url($job['post_id']),'photo_error'=>$job['photo_error']??''];}
function atp_ai_edit_url($id){return in_array('matvip_operator',(array)wp_get_current_user()->roles,true)?matvip_panel_url('blog',['edit'=>$id]):admin_url('post.php?post='.(int)$id.'&action=edit');}
function atp_ai_lock($id){
 global $wpdb;$key=atp_ai_job_key($id).'_lock';$old=get_option($key);
 if(is_string($old)&&((int)explode(':',$old)[0])<time()){
  // Conditional deletion prevents removing a lock another request has just acquired.
  $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,$old));wp_cache_delete($key,'options');
 }
 $token=(time()+120).':'.wp_generate_uuid4();return add_option($key,$token,'',false)?$token:false;
}
function atp_ai_unlock($id,$token){
 global $wpdb;$key=atp_ai_job_key($id).'_lock';
 $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,$token));wp_cache_delete($key,'options');
}
function atp_ai_generate_stage($id,$lang){
 $job=atp_ai_load_job($id);if(is_wp_error($job))return $job;
 if(!isset(atp_ai_langs()[$lang]))return new WP_Error('format','Invalid language.');
 if(isset($job['articles'][$lang]))return atp_ai_job_result($job);
 $lock=atp_ai_lock($id);if(!$lock)return new WP_Error('busy','This job is still running. Wait a moment, then resume.');
 try{
  $job=atp_ai_load_job($id);if(isset($job['articles'][$lang]))return atp_ai_job_result($job);
  $links=$job['links'][$lang]??atp_ai_research($job['keyword'],$lang);
  $data=atp_ai_call_gemini($job['keyword'],$lang,$links,$job['model']);if(is_wp_error($data))return $data;
  $data=atp_ai_clean_article($data,$lang,$links);if(is_wp_error($data))return $data;
  $job['links'][$lang]=$links;$job['articles'][$lang]=$data;atp_ai_save_job($job);
  return atp_ai_job_result($job);
 }finally{atp_ai_unlock($id,$lock);}
}
function atp_ai_finalize_job($id){
 $job=atp_ai_load_job($id);if(is_wp_error($job))return $job;
 if(!empty($job['post_id']))return atp_ai_job_result($job);
 $lock=atp_ai_lock($id);if(!$lock)return new WP_Error('busy','This job is still running. Wait a moment, then resume.');
 try{
  $job=atp_ai_load_job($id);if(!empty($job['post_id']))return atp_ai_job_result($job);
  // Recover a successful insert even if the previous HTTP response or job update was lost.
  $existing=get_posts(['post_type'=>'post','post_status'=>['draft','publish','pending','future','private','trash'],'meta_key'=>'_atp_ai_job','meta_value'=>$id,'fields'=>'ids','posts_per_page'=>1]);
  if($existing){$job['post_id']=(int)$existing[0];atp_ai_save_job($job);return atp_ai_job_result($job);}
  $data=[];foreach(atp_ai_langs() as $l=>$name){$article=atp_ai_clean_article($job['articles'][$l]??null,$l,$job['links'][$l]??[]);if(is_wp_error($article))return $article;$data[$l]=$article;}
  $data['category']='Antalya Travel Guide';$data['tags']=[$job['keyword'],'airport transfer'];
  // Persist the draft before downloading a photo; retries always recover this post.
  $post_id=twt_bs_save($data,['status'=>'draft','featured'=>0,'images'=>[],'job_id'=>$id]);
  if(is_wp_error($post_id))return $post_id;
  $job['post_id']=$post_id;atp_ai_save_job($job);
  $photo=atp_ai_pexels($data['en']['focus_keyword'],$id);
  if(is_wp_error($photo))$job['photo_error']=$photo->get_error_message();
  else{set_post_thumbnail($post_id,$photo);update_post_meta($photo,'_wp_attachment_image_alt',sanitize_text_field($data['en']['featured_image_alt']));wp_update_post(['ID'=>$photo,'post_parent'=>$post_id]);}
  atp_ai_save_job($job);return atp_ai_job_result($job);
 }finally{atp_ai_unlock($id,$lock);}
}
function atp_ai_ajax_auth(){
 if(!atp_ai_allowed())wp_send_json_error('Access denied',403);
 check_ajax_referer('atp_ai_nonce','nonce');
}
function atp_ai_ajax_result($result){
 if(is_wp_error($result))wp_send_json_error(['code'=>$result->get_error_code(),'message'=>$result->get_error_message()],in_array($result->get_error_code(),['busy','retryable'],true)?503:400);
 wp_send_json_success($result);
}
add_action('wp_ajax_atp_ai_start',function(){
 atp_ai_ajax_auth();$raw=$_POST['keyword']??'';
 if(!is_string($raw))wp_send_json_error('Invalid keyword',400);
 $kw=trim(sanitize_text_field(wp_unslash($raw)));if(mb_strlen($kw)<3||mb_strlen($kw)>130)wp_send_json_error('Provide a topic of 3–130 characters.',400);
 $active=get_user_meta(get_current_user_id(),'atp_ai_active_job',true);
 if($active&&empty($_POST['new_job'])){$old=atp_ai_load_job($active);if(!is_wp_error($old)&&$old['keyword']===$kw)wp_send_json_success(atp_ai_job_result($old));}
 $cfg=atp_ai_settings();$id=wp_generate_uuid4();
 $job=['id'=>$id,'owner'=>get_current_user_id(),'keyword'=>$kw,'model'=>$cfg['model']??'gemini-2.5-flash','articles'=>[],'links'=>[],'created'=>time(),'updated'=>time(),'post_id'=>0];
 if(!add_option(atp_ai_job_key($id),$job,'',false))wp_send_json_error('Could not start the job.',500);
 update_user_meta(get_current_user_id(),'atp_ai_active_job',$id);
 $history=get_user_meta(get_current_user_id(),'atp_ai_job_history',true);if(!is_array($history))$history=[];$history[]=$id;
 while(count($history)>20){$expired=array_shift($history);if(is_string($expired))delete_option(atp_ai_job_key($expired));}
 update_user_meta(get_current_user_id(),'atp_ai_job_history',$history);wp_send_json_success(atp_ai_job_result($job));
});
add_action('wp_ajax_atp_ai_generate',function(){atp_ai_ajax_auth();atp_ai_ajax_result(atp_ai_generate_stage(is_string($_POST['job_id']??null)?wp_unslash($_POST['job_id']):'',is_string($_POST['lang']??null)?sanitize_key($_POST['lang']):''));});
add_action('wp_ajax_atp_ai_finalize',function(){atp_ai_ajax_auth();atp_ai_ajax_result(atp_ai_finalize_job(is_string($_POST['job_id']??null)?wp_unslash($_POST['job_id']):''));});
function atp_ai_screen($standalone=false){
 if(!atp_ai_allowed())return;$cfg=atp_ai_settings();$nonce=wp_create_nonce('atp_ai_nonce');$active=atp_ai_load_job((string)get_user_meta(get_current_user_id(),'atp_ai_active_job',true));
 if($standalone)echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Antalya Transfer Pro · AI Blog Studio</title></head><body>';
 echo '<div class="wrap atp-editorial"><h1>Antalya Transfer Pro · AI Blog Studio</h1><p>English → Deutsch → Русский → Türkçe · Traveller-first editorial workflow · Pexels photos · WordPress drafts</p>';
 if(isset($_GET['settings']))echo '<div class="notice notice-success"><p>API settings saved.</p></div>';
 echo '<section class="atp-panel"><h2>Generate four-language travel guide</h2><p>One keyword, four locally written guides. Review all facts, sources and language before publishing.</p><label for="atp-keyword">Primary topic / keyword</label><div class="atp-toolbar"><input id="atp-keyword" type="text" placeholder="Antalya Airport to Belek transfer" maxlength="130" value="'.esc_attr(is_wp_error($active)?'':$active['keyword']).'"><button id="atp-start" class="button button-primary">Create / resume article</button><button type="button" id="atp-new" class="button">Start a new article</button></div><div id="atp-status" role="status" aria-live="polite"></div><div class="atp-track"><div id="atp-fill"></div></div><b id="atp-percent">0%</b><ol id="atp-steps"><li data-lang="en">English — Waiting</li><li data-lang="de">Deutsch — Waiting</li><li data-lang="ru">Русский — Waiting</li><li data-lang="tr">Türkçe — Waiting</li><li data-lang="image">Pexels &amp; Save draft — Waiting</li></ol><div id="atp-result"></div></section>';
 if(current_user_can('manage_options')){
 echo '<section class="atp-panel"><h2>API &amp; model settings</h2><form action="'.esc_url(admin_url('admin-post.php')).'" method="post">';wp_nonce_field('atp_ai_settings');echo '<input type="hidden" name="action" value="atp_ai_settings">';
 foreach(['gemini_key'=>'Gemini API key','pexels_key'=>'Pexels API key'] as $k=>$label)echo '<p><label>'.esc_html($label).' '.(!empty($cfg[$k])?'(saved)':'(missing)').'<br><input autocomplete="off" type="password" name="'.esc_attr($k).'" placeholder="'.(!empty($cfg[$k])?'Leave blank to keep current key':'Paste API key').'" style="width:min(100%,570px)"></label> <label><input type="checkbox" name="clear_'.esc_attr($k).'" value="1"> Clear</label></p>';
 echo '<p><label>Gemini model ID<br><input name="model" id="atp-model" list="atp-model-list" required value="'.esc_attr($cfg['model']??'gemini-2.5-flash').'" pattern="gemini-[a-z0-9.-]+"></label><datalist id="atp-model-list"></datalist> <button type="button" id="atp-load-models" class="button">Load available models</button> <span id="atp-model-status" role="status"></span></p><p>Save your key first, then load the model catalogue and choose an available ID.</p><button class="button button-secondary">Save settings</button></form></section>';
 }

 // Show posts in the same screen, including existing drafts and published guides.
 $entry_args=['post_type'=>'post','post_status'=>['publish','draft','pending','future'],'posts_per_page'=>30,'orderby'=>'modified','order'=>'DESC'];if(!current_user_can('edit_others_posts'))$entry_args['author']=get_current_user_id();$entries=get_posts($entry_args);
 echo '<section class="atp-panel atp-saved-posts" id="atp-saved-posts"><div class="atp-saved-head"><div><h2>Saved blog articles</h2><p>Published articles and drafts · latest updated first</p></div><span>'.count($entries).' shown</span></div>';
 if(!$entries) echo '<p>No saved blog articles yet.</p>';
 foreach($entries as $post){
  $status=get_post_status($post);$image=get_the_post_thumbnail_url($post,'thumbnail');$edit=current_user_can('edit_post',$post->ID)?atp_ai_edit_url($post->ID):'';
  echo '<article class="atp-saved-row">';
  if($image)echo '<img loading="lazy" src="'.esc_url($image).'" alt="">';
  echo '<div><span class="atp-post-status '.esc_attr($status).'">'.esc_html(ucfirst($status)).'</span><h3>'.esc_html(get_the_title($post)).'</h3><small>'.esc_html(get_the_modified_date('d M Y H:i',$post)).'</small><div class="atp-saved-actions">';
  if($edit)echo '<a href="'.esc_url($edit).'">Edit</a>';
  if($status==='publish')echo '<a href="'.esc_url(twt_post_lang_url($post,'en')).'" target="_blank" rel="noopener">View →</a>';
  echo '</div></div></article>';
 }
 echo '</section>';
 if(current_user_can('manage_options'))echo '<p><a href="'.esc_url(admin_url('edit.php?page=twt-blog-studio')).'">Open the existing four-language JSON editor</a> · <a href="'.esc_url(admin_url('edit.php')).'">All blog posts</a></p>';
 ?>
 <style>
 body:not(.matvip-admin-page):has(.atp-editorial){background:#f4f7fb}.atp-editorial{max-width:1340px;margin:32px auto!important;padding:0 20px;font-family:system-ui,-apple-system,sans-serif;color:#17253b}.atp-editorial h1{font-size:29px}.atp-panel{background:white;border:1px solid #dce4ee;border-radius:14px;padding:24px;margin:20px 0;box-shadow:0 7px 25px #101d3510}.atp-toolbar{display:flex;gap:12px;margin:12px 0}.atp-toolbar input{flex:1;min-width:0;padding:12px;border:1px solid #bbc6d3;border-radius:8px;font-size:15px}.atp-toolbar button,.atp-editorial button{cursor:pointer;padding:10px 15px;border-radius:7px}.atp-track{height:12px;border-radius:12px;background:#e5eaf1;overflow:hidden;margin:16px 0 6px}.atp-track>div{background:#187d65;width:0%;height:100%;transition:width .35s}#atp-steps{line-height:2.1;padding-left:24px}#atp-steps li.done{color:#168250;font-weight:600}#atp-steps li.live{color:#bd6d10;font-weight:600}#atp-steps li.fail{color:#ad2626;font-weight:600}#atp-result a{font-weight:bold}#atp-status{margin:12px 0}body:has(.atp-editorial) .button-primary{background:#132946;color:#fff;border:0}@media(max-width:640px){.atp-toolbar{flex-direction:column}}
 .atp-editorial .atp-saved-posts{margin-top:20px}.atp-saved-head{display:flex;justify-content:space-between;align-items:center;gap:12px}.atp-saved-head h2{margin:0}.atp-saved-head p{color:#778390;margin:5px 0 15px}.atp-saved-row{display:flex;gap:15px;align-items:center;border-top:1px solid #e7ebef;padding:14px 0}.atp-saved-row>img{width:98px;height:72px;border-radius:10px;object-fit:cover}.atp-saved-row h3{font-size:15px;margin:5px 0}.atp-saved-row small{color:#798391}.atp-post-status{font-size:10px;font-weight:800;letter-spacing:.05em;color:#875f23;background:#fff3d7;padding:4px 8px;border-radius:40px}.atp-post-status.publish{color:#087956;background:#def7ec}.atp-saved-actions{display:flex;gap:20px;margin-top:8px;font-size:12px}.matvip-admin-page .atp-editorial{margin:0 auto!important;padding:0;width:100%;max-width:1250px}.matvip-admin-page .atp-panel{box-shadow:none;border-radius:18px}.matvip-admin-page .atp-editorial h1{font-size:28px}@media(min-width:1160px){.matvip-admin-page .atp-editorial .atp-saved-posts{width:100%}}
 </style>
 <?php wp_enqueue_script('atp-editorial',get_template_directory_uri().'/assets/js/editorial.js',[],wp_get_theme()->get('Version'),true);
 wp_localize_script('atp-editorial','AtpEditorial',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>$nonce,'active'=>is_wp_error($active)?null:atp_ai_job_result($active)]); ?>

 <?php
 echo '</div>';if($standalone)echo '</body></html>';
}
add_action('wp_head',function(){if(!is_singular('post'))return;echo '<style>.article-body-enhanced table,.twt-authored-content table,.entry-content table{width:100%;border-collapse:collapse;display:block;overflow-x:auto;margin:20px 0 25px;font-size:.94em}.article-body-enhanced th,.article-body-enhanced td,.twt-authored-content th,.twt-authored-content td,.entry-content th,.entry-content td{border:1px solid #dde4eb;padding:12px 14px;text-align:left;min-width:100px}.article-body-enhanced th,.twt-authored-content th,.entry-content th{background:#eff5f9;color:#16334b}.article-body-enhanced tr:nth-child(even),.twt-authored-content tr:nth-child(even),.entry-content tr:nth-child(even){background:#fafcfe}</style>';},80);
