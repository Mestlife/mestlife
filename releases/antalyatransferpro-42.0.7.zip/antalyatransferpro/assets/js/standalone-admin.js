/* Independent dashboard enhancements. The existing zone/price/fleet JS stays authoritative. */
(function($){
  'use strict';
  document.addEventListener('DOMContentLoaded',function(){
    const toggle=document.getElementById('matvip-mobile-menu'),sidebar=document.getElementById('matvip-sidebar');
    if(toggle&&sidebar){toggle.addEventListener('click',()=>sidebar.classList.toggle('open'));document.addEventListener('click',e=>{if(sidebar.classList.contains('open')&&!sidebar.contains(e.target)&&!toggle.contains(e.target))sidebar.classList.remove('open')});}
    document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{if(!window.confirm(el.dataset.confirm||'Confirm?'))e.preventDefault()}));
    const blogTabs=document.querySelectorAll('.matvip-blog-tab');
    function activate(lang){
      blogTabs.forEach(btn=>{const active=btn.dataset.lang===lang;btn.classList.toggle('active',active);btn.setAttribute('aria-selected',active?'true':'false')});
      document.querySelectorAll('.matvip-blog-lang').forEach(box=>box.classList.toggle('active',box.dataset.lang===lang));
    }
    blogTabs.forEach(btn=>btn.addEventListener('click',()=>activate(btn.dataset.lang)));
    const form=document.getElementById('matvip-blog-form');
    if(form)form.addEventListener('submit',function(e){
      // Validate every translation before submitting; reveal the tab with a missing field.
      for(const box of document.querySelectorAll('.matvip-blog-lang')){
        const required=box.querySelectorAll('[data-required="1"]');
        for(const field of required){
          if(field.value.trim()===''){
            activate(box.dataset.lang);field.focus();field.setCustomValidity('Please complete all four languages.');field.reportValidity();field.addEventListener('input',()=>field.setCustomValidity(''),{once:true});e.preventDefault();return;
          }
        }
      }
    });
    const choose=document.getElementById('matvip-blog-image-pick'),clear=document.getElementById('matvip-blog-image-clear'),input=document.getElementById('matvip-blog-image-id'),preview=document.getElementById('matvip-blog-image-preview');
    if(choose)choose.addEventListener('click',function(){
      if(!window.wp||!wp.media){window.alert('Media library is not available for this user.');return;}
      const frame=wp.media({title:'Choose featured image',button:{text:'Use selected image'},library:{type:'image'},multiple:false});
      frame.on('select',function(){const img=frame.state().get('selection').first().toJSON();input.value=img.id;const src=(img.sizes&&img.sizes.medium?img.sizes.medium.url:img.url);const image=document.createElement('img');image.src=src;image.alt='Selected';preview.replaceChildren(image);});frame.open();
    });
    if(clear)clear.addEventListener('click',()=>{input.value='';preview.innerHTML='<div class="matvip-upload-placeholder">No image selected</div>'});
  });
})(jQuery);
/* Translated operating controls for the reused WP-native map and pricing modules.
   Content/user-generated names and descriptions are deliberately not machine-translated. */
(function($){
  const current=(new URLSearchParams(location.search).get('lang') || (document.documentElement.getAttribute('lang')||'tr')).toLowerCase();
  if(!['en','de','ru'].includes(current)) return;
  const i18n={
    en:{'Bölgeler & Polygon':'Regions & Boundaries','Yeni / Düzenle':'Add / Edit','Ülke':'Country','Şehir':'City','Bölge':'Region','Sınırı Bul':'Find Boundary','Otomatik Çiz':'Auto Draw','Temizle':'Clear','Koordinatları Çiz':'Draw Coordinates','Haritadaki Polygonu Koordinata Aktar':'Copy Map Coordinates','Bölgeyi Kaydet':'Save Region','Kayıtlı Bölgeler':'Saved Regions','Otel Tara':'Scan Hotels','Düzenle':'Edit','Kaydet':'Save','Havalimanları':'Airports','Havalimanı':'Airport','Kayıtlı Havalimanları':'Saved Airports','Havalimanını Kaydet':'Save Airport','OSM’de Bul':'Find on OSM','Fiyat Matrisi':'Price Matrix','Havalimanı + şehir seçildiğinde bölgeler satır, araçlar sütun olarak açılır. Baz fiyat EUR; para birimi ön yüzde otomatik çevrilir.':'Select an airport and city to display regional prices by vehicle. Base currency: EUR.','Extralar':'Extras','Araç Filosu':'Vehicle Fleet','Araç sınıfı':'Vehicle Class','Yeni Araç':'New Vehicle','Aracı Düzenle':'Edit Vehicle','Servis tipi':'Service Type','Fiyatlandırma':'Pricing','Araç tipi':'Vehicle Type','Araç görseli':'Vehicle Image','Toplam yolcu':'Passengers','Bagaj':'Luggage','Yetişkin kapasitesi':'Adult Capacity','Çocuk kapasitesi':'Child Capacity','Listeleme önceliği':'Listing Priority','Sıra':'Sort Order','Özellikler':'Features','Maks. bekleme (dk)':'Max Wait (min)','Maks. durak':'Max Stops','Kişi başı bagaj':'Luggage per Person','Kapalı tarihler':'Unavailable Dates','Kapalı saat aralıkları (YYYY-MM-DD HH:MM-HH:MM)':'Unavailable Time Slots','Değişiklikleri Kaydet':'Save Changes','Araç Ekle':'Add Vehicle','Filo':'Fleet','Henüz araç eklenmedi.':'No vehicles yet.','Medya Kütüphanesinden Seç':'Choose Image','Kaldır':'Remove','Ülkeler & Şehirler':'Countries & Cities','Ülke Ekle':'Add Country','Şehir Ekle':'Add City','Ülke adı':'Country Name','ISO kodu':'ISO Code','Ülkeyi Kaydet':'Save Country','Şehri Kaydet':'Save City','Çeviri Merkezi':'Translation Centre','Çevirileri Kaydet':'Save Translations','Ekstra Ekle':'Add Extra','Extra Ekle':'Add Extra','Extra adı':'Extra Name','Fiyat tipi':'Price Type','Adet başı':'Per Item','Rezervasyon başı':'Per Booking','Maks. adet':'Max Quantity','Otel Veritabanı':'Hotel Database','Uçuş':'Flight','Aktif':'Active','Pasif':'Inactive','Tek Yön':'One-way','Gidiş-Dönüş':'Round-trip','Bölge İçerikleri':'Region Content','Tüm Fiyatları Kaydet':'Save All Prices'},
    de:{'Bölgeler & Polygon':'Regionen & Grenzen','Yeni / Düzenle':'Hinzufügen / Bearbeiten','Ülke':'Land','Şehir':'Stadt','Bölge':'Region','Sınırı Bul':'Grenze suchen','Otomatik Çiz':'Automatisch zeichnen','Temizle':'Löschen','Koordinatları Çiz':'Koordinaten zeichnen','Haritadaki Polygonu Koordinata Aktar':'Kartenkoordinaten übernehmen','Bölgeyi Kaydet':'Region speichern','Kayıtlı Bölgeler':'Gespeicherte Regionen','Otel Tara':'Hotels suchen','Düzenle':'Bearbeiten','Kaydet':'Speichern','Havalimanları':'Flughäfen','Havalimanı':'Flughafen','Kayıtlı Havalimanları':'Gespeicherte Flughäfen','Havalimanını Kaydet':'Flughafen speichern','OSM’de Bul':'Auf OSM suchen','Fiyat Matrisi':'Preismatrix','Extralar':'Extras','Araç Filosu':'Fuhrpark','Araç sınıfı':'Fahrzeugklasse','Yeni Araç':'Neues Fahrzeug','Aracı Düzenle':'Fahrzeug bearbeiten','Servis tipi':'Serviceart','Fiyatlandırma':'Preisberechnung','Araç tipi':'Fahrzeugtyp','Araç görseli':'Fahrzeugbild','Toplam yolcu':'Fahrgäste','Bagaj':'Gepäck','Yetişkin kapasitesi':'Kapazität Erwachsene','Çocuk kapasitesi':'Kapazität Kinder','Listeleme önceliği':'Anzeigereihenfolge','Sıra':'Sortierung','Özellikler':'Ausstattung','Maks. bekleme (dk)':'Max. Wartezeit (Min.)','Maks. durak':'Max. Haltestellen','Kişi başı bagaj':'Gepäck pro Person','Kapalı tarihler':'Nicht verfügbare Tage','Kapalı saat aralıkları (YYYY-MM-DD HH:MM-HH:MM)':'Nicht verfügbare Uhrzeiten','Değişiklikleri Kaydet':'Änderungen speichern','Araç Ekle':'Fahrzeug hinzufügen','Filo':'Fuhrpark','Henüz araç eklenmedi.':'Noch keine Fahrzeuge.','Medya Kütüphanesinden Seç':'Bild auswählen','Kaldır':'Entfernen','Ülkeler & Şehirler':'Länder & Städte','Ülke Ekle':'Land hinzufügen','Şehir Ekle':'Stadt hinzufügen','Ülke adı':'Landesname','ISO kodu':'ISO-Code','Ülkeyi Kaydet':'Land speichern','Şehri Kaydet':'Stadt speichern','Çeviri Merkezi':'Übersetzungszentrum','Çevirileri Kaydet':'Übersetzungen speichern','Extra Ekle':'Extra hinzufügen','Extra adı':'Name der Zusatzleistung','Fiyat tipi':'Preismodell','Adet başı':'Pro Stück','Rezervasyon başı':'Pro Buchung','Maks. adet':'Max. Anzahl','Otel Veritabanı':'Hoteldatenbank','Aktif':'Aktiv','Pasif':'Inaktiv','Tek Yön':'Einfach','Gidiş-Dönüş':'Hin und zurück','Tüm Fiyatları Kaydet':'Alle Preise speichern'},
    ru:{'Bölgeler & Polygon':'Регионы и границы','Yeni / Düzenle':'Добавить / изменить','Ülke':'Страна','Şehir':'Город','Bölge':'Регион','Sınırı Bul':'Найти границу','Otomatik Çiz':'Автопостроение','Temizle':'Очистить','Koordinatları Çiz':'Построить по координатам','Haritadaki Polygonu Koordinata Aktar':'Скопировать координаты карты','Bölgeyi Kaydet':'Сохранить регион','Kayıtlı Bölgeler':'Сохранённые регионы','Otel Tara':'Найти отели','Düzenle':'Изменить','Kaydet':'Сохранить','Havalimanları':'Аэропорты','Havalimanı':'Аэропорт','Kayıtlı Havalimanları':'Сохранённые аэропорты','Havalimanını Kaydet':'Сохранить аэропорт','OSM’de Bul':'Найти в OSM','Fiyat Matrisi':'Таблица тарифов','Extralar':'Дополнительные услуги','Araç Filosu':'Автопарк','Araç sınıfı':'Класс автомобиля','Yeni Araç':'Новый автомобиль','Aracı Düzenle':'Изменить автомобиль','Servis tipi':'Тип услуги','Fiyatlandırma':'Тарификация','Araç tipi':'Тип автомобиля','Araç görseli':'Фото автомобиля','Toplam yolcu':'Пассажиры','Bagaj':'Багаж','Yetişkin kapasitesi':'Взрослых','Çocuk kapasitesi':'Детей','Listeleme önceliği':'Приоритет показа','Sıra':'Порядок','Özellikler':'Особенности','Maks. bekleme (dk)':'Макс. ожидание (мин)','Maks. durak':'Макс. остановок','Kişi başı bagaj':'Багаж на человека','Kapalı tarihler':'Недоступные даты','Kapalı saat aralıkları (YYYY-MM-DD HH:MM-HH:MM)':'Недоступное время','Değişiklikleri Kaydet':'Сохранить изменения','Araç Ekle':'Добавить авто','Filo':'Автопарк','Henüz araç eklenmedi.':'Автомобилей пока нет.','Medya Kütüphanesinden Seç':'Выбрать фото','Kaldır':'Удалить','Ülkeler & Şehirler':'Страны и города','Ülke Ekle':'Добавить страну','Şehir Ekle':'Добавить город','Ülke adı':'Название страны','ISO kodu':'Код ISO','Ülkeyi Kaydet':'Сохранить страну','Şehri Kaydet':'Сохранить город','Çeviri Merkezi':'Центр переводов','Çevirileri Kaydet':'Сохранить переводы','Extra Ekle':'Добавить услугу','Extra adı':'Название услуги','Fiyat tipi':'Тип цены','Adet başı':'За единицу','Rezervasyon başı':'За бронирование','Maks. adet':'Макс. количество','Otel Veritabanı':'Каталог отелей','Aktif':'Активно','Pasif':'Неактивно','Tek Yön':'В одну сторону','Gidiş-Dönüş':'Туда и обратно','Tüm Fiyatları Kaydet':'Сохранить все цены'}
  }[current];
  const translate=function(){
    document.querySelectorAll('.deniz-os h1,.deniz-os h2,.deniz-os h3,.deniz-os label,.deniz-os th,.deniz-os button,.deniz-os option,.deniz-os .dos-head p').forEach(el=>{
      for(const n of Array.from(el.childNodes)){
        if(n.nodeType!==3)continue;
        const original=(n.textContent||'').trim();
        if(!original||!i18n[original])continue;
        n.textContent=n.textContent.replace(original,i18n[original]);
      }
    });
  };
  $(translate);$(document).ajaxComplete(()=>window.setTimeout(translate,0));
})(jQuery);
